/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef WSTRING_H
#define WSTRING_H

#ifdef __cplusplus

#include <stddef.h>
#include <stdint.h>
#include <string.h>

class __FlashStringHelper;

/**
 * @brief Arduino String: a heap-allocated, growable text buffer.
 *
 * Follows the Arduino String API. When the heap runs out, the String becomes
 * invalid: c_str() returns "", length() is 0, and `if (s)` is false.
 */
class String
{
  public:
    String(const char *cstr = "");
    String(const char *cstr, unsigned int length);
    String(const String &other);
    String(String &&other) noexcept;
    String(const __FlashStringHelper *str);
    explicit String(char c);
    explicit String(unsigned char value, unsigned char base = 10);
    explicit String(int value, unsigned char base = 10);
    explicit String(unsigned int value, unsigned char base = 10);
    explicit String(long value, unsigned char base = 10);
    explicit String(unsigned long value, unsigned char base = 10);
    explicit String(long long value, unsigned char base = 10);
    explicit String(unsigned long long value, unsigned char base = 10);
    explicit String(float value, unsigned char decimalPlaces = 2);
    explicit String(double value, unsigned char decimalPlaces = 2);
    ~String();

    String &operator=(const String &rhs);
    String &operator=(String &&rhs) noexcept;
    String &operator=(const char *cstr);
    String &operator=(const __FlashStringHelper *str);

    /** @brief Make room for size characters; false if the heap is full. */
    bool reserve(unsigned int size);
    unsigned int length() const
    {
        return len;
    }
    bool isEmpty() const
    {
        return len == 0;
    }
    explicit operator bool() const
    {
        return buffer != nullptr;
    }

    /* append; false if the heap is full */
    bool concat(const String &str);
    bool concat(const char *cstr);
    bool concat(const char *cstr, unsigned int length);
    bool concat(const uint8_t *data, unsigned int length)
    {
        return concat((const char *)data, length);
    }
    bool concat(const __FlashStringHelper *str);
    bool concat(char c);
    bool concat(unsigned char value);
    bool concat(int value);
    bool concat(unsigned int value);
    bool concat(long value);
    bool concat(unsigned long value);
    bool concat(long long value);
    bool concat(unsigned long long value);
    bool concat(float value);
    bool concat(double value);

    template <typename T> String &operator+=(const T &rhs)
    {
        concat(rhs);
        return *this;
    }

    /* comparison */
    int compareTo(const String &s) const;
    int compareTo(const char *cstr) const;
    bool equals(const String &s) const;
    bool equals(const char *cstr) const;
    bool equalsIgnoreCase(const String &s) const;
    bool startsWith(const String &prefix) const;
    bool startsWith(const String &prefix, unsigned int offset) const;
    bool endsWith(const String &suffix) const;

    bool operator==(const String &rhs) const
    {
        return equals(rhs);
    }
    bool operator==(const char *cstr) const
    {
        return equals(cstr);
    }
    bool operator!=(const String &rhs) const
    {
        return !equals(rhs);
    }
    bool operator!=(const char *cstr) const
    {
        return !equals(cstr);
    }
    bool operator<(const String &rhs) const
    {
        return compareTo(rhs) < 0;
    }
    bool operator>(const String &rhs) const
    {
        return compareTo(rhs) > 0;
    }
    bool operator<=(const String &rhs) const
    {
        return compareTo(rhs) <= 0;
    }
    bool operator>=(const String &rhs) const
    {
        return compareTo(rhs) >= 0;
    }

    /* characters */
    char charAt(unsigned int index) const;
    void setCharAt(unsigned int index, char c);
    char operator[](unsigned int index) const;
    char &operator[](unsigned int index);
    void getBytes(unsigned char *buf, unsigned int bufsize, unsigned int index = 0) const;
    void toCharArray(char *buf, unsigned int bufsize, unsigned int index = 0) const
    {
        getBytes((unsigned char *)buf, bufsize, index);
    }
    const char *c_str() const
    {
        return buffer ? buffer : "";
    }
    char *begin()
    {
        return buffer;
    }
    char *end()
    {
        return buffer ? buffer + len : nullptr;
    }
    const char *begin() const
    {
        return c_str();
    }
    const char *end() const
    {
        return c_str() + len;
    }

    /* search: index, or -1 if not found */
    int indexOf(char ch) const;
    int indexOf(char ch, unsigned int fromIndex) const;
    int indexOf(const String &str) const;
    int indexOf(const String &str, unsigned int fromIndex) const;
    int lastIndexOf(char ch) const;
    int lastIndexOf(char ch, unsigned int fromIndex) const;
    int lastIndexOf(const String &str) const;
    int lastIndexOf(const String &str, unsigned int fromIndex) const;
    String substring(unsigned int beginIndex) const
    {
        return substring(beginIndex, len);
    }
    String substring(unsigned int beginIndex, unsigned int endIndex) const;

    /* modification */
    void replace(char find, char replaceWith);
    void replace(const String &find, const String &replaceWith);
    void remove(unsigned int index);
    void remove(unsigned int index, unsigned int count);
    void toLowerCase();
    void toUpperCase();
    void trim();

    /* parsing (0 when the text is not a number) */
    long toInt() const;
    float toFloat() const;
    double toDouble() const;

  private:
    char *buffer     = nullptr; /* NUL-terminated, or nullptr when invalid */
    unsigned int cap = 0;       /* characters that fit, without the NUL */
    unsigned int len = 0;

    void invalidate();
    bool grow(unsigned int size);
    String &copy(const char *cstr, unsigned int length);
    template <typename T> bool concatPrinted(T value, int arg);
};

/* a + b, for any right-hand side that concat() accepts */
template <typename T> String operator+(const String &lhs, const T &rhs)
{
    String r(lhs);
    r.concat(rhs);
    return r;
}
template <typename T> String operator+(String &&lhs, const T &rhs)
{
    String r(static_cast<String &&>(lhs));
    r.concat(rhs);
    return r;
}
inline String operator+(const char *lhs, const String &rhs)
{
    String r(lhs);
    r.concat(rhs);
    return r;
}
inline String operator+(char lhs, const String &rhs)
{
    String r(lhs);
    r.concat(rhs);
    return r;
}
inline bool operator==(const char *lhs, const String &rhs)
{
    return rhs.equals(lhs);
}
inline bool operator!=(const char *lhs, const String &rhs)
{
    return !rhs.equals(lhs);
}

#endif /* __cplusplus */
#endif /* WSTRING_H */
