/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"

/*
 * ER8130 EVK: called by the core before setup(). The LEDs light on HIGH;
 * their pins are inputs with the pull-down until a sketch sets them with
 * pinMode(), so an LED the sketch does not use stays dark (left as it was,
 * it glowed dimly; with the pull-up it glows too).
 */
void initVariant(void)
{
    pinMode(LED_BUILTIN, INPUT_PULLDOWN);
    pinMode(LED_BUILTIN_2, INPUT_PULLDOWN);
}
