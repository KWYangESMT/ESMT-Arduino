/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef ESMT_LOW_POWER_H
#define ESMT_LOW_POWER_H

#include <Arduino.h>

/**
 * @brief Low-power modes of the ER813x with the ArduinoLowPower API.
 *
 * - idle(): the CPU stops, peripherals keep running; any interrupt (Serial
 *   RX, a pin interrupt, ...) or the wake-up timer resumes it.
 * - sleep(): system sleep (wise_sys_enter_sleep_mode()): CPU, peripherals,
 *   analog and radio are powered down, RAM is kept. The wake-up timer or a
 *   pin from attachInterruptWakeup() wakes it; execution continues after the
 *   call. Serial ports are set up again by the core; other peripherals
 *   (SPI, Wire, analogWrite) may need begin() / a new write after the wake.
 * - deepSleep(): shutdown (wise_sys_enter_shutdown_mode()): almost everything
 *   is off and RAM is lost; the wake-up timer or the wake pin restarts the
 *   chip, so the sketch starts again from setup(). Does not return.
 *
 * With a time, the call returns (or the chip restarts) after that many
 * milliseconds at the latest; idle() and sleep() return earlier when another
 * interrupt wakes the CPU. Without a time, only an interrupt (or for
 * deepSleep() the wake pin) ends it.
 *
 * The watchdog is paused while asleep and Serial output is sent before the
 * chip sleeps. The upload escape cannot wake a sleeping chip: keep timed
 * sleeps short while developing, or press reset to upload.
 */
class ESMTLowPowerClass
{
  public:
    void idle();
    void idle(uint32_t ms);
    void idle(int ms)
    {
        idle((uint32_t)ms);
    }

    void sleep();
    void sleep(uint32_t ms);
    void sleep(int ms)
    {
        sleep((uint32_t)ms);
    }

    [[noreturn]] void deepSleep();
    [[noreturn]] void deepSleep(uint32_t ms);
    [[noreturn]] void deepSleep(int ms)
    {
        deepSleep((uint32_t)ms);
    }

    /**
     * @brief Wake from idle() / sleep() on a pin interrupt (attachInterrupt()
     * modes; the SDK demo wakes from sleep with a level, LOW or HIGH). The pin
     * is also the deepSleep() wake pin, which restarts the chip when it goes
     * HIGH.
     */
    void attachInterruptWakeup(uint32_t pin, voidFuncPtr callback, uint32_t mode);

  private:
    uint8_t wakePin = 0xFF; /* none */

    void powerDown(uint32_t ms, bool system);
    [[noreturn]] void shutdown(uint32_t ms);
};

extern ESMTLowPowerClass LowPower;

#endif /* ESMT_LOW_POWER_H */
