// Sends "hello <n>" once a second. Run RadioReceiver on a second board.
//
// Set FREQUENCY to a band you may use where you are (for example 868 MHz in
// Europe, 915 MHz in the US, 920 MHz in Taiwan / Japan), the same on both boards.

#include <ESMTRadio.h>

const long FREQUENCY = 915000000; // Hz

unsigned long counter;

void setup()
{
    Serial.begin(115200);
    if (!Radio.begin(FREQUENCY)) {
        Serial.println("Radio.begin failed");
        while (true) {
            delay(1000);
        }
    }
    Serial.println("RadioSender");
}

void loop()
{
    Radio.beginPacket();
    Radio.print("hello ");
    Radio.print(counter);
    if (Radio.endPacket()) {
        Serial.print("sent ");
        Serial.println(counter);
    } else {
        Serial.println("send failed");
    }
    counter++;
    delay(1000);
}
