/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"

long map(long x, long in_min, long in_max, long out_min, long out_max)
{
    if (in_max == in_min) {
        return out_min;
    }

    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void randomSeed(unsigned long seed)
{
    if (seed != 0) {
        srand((unsigned)seed);
    }
}

long random(long howbig)
{
    if (howbig <= 0) {
        return 0;
    }

    return (long)((unsigned long)rand() % (unsigned long)howbig);
}

long random(long howsmall, long howbig)
{
    if (howsmall >= howbig) {
        return howsmall;
    }

    return random(howbig - howsmall) + howsmall;
}
