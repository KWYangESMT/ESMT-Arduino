/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/* AVR libc number-to-string functions (avr/dtostrf.h). nano.specs has no
 * float printf, so dtostrf() formats the digits itself. */

#include <math.h>
#include <string.h>

#include "avr/dtostrf.h"

static char *_reverse(char *buf, char *end)
{
    char *s = buf;

    *end = '\0';
    for (end--; s < end; s++, end--) {
        char c = *s;
        *s     = *end;
        *end   = c;
    }
    return buf;
}

char *ultoa(unsigned long val, char *buf, int radix)
{
    char *p = buf;

    if (radix < 2 || radix > 36) {
        *buf = '\0';
        return buf;
    }
    do {
        unsigned long d = val % (unsigned long)radix;
        *p++            = (char)(d < 10 ? '0' + d : 'a' + d - 10);
        val /= (unsigned long)radix;
    } while (val != 0);
    return _reverse(buf, p);
}

char *ltoa(long val, char *buf, int radix)
{
    if (val < 0 && radix == 10) {
        buf[0] = '-';
        ultoa(0UL - (unsigned long)val, buf + 1, radix);
        return buf;
    }
    return ultoa((unsigned long)val, buf, radix);
}

char *dtostrf(double val, signed char width, unsigned char prec, char *buf)
{
    char tmp[48];
    char *p = tmp;
    int len, pad, w = width < 0 ? -width : width;

    if (prec > 15) {
        prec = 15;
    }

    if (isnan(val)) {
        strcpy(tmp, "nan");
    } else if (isinf(val)) {
        strcpy(tmp, val < 0 ? "-inf" : "inf");
    } else {
        double rounding = 0.5;
        double ip;

        if (signbit(val)) {
            *p++ = '-';
            val  = -val;
        }
        for (unsigned char i = 0; i < prec; i++) {
            rounding /= 10.0;
        }
        val += rounding;

        if (val >= 4294967296.0) {
            strcpy(p, "ovf"); /* as Print::print(double) */
        } else {
            ip = floor(val);
            ultoa((unsigned long)ip, p, 10);
            p += strlen(p);
            if (prec > 0) {
                double frac = val - ip;

                *p++ = '.';
                for (unsigned char i = 0; i < prec; i++) {
                    int d;

                    frac *= 10.0;
                    d = (int)frac;
                    *p++ = (char)('0' + d);
                    frac -= d;
                }
            }
            *p = '\0';
        }
    }

    len = (int)strlen(tmp);
    pad = w > len ? w - len : 0;
    if (width < 0) {
        memcpy(buf, tmp, (size_t)len);
        memset(buf + len, ' ', (size_t)pad);
    } else {
        memset(buf, ' ', (size_t)pad);
        memcpy(buf + pad, tmp, (size_t)len);
    }
    buf[len + pad] = '\0';
    return buf;
}
