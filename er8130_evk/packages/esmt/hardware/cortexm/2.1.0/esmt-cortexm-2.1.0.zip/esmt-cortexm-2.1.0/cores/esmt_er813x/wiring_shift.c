/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"

/* Bit-banged serial shift, one bit per clock pulse (clock idle LOW). */

uint8_t shiftIn(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder)
{
    uint8_t value = 0;

    for (uint8_t i = 0; i < 8; i++) {
        digitalWrite(clockPin, HIGH);
        if (bitOrder == LSBFIRST) {
            value |= (uint8_t)(digitalRead(dataPin) << i);
        } else {
            value |= (uint8_t)(digitalRead(dataPin) << (7 - i));
        }
        digitalWrite(clockPin, LOW);
    }
    return value;
}

void shiftOut(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder, uint8_t val)
{
    for (uint8_t i = 0; i < 8; i++) {
        uint8_t bitValue = (bitOrder == LSBFIRST) ? ((val >> i) & 1U) : ((val >> (7 - i)) & 1U);
        digitalWrite(dataPin, bitValue ? HIGH : LOW);
        digitalWrite(clockPin, HIGH);
        digitalWrite(clockPin, LOW);
    }
}
