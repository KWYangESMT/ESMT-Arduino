// ButtonWakeup: sleep until the button pulls PIN_BUTTON low, then count.
//
// The SDK's power demo wakes from sleep on a level, so the wake-up interrupt
// is LOW; the handler only sets a flag (it keeps firing while the pin is low,
// so it detaches itself).

#include <ESMTLowPower.h>

volatile bool pressed;
unsigned long wakes;

void onButton()
{
    detachInterrupt(PIN_BUTTON);
    pressed = true;
}

void setup()
{
    Serial.begin(115200);
    pinMode(PIN_BUTTON, INPUT_PULLUP);
    Serial.println(F("Press the button to wake me"));
}

void loop()
{
    pressed = false;
    LowPower.attachInterruptWakeup(PIN_BUTTON, onButton, LOW);
    LowPower.sleep(); // until the button

    if (pressed) {
        wakes++;
        Serial.print(F("woken by the button, "));
        Serial.print(wakes);
        Serial.println(F(" times"));
        while (digitalRead(PIN_BUTTON) == LOW) {
            delay(10); // wait for the release
        }
    }
}
