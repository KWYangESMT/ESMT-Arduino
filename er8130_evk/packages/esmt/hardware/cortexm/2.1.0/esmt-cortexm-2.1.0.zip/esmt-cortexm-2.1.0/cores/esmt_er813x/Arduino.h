/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/**
 * @file Arduino.h
 * @brief Arduino core API for the ESMT ER813x (subg_soc_9006).
 */

#ifndef ARDUINO_H
#define ARDUINO_H

#include <math.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "avr/dtostrf.h"
#include "avr/pgmspace.h"
#include "pins_arduino.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------------- */
/*                              Arduino constants                            */
/* ------------------------------------------------------------------------- */
#define LOW 0x0
#define HIGH 0x1

#define INPUT 0x0
#define OUTPUT 0x1
#define INPUT_PULLUP 0x2
#define INPUT_PULLDOWN 0x3

/* attachInterrupt() modes (LOW / HIGH above are the level modes) */
#define CHANGE 0x2
#define FALLING 0x3
#define RISING 0x4

/* shiftIn() / shiftOut() / SPI bit order. An enum named BitOrder, as in the
 * other ARM cores (ArduinoCore-API, SAMD): libraries such as Adafruit_BusIO
 * use the type. The values convert to the uint8_t parameters used here. */
typedef enum {
    LSBFIRST = 0,
    MSBFIRST = 1
} BitOrder;

/* analogReference() */
#define AR_DEFAULT 0x0     /**< 2.4 V */
#define AR_INTERNAL2V4 0x0 /**< 2.4 V */
#define AR_INTERNAL1V6 0x1 /**< 1.6 V */

#define PI 3.1415926535897932384626433832795
#define HALF_PI 1.5707963267948966192313216916398
#define TWO_PI 6.283185307179586476925286766559
#define DEG_TO_RAD 0.017453292519943295769236907684886
#define RAD_TO_DEG 57.295779513082320876798154814105

typedef bool boolean;
typedef uint8_t byte;
typedef uint16_t word;
typedef void (*voidFuncPtr)(void);

/* ------------------------------------------------------------------------- */
/*                                 Bits and bytes                            */
/* ------------------------------------------------------------------------- */
#define lowByte(w) ((uint8_t)((w) & 0xff))
#define highByte(w) ((uint8_t)((w) >> 8))
#define bit(b) (1UL << (b))
#define bitRead(value, b) (((value) >> (b)) & 0x01)
#define bitSet(value, b) ((value) |= (1UL << (b)))
#define bitClear(value, b) ((value) &= ~(1UL << (b)))
#define bitToggle(value, b) ((value) ^= (1UL << (b)))
#define bitWrite(value, b, v) ((v) ? bitSet(value, b) : bitClear(value, b))

#define radians(deg) ((deg) * DEG_TO_RAD)
#define degrees(rad) ((rad) * RAD_TO_DEG)
#define sq(x) ((x) * (x))
#define constrain(amt, low, high) ((amt) < (low) ? (low) : ((amt) > (high) ? (high) : (amt)))

#ifndef __cplusplus
#define min(a, b) ((a) < (b) ? (a) : (b))
#define max(a, b) ((a) > (b) ? (a) : (b))
#endif

/* ------------------------------------------------------------------------- */
/*                                 Digital I/O                               */
/* ------------------------------------------------------------------------- */
void pinMode(uint8_t pin, uint8_t mode);
/**
 * @brief Release a pin from the system function it has at reset (GPIO10: TCXO,
 * GPIO14/15: SWD) so the pin mux can use it. pinMode(), analogWrite(),
 * attachInterrupt(), Serial, SPI and Wire call it; other code that sets a pin
 * function with wise_gpio_func_cfg() should call it first. SWD stays off
 * until the next reset.
 */
void esmtPinClaim(uint8_t pin);
void digitalWrite(uint8_t pin, uint8_t val);
int digitalRead(uint8_t pin);

/* ------------------------------------------------------------------------- */
/*                                  Analog I/O                               */
/* ------------------------------------------------------------------------- */
/** @brief Read A0 (external input), A1 (battery) or A2 (temperature sensor). */
int analogRead(uint8_t pin);
void analogReference(uint8_t mode);
void analogReadResolution(int bits);
/** @brief PWM on any GPIO (up to 6 pins at once); 0 and full scale drive the pin LOW / HIGH. */
void analogWrite(uint8_t pin, int value);
void analogWriteResolution(int bits);
void analogWriteFrequency(uint32_t hz);

/* ------------------------------------------------------------------------- */
/*                                Advanced I/O                               */
/* ------------------------------------------------------------------------- */
/** @brief Pulse length in microseconds, 0 on timeout (C++ default timeout: 1 s). */
unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout);
unsigned long pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout);
uint8_t shiftIn(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder);
void shiftOut(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder, uint8_t val);

/* ------------------------------------------------------------------------- */
/*                                  Interrupts                               */
/* ------------------------------------------------------------------------- */
#define digitalPinToInterrupt(p) ((p) < NUM_DIGITAL_PINS ? (p) : -1)
void attachInterrupt(uint8_t interruptNum, voidFuncPtr callback, int mode);
void detachInterrupt(uint8_t interruptNum);

static inline void interrupts(void)
{
    __asm volatile("cpsie i" ::: "memory");
}
static inline void noInterrupts(void)
{
    __asm volatile("cpsid i" ::: "memory");
}

/* ------------------------------------------------------------------------- */
/*                                    Time                                   */
/* ------------------------------------------------------------------------- */
unsigned long millis(void);
unsigned long micros(void);
void delay(unsigned long ms);
void delayMicroseconds(unsigned int us);

/* ------------------------------------------------------------------------- */
/*                              Sketch / core hooks                          */
/* ------------------------------------------------------------------------- */
void setup(void);
void loop(void);

/** @brief Called while the core waits (delay(), Stream timeouts); may be overridden by the sketch. */
void yield(void);

/** @brief Board-specific start-up, called after wise_init(); weak, variant may override. */
void initVariant(void);

/** @brief Run one pass of the core service: wise_core work, time base, watchdog feed. */
void esmt_core_service(void);

/**
 * @brief Run fn on every pass of the core service (between loop() passes and
 * while the core waits in delay() or a Stream timeout). For libraries that
 * need periodic work outside interrupts; up to 4, adding one twice is a no-op.
 * @return false when all slots are taken.
 */
bool esmtAddService(void (*fn)(void));

/* ------------------------------------------------------------------------- */
/*                                  Watchdog                                 */
/* ------------------------------------------------------------------------- */
/*
 * The core starts the watchdog before setup() (Tools > Watchdog, default 2 s)
 * and feeds it on every loop() pass, in delay() and while Stream functions
 * wait. If the sketch stops returning for about twice the timeout (blocked
 * with interrupts off, endless loop without delay()), the chip resets and
 * the loader can take a new upload. Sketches that block on purpose can call
 * esmtWatchdogFeed() or esmtWatchdogDisable().
 */
/** @brief Start (or restart) the watchdog; timeout_ms = 0 stops it. */
void esmtWatchdogEnable(unsigned long timeout_ms);
/** @brief Stop the watchdog. Uploads then need the escape or a manual reset. */
void esmtWatchdogDisable(void);
/** @brief Restart the watchdog count. */
void esmtWatchdogFeed(void);

/* ------------------------------------------------------------------------- */
/*                                 Low power                                 */
/* ------------------------------------------------------------------------- */
/*
 * For low-power libraries (ESMTLowPower): call esmtLowPowerEnter() before a
 * wise_core sleep call and esmtLowPowerExit() after it. Enter flushes Serial
 * and pauses the watchdog; Exit sets the Serial ports up again when the sleep
 * powered the peripherals down, refreshes the time base and restarts the
 * watchdog with its previous timeout.
 */
void esmtLowPowerEnter(void);
void esmtLowPowerExit(bool peripheralsOff);

#ifdef __cplusplus
} // extern "C"
#endif

#ifdef __cplusplus
#include "WString.h"
#include "HardwareSerial.h"

/* C++-only helpers, as in the Arduino API */
template <class T, class L> auto min(const T &a, const L &b) -> decltype((b < a) ? b : a)
{
    return (b < a) ? b : a;
}
template <class T, class L> auto max(const T &a, const L &b) -> decltype((b < a) ? b : a)
{
    return (a < b) ? b : a;
}

unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout = 1000000UL);
unsigned long pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout = 1000000UL);

/** @brief 50 % square wave on any GPIO (one tone at a time, uses a PWM channel); duration 0 = until noTone(). */
void tone(uint8_t pin, unsigned int frequency, unsigned long duration = 0);
void noTone(uint8_t pin);

long map(long x, long in_min, long in_max, long out_min, long out_max);
long random(long howbig);
long random(long howsmall, long howbig);
void randomSeed(unsigned long seed);
#endif /* __cplusplus */

#endif /* ARDUINO_H */
