// I2C scanner: lists the 7-bit addresses that answer on SDA (GPIO11) / SCL (GPIO12).
// The bus needs pull-up resistors (for example 4.7 kOhm to 3.3 V).

#include <Wire.h>

void setup()
{
    Serial.begin(115200);
    Wire.begin();
    Wire.setClock(100000);
}

void loop()
{
    int found = 0;

    Serial.println("Scanning...");
    for (uint8_t address = 1; address < 127; address++) {
        Wire.beginTransmission(address);
        uint8_t error = Wire.endTransmission();
        if (error == 0) {
            Serial.printf("  device at 0x%02X\r\n", address);
            found++;
        } else if (error == 4) {
            Serial.printf("  bus error at 0x%02X\r\n", address);
        }
    }
    Serial.print(found);
    Serial.println(" device(s) found");
    delay(5000);
}
