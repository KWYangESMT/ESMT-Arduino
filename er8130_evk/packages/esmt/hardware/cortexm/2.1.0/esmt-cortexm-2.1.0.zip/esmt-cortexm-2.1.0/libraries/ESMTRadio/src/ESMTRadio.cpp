/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "ESMTRadio.h"

#include <string.h>

extern "C" {
#include "wise_core.h"
#include "wise_radio_api.h"
}

/*
 * The setup follows the WISE shell "rf" commands (middleware/wise_shell/
 * functions/func_rf.c) and demo_radio_trx: GFSK, variable-length packets
 * with a 1-byte length header that is part of the frame (frame[0] = payload
 * length, the driver sends frame[0..length]) and a CRC-16/CCITT done by the
 * hardware. Received frames are taken with wise_radio_get_rx_frame_info() +
 * wise_radio_release_rx_frame(), which also resumes an RX that paused on a
 * full queue.
 */

#define RADIO_INTF 0
#define RADIO_CH   0 /* a single channel: the frequency set by begin() */

/* Driver frame block: max length rounded to 16, 16 guard bytes, 16 bytes of
 * metadata. One block is the TX buffer, the rest hold received frames. */
#define FRAME_LEN    (ESMT_RADIO_MAX_PACKET + 1)
#define FRAME_BLOCK  (((FRAME_LEN + 15) & ~15) + 16 + 16)
#define RX_FRAMES    3
#define BUF_POOL_LEN (FRAME_BLOCK * (1 + RX_FRAMES))

static uint8_t bufPool[BUF_POOL_LEN] __attribute__((aligned(16)));

ESMTRadioClass Radio;

static bool rateToEnum(long bps, WISE_DATA_RATE_T *out)
{
    static const struct {
        long bps;
        WISE_DATA_RATE_T rate;
    } rates[] = {
        {12500, E_DATA_RATE_12P5K},   {50000, E_DATA_RATE_50K},   {100000, E_DATA_RATE_100K},
        {125000, E_DATA_RATE_125K},   {250000, E_DATA_RATE_250K}, {500000, E_DATA_RATE_500K},
        {1000000, E_DATA_RATE_1M},
    };
    for (size_t i = 0; i < sizeof(rates) / sizeof(rates[0]); i++) {
        if (rates[i].bps == bps) {
            *out = rates[i].rate;
            return true;
        }
    }
    return false;
}

/* Modulation index x100 as the driver rounds it (_hal_drv_radio_get_mod_idx). */
static bool deviationOk(long bps, long hz)
{
    long h = (2 * hz * 100 + bps / 2) / bps;
    if (h == 50) {
        return true;
    }
    if (h == 100) {
        return bps != 1000000;
    }
    return (h == 400) && (bps == 12500);
}

int ESMTRadioClass::configure()
{
    WISE_RADIO_CFG_T cfg;
    WISE_RADIO_PKT_FMT_T fmt;
    WISE_DATA_RATE_T rate = E_DATA_RATE_500K;

    rateToEnum(dataRate, &rate);

    memset(&cfg, 0, sizeof(cfg));
    cfg.modulation    = E_MOD_TYPE_GFSK;
    cfg.ch_freq_min   = (uint32_t)frequency;
    cfg.ch_freq_max   = (uint32_t)frequency;
    cfg.ch_spacing    = 0; /* one channel */
    cfg.deviation     = (uint32_t)deviation;
    cfg.data_rate     = rate;
    cfg.syncword      = syncWord;
    cfg.sync_word_len = 4;
    cfg.preamble      = 0xAA;
    cfg.preamble_len  = preambleLen;

    memset(&fmt, 0, sizeof(fmt));
    fmt.pkt_type       = PKT_VARIABLE_LENGTH;
    fmt.max_pkt_length = FRAME_LEN;
    fmt.frame_format   = FRAME_FMT_PREAMBLE_EN | FRAME_FMT_SYNCWORD_EN | FRAME_FMT_HEADER_EN;
    if (crc) {
        fmt.frame_format |= FRAME_FMT_CRC_EN;
    }
    fmt.phr.hdr_config        = PHR_LENGTH_INCLUDE_CRC;
    fmt.phr.hdr_bytes         = 1;
    fmt.phr.length_bit_size   = 8;
    fmt.phr.length_bit_offset = 0;
    fmt.crc.crc_config   = CRC_INPUT_BIT_ENDIAN_MSB_FIRST | CRC_OUTPUT_BIT_ENDIAN_MSB_FIRST | CRC_OUTPUT_BYTE_ENDIAN_MSB_FIRST;
    fmt.crc.crc_poly_sel = CRC_POLYNOMIAL_CCITT_16;
    fmt.crc.crc_seed     = 0;
    fmt.frame_codec      = E_FRAME_CODEC_NONE;

    bool wasListening = listening;
    if (wasListening) {
        wise_radio_rx_stop(RADIO_INTF);
    }
    if (wise_radio_config(RADIO_INTF, &cfg, &fmt) != WISE_SUCCESS) {
        return 0;
    }
    wise_radio_set_tx_pwr_dbm(RADIO_INTF, txPowerDbm);
    if (wasListening) {
        listen();
    }
    return 1;
}

int ESMTRadioClass::begin(long freq)
{
    static WISE_RADIO_BUFFER_T pool = {BUF_POOL_LEN, (uint32_t)bufPool};

    if (started) {
        end();
    }
    if (freq <= 0) {
        return 0;
    }
    frequency = freq;

    if (wise_radio_init(RADIO_INTF) != WISE_SUCCESS) {
        return 0;
    }
    wise_radio_set_evt_callback(RADIO_INTF, _event);
    wise_radio_set_buffer(RADIO_INTF, &pool);
    if (!configure()) {
        wise_radio_deinit(RADIO_INTF);
        return 0;
    }
    wise_radio_set_rx_mode(RADIO_INTF, RADIO_RX_CONTINUOUS);
    wise_radio_set_tx_state_transition(RADIO_INTF, TX_FINISH_TO_IDLE);
    wise_radio_clear_stats(RADIO_INTF);

    started  = true;
    txBusy   = false;
    txFinish = false;
    rxLen = rxPos = 0;
    txLen = 0;
    esmtAddService(_service);
    if (userReceive) {
        listen();
    }
    return 1;
}

void ESMTRadioClass::end()
{
    if (!started) {
        return;
    }
    idle();
    wise_radio_deinit(RADIO_INTF);
    started = false;
    txBusy  = false;
}

void ESMTRadioClass::listen()
{
    if (wise_radio_rx_start(RADIO_INTF, RADIO_CH) == WISE_SUCCESS) {
        listening = true;
    }
}

void ESMTRadioClass::receive()
{
    if (started) {
        listen();
    }
}

void ESMTRadioClass::idle()
{
    if (started && listening) {
        wise_radio_rx_stop(RADIO_INTF);
    }
    listening = false;
}

/* ---------------------------------------------------------------- send --- */

int ESMTRadioClass::beginPacket()
{
    if (!started || txBusy) {
        return 0;
    }
    txLen = 0;
    return 1;
}

size_t ESMTRadioClass::write(uint8_t byte)
{
    return write(&byte, 1);
}

size_t ESMTRadioClass::write(const uint8_t *buffer, size_t size)
{
    size_t room = ESMT_RADIO_MAX_PACKET - txLen;
    if (size > room) {
        size = room;
    }
    memcpy(&txBuf[1 + txLen], buffer, size);
    txLen += size;
    return size;
}

int ESMTRadioClass::endPacket(bool async)
{
    if (!started || txBusy || txLen == 0) {
        return 0;
    }
    txBuf[0] = (uint8_t)txLen;
    uint16_t frameLen = txLen + 1;
    txLen = 0;

    if (!async) {
        wise_radio_set_tx_io_mode(RADIO_INTF, CORE_IO_BLOCKING);
        return wise_radio_tx_frame(RADIO_INTF, RADIO_CH, txBuf, frameLen) == WISE_SUCCESS ? 1 : 0;
    }

    txFinish = false;
    txBusy   = true;
    wise_radio_set_tx_io_mode(RADIO_INTF, CORE_IO_NONBLOCKING);
    if (wise_radio_tx_frame(RADIO_INTF, RADIO_CH, txBuf, frameLen) != WISE_SUCCESS) {
        txBusy = false;
        return 0;
    }
    return 1;
}

bool ESMTRadioClass::isTransmitting()
{
    return txBusy;
}

/* ------------------------------------------------------------- receive --- */

int ESMTRadioClass::parsePacket()
{
    rxLen = rxPos = 0;
    if (!started) {
        return 0;
    }

    while (wise_radio_get_rx_frame_num(RADIO_INTF) > 0) {
        uint32_t addr = 0;
        WISE_RX_META_T meta;

        memset(&meta, 0, sizeof(meta));
        if (wise_radio_get_rx_frame_info(RADIO_INTF, &addr, &meta) != WISE_SUCCESS) {
            break;
        }

        const uint8_t *frame = (const uint8_t *)addr;
        uint16_t size        = 0;
        if (meta.valid == RX_FRAME_VALID && meta.data_len > 1) {
            /* frame[0] is the payload length; never read past what arrived */
            size = frame[0];
            if (size > meta.data_len - 1) {
                size = meta.data_len - 1;
            }
            if (size > ESMT_RADIO_MAX_PACKET) {
                size = ESMT_RADIO_MAX_PACKET;
            }
            memcpy(rxBuf, &frame[1], size);
            lastRssi = meta.rssi;
        }
        wise_radio_release_rx_frame(RADIO_INTF);

        if (size > 0) {
            rxLen = size;
            return size;
        }
    }
    return 0;
}

int ESMTRadioClass::available()
{
    return rxLen - rxPos;
}

int ESMTRadioClass::read()
{
    return (rxPos < rxLen) ? rxBuf[rxPos++] : -1;
}

int ESMTRadioClass::peek()
{
    return (rxPos < rxLen) ? rxBuf[rxPos] : -1;
}

int ESMTRadioClass::packetRssi()
{
    return lastRssi;
}

int ESMTRadioClass::rssi()
{
    return (started && listening) ? wise_radio_get_rssi(RADIO_INTF) : 0;
}

/* ----------------------------------------------------------- callbacks --- */

void ESMTRadioClass::onReceive(void (*callback)(int))
{
    userReceive = callback;
    if (callback) {
        receive();
    }
}

void ESMTRadioClass::onTxDone(void (*callback)())
{
    userTxDone = callback;
}

/* Radio interrupt: only the async-send end is recorded here; received
 * frames stay queued in the driver until parsePacket(). */
void ESMTRadioClass::_event(uint32_t evt)
{
    if (evt & (WISE_RADIO_EVT_TX_DONE | WISE_RADIO_EVT_TX_ERR)) {
        Radio.txBusy   = false;
        Radio.txFinish = true;
    }
}

/* Core loop: deliver the callbacks outside the interrupt. */
void ESMTRadioClass::_service()
{
    if (!Radio.started) {
        return;
    }
    if (Radio.txFinish) {
        Radio.txFinish = false;
        if (Radio.userTxDone) {
            Radio.userTxDone();
        }
    }
    if (Radio.userReceive) {
        int size;
        while ((size = Radio.parsePacket()) > 0) {
            Radio.userReceive(size);
        }
    }
}

/* ------------------------------------------------------------ settings --- */

void ESMTRadioClass::setTxPower(int dbm)
{
    if (dbm < -6) {
        dbm = -6;
    }
    if (dbm > 11) {
        dbm = 11;
    }
    txPowerDbm = (int8_t)dbm;
    if (started) {
        wise_radio_set_tx_pwr_dbm(RADIO_INTF, txPowerDbm);
    }
}

int ESMTRadioClass::setFrequency(long freq)
{
    if (freq <= 0) {
        return 0;
    }
    frequency = freq;
    return started ? configure() : 1;
}

int ESMTRadioClass::setDataRate(long bps)
{
    WISE_DATA_RATE_T rate;
    if (!rateToEnum(bps, &rate)) {
        return 0;
    }
    dataRate  = bps;
    deviation = bps / 4;
    return started ? configure() : 1;
}

int ESMTRadioClass::setFrequencyDeviation(long hz)
{
    if (hz <= 0 || !deviationOk(dataRate, hz)) {
        return 0;
    }
    deviation = hz;
    return started ? configure() : 1;
}

void ESMTRadioClass::setSyncWord(uint32_t word)
{
    syncWord = word;
    if (started) {
        configure();
    }
}

void ESMTRadioClass::setPreambleLength(int bytes)
{
    if (bytes < 1) {
        bytes = 1;
    }
    if (bytes > MAX_PREAMBLE_LEN) {
        bytes = MAX_PREAMBLE_LEN;
    }
    preambleLen = (uint8_t)bytes;
    if (started) {
        configure();
    }
}

void ESMTRadioClass::enableCrc()
{
    crc = true;
    if (started) {
        configure();
    }
}

void ESMTRadioClass::disableCrc()
{
    crc = false;
    if (started) {
        configure();
    }
}

unsigned long ESMTRadioClass::packetsReceived()
{
    WISE_RADIO_RX_STATS_T st;
    memset(&st, 0, sizeof(st));
    wise_radio_get_rx_stats(RADIO_INTF, &st);
    return st.rx_ok;
}

unsigned long ESMTRadioClass::crcErrors()
{
    WISE_RADIO_RX_STATS_T st;
    memset(&st, 0, sizeof(st));
    wise_radio_get_rx_stats(RADIO_INTF, &st);
    return st.crc_err;
}
