/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef STREAM_H
#define STREAM_H

#include "Print.h"
#include "WString.h"

/** @brief What parseInt()/parseFloat() do with characters that are not part of a number. */
enum LookaheadMode {
    SKIP_ALL,        /**< Skip everything that is not a digit or a minus sign. */
    SKIP_NONE,       /**< Stop at the first character that is not part of a number. */
    SKIP_WHITESPACE, /**< Skip spaces, tabs and line breaks only. */
};

#define NO_IGNORE_CHAR '\x01'

/**
 * @brief Readable byte stream with timeouts (base of HardwareSerial).
 *
 * Waiting functions keep the WISE system loop and yield() running.
 */
class Stream: public Print
{
  public:
    virtual int available() = 0;
    virtual int read()      = 0;
    virtual int peek()      = 0;

    void setTimeout(unsigned long timeout)
    {
        _timeout = timeout;
    }
    unsigned long getTimeout(void)
    {
        return _timeout;
    }

    bool find(const char *target);
    bool find(const char *target, size_t length);
    bool find(char target)
    {
        return find(&target, 1);
    }
    bool findUntil(const char *target, const char *terminator);
    bool findUntil(const char *target, size_t targetLen, const char *terminate, size_t termLen);

    long parseInt(LookaheadMode lookahead = SKIP_ALL, char ignore = NO_IGNORE_CHAR);
    float parseFloat(LookaheadMode lookahead = SKIP_ALL, char ignore = NO_IGNORE_CHAR);

    size_t readBytes(char *buffer, size_t length);
    size_t readBytes(uint8_t *buffer, size_t length)
    {
        return readBytes((char *)buffer, length);
    }
    size_t readBytesUntil(char terminator, char *buffer, size_t length);
    size_t readBytesUntil(char terminator, uint8_t *buffer, size_t length)
    {
        return readBytesUntil(terminator, (char *)buffer, length);
    }

    /** @brief Read until the timeout passes with no new byte. */
    String readString();
    /** @brief Read until terminator (not stored) or the timeout. */
    String readStringUntil(char terminator);

    bool find(const String &target)
    {
        return find(target.c_str(), target.length());
    }

  protected:
    unsigned long _timeout = 1000;

    int timedRead();
    int timedPeek();
    int peekNextDigit(LookaheadMode lookahead, bool detectDecimal);
};

#endif /* STREAM_H */
