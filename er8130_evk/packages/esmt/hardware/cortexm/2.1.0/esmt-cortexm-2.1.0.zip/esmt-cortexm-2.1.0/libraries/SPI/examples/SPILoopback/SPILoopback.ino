// SPI loopback: connect MOSI (GPIO6) to MISO (GPIO7) with a jumper.
// Every byte sent comes back; the sketch prints PASS or the first mismatch.

#include <SPI.h>

void setup()
{
    Serial.begin(115200);
    pinMode(SS, OUTPUT);
    digitalWrite(SS, HIGH);
    SPI.begin();
}

void loop()
{
    uint8_t buf[64];
    for (unsigned i = 0; i < sizeof(buf); i++) {
        buf[i] = (uint8_t)(i * 7 + 1);
    }

    SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
    digitalWrite(SS, LOW);
    uint8_t single = SPI.transfer(0xA5);
    SPI.transfer(buf, sizeof(buf)); /* in place */
    digitalWrite(SS, HIGH);
    SPI.endTransaction();

    bool ok = (single == 0xA5);
    for (unsigned i = 0; ok && i < sizeof(buf); i++) {
        if (buf[i] != (uint8_t)(i * 7 + 1)) {
            Serial.print("mismatch at ");
            Serial.println(i);
            ok = false;
        }
    }
    Serial.println(ok ? "PASS" : "FAIL (is MOSI wired to MISO?)");
    delay(1000);
}
