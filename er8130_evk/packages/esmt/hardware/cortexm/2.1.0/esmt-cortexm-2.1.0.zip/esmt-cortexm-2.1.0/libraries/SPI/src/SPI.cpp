/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "SPI.h"

extern "C" {
#include "wise_core.h"
#include "wise_gpio_api.h"
#include "wise_spi_api.h"
}

/* Driver limit per wise_spi_msg_xfer(): 512 units (bytes at 8-bit width). */
#define SPI_MAX_UNITS 512U
#define SPI_SCRATCH 64U

SPIClass SPI(SPI_INTERFACE, PIN_SPI_SCK, PIN_SPI_MISO, PIN_SPI_MOSI);

static const struct {
    uint32_t hz;
    WISE_SPI_MASTER_CLOCK_SEL_T sel;
} spiClocks[] = {
    {20000000UL, E_SPI_CLOCK_SEL_20M}, {10000000UL, E_SPI_CLOCK_SEL_10M}, {5000000UL, E_SPI_CLOCK_SEL_5M},  {4000000UL, E_SPI_CLOCK_SEL_4M},
    {2000000UL, E_SPI_CLOCK_SEL_2M},   {1000000UL, E_SPI_CLOCK_SEL_1M},   {800000UL, E_SPI_CLOCK_SEL_800K}, {500000UL, E_SPI_CLOCK_SEL_500K},
    {400000UL, E_SPI_CLOCK_SEL_400K},  {200000UL, E_SPI_CLOCK_SEL_200K},  {100000UL, E_SPI_CLOCK_SEL_100K},
};

static WISE_SPI_MASTER_CLOCK_SEL_T _clock_sel(uint32_t hz)
{
    for (size_t i = 0; i < sizeof(spiClocks) / sizeof(spiClocks[0]); i++) {
        if (hz >= spiClocks[i].hz) {
            return spiClocks[i].sel;
        }
    }
    return E_SPI_CLOCK_SEL_100K; /* slowest available */
}

static uint8_t _pio_func(uint8_t channel, uint8_t which)
{
    /* which: 0 = CLK, 1 = MOSI, 2 = MISO */
    static const uint8_t funcs[2][3] = {
        {MODE_PIO_FUNC_SPI0_CLK, MODE_PIO_FUNC_SPI0_MOSI, MODE_PIO_FUNC_SPI0_MISO},
        {MODE_PIO_FUNC_SPI1_CLK, MODE_PIO_FUNC_SPI1_MOSI, MODE_PIO_FUNC_SPI1_MISO},
    };
    return funcs[channel & 1U][which];
}

SPIClass::SPIClass(uint8_t ch, uint8_t sck, uint8_t miso, uint8_t mosi) : channel(ch), pinSck(sck), pinMiso(miso), pinMosi(mosi)
{
}

void SPIClass::setPins(uint8_t sck, uint8_t miso, uint8_t mosi)
{
    if (!started) {
        pinSck  = sck;
        pinMiso = miso;
        pinMosi = mosi;
    }
}

void SPIClass::begin()
{
    if (started) {
        return;
    }
    wise_spi_init();
    esmtPinClaim(pinSck);
    esmtPinClaim(pinMosi);
    esmtPinClaim(pinMiso);
    wise_gpio_func_cfg(pinSck, _pio_func(channel, 0));
    wise_gpio_func_cfg(pinMosi, _pio_func(channel, 1));
    wise_gpio_func_cfg(pinMiso, _pio_func(channel, 2));
    started    = true;
    configured = false;
    apply();
}

void SPIClass::end()
{
    if (!started) {
        return;
    }
    wise_spi_close(channel);
    wise_gpio_func_cfg(pinSck, MODE_PIO_FUNC_GPIO);
    wise_gpio_func_cfg(pinMosi, MODE_PIO_FUNC_GPIO);
    wise_gpio_func_cfg(pinMiso, MODE_PIO_FUNC_GPIO);
    started = false;
}

/* (Re)open the channel only when the settings changed since the last open. */
void SPIClass::apply()
{
    WISE_SPI_CONF_T cfg;

    if (!started) {
        return;
    }
    if (configured && applied.clock == current.clock && applied.bitOrder == current.bitOrder && applied.dataMode == current.dataMode) {
        return;
    }

    memset(&cfg, 0, sizeof(cfg));
    cfg.clock_mode     = (WISE_SPI_CLOCK_MODE_T)(current.dataMode & 0x03U);
    cfg.bit_order      = (current.bitOrder == LSBFIRST) ? SPI_LSB_FIRST : SPI_MSB_FIRST;
    cfg.io_mode        = WISE_SPI_IO_SINGLE;
    cfg.data_bit_width = 8;
    cfg.data_merge     = WISE_SPI_DISABLE; /* one byte per FIFO access */
    cfg.clock_sel      = _clock_sel(current.clock);
    cfg.block_mode     = E_SPI_BLOCK_MODE;
    cfg.dma_enable     = WISE_SPI_DISABLE;

    if (WISE_SUCCESS == wise_spi_master_open(channel, &cfg)) {
        applied    = current;
        configured = true;
    }
}

void SPIClass::beginTransaction(SPISettings settings)
{
    current = settings;
    apply();
}

void SPIClass::endTransaction()
{
}

void SPIClass::transfer(const void *txBuf, void *rxBuf, size_t count)
{
    static uint8_t scratchTx[SPI_SCRATCH]; /* zeros, sent when txBuf is NULL */
    static uint8_t scratchRx[SPI_SCRATCH]; /* sink when rxBuf is NULL */
    const uint8_t *tx = (const uint8_t *)txBuf;
    uint8_t *rx       = (uint8_t *)rxBuf;

    if (!started || count == 0) {
        return;
    }

    while (count > 0) {
        size_t limit = (tx && rx) ? SPI_MAX_UNITS : SPI_SCRATCH;
        size_t n     = (count < limit) ? count : limit;
        WISE_SPI_XFER_MSG_T msg;

        memset(&msg, 0, sizeof(msg));
        msg.trans_mode    = WISE_SPI_TM_WRITE_AND_READ;
        msg.tx_data_buff  = tx ? (void *)tx : (void *)scratchTx;
        msg.tx_unit_count = (uint16_t)n;
        msg.rx_data_buff  = rx ? (void *)rx : (void *)scratchRx;
        msg.rx_unit_count = (uint16_t)n;

        if (WISE_SUCCESS != wise_spi_msg_xfer(channel, &msg)) {
            return;
        }

        count -= n;
        if (tx) {
            tx += n;
        }
        if (rx) {
            rx += n;
        }
    }
}

void SPIClass::transfer(void *buf, size_t count)
{
    /* In place: the driver reads each TX byte before the matching RX byte
     * is stored, so one buffer can serve both. */
    transfer(buf, buf, count);
}

uint8_t SPIClass::transfer(uint8_t data)
{
    uint8_t rx = 0;

    transfer(&data, &rx, 1);
    return rx;
}

uint16_t SPIClass::transfer16(uint16_t data)
{
    uint8_t buf[2];

    if (current.bitOrder == LSBFIRST) {
        buf[0] = (uint8_t)data;
        buf[1] = (uint8_t)(data >> 8);
        transfer(buf, 2);
        return (uint16_t)(buf[0] | ((uint16_t)buf[1] << 8));
    }
    buf[0] = (uint8_t)(data >> 8);
    buf[1] = (uint8_t)data;
    transfer(buf, 2);
    return (uint16_t)(((uint16_t)buf[0] << 8) | buf[1]);
}

void SPIClass::setBitOrder(uint8_t order)
{
    current.bitOrder = order;
    apply();
}

void SPIClass::setDataMode(uint8_t mode)
{
    current.dataMode = mode;
    apply();
}

void SPIClass::setClockDivider(uint8_t divider)
{
    setFrequency(SystemCoreClock / (divider ? divider : 1U));
}

void SPIClass::setFrequency(uint32_t clockHz)
{
    current.clock = clockHz;
    apply();
}
