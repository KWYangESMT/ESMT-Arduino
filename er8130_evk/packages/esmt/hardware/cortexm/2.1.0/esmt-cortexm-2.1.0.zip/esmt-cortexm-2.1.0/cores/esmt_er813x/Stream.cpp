/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"
#include "Stream.h"

int Stream::timedRead()
{
    unsigned long start = millis();

    do {
        int c = read();
        if (c >= 0) {
            return c;
        }
        esmt_core_service();
        yield();
    } while ((millis() - start) < _timeout);

    return -1;
}

int Stream::timedPeek()
{
    unsigned long start = millis();

    do {
        int c = peek();
        if (c >= 0) {
            return c;
        }
        esmt_core_service();
        yield();
    } while ((millis() - start) < _timeout);

    return -1;
}

int Stream::peekNextDigit(LookaheadMode lookahead, bool detectDecimal)
{
    for (;;) {
        int c = timedPeek();

        if ((c < 0) || (c == '-') || ((c >= '0') && (c <= '9')) || (detectDecimal && (c == '.'))) {
            return c;
        }

        switch (lookahead) {
        case SKIP_NONE:
            return -1;
        case SKIP_WHITESPACE:
            if ((c != ' ') && (c != '\t') && (c != '\r') && (c != '\n')) {
                return -1;
            }
            break;
        case SKIP_ALL:
        default:
            break;
        }

        read(); /* discard */
    }
}

bool Stream::find(const char *target)
{
    return findUntil(target, strlen(target), NULL, 0);
}

bool Stream::find(const char *target, size_t length)
{
    return findUntil(target, length, NULL, 0);
}

bool Stream::findUntil(const char *target, const char *terminator)
{
    return findUntil(target, strlen(target), terminator, (terminator == NULL) ? 0 : strlen(terminator));
}

bool Stream::findUntil(const char *target, size_t targetLen, const char *terminate, size_t termLen)
{
    size_t index   = 0;
    size_t termIdx = 0;

    if (targetLen == 0) {
        return true;
    }

    for (;;) {
        int c = timedRead();
        if (c < 0) {
            return false;
        }

        /* Simple restart matching; good enough for the usual short markers. */
        if (c == target[index]) {
            if (++index >= targetLen) {
                return true;
            }
        } else {
            index = (c == target[0]) ? 1 : 0;
        }

        if (termLen > 0) {
            if (c == terminate[termIdx]) {
                if (++termIdx >= termLen) {
                    return false;
                }
            } else {
                termIdx = (c == terminate[0]) ? 1 : 0;
            }
        }
    }
}

long Stream::parseInt(LookaheadMode lookahead, char ignore)
{
    bool isNegative = false;
    long value      = 0;
    int c           = peekNextDigit(lookahead, false);

    if (c < 0) {
        return 0;
    }

    do {
        if (c == ignore) {
            /* skip */
        } else if (c == '-') {
            isNegative = true;
        } else if ((c >= '0') && (c <= '9')) {
            value = value * 10 + (c - '0');
        }
        read();
        c = timedPeek();
    } while (((c >= '0') && (c <= '9')) || (c == ignore));

    return isNegative ? -value : value;
}

float Stream::parseFloat(LookaheadMode lookahead, char ignore)
{
    bool isNegative = false;
    bool isFraction = false;
    double value    = 0.0;
    double fraction = 1.0;
    int c           = peekNextDigit(lookahead, true);

    if (c < 0) {
        return 0.0f;
    }

    do {
        if (c == ignore) {
            /* skip */
        } else if (c == '-') {
            isNegative = true;
        } else if (c == '.') {
            isFraction = true;
        } else if ((c >= '0') && (c <= '9')) {
            value = value * 10.0 + (c - '0');
            if (isFraction) {
                fraction *= 0.1;
            }
        }
        read();
        c = timedPeek();
    } while (((c >= '0') && (c <= '9')) || ((c == '.') && !isFraction) || (c == ignore));

    if (isFraction) {
        value *= fraction;
    }

    return (float)(isNegative ? -value : value);
}

size_t Stream::readBytes(char *buffer, size_t length)
{
    size_t count = 0;

    while (count < length) {
        int c = timedRead();
        if (c < 0) {
            break;
        }
        *buffer++ = (char)c;
        count++;
    }

    return count;
}

size_t Stream::readBytesUntil(char terminator, char *buffer, size_t length)
{
    size_t index = 0;

    while (index < length) {
        int c = timedRead();
        if ((c < 0) || (c == terminator)) {
            break;
        }
        *buffer++ = (char)c;
        index++;
    }

    return index;
}

String Stream::readString()
{
    String s;
    int c;

    while ((c = timedRead()) >= 0) {
        s.concat((char)c);
    }

    return s;
}

String Stream::readStringUntil(char terminator)
{
    String s;
    int c;

    while (((c = timedRead()) >= 0) && (c != terminator)) {
        s.concat((char)c);
    }

    return s;
}
