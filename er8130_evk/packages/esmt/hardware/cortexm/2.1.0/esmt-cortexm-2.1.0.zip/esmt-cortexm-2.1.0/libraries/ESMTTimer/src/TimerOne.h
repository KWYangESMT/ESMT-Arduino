/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/* For sketches written for the TimerOne library: Timer1 is a GPTMR here.
 * initialize(), attachInterrupt(), detachInterrupt(), setPeriod(), start(),
 * stop(), restart(), resume() and read() work as there; the PWM functions of
 * TimerOne (pwm(), setPwmDuty(), disablePwm()) do not exist: use
 * analogWrite(). */
#include "ESMTTimer.h"
