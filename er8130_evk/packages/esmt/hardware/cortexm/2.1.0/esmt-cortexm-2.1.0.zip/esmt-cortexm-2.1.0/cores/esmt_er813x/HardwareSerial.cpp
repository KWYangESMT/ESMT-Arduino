/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"
#include "HardwareSerial.h"
#include "wiring_private.h"

extern "C" {
#include "wise_core.h"
#include "wise_gpio_api.h"
#include "wise_uart_api.h"
}

#if (SERIAL_RX_BUFFER_SIZE & (SERIAL_RX_BUFFER_SIZE - 1)) != 0
#error "SERIAL_RX_BUFFER_SIZE must be a power of two"
#endif

#define RX_MASK (SERIAL_RX_BUFFER_SIZE - 1U)

#define UART_COUNT 3

static uint8_t rxBuffer0[SERIAL_RX_BUFFER_SIZE];
static uint8_t rxBuffer1[SERIAL_RX_BUFFER_SIZE];
static uint8_t rxBuffer2[SERIAL_RX_BUFFER_SIZE];

HardwareSerial Serial(PIN_SERIAL_UART, PIN_SERIAL_TX, PIN_SERIAL_RX, rxBuffer0);
HardwareSerial Serial1(1, PIN_SERIAL1_TX, PIN_SERIAL1_RX, rxBuffer1);
HardwareSerial Serial2(2, PIN_SERIAL2_TX, PIN_SERIAL2_RX, rxBuffer2);

/* Filled by _open(), so only the ports a sketch uses are referenced. */
static HardwareSerial *volatile openPorts[UART_COUNT];

static const uint8_t uartPinFunc[UART_COUNT][2] = {
    {MODE_PIO_FUNC_UART0_TX, MODE_PIO_FUNC_UART0_RX},
    {MODE_PIO_FUNC_UART1_TX, MODE_PIO_FUNC_UART1_RX},
    {MODE_PIO_FUNC_UART2_TX, MODE_PIO_FUNC_UART2_RX},
};

/* No WISE RX FIFO is attached, so wise_uart_api.c calls this for every byte
 * from the RX interrupt. On the upload UART the escape is checked first; the
 * byte still reaches the sketch. */
static void _serial_rx_isr(uint8_t uartIntf, uint8_t rxByte)
{
    HardwareSerial *port;

    if (uartIntf >= UART_COUNT) {
        return;
    }
    if (uartIntf == PIN_SERIAL_UART) {
        _esmt_upload_escape_feed(rxByte);
    }
    port = openPorts[uartIntf];
    if (port) {
        port->_rx_byte(rxByte);
    }
}

static void _uart_apply(uint8_t uart, unsigned long baud, uint16_t config)
{
    WISE_UART_CFG_T cfg;

    cfg.baudrate  = (uint32_t)baud;
    cfg.data      = (uint8_t)(E_UART_DATA_5_BIT + (config & 0x03));
    cfg.parity    = ((config & 0x0C) == SERIAL_PARITY_E)   ? E_UART_PARITY_EVEN
                    : ((config & 0x0C) == SERIAL_PARITY_O) ? E_UART_PARITY_ODD
                                                           : E_UART_PARITY_NONE;
    cfg.stop      = (config & SERIAL_STOP_2) ? E_UART_STOP_2_BIT : E_UART_STOP_1_BIT;
    cfg.dmaEnable = 0;

    wise_uart_config(uart, &cfg);
    wise_uart_enable(uart, WISE_UART_FLAG_RX | WISE_UART_FLAG_TX);
    wise_uart_enable_interrupt(uart);
}

extern "C" void _esmt_serial_init(void)
{
    /* registers the RX/TX interrupt dispatch for every UART */
    wise_uart_init();
    Serial._open(115200, SERIAL_8N1);
}

void HardwareSerial::_open(unsigned long baud, uint16_t config)
{
    if (_uart >= UART_COUNT) {
        return;
    }
    openPorts[_uart] = this;
    _baud            = baud;
    _config          = config;
    wise_uart_set_rx_int_handler(_uart, _serial_rx_isr);
    _uart_apply(_uart, baud, config);
    esmtPinClaim(_txPin);
    esmtPinClaim(_rxPin);
    wise_gpio_func_cfg(_txPin, uartPinFunc[_uart][0]);
    wise_gpio_func_cfg(_rxPin, uartPinFunc[_uart][1]);
}

void HardwareSerial::setPins(uint8_t txPin, uint8_t rxPin)
{
    if (!_started) {
        _txPin = txPin;
        _rxPin = rxPin;
    }
}

void HardwareSerial::_rx_byte(uint8_t c)
{
    uint16_t head = _rxHead;
    uint16_t next = (uint16_t)((head + 1U) & RX_MASK);

    /* Full: drop the new byte, as other Arduino cores do. */
    if (next != _rxTail) {
        _rxBuf[head] = c;
        _rxHead      = next;
    }
}

void HardwareSerial::begin(unsigned long baud, uint16_t config)
{
    if (_started) {
        flush();
    }

    _open(baud, config);

    _rxTail  = _rxHead; /* discard what arrived before begin() */
    _started = true;
}

void HardwareSerial::end()
{
    if (_uart >= UART_COUNT) {
        return;
    }
    flush();
    wise_uart_disable_interrupt(_uart);
    wise_uart_enable(_uart, WISE_UART_FLAG_NONE);
    wise_gpio_func_cfg(_txPin, MODE_PIO_FUNC_GPIO);
    wise_gpio_func_cfg(_rxPin, MODE_PIO_FUNC_GPIO);
    openPorts[_uart] = nullptr;

    _rxTail  = _rxHead;
    _started = false;
}

int HardwareSerial::available()
{
    return (int)((uint16_t)(_rxHead - _rxTail) & RX_MASK);
}

int HardwareSerial::peek()
{
    uint16_t tail = _rxTail;

    if (tail == _rxHead) {
        return -1;
    }

    return _rxBuf[tail];
}

int HardwareSerial::read()
{
    uint16_t tail = _rxTail;
    uint8_t c;

    if (tail == _rxHead) {
        return -1;
    }

    c       = _rxBuf[tail];
    _rxTail = (uint16_t)((tail + 1U) & RX_MASK);

    return c;
}

int HardwareSerial::availableForWrite()
{
    /* No TX FIFO: each write() returns once its byte is in the UART. */
    return 1;
}

void HardwareSerial::flush()
{
    /* Bounded: wise_uart_flush_tx() waits at most about two character times. */
    for (int i = 0; i < 1000; i++) {
        if (WISE_SUCCESS == wise_uart_flush_tx(_uart)) {
            break;
        }
    }
}

size_t HardwareSerial::write(uint8_t c)
{
    return (WISE_SUCCESS == wise_uart_write_char(_uart, c)) ? 1 : 0;
}

size_t HardwareSerial::write(const uint8_t *buffer, size_t size)
{
    size_t n = 0;

    while (n < size) {
        if (WISE_SUCCESS != wise_uart_write_char(_uart, buffer[n])) {
            setWriteError();
            break;
        }
        n++;
    }

    return n;
}

/* Low power: a sleep powers the UARTs down, so finish sending first and
 * set the open ports up again afterwards (what wise_system_restore() does
 * for middleware apps). Received bytes still in the ring buffers stay. */
extern "C" void _esmt_serial_flush_all(void)
{
    for (uint8_t i = 0; i < UART_COUNT; i++) {
        HardwareSerial *port = openPorts[i];
        if (port) {
            port->flush();
        }
    }
}

extern "C" void _esmt_serial_restore_all(void)
{
    for (uint8_t i = 0; i < UART_COUNT; i++) {
        HardwareSerial *port = openPorts[i];
        if (port) {
            port->_open(port->baudRate(), port->_lineConfig());
        }
    }
}

/* serialEvent(), serialEvent1(), serialEvent2(): optional sketch functions,
 * called after loop() while their port has received data. Weak references,
 * so a sketch without them costs nothing; the ports are read through
 * openPorts so an unused Serial1 / Serial2 is not pulled in. */
void serialEvent(void) __attribute__((weak));
void serialEvent1(void) __attribute__((weak));
void serialEvent2(void) __attribute__((weak));

extern "C" void _esmt_serial_event_run(void)
{
    void (*const events[UART_COUNT])(void) = {serialEvent, serialEvent1, serialEvent2};

    for (uint8_t i = 0; i < UART_COUNT; i++) {
        HardwareSerial *port = openPorts[i];
        if (events[i] && port && port->available() > 0) {
            events[i]();
        }
    }
}
