/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "ESMTTimer.h"

extern "C" {
#include "wise_core.h"
#include "wise_gptmr_api.h"
}

/*
 * On wise_gptmr_api (as demo_gptmr): wise_timer_config() programs the
 * period, the mode and the interrupt enable and leaves the timer stopped;
 * wise_timer_start() runs it. The counter counts down from RELOAD (period x
 * 40 clocks) and reloads; a one-shot channel is stopped by the driver's ISR.
 * The callback runs in the GPTMR interrupt.
 */

#define CLK_PER_US (__SYSTEM_CLOCK / 1000000UL)

ESMTTimer Timer0(0);
ESMTTimer Timer1(1);
ESMTTimer Timer2(2);
ESMTTimer Timer3(3);
ESMTTimer Timer4(4);

static ESMTTimer *const timers[] = {&Timer0, &Timer1, &Timer2, &Timer3, &Timer4};

static void timerInit(void)
{
    static bool done;
    if (!done) {
        wise_timer_init();
        done = true;
    }
}

void ESMTTimer::_isr(void *context, uint8_t idx)
{
    (void)context;
    if (idx < sizeof(timers) / sizeof(timers[0])) {
        void (*fn)() = timers[idx]->callback;
        if (fn) {
            fn();
        }
    }
}

bool ESMTTimer::configure(unsigned long periodUs, bool single)
{
    if (periodUs == 0 || periodUs > ESMT_TIMER_MAX_PERIOD_US) {
        return false;
    }
    timerInit();

    WISE_TIMER_CTRL_T cfg;
    cfg.type             = single ? WISE_TIMER_ONE_SHOT : WISE_TIMER_PERIODIC;
    cfg.interval         = (uint32_t)periodUs;
    cfg.start_offset     = 0;
    cfg.interrupt_enable = single || (callback != nullptr);

    if (wise_timer_config(channel, &cfg) != WISE_SUCCESS) {
        return false;
    }
    if (!configured) {
        wise_timer_register_callback(channel, _isr, nullptr);
    }
    period     = periodUs;
    oneShot    = single;
    configured = true;
    return true;
}

bool ESMTTimer::initialize(unsigned long periodUs)
{
    if (!configure(periodUs, false)) {
        return false;
    }
    wise_timer_start(channel);
    return true;
}

bool ESMTTimer::setPeriod(unsigned long periodUs)
{
    bool running = isRunning();
    if (!configure(periodUs, oneShot)) {
        return false;
    }
    if (running) {
        wise_timer_start(channel);
    }
    return true;
}

void ESMTTimer::attachInterrupt(void (*isr)())
{
    callback = isr;
    if (!configured) {
        initialize(1000000UL);
    } else if (isr) {
        wise_timer_enable_int(channel);
    }
}

void ESMTTimer::attachInterrupt(void (*isr)(), unsigned long periodUs)
{
    callback = isr;
    if (!configured || periodUs != period) {
        initialize(periodUs);
    } else if (isr) {
        wise_timer_enable_int(channel);
    }
}

void ESMTTimer::detachInterrupt()
{
    callback = nullptr;
    if (configured && !oneShot) {
        wise_timer_disable_int(channel);
    }
}

void ESMTTimer::start()
{
    if (!configured) {
        return;
    }
    /* config reloads the count from the start of a period */
    if (configure(period, oneShot)) {
        wise_timer_start(channel);
    }
}

void ESMTTimer::stop()
{
    if (configured) {
        wise_timer_stop(channel);
    }
}

void ESMTTimer::resume()
{
    if (configured) {
        wise_timer_start(channel);
    }
}

bool ESMTTimer::isRunning() const
{
    return configured && wise_timer_is_enabled(channel);
}

unsigned long ESMTTimer::read() const
{
    if (!configured) {
        return 0;
    }
    uint32_t reload = wise_timer_get_counter_max(channel);
    uint32_t value  = wise_timer_get_counter(channel);
    /* The GPTMR counts up from 0 to the reload value (measured on the EVK: 200 ms
       into a 1 s period, reload - value gave 799984 us). */
    return ((value <= reload) ? value : reload) / CLK_PER_US;
}

bool ESMTTimer::once(unsigned long us, void (*isr)())
{
    callback = isr;
    if (!configure(us, true)) {
        return false;
    }
    wise_timer_start(channel);
    return true;
}

void ESMTTimer::end()
{
    if (!configured) {
        return;
    }
    wise_timer_stop(channel);
    wise_timer_disable_int(channel);
    callback   = nullptr;
    configured = false;
    period     = 0;
    oneShot    = false;
}
