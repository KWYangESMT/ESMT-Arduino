/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"

/*
 * pulseIn(): length of a pulse in microseconds, measured with micros() while
 * polling the pin. Resolution is a few microseconds; for short pulses use a
 * capture timer instead. The watchdog is fed while waiting, so timeouts
 * longer than the watchdog period are safe.
 */
static unsigned long _wait_level(uint8_t pin, int level, unsigned long start, unsigned long timeout)
{
    while (digitalRead(pin) != level) {
        if ((micros() - start) >= timeout) {
            return 0;
        }
        esmtWatchdogFeed();
    }
    return 1;
}

unsigned long pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout)
{
    const int active    = (state != LOW) ? HIGH : LOW;
    const int inactive  = (active == HIGH) ? LOW : HIGH;
    unsigned long start = micros();
    unsigned long begin;

    /* let a pulse that is already in progress finish first */
    if (!_wait_level(pin, inactive, start, timeout)) {
        return 0;
    }
    if (!_wait_level(pin, active, start, timeout)) {
        return 0;
    }
    begin = micros();
    if (!_wait_level(pin, inactive, start, timeout)) {
        return 0;
    }
    return micros() - begin;
}

unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout)
{
    return pulseInLong(pin, state, timeout);
}
