/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"
#include "wise_gpio_api.h"

static voidFuncPtr isrTable[NUM_DIGITAL_PINS];

/* Runs in the GPIO interrupt; idx is the GPIO index. */
static void _gpio_isr(void *context, uint8_t idx)
{
    (void)context;

    if ((idx < NUM_DIGITAL_PINS) && (isrTable[idx] != NULL)) {
        isrTable[idx]();
    }
}

void attachInterrupt(uint8_t interruptNum, voidFuncPtr callback, int mode)
{
    WISE_GPIO_INT_CFG_T cfg;
    uint8_t pin = interruptNum;

    if ((pin >= NUM_DIGITAL_PINS) || (callback == NULL)) {
        return;
    }

    switch (mode) {
    case LOW:
        cfg.int_type = GPIO_INT_TYPE_LEVEL_LOW;
        break;
    case HIGH:
        cfg.int_type = GPIO_INT_TYPE_LEVEL_HIGH;
        break;
    case FALLING:
        cfg.int_type = GPIO_INT_TYPE_EDGE_FALLING;
        break;
    case RISING:
        cfg.int_type = GPIO_INT_TYPE_EDGE_RISING;
        break;
    case CHANGE:
        cfg.int_type = GPIO_INT_TYPE_EDGE_BOTH;
        break;
    default:
        return;
    }

    /* The pin must be a GPIO input; keep any pull setting from pinMode(). */
    if (wise_gpio_get_direction(pin) != GPIO_DIR_INPUT) {
        pinMode(pin, INPUT);
    } else {
        esmtPinClaim(pin);
    }

    isrTable[pin] = callback;
    wise_gpio_register_callback(pin, _gpio_isr, NULL);

    cfg.int_en = GPIO_INT_ENABLE;
    wise_gpio_clear_int_status(pin);
    wise_gpio_set_interrupt(pin, &cfg);
}

void detachInterrupt(uint8_t interruptNum)
{
    WISE_GPIO_INT_CFG_T cfg = {GPIO_INT_DISABLE, GPIO_INT_TYPE_NONE};
    uint8_t pin             = interruptNum;

    if (pin >= NUM_DIGITAL_PINS) {
        return;
    }

    wise_gpio_set_interrupt(pin, &cfg);
    wise_gpio_unregister_callback(pin);
    isrTable[pin] = NULL;
}
