// NfcSensor: the tag holds a text record that the sketch updates every
// second, so a phone that reads it sees the latest value. A second record
// carries a web address. Use an NFC reader app to see the text.

#include <ESMTNFC.h>

unsigned long count;

void setup()
{
    Serial.begin(9600);
    NFC.begin();
}

void loop()
{
    char text[64];
    int raw = analogRead(A2); // temperature sensor input, raw 10-bit value

    count++;
    snprintf(text, sizeof(text), "Reading %lu: A2 = %d", count, raw);

    NFC.beginMessage();
    NFC.addText(text);
    NFC.addUri("https://www.esmt.com.tw/");
    if (NFC.endMessage()) {
        Serial.println(text);
    } else {
        Serial.println(F("NFC: message too long"));
    }
    delay(1000);
}
