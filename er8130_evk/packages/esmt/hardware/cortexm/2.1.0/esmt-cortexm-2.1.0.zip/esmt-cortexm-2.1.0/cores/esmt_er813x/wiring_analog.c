/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"
#include "wiring_private.h"

#include "wise_core.h"
#include "wise_gpio_api.h"
#include "wise_pwm_api.h"
#include "wise_sys_api.h"

/* ------------------------------------------------------------------------- */
/*                         analogRead() - ASARADC                            */
/* ------------------------------------------------------------------------- */

#define ADC_NATIVE_BITS 12

static bool adcInited;
static uint8_t adcReadBits   = 10; /* Arduino default */
static uint8_t adcReference  = AR_DEFAULT;
static uint8_t adcAppliedRef = 0xFF;

static int _adc_vin(uint8_t pin, ASARADC_VIN_SEL_T *vin)
{
    if (pin >= PIN_A0) {
        pin -= PIN_A0;
    }

    switch (pin) {
    case 0:
        *vin = ASARADC_VIN_EXTERNAL;
        return 0;
    case 1:
        *vin = ASARADC_VIN_BATTERY;
        return 0;
    case 2:
        *vin = ASARADC_VIN_TEMP;
        return 0;
    default:
        return -1;
    }
}

void analogReference(uint8_t mode)
{
    adcReference = mode;
}

void analogReadResolution(int bits)
{
    if (bits < 1) {
        bits = 1;
    }
    if (bits > 16) {
        bits = 16;
    }
    adcReadBits = (uint8_t)bits;
}

int analogRead(uint8_t pin)
{
    ASARADC_VIN_SEL_T vin;
    uint16_t raw = 0;

    if (_adc_vin(pin, &vin) < 0) {
        return 0;
    }

    if (!adcInited) {
        wise_asaradc_init();
        adcInited = true;
    }

    if (adcAppliedRef != adcReference) {
        wise_asaradc_config((adcReference == AR_INTERNAL1V6) ? ASARADC_VREF_1P6V : ASARADC_VREF_2P4V);
        adcAppliedRef = adcReference;
    }

    if (WISE_SUCCESS != wise_asaradc_read_input(vin, &raw)) {
        return 0;
    }

    if (adcReadBits < ADC_NATIVE_BITS) {
        return (int)(raw >> (ADC_NATIVE_BITS - adcReadBits));
    }

    return (int)((uint32_t)raw << (adcReadBits - ADC_NATIVE_BITS));
}

/* ------------------------------------------------------------------------- */
/*                          analogWrite() - PWM                              */
/* ------------------------------------------------------------------------- */
/*
 * Period mode: the PWM counter runs at SystemCoreClock, so a 1 kHz output has
 * a 40000-tick period and the duty keeps the full analogWrite resolution
 * (frequency mode would round it to whole percent).
 */

#define PWM_CHANNELS CHIP_PWM_CHANNEL_NUM
#define PWM_NO_PIN 0xFF

static bool pwmInited;
static uint8_t pwmWriteBits                = 8; /* Arduino default */
static uint32_t pwmFrequency               = 1000;
static uint8_t pwmChannelPin[PWM_CHANNELS] = {PWM_NO_PIN, PWM_NO_PIN, PWM_NO_PIN, PWM_NO_PIN, PWM_NO_PIN, PWM_NO_PIN};

void analogWriteResolution(int bits)
{
    if (bits < 1) {
        bits = 1;
    }
    if (bits > 16) {
        bits = 16;
    }
    pwmWriteBits = (uint8_t)bits;
}

void analogWriteFrequency(uint32_t hz)
{
    if (hz == 0) {
        hz = 1;
    }
    pwmFrequency = hz;
}

static int _pwm_channel_of(uint8_t pin)
{
    for (int ch = 0; ch < PWM_CHANNELS; ch++) {
        if (pwmChannelPin[ch] == pin) {
            return ch;
        }
    }
    return -1;
}

int _esmt_pwm_detach(uint8_t pin)
{
    int ch = _pwm_channel_of(pin);

    if (ch < 0) {
        return 0;
    }

    wise_pwm_stop(1UL << ch);
    wise_pwm_io_disable_pin(pin);
    wise_gpio_func_cfg(pin, MODE_PIO_FUNC_GPIO);
    pwmChannelPin[ch] = PWM_NO_PIN;

    return 1;
}

int _esmt_pwm_output(uint8_t pin, uint32_t period, uint32_t active)
{
    WISE_PWM_CONF_T conf;
    int ch;

    if (pin >= NUM_DIGITAL_PINS) {
        return -1;
    }

    if (!pwmInited) {
        wise_pwm_init();
        pwmInited = true;
    }

    if (period < 2) {
        period = 2;
    }

    memset(&conf, 0, sizeof(conf));
    conf.common.mode            = PWM_MODE_PERIOD;
    conf.u.period.period        = period;
    conf.u.period.active_period = active;

    ch = _pwm_channel_of(pin);
    if (ch >= 0) {
        wise_pwm_reconf_channel((uint8_t)ch, &conf);
        return 0;
    }

    for (ch = 0; ch < PWM_CHANNELS; ch++) {
        if (pwmChannelPin[ch] == PWM_NO_PIN) {
            break;
        }
    }
    if (ch >= PWM_CHANNELS) {
        return -1; /* all channels in use */
    }

    esmtPinClaim(pin);
    if (WISE_SUCCESS != wise_pwm_configure((uint8_t)ch, pin, &conf)) {
        return -1;
    }

    pwmChannelPin[ch] = pin;
    wise_pwm_start(1UL << ch);
    return 0;
}

void analogWrite(uint8_t pin, int value)
{
    const uint32_t maxValue = (1UL << pwmWriteBits) - 1UL;
    uint32_t period;

    if (pin >= NUM_DIGITAL_PINS) {
        return;
    }

    if (value <= 0) {
        _esmt_pwm_detach(pin);
        pinMode(pin, OUTPUT);
        digitalWrite(pin, LOW);
        return;
    }

    if ((uint32_t)value >= maxValue) {
        _esmt_pwm_detach(pin);
        pinMode(pin, OUTPUT);
        digitalWrite(pin, HIGH);
        return;
    }

    period = SystemCoreClock / pwmFrequency;
    if (period < 2) {
        period = 2;
    }

    (void)_esmt_pwm_output(pin, period, (uint32_t)(((uint64_t)period * (uint32_t)value) / maxValue));
}
