// TimedWakeup: blink once, then sleep for 5 seconds; repeat.
//
// LowPower.sleep() powers the chip down (RAM is kept) until the wake-up timer
// fires; the sketch continues after the call and Serial works again.
// LowPower.deepSleep(5000) would restart the sketch from setup() instead.
//
// Uploading: the upload escape cannot wake a sleeping chip, but each wake
// gives it a chance; if an upload does not start, press reset.

#include <ESMTLowPower.h>

void setup()
{
    Serial.begin(115200);
    pinMode(LED_BUILTIN, OUTPUT);
}

void loop()
{
    digitalWrite(LED_BUILTIN, HIGH);
    delay(200);
    digitalWrite(LED_BUILTIN, LOW);

    Serial.print(F("awake at "));
    Serial.print(millis());
    Serial.println(F(" ms, sleeping 5 s"));

    LowPower.sleep(5000);
}
