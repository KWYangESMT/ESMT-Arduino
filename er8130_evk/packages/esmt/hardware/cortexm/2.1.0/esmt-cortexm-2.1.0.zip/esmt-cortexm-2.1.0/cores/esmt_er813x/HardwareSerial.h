/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef HARDWARESERIAL_H
#define HARDWARESERIAL_H

#include "Stream.h"

/* Frame formats for begin(baud, config): bits[1:0] data (5..8), bits[3:2] parity, bit[4] stop. */
#define SERIAL_DATA_5 0x00
#define SERIAL_DATA_6 0x01
#define SERIAL_DATA_7 0x02
#define SERIAL_DATA_8 0x03
#define SERIAL_PARITY_N 0x00
#define SERIAL_PARITY_O 0x04
#define SERIAL_PARITY_E 0x08
#define SERIAL_STOP_1 0x00
#define SERIAL_STOP_2 0x10

#define SERIAL_5N1 (SERIAL_DATA_5 | SERIAL_PARITY_N | SERIAL_STOP_1)
#define SERIAL_6N1 (SERIAL_DATA_6 | SERIAL_PARITY_N | SERIAL_STOP_1)
#define SERIAL_7N1 (SERIAL_DATA_7 | SERIAL_PARITY_N | SERIAL_STOP_1)
#define SERIAL_8N1 (SERIAL_DATA_8 | SERIAL_PARITY_N | SERIAL_STOP_1)
#define SERIAL_8N2 (SERIAL_DATA_8 | SERIAL_PARITY_N | SERIAL_STOP_2)
#define SERIAL_7E1 (SERIAL_DATA_7 | SERIAL_PARITY_E | SERIAL_STOP_1)
#define SERIAL_8E1 (SERIAL_DATA_8 | SERIAL_PARITY_E | SERIAL_STOP_1)
#define SERIAL_8E2 (SERIAL_DATA_8 | SERIAL_PARITY_E | SERIAL_STOP_2)
#define SERIAL_7O1 (SERIAL_DATA_7 | SERIAL_PARITY_O | SERIAL_STOP_1)
#define SERIAL_8O1 (SERIAL_DATA_8 | SERIAL_PARITY_O | SERIAL_STOP_1)
#define SERIAL_8O2 (SERIAL_DATA_8 | SERIAL_PARITY_O | SERIAL_STOP_2)

/** @brief Serial RX ring buffer size in bytes (power of two). */
#ifndef SERIAL_RX_BUFFER_SIZE
#define SERIAL_RX_BUFFER_SIZE 256
#endif

/**
 * @brief Arduino Serial on a WISE UART (Serial = UART0, Serial1 = UART1, Serial2 = UART2).
 *
 * The UART runs without a WISE RX FIFO: the RX interrupt hands every byte to
 * the core (wise_uart_set_rx_int_handler()), which keeps it in its own ring
 * buffer. TX goes through wise_uart_write_char(), which waits until each byte
 * is handed to the UART (no TX FIFO), so write() also works with interrupts off.
 *
 * The constructor is constexpr, so the objects need no start-up code and an
 * unused Serial1 / Serial2 (with its RX buffer) is dropped by the linker.
 */
class HardwareSerial: public Stream
{
  public:
    /** @param rxBuffer SERIAL_RX_BUFFER_SIZE bytes, kept outside the object so it stays in .bss. */
    constexpr HardwareSerial(uint8_t uart, uint8_t txPin, uint8_t rxPin, uint8_t *rxBuffer)
        : _uart(uart), _txPin(txPin), _rxPin(rxPin), _rxBuf(rxBuffer)
    {
    }

    /** @brief Stores one received byte; called from the UART RX interrupt. Not for sketches. */
    void _rx_byte(uint8_t c);
    /** @brief Pins, RX interrupt and line settings, without begin()'s bookkeeping. Not for sketches. */
    void _open(unsigned long baud, uint16_t config);

    /** @brief Use other pins (any GPIO); call before begin(). */
    void setPins(uint8_t txPin, uint8_t rxPin);

    void begin(unsigned long baud)
    {
        begin(baud, SERIAL_8N1);
    }
    void begin(unsigned long baud, uint16_t config);
    void end();

    int available() override;
    int peek() override;
    int read() override;
    int availableForWrite() override;
    void flush() override;

    size_t write(uint8_t c) override;
    size_t write(const uint8_t *buffer, size_t size) override;
    using Print::write;

    unsigned long baudRate() const
    {
        return _baud;
    }
    /** @brief Line settings (SERIAL_8N1 ...) of the last open. Not for sketches. */
    uint16_t _lineConfig() const
    {
        return _config;
    }

    operator bool()
    {
        return _started;
    }

  private:
    uint8_t _uart;
    uint8_t _txPin;
    uint8_t _rxPin;
    uint8_t *_rxBuf;
    bool _started       = false;
    unsigned long _baud = 0;
    uint16_t _config    = 0; /* line settings of the last _open(), for the restore after sleep */

    /* One producer (the RX interrupt writes _rxHead) and one consumer
     * (read()/begin() write _rxTail); 16-bit stores are atomic on Cortex-M. */
    volatile uint16_t _rxHead = 0;
    volatile uint16_t _rxTail = 0;
};

extern HardwareSerial Serial;
extern HardwareSerial Serial1;
extern HardwareSerial Serial2;

#define SERIAL_PORT_MONITOR Serial
#define SERIAL_PORT_HARDWARE Serial
#define SERIAL_PORT_HARDWARE1 Serial1
#define SERIAL_PORT_HARDWARE2 Serial2

#endif /* HARDWARESERIAL_H */
