/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"
#include "wiring_private.h"

#include "wise_core.h"
#include "wise_tick_api.h"

/*
 * wise_tick_get_counter() is a 32-bit counter at the tick clock, so it wraps
 * long before 2^32 ms. Extend it to 64 bits here so millis()/micros() wrap
 * the way Arduino code expects (at 2^32 of their own unit).
 *
 * The extension only sees wraps between two calls. The core folds the counter
 * in on every pass of the main loop and while waiting (esmt_core_service()),
 * so time stays right unless a single loop() pass blocks without delay() or
 * yield() for longer than one counter period (2^32 / tick clock, about 107 s
 * at 40 MHz).
 */
static uint64_t ticksTotal;
static uint32_t ticksLast;

static uint64_t _ticks_now(void)
{
    CORE_DECLARE_IRQ_STATE
    uint32_t now;

    CORE_ENTER_CRITICAL();
    now         = wise_tick_get_counter();
    ticksTotal += (uint32_t)(now - ticksLast);
    /* a sleep longer than one tick period (about 107 s) drops whole wraps,
     * which wise_core counts for us */
    ticksTotal += (uint64_t)wise_tick_take_sleep_wraps() << 32;
    ticksLast   = now;
    CORE_EXIT_CRITICAL();

    return ticksTotal;
}

void _esmt_time_refresh(void)
{
    (void)_ticks_now();
}

unsigned long millis(void)
{
    return (unsigned long)(_ticks_now() / CLK_PER_MS);
}

unsigned long micros(void)
{
    return (unsigned long)(_ticks_now() / CLK_PER_US);
}

void delay(unsigned long ms)
{
    uint64_t start = _ticks_now();
    uint64_t wait  = (uint64_t)ms * CLK_PER_MS;

    while ((_ticks_now() - start) < wait) {
        esmt_core_service();
        yield();
    }
}

void delayMicroseconds(unsigned int us)
{
    wise_tick_delay_us(us);
}
