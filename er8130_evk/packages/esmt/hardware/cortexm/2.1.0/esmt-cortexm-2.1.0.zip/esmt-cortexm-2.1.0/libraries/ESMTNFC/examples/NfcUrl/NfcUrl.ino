// NfcUrl: hold a phone with NFC on to the board's antenna and it opens the
// web address below. The LED blinks when the phone reads the tag.

#include <ESMTNFC.h>

void onNfc(int source)
{
    Serial.print(F("NFC event, source "));
    Serial.print(source);
    Serial.print(F(", count "));
    Serial.println(NFC.events());
    digitalWrite(LED_BUILTIN, HIGH);
    delay(300); // interrupts meanwhile give one more call, not one each
    digitalWrite(LED_BUILTIN, LOW);
}

void setup()
{
    Serial.begin(9600);
    pinMode(LED_BUILTIN, OUTPUT);

    NFC.onEvent(onNfc);
    NFC.begin();
    if (NFC.setUri("https://www.esmt.com.tw/")) {
        Serial.println(F("NFC tag ready: touch it with a phone"));
    } else {
        Serial.println(F("NFC: the address does not fit"));
    }
}

void loop()
{
}
