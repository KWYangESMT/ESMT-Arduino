/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"
#include "wiring_private.h"

extern "C" __attribute__((weak)) void initVariant(void)
{
}

extern "C" __attribute__((weak)) void yield(void)
{
}

#define SERVICE_SLOTS 4
static void (*services[SERVICE_SLOTS])(void);

extern "C" bool esmtAddService(void (*fn)(void))
{
    for (int i = 0; i < SERVICE_SLOTS; i++) {
        if (services[i] == fn) {
            return true;
        }
        if (services[i] == nullptr) {
            services[i] = fn;
            return true;
        }
    }
    return false;
}

extern "C" void esmt_core_service(void)
{
    _esmt_system_service();
    _esmt_time_refresh();
    _esmt_tone_service();
    for (int i = 0; i < SERVICE_SLOTS && services[i] != nullptr; i++) {
        services[i]();
    }
}

int main(void)
{
    /* Clocks, tick, GPIO, flash and UART0, straight on the wise_core API. */
    _esmt_system_init();

    initVariant();

    setup();

    for (;;) {
        esmt_core_service();
        loop();
        _esmt_serial_event_run();
    }

    return 0;
}
