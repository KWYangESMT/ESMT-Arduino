/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef ESMT_NFC_H
#define ESMT_NFC_H

#include <Arduino.h>

/** Bytes of NDEF data the tag holds (blocks 4 to 251, as the capability container says). */
#define ESMT_NFC_CAPACITY 992

/** A new message waits this long after the last NFC interrupt before it is written. */
#define ESMT_NFC_HOLD_MS 1000

/**
 * @brief NFC interrupt sources. The chip raises one of them at a time,
 * chosen with NFC.onEvent(). Measured with a phone reading the tag on the
 * EVK: only NFC_EVENT_TX fires on every read.
 */
enum {
    NFC_EVENT_POR = 1, /**< Did not fire when a phone read the tag (begin() powers the NFC block from the chip). */
    NFC_EVENT_RX  = 2, /**< Fires on some reads only, not on every one. */
    NFC_EVENT_TX  = 3, /**< The tag answered a reader: fires on every read, 1 to 4 times per touch. The default. */
    NFC_EVENT_0   = 4, /**< Did not fire when a phone read the tag. */
    NFC_EVENT_1   = 5, /**< Did not fire when a phone read the tag. */
};

/**
 * @brief The NFC tag of the ER813x (NFC Forum Type 2 tag memory).
 *
 * A phone that touches the board reads the NDEF message the sketch put in
 * the tag: a web address, a text, or several records.
 *
 * @code
 * NFC.begin();
 * NFC.setUri("https://www.esmt.com.tw/");   // the phone opens it
 *
 * NFC.beginMessage();                        // or several records
 * NFC.addText("Temperature 25 C");
 * NFC.addUri("https://example.com/");
 * NFC.endMessage();
 * @endcode
 *
 * The memory is 256 blocks of 4 bytes: blocks 0-3 hold the tag header
 * (UID, lock bytes, capability container), the NDEF message starts at
 * block 4 (up to 992 bytes), block 255 is the trigger / dynamic lock block.
 * Bytes are stored little-endian in each 32-bit block.
 *
 * A message written while a phone is reading the tag is held back and
 * written by the core loop once the reader has been quiet for
 * ESMT_NFC_HOLD_MS, so the phone never reads a message that changes half
 * way. The reader is seen through the active interrupt source (TX by
 * default).
 *
 * onEvent() callbacks run from the core loop (between loop() passes and
 * inside delay()), not in the interrupt.
 */
class ESMTNFCClass
{
  public:
    /**
     * @brief Power the NFC block from the chip and start with an empty
     * message (this clears the tag memory).
     * @return true.
     */
    bool begin();
    /** @brief Stop the NFC block and return it to reader (antenna) power, as at start-up. */
    void end();

    /** @brief Replace the message with one URI record. @return false if it does not fit or is empty. */
    bool setUri(const char *uri);
    /**
     * @brief Replace the message with one text record (UTF-8).
     * @param text Text to show.
     * @param lang IANA language code, for example "en" (1 to 63 characters).
     * @return false if it does not fit.
     */
    bool setText(const char *text, const char *lang = "en");
    /** @brief Make the message empty (the tag stays readable, with no records). */
    void clear();

    /** @brief Start building a message of several records; endMessage() writes it. */
    void beginMessage();
    /** @brief Add a URI record ("https://", "http://www.", "tel:", "mailto:" ... are shortened). */
    bool addUri(const char *uri);
    /** @brief Add a text record. */
    bool addText(const char *text, const char *lang = "en");
    /**
     * @brief Add a record of any type.
     * @param tnf Type name format (1 well-known, 2 MIME, 4 external ...).
     * @param type Record type, typeLen bytes.
     * @param payload Payload, payloadLen bytes.
     */
    bool addRecord(uint8_t tnf, const uint8_t *type, uint8_t typeLen, const uint8_t *payload, size_t payloadLen);
    /**
     * @brief Write the message built since beginMessage() to the tag, or
     * hold it while a phone is reading (see writePending()).
     * @return false if nothing was added or it overflowed; the tag then keeps its message.
     */
    bool endMessage();
    /** @brief true while a new message waits for the reader to leave before it is written. */
    bool writePending() const;
    /** @brief Bytes left for records in the message being built. */
    size_t spaceLeft() const;

    /**
     * @brief Read the NDEF message now in the tag (for example one a phone wrote).
     * @param buffer Where to copy the message (the records, without the TLV header).
     * @param size Size of buffer.
     * @return Length of the message, 0 if empty, -1 if the tag holds no valid NDEF TLV.
     * At most size bytes are copied.
     */
    int readMessage(uint8_t *buffer, size_t size); /* the tag, not a held message */

    /** @brief Read count blocks (4 bytes each) starting at block. @return false outside 0-255. */
    bool readBlock(uint8_t block, uint32_t *data, uint8_t count = 1);
    /** @brief Write count blocks starting at block. @return false outside 0-255. */
    bool writeBlock(uint8_t block, const uint32_t *data, uint8_t count = 1);

    /**
     * @brief Call fn(source) from the core loop when the NFC interrupt
     * source fires. Only one source is active at a time. Interrupts that
     * arrive before the callback runs are merged into one call, so one
     * touch usually gives one call; events() counts every interrupt.
     * @param callback Function to call, or nullptr to stop.
     * @param source One of NFC_EVENT_POR, NFC_EVENT_RX, NFC_EVENT_TX, NFC_EVENT_0, NFC_EVENT_1.
     */
    void onEvent(void (*callback)(int), int source = NFC_EVENT_TX);
    /** @brief Number of interrupts of the active source since begin(). */
    unsigned long events();

    /** @brief Not for sketches: interrupt and core-loop hooks. */
    static void _isr(void *context, uint8_t idx);
    static void _service();

  private:
    bool started = false;
    uint8_t msg[ESMT_NFC_CAPACITY];
    size_t msgLen = 0;
    size_t lastRecord = 0;
    bool building = false;
    bool overflow = false;

    volatile unsigned long eventCount = 0;
    unsigned long eventSeen = 0;
    int eventSource = 0;
    void (*userEvent)(int) = nullptr;
    bool pending = false;
    unsigned long quietCount = 0;
    unsigned long quietSince = 0;

    bool readerActive();
    bool store();

    bool append(uint8_t tnf, const uint8_t *type, uint8_t typeLen, const uint8_t *prefix, size_t prefixLen,
                const uint8_t *payload, size_t payloadLen);
    bool writeMessage();
};

extern ESMTNFCClass NFC;

#endif /* ESMT_NFC_H */
