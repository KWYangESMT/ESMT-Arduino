/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"
#include "wiring_private.h"
#include "wise_gpio_api.h"
#include "wise_sys_api.h"

/* Arduino pin N is GPIO N. */
static bool _pin_valid(uint8_t pin)
{
    return pin < NUM_DIGITAL_PINS;
}

/* Last level given to digitalWrite() per pin, LOW until written. The GPIO
 * output register comes out of reset all HIGH, but an Arduino output starts
 * LOW (AVR: PORT is 0 at reset) unless the sketch wrote HIGH before
 * pinMode(OUTPUT). The public API can only write an output, so the pin shows
 * the old register value for the few cycles between the two calls. */
static uint32_t outLevel;

static void _set_out_level(uint8_t pin, uint8_t val)
{
    if (val == LOW) {
        outLevel &= ~(1UL << pin);
    } else {
        outLevel |= 1UL << pin;
    }
}

void esmtPinClaim(uint8_t pin)
{
    /* Until released, the system function owns the pin and the pin mux has
     * no effect on it (WISEDemoApp and the shell do the same). */
    if (pin == PIN_SYS_TCXO) {
        wise_sys_tcxo_config(false);
    } else if (pin == PIN_SYS_SWD_A || pin == PIN_SYS_SWD_B) {
        wise_sys_swd_config(false);
    }
}

void pinMode(uint8_t pin, uint8_t mode)
{
    if (!_pin_valid(pin)) {
        return;
    }

    /* The pin must be in GPIO function before its direction is set
     * (wise_gpio_set_direction()). This also detaches UART/SPI/I2C and PWM. */
    _esmt_pwm_detach(pin);
    esmtPinClaim(pin);
    wise_gpio_func_cfg(pin, MODE_PIO_FUNC_GPIO);

    switch (mode) {
    case OUTPUT:
        wise_gpio_set_pull_sel(pin, PUSEL_DISABLE);
        wise_gpio_set_direction(pin, GPIO_DIR_OUTPUT);
        wise_gpio_write(pin, (outLevel & (1UL << pin)) ? GPIO_HIGH : GPIO_LOW);
        break;

    case INPUT_PULLUP:
        wise_gpio_set_direction(pin, GPIO_DIR_INPUT);
        wise_gpio_set_pull_sel(pin, PUSEL_PULL_UP);
        break;

    case INPUT_PULLDOWN:
        wise_gpio_set_direction(pin, GPIO_DIR_INPUT);
        wise_gpio_set_pull_sel(pin, PUSEL_PULL_DOWN);
        break;

    case INPUT:
    default:
        wise_gpio_set_direction(pin, GPIO_DIR_INPUT);
        wise_gpio_set_pull_sel(pin, PUSEL_DISABLE);
        break;
    }
}

void digitalWrite(uint8_t pin, uint8_t val)
{
    if (!_pin_valid(pin)) {
        return;
    }

    /* As on other Arduino cores, digitalWrite() ends analogWrite() on the pin
     * and leaves it a plain output. */
    _set_out_level(pin, val);
    if (_esmt_pwm_detach(pin)) {
        wise_gpio_set_direction(pin, GPIO_DIR_OUTPUT);
    }
    /* On an input only the level is kept, for the next pinMode(OUTPUT). */
    if (wise_gpio_get_direction(pin) == GPIO_DIR_OUTPUT) {
        wise_gpio_write(pin, (val == LOW) ? GPIO_LOW : GPIO_HIGH);
    }
}

int digitalRead(uint8_t pin)
{
    if (!_pin_valid(pin)) {
        return LOW;
    }

    return (wise_gpio_read(pin) == GPIO_HIGH) ? HIGH : LOW;
}
