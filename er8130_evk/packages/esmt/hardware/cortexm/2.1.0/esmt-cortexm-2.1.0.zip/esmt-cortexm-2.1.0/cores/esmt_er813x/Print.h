/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef PRINT_H
#define PRINT_H

#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "Printable.h"

#define DEC 10
#define HEX 16
#define OCT 8
#define BIN 2

/* Flash and RAM share one address space on Cortex-M, so F() is a plain cast. */
class __FlashStringHelper;
class String;
#define F(string_literal) (reinterpret_cast<const __FlashStringHelper *>(string_literal))

/**
 * @brief Base class for anything that can print text and numbers.
 *
 * Derived classes implement write(uint8_t); everything else is built on it.
 */
class Print
{
  public:
    /* No virtual destructor (as in the AVR core): a trivial destructor lets
     * global Print objects such as Serial1 be constant-initialized, so unused
     * ones are dropped by the linker. Do not delete a derived object through
     * a Print pointer. */

    virtual size_t write(uint8_t c) = 0;
    virtual size_t write(const uint8_t *buffer, size_t size);
    size_t write(const char *str)
    {
        return (str == nullptr) ? 0 : write((const uint8_t *)str, strlen(str));
    }
    size_t write(const char *buffer, size_t size)
    {
        return write((const uint8_t *)buffer, size);
    }

    /** @brief Bytes that can be written without blocking; 0 if unknown. */
    virtual int availableForWrite()
    {
        return 0;
    }
    virtual void flush()
    {
    }

    int getWriteError()
    {
        return writeError;
    }
    void clearWriteError()
    {
        writeError = 0;
    }

    size_t print(const __FlashStringHelper *s);
    size_t print(const String &s);
    size_t print(const char *s);
    size_t print(char c);
    size_t print(unsigned char n, int base = DEC);
    size_t print(int n, int base = DEC);
    size_t print(unsigned int n, int base = DEC);
    size_t print(long n, int base = DEC);
    size_t print(unsigned long n, int base = DEC);
    size_t print(long long n, int base = DEC);
    size_t print(unsigned long long n, int base = DEC);
    size_t print(double n, int digits = 2);
    size_t print(const Printable &p);

    size_t println(void);
    size_t println(const __FlashStringHelper *s);
    size_t println(const String &s);
    size_t println(const char *s);
    size_t println(char c);
    size_t println(unsigned char n, int base = DEC);
    size_t println(int n, int base = DEC);
    size_t println(unsigned int n, int base = DEC);
    size_t println(long n, int base = DEC);
    size_t println(unsigned long n, int base = DEC);
    size_t println(long long n, int base = DEC);
    size_t println(unsigned long long n, int base = DEC);
    size_t println(double n, int digits = 2);
    size_t println(const Printable &p);

    /** @brief printf-style output (no float support in newlib-nano by default). */
    size_t printf(const char *format, ...) __attribute__((format(printf, 2, 3)));
    size_t vprintf(const char *format, va_list args);

  protected:
    void setWriteError(int err = 1)
    {
        writeError = err;
    }

  private:
    int writeError = 0;

    size_t printNumber(unsigned long long n, uint8_t base);
    size_t printSigned(long long n, int base);
    size_t printFloat(double number, uint8_t digits);
};

#endif /* PRINT_H */
