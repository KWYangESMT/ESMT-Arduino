// EEPROM boot counter: counts resets and uploads in EEPROM address 0.
// The value survives resets, power loss and new uploads.

#include <EEPROM.h>

void setup()
{
    Serial.begin(115200);

    if (!EEPROM.ok()) {
        Serial.println("EEPROM not available (the sketch was not started by the Arduino bootloader)");
        return;
    }

    uint32_t boots = 0;
    EEPROM.get(0, boots);
    if (boots == 0xFFFFFFFFUL) {
        boots = 0; /* blank EEPROM */
    }
    boots++;
    EEPROM.put(0, boots);

    Serial.print("Boot number ");
    Serial.print(boots);
    Serial.print(" (EEPROM size ");
    Serial.print(EEPROM.length());
    Serial.println(" bytes)");
}

void loop()
{
}
