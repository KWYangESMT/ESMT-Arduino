/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/**
 * @file interrupt.h
 * @brief sei() / cli() for libraries written for AVR boards.
 *
 * AVR interrupt vectors (ISR(), registers) have no equivalent; use
 * attachInterrupt() instead.
 */

#ifndef ESMT_AVR_INTERRUPT_H
#define ESMT_AVR_INTERRUPT_H

#define sei() __asm volatile("cpsie i" ::: "memory")
#define cli() __asm volatile("cpsid i" ::: "memory")

#endif /* ESMT_AVR_INTERRUPT_H */
