/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Print.h"

#include <math.h>
#include <stdio.h>

#include "WString.h"

size_t Print::write(const uint8_t *buffer, size_t size)
{
    size_t n = 0;

    while (size--) {
        if (write(*buffer++)) {
            n++;
        } else {
            break;
        }
    }

    return n;
}

/* ---------------------------------------------------------------- print */

size_t Print::print(const __FlashStringHelper *s)
{
    return print(reinterpret_cast<const char *>(s));
}

size_t Print::print(const String &s)
{
    return write(s.c_str(), s.length());
}

size_t Print::print(const char *s)
{
    return write(s);
}

size_t Print::print(char c)
{
    return write((uint8_t)c);
}

size_t Print::print(unsigned char n, int base)
{
    return print((unsigned long)n, base);
}

size_t Print::print(int n, int base)
{
    return print((long)n, base);
}

size_t Print::print(unsigned int n, int base)
{
    return print((unsigned long)n, base);
}

size_t Print::print(long n, int base)
{
    return printSigned(n, base);
}

size_t Print::print(unsigned long n, int base)
{
    if (base == 0) {
        return write((uint8_t)n);
    }

    return printNumber(n, (uint8_t)base);
}

size_t Print::print(long long n, int base)
{
    return printSigned(n, base);
}

size_t Print::print(unsigned long long n, int base)
{
    if (base == 0) {
        return write((uint8_t)n);
    }

    return printNumber(n, (uint8_t)base);
}

size_t Print::print(double n, int digits)
{
    return printFloat(n, (digits < 0) ? 2 : (uint8_t)digits);
}

size_t Print::print(const Printable &p)
{
    return p.printTo(*this);
}

/* -------------------------------------------------------------- println */

size_t Print::println(void)
{
    return write("\r\n");
}

size_t Print::println(const __FlashStringHelper *s)
{
    size_t len = print(s);
    return len + println();
}

size_t Print::println(const String &s)
{
    size_t len = print(s);
    return len + println();
}

size_t Print::println(const char *s)
{
    size_t len = print(s);
    return len + println();
}

size_t Print::println(char c)
{
    size_t len = print(c);
    return len + println();
}

size_t Print::println(unsigned char n, int base)
{
    size_t len = print(n, base);
    return len + println();
}

size_t Print::println(int n, int base)
{
    size_t len = print(n, base);
    return len + println();
}

size_t Print::println(unsigned int n, int base)
{
    size_t len = print(n, base);
    return len + println();
}

size_t Print::println(long n, int base)
{
    size_t len = print(n, base);
    return len + println();
}

size_t Print::println(unsigned long n, int base)
{
    size_t len = print(n, base);
    return len + println();
}

size_t Print::println(long long n, int base)
{
    size_t len = print(n, base);
    return len + println();
}

size_t Print::println(unsigned long long n, int base)
{
    size_t len = print(n, base);
    return len + println();
}

size_t Print::println(double n, int digits)
{
    size_t len = print(n, digits);
    return len + println();
}

size_t Print::println(const Printable &p)
{
    size_t len = print(p);
    return len + println();
}

/* --------------------------------------------------------------- printf */

size_t Print::printf(const char *format, ...)
{
    va_list args;
    size_t n;

    va_start(args, format);
    n = vprintf(format, args);
    va_end(args);

    return n;
}

size_t Print::vprintf(const char *format, va_list args)
{
    char buf[128];
    va_list copy;
    int len;

    va_copy(copy, args);
    len = vsnprintf(buf, sizeof(buf), format, copy);
    va_end(copy);

    if (len < 0) {
        return 0;
    }

    if ((size_t)len < sizeof(buf)) {
        return write((const uint8_t *)buf, (size_t)len);
    }

    /* Longer than the stack buffer: format into a heap buffer. */
    char *big = new char[len + 1];
    if (big == nullptr) {
        return 0;
    }

    vsnprintf(big, (size_t)len + 1, format, args);
    size_t n = write((const uint8_t *)big, (size_t)len);
    delete[] big;

    return n;
}

/* -------------------------------------------------------------- helpers */

size_t Print::printSigned(long long n, int base)
{
    if (base == 0) {
        return write((uint8_t)n);
    }

    if ((base == DEC) && (n < 0)) {
        size_t t = print('-');
        /* Negate in unsigned space so the most negative value is handled. */
        return t + printNumber(0ULL - (unsigned long long)n, DEC);
    }

    return printNumber((unsigned long long)n, (uint8_t)base);
}

size_t Print::printNumber(unsigned long long n, uint8_t base)
{
    char buf[8 * sizeof(n) + 1];
    char *str = &buf[sizeof(buf) - 1];

    *str = '\0';

    if (base < 2) {
        base = 10;
    }

    do {
        unsigned digit  = (unsigned)(n % base);
        n              /= base;
        *--str          = (char)((digit < 10) ? ('0' + digit) : ('A' + digit - 10));
    } while (n);

    return write(str);
}

size_t Print::printFloat(double number, uint8_t digits)
{
    size_t n = 0;

    if (isnan(number)) {
        return print("nan");
    }
    if (isinf(number)) {
        return print("inf");
    }
    if (number > 4294967040.0 || number < -4294967040.0) {
        return print("ovf");
    }

    if (number < 0.0) {
        n      += print('-');
        number  = -number;
    }

    /* Round to the requested number of digits. */
    double rounding = 0.5;
    for (uint8_t i = 0; i < digits; ++i) {
        rounding /= 10.0;
    }
    number += rounding;

    unsigned long intPart  = (unsigned long)number;
    double remainder       = number - (double)intPart;
    n                     += print(intPart);

    if (digits > 0) {
        n += print('.');
    }

    while (digits-- > 0) {
        remainder        *= 10.0;
        unsigned toPrint  = (unsigned)remainder;
        n                += print(toPrint);
        remainder        -= toPrint;
    }

    return n;
}
