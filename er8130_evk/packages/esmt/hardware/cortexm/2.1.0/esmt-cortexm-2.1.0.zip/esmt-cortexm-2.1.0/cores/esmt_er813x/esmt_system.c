/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/*
 * Chip start-up for Arduino sketches, written directly on the wise_core API.
 *
 * The core does not link the WISE middleware (wise_system, retarget, shell,
 * ctrl-cmd). The sequence below is the platform part of wise_init():
 * _platform_init() in middleware/wise_system/wise_common.c. When that function
 * changes, change this one with it.
 *
 * Left out on purpose, because no Arduino API uses them: chip-unique address
 * (wise_get_device_addr), event queue and scheduler (wise_event / wise_schlr),
 * power management, and sleep/restore of the UART settings.
 */

#include <stdio.h>

#include "Arduino.h"
#include "wiring_private.h"

#include "wise_core.h"
#include "wise_efuse_api.h"
#include "wise_flash_api.h"
#include "wise_gpio_api.h"
#include "wise_nfc_api.h"
#include "wise_sys_api.h"
#include "wise_tick_api.h"
#include "wise_wdt_api.h"
#include "wise_wutmr_api.h"

/* Board values come from the SDK's board header, with the SDK defaults
 * (wise_cfg_check.h, configuration only) for anything it leaves out. */
#if defined(BOARD_CONFIG_FILE)
#include BOARD_CONFIG_FILE
#else
#include "board_default_cfg.h"
#endif
#include "wise_cfg_check.h"

/* Watchdog timeout set before setup(); 0 = off. boards.txt: Tools > Watchdog. */
#ifndef ESMT_WDT_TIMEOUT_MS
#define ESMT_WDT_TIMEOUT_MS 2000
#endif

/* No peripheral uses DMA in the Arduino core yet. */
static const uint8_t dmaChannelMap[SYS_DMA_CHANNEL_NUM] = {DMA_CH0_FUNC, DMA_CH1_FUNC, DMA_CH2_FUNC, DMA_CH3_FUNC, DMA_CH4_FUNC, DMA_CH5_FUNC};

static const WISE_SYS_BOARD_PROPERTY_T boardProperty = {
    .tcxo_output_en       = BOARD_TCXO_OUTPUT_EN,
    .pa_type              = BOARD_PA_TYPE,
    .matching_type        = BOARD_BAND_MATCHING,
    .gain_ctrl_40m        = BOARD_40M_GAIN_CTRL,
    .gain_ctrl_40m_s      = BOARD_40M_GAIN_CTRL_S,
    .cap_xtal_i           = BOARD_40M_CAP_XTAL_I,
    .cap_xtal_o           = BOARD_40M_CAP_XTAL_O,
    .maincap_xtal_i       = BOARD_40M_MAINCAP_I_EN,
    .maincap_xtal_o       = BOARD_40M_MAINCAP_O_EN,
    .cap_lpxtal_i         = BOARD_32K_CAP_LPXTAL_I,
    .cap_lpxtal_o         = BOARD_32K_CAP_LPXTAL_O,
    .maincap_lpxtal_i     = BOARD_32K_MAINCAP_I_EN,
    .maincap_lpxtal_o     = BOARD_32K_MAINCAP_O_EN,
    .gain_lpxtal          = BOARD_32K_LPXTAL_GAIN,
    .sram_retain          = BOARD_SRAM_RETAIN,
    .ext32k_lp_workaround = BOARD_EXT32K_LP_WORKAROUND,
    .ulpldo_vref          = BOARD_ULPLDO_VREF,
    .ulpldo_enmode        = BOARD_ULPLDO_ENMODE,
};

/* UART is not up during the platform steps, so a failure is kept and
 * reported once Serial can print (same idea as wise_boot_fault_record()). */
static const char *bootFaultStage;
static int32_t bootFaultStatus;
static uint32_t bootFaultNum;

static void _boot_check(const char *stage, int32_t status)
{
    if (WISE_SUCCESS == status) {
        return;
    }
    if (0U == bootFaultNum) {
        bootFaultStage  = stage;
        bootFaultStatus = status;
    }
    bootFaultNum++;
}

static void _platform_init(void)
{
    WISE_LFOSC_SRC_T oscCfg = {
        .clk_src          = ES_DEVICE_LFOSC_SELECT,
        .mode.mode_select = ES_DEVICE_LFOSC_OPTION,
        .calFinish        = 0,
    };

    _boot_check("wise_core_init", (int32_t)wise_core_init());

    wise_sys_set_board_property(&boardProperty);

    _boot_check("lfosc_clk_src_config", wise_sys_lfosc_clk_src_config(oscCfg));
    _boot_check("lfosc_clk_calibration", wise_sys_lfosc_clk_calibration());
    _boot_check("wutmr_init", wise_wutmr_init());
    wise_wutmr_enable();

    wise_sys_init_dma_channel(dmaChannelMap);
    wise_sys_dma_channel_export();

    wise_gpio_init();
    _boot_check("tick_init", wise_tick_init());
    wise_flash_init();
    wise_efuse_init();

#if (defined BOARD_BOD_ENALBE) && (BOARD_BOD_ENALBE == 1)
#ifdef BOARD_BOD_DG_PERIOD
    wise_sys_config_bod_deglitch(1, BOARD_BOD_DG_PERIOD);
#endif
    wise_sys_enable_bod(BOARD_BOD_LEVEL, 1);
#endif

    /* NFC starts in passive power mode for lower consumption. */
    wise_nfc_switch_pwr_src(NFC_PWR_MODE_PASSIVE);
}

void _esmt_system_init(void)
{
    _platform_init();

    /* UART0 at 115200 8N1 before setup(), so printf() and the HardFault
     * report work even if the sketch never calls Serial.begin(). */
    _esmt_serial_init();

    if (bootFaultNum != 0U) {
        printf("\n[esmt] %lu boot fault(s), first: %s status=%ld\n", (unsigned long)bootFaultNum, bootFaultStage, (long)bootFaultStatus);
    }

    esmtWatchdogEnable(ESMT_WDT_TIMEOUT_MS);
}

void _esmt_system_service(void)
{
    wise_sys_proc();
    esmtWatchdogFeed();
}

/* ------------------------------------------------------------------------- */
/*                                  Watchdog                                 */
/* ------------------------------------------------------------------------- */
/*
 * CMSDK watchdog: the first timeout raises the WDT interrupt, the second one
 * (interrupt still pending) resets the chip. No handler clears it, so a stuck
 * sketch is reset about 2 x timeout after the last feed.
 */
static uint8_t wdtRunning;
static unsigned long wdtTimeoutMs;

void esmtWatchdogEnable(unsigned long timeout_ms)
{
    if (0UL == timeout_ms) {
        esmtWatchdogDisable();
        return;
    }

    wise_wdt_config(WDT_RESET_ENABLE, (uint32_t)timeout_ms);
    wise_wdt_start();
    wdtRunning   = 1;
    wdtTimeoutMs = timeout_ms;
}

void esmtWatchdogDisable(void)
{
    if (wdtRunning) {
        wise_wdt_stop();
        wise_wdt_deinit();
        wdtRunning = 0;
    }
}

void esmtWatchdogFeed(void)
{
    if (wdtRunning) {
        wise_wdt_set_refresh();
    }
}

/* ------------------------------------------------------------------------- */
/*                                Low power                                  */
/* ------------------------------------------------------------------------- */
/*
 * Around a sleep: the watchdog is paused (a sleep may be longer than its
 * timeout), Serial finishes sending, and after the wake the UARTs that a
 * sleep powers down are configured again. Time across the sleep is restored
 * by wise_core (tick from the wake-up timer, see wiring_time.c).
 */
static unsigned long sleepWdtMs;

void esmtLowPowerEnter(void)
{
    _esmt_serial_flush_all();
    sleepWdtMs = wdtRunning ? wdtTimeoutMs : 0UL;
    esmtWatchdogDisable();
}

void esmtLowPowerExit(bool peripheralsOff)
{
    if (peripheralsOff) {
        _esmt_serial_restore_all();
    }
    _esmt_time_refresh();
    if (sleepWdtMs != 0UL) {
        esmtWatchdogEnable(sleepWdtMs);
    }
}

/* ------------------------------------------------------------------------- */
/*                              Upload escape                                */
/* ------------------------------------------------------------------------- */
/*
 * The uploader (tools/esmt_upload.py, ESCAPE) sends this sequence on the
 * Serial UART. Every received byte passes through here inside the UART RX
 * interrupt, so the chip resets into the loader even when loop() is stuck,
 * as long as interrupts are on. ESC appears only at the start, so a mismatch
 * can restart the match without backtracking.
 */
static const char uploadEscape[] = "\x1b[ESMT-UPLOAD-9006]";
static uint8_t escapePos;

void _esmt_upload_escape_feed(uint8_t c)
{
    if ((uint8_t)uploadEscape[escapePos] == c) {
        escapePos++;
        if (escapePos == (sizeof(uploadEscape) - 1U)) {
            wise_sys_chip_reset();
        }
    } else {
        escapePos = ((uint8_t)uploadEscape[0] == c) ? 1U : 0U;
    }
}
