// SlaveSender: this board is I2C slave 0x08 with two "registers".
//
//   register 0: uptime in seconds (4 bytes, little-endian)
//   register 1: a counter the master can set (1 byte)
//
// The master writes the register number (and, for register 1, a new value),
// then reads: Wire.beginTransmission(8); Wire.write(0); Wire.endTransmission();
// Wire.requestFrom(8, 4);
//
// End the write with a STOP (plain endTransmission()) so the whole reply
// belongs to the register just selected: this core prepares a reply ahead of
// the read, see Wire.h. Wiring as in SlaveReceiver.

#include <Wire.h>

volatile uint8_t selected;
volatile uint8_t counter;

void receiveEvent(int count)
{
    if (count >= 1) {
        selected = (uint8_t)Wire.read();
    }
    if (count >= 2 && selected == 1) {
        counter = (uint8_t)Wire.read();
    }
    while (Wire.available()) {
        Wire.read();
    }
}

// Fills the reply for the next read; can run more than once per read.
void requestEvent()
{
    if (selected == 0) {
        uint32_t seconds = millis() / 1000;
        Wire.write((const uint8_t *)&seconds, sizeof(seconds));
    } else {
        Wire.write(counter);
    }
}

void setup()
{
    Serial.begin(115200);
    Wire.begin(8);
    Wire.onReceive(receiveEvent);
    Wire.onRequest(requestEvent);
    Serial.println(F("I2C slave 0x08: register 0 uptime, register 1 counter"));
}

void loop()
{
    delay(10);
}
