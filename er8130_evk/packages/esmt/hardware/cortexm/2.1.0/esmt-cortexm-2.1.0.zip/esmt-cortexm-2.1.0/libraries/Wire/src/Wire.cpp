/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Wire.h"

extern "C" {
#include "wise_core.h"
#include "wise_gpio_api.h"
#include "wise_i2c_api.h"
}

/*
 * Built on wise_i2c_transfer() and wise_i2c_probe().
 *
 * Limitation of the current WISE I2C API: wise_i2c_transfer() reports a bus
 * error or timeout but not a NACK from the slave, so a write with data to an
 * absent device still returns 0 here. Only zero-length writes (the usual
 * "is a device at this address?" check) go through wise_i2c_probe(), which
 * sees the ACK - and which sends one 0x00 data byte when the device answers.
 */

TwoWire Wire(WIRE_INTERFACE, PIN_WIRE_SDA, PIN_WIRE_SCL);

#define I2C_CHANNELS 2
#define SLAVE_STUCK_MS 500 /* wise_i2c_slave_proc(): recover a transaction that never ends */

static bool i2cInited;                /* wise_i2c_init() resets every channel: call it once */
static TwoWire *slaves[I2C_CHANNELS]; /* channels in slave mode, for serviceAll() */

TwoWire::TwoWire(uint8_t ch, uint8_t sda, uint8_t scl) : channel(ch), pinSda(sda), pinScl(scl)
{
}

void TwoWire::setPins(uint8_t sda, uint8_t scl)
{
    if (!started) {
        pinSda = sda;
        pinScl = scl;
    }
}

void TwoWire::configure()
{
    WISE_I2C_CONF_T cfg;

    memset(&cfg, 0, sizeof(cfg));
    cfg.i2c_idx        = channel;
    cfg.role           = slaveAddress ? I2C_SLAVE : I2C_MASTER;
    cfg.i2cEn          = I2C_ENABLE;
    cfg.dmaEn          = 0;
    cfg.speedMode      = (busHz <= 100000UL) ? E_I2C_CLOCK_SEL_100K : (busHz <= 400000UL) ? E_I2C_CLOCK_SEL_400K : E_I2C_CLOCK_SEL_1M;
    cfg.bus_hz         = busHz;
    cfg.addressing     = I2C_ADDR_7_BITS;
    cfg.dir            = slaveAddress ? 0 : 1; /* slave receiver / master transmitter */
    cfg.target_address = slaveAddress;

    (void)wise_i2c_config(channel, &cfg);
}

void TwoWire::begin()
{
    if (started && slaveAddress != 0) {
        end(); /* slave -> master */
    }
    if (started) {
        return;
    }
    start();
    configure();
}

void TwoWire::begin(uint8_t address)
{
    address &= 0x7F;
    if (address == 0 || channel >= I2C_CHANNELS) {
        return; /* 0 is the general call address */
    }
    if (started) {
        end();
    }
    slaveAddress = address;
    start();
    configure();

    wise_i2c_register_event_callback(channel, slaveEvent, this);
    wise_i2c_slave_set_timeout(channel, SLAVE_STUCK_MS);
    slavePrepareReply();
    slaves[channel] = this;
    esmtAddService(serviceAll);
    slaveNeedArm = true;
    slaveArm();
}

void TwoWire::start()
{
    if (!i2cInited) {
        wise_i2c_init();
        i2cInited = true;
    }
    wise_i2c_open(channel);

    esmtPinClaim(pinScl);
    esmtPinClaim(pinSda);
    wise_gpio_func_cfg(pinScl, (channel == 0) ? MODE_PIO_FUNC_I2C0_SCL : MODE_PIO_FUNC_I2C1_SCL);
    wise_gpio_func_cfg(pinSda, (channel == 0) ? MODE_PIO_FUNC_I2C0_SDA : MODE_PIO_FUNC_I2C1_SDA);
    /* weak internal pull-ups; real buses still need external resistors */
    wise_gpio_set_pull_sel(pinScl, PUSEL_PULL_UP);
    wise_gpio_set_pull_sel(pinSda, PUSEL_PULL_UP);

    started        = true;
    pendingRestart = false;
    transmitting   = false;
    rxLength = rxIndex = 0;
}

void TwoWire::end()
{
    if (!started) {
        return;
    }
    if (slaveAddress != 0) {
        slaves[channel] = nullptr;
        wise_i2c_unregister_event_callback(channel);
        wise_i2c_slave_set_timeout(channel, 0);
        slaveAddress = 0;
        slaveBusy = slaveNeedArm = slaveReceived = false;
    }
    wise_i2c_close(channel);
    wise_gpio_func_cfg(pinScl, MODE_PIO_FUNC_GPIO);
    wise_gpio_func_cfg(pinSda, MODE_PIO_FUNC_GPIO);
    started = false;
}

void TwoWire::setClock(uint32_t hz)
{
    if (hz == 0) {
        return;
    }
    busHz = hz;
    if (started) {
        (void)wise_i2c_set_timing_profile(channel, hz);
    }
}

void TwoWire::setWireTimeout(uint32_t timeout_us, bool reset_with_timeout)
{
    timeoutMs      = (timeout_us == 0) ? 1000UL : (timeout_us + 999UL) / 1000UL;
    resetOnTimeout = reset_with_timeout;
}

void TwoWire::failed()
{
    timeoutFlag = true;
    if (resetOnTimeout && started && slaveAddress == 0) {
        configure();
    }
}

void TwoWire::beginTransmission(uint8_t address)
{
    if (pendingRestart) {
        /* the held-back write was not followed by requestFrom(): send it now */
        (void)sendWrite(true);
    }
    txAddress    = address;
    txLength     = 0;
    txOverflow   = false;
    transmitting = true;
}

uint8_t TwoWire::sendWrite(bool sendStop)
{
    WISE_I2C_XFER_MSG_T msg;

    pendingRestart = false;
    if (!started || slaveAddress != 0) {
        return 4;
    }

    if (txLength == 0) {
        /* address check only */
        return (WISE_SUCCESS == wise_i2c_probe(channel, txAddress, timeoutMs)) ? 0 : 2;
    }

    msg.addr  = txAddress;
    msg.flags = sendStop ? 0 : WISE_I2C_M_NO_STOP;
    msg.buf   = txBuffer;
    msg.len   = (uint16_t)txLength;
    if (WISE_SUCCESS != wise_i2c_transfer(channel, &msg, 1, timeoutMs)) {
        failed();
        return 4;
    }
    return 0;
}

uint8_t TwoWire::endTransmission(bool sendStop)
{
    if (!transmitting) {
        return 4;
    }
    transmitting = false;
    if (txOverflow) {
        txLength = 0;
        return 1;
    }
    if (!sendStop && txLength > 0) {
        /* sent together with the next requestFrom() (repeated START) */
        pendingRestart = true;
        return 0;
    }
    return sendWrite(true);
}

size_t TwoWire::requestFrom(uint8_t address, size_t quantity, bool sendStop)
{
    WISE_I2C_XFER_MSG_T msgs[2];
    size_t n = 0;

    rxLength = rxIndex = 0;
    if (!started || slaveAddress != 0 || quantity == 0) {
        pendingRestart = false;
        return 0;
    }
    if (quantity > WIRE_BUFFER_SIZE) {
        quantity = WIRE_BUFFER_SIZE;
    }

    if (pendingRestart && txAddress == address) {
        msgs[n].addr  = address;
        msgs[n].flags = 0;
        msgs[n].buf   = txBuffer;
        msgs[n].len   = (uint16_t)txLength;
        n++;
    } else if (pendingRestart) {
        (void)sendWrite(true);
    }
    pendingRestart = false;

    msgs[n].addr  = address;
    msgs[n].flags = (uint16_t)(WISE_I2C_M_RD | (sendStop ? 0 : WISE_I2C_M_NO_STOP));
    msgs[n].buf   = rxBuffer;
    msgs[n].len   = (uint16_t)quantity;
    n++;

    if (WISE_SUCCESS != wise_i2c_transfer(channel, msgs, n, timeoutMs)) {
        failed();
        return 0;
    }

    rxLength = quantity;
    return quantity;
}

size_t TwoWire::write(uint8_t data)
{
    if (!transmitting && !inRequest) {
        return 0;
    }
    if (txLength >= WIRE_BUFFER_SIZE) {
        txOverflow = true;
        setWriteError();
        return 0;
    }
    txBuffer[txLength++] = data;
    return 1;
}

size_t TwoWire::write(const uint8_t *data, size_t quantity)
{
    size_t n = 0;

    while (n < quantity && write(data[n])) {
        n++;
    }
    return n;
}

int TwoWire::available()
{
    return (int)(rxLength - rxIndex);
}

int TwoWire::read()
{
    return (rxIndex < rxLength) ? rxBuffer[rxIndex++] : -1;
}

int TwoWire::peek()
{
    return (rxIndex < rxLength) ? rxBuffer[rxIndex] : -1;
}

/* ---------------------------------------------------------------------------
 * Slave mode
 *
 * Driver events (I2C interrupt):
 *   ADDRESS_HIT   a transaction starts. For a master read after a write with
 *                 a repeated START, the written bytes are already in the
 *                 receive buffer (rx count > 0) and no TRANSFER_DONE came
 *                 between: deliver them now. Byte 0 of the reply has already
 *                 been loaded from the buffer set by wise_i2c_slave_set_tx_buf().
 *   TRANSFER_DONE the master sent STOP: deliver a write that is still pending,
 *                 prepare the reply for the next read and ask the core loop to
 *                 re-arm the receive path (as WISEDemoApp's demo_i2c does; the
 *                 driver re-arm is not made for interrupt context).
 * ------------------------------------------------------------------------- */

void TwoWire::onReceive(void (*handler)(int))
{
    userReceive = handler;
}

void TwoWire::onRequest(void (*handler)(void))
{
    userRequest = handler;
    if (slaveAddress != 0 && !slaveBusy) {
        slavePrepareReply();
    }
}

void TwoWire::slaveDeliver(uint8_t count)
{
    if (count > WIRE_BUFFER_SIZE) {
        count = WIRE_BUFFER_SIZE;
    }
    slaveReceived = true;
    rxLength      = count;
    rxIndex       = 0;
    if (userReceive) {
        userReceive(count);
    }
}

void TwoWire::slavePrepareReply()
{
    txLength   = 0;
    txOverflow = false;
    inRequest  = true;
    if (userRequest) {
        userRequest();
    }
    inRequest = false;
    if (txLength == 0) {
        txBuffer[0] = 0xFF; /* nothing to say: what an idle bus reads anyway */
        txLength    = 1;
    }
    wise_i2c_slave_set_tx_buf(channel, txBuffer, (uint16_t)txLength);
}

void TwoWire::slaveEvent(uint8_t ch, uint32_t event, void *context)
{
    TwoWire *w = static_cast<TwoWire *>(context);
    uint8_t count;

    (void)ch;
    if (w == nullptr || w->slaveAddress == 0) {
        return;
    }
    count = wise_i2c_slave_get_rx_count(w->channel);

    if (event == WISE_I2C_EVENT_ADDRESS_HIT) {
        if (count == 0) {
            /* A new transaction, nothing received yet. The driver sends no
             * TRANSFER_DONE after the slave has sent a reply, so after a read
             * the core has not re-armed and slaveReceived is still set from
             * the write before it; TRANSFER_DONE would then drop this write. */
            w->slaveReceived = false;
        }
        w->slaveBusy = true;
        if (count > 0 && !w->slaveReceived) {
            /* read after a write with a repeated START */
            w->slaveDeliver(count);
            w->slavePrepareReply();
        }
    } else if (event == WISE_I2C_EVENT_TRANSFER_DONE) {
        if (count > 0 && !w->slaveReceived) {
            w->slaveDeliver(count);
        }
        w->slavePrepareReply();
        w->slaveBusy    = false;
        w->slaveNeedArm = true;
    }
}

void TwoWire::slaveArm()
{
    noInterrupts();
    if (!slaveNeedArm || slaveBusy) {
        /* nothing to do, or a new transaction started before the re-arm:
         * wait for its TRANSFER_DONE */
        interrupts();
        return;
    }
    slaveNeedArm  = false;
    slaveReceived = false;
    /* masks interrupts itself while it sets up the driver */
    (void)wise_i2c_slave_arm_rx(channel, rxBuffer, WIRE_BUFFER_SIZE);
    interrupts();
}

void TwoWire::slaveService()
{
    if (wise_i2c_slave_proc(channel) == 1) {
        /* bus stuck: the driver reconfigured the channel and re-armed it */
        noInterrupts();
        slaveBusy     = false;
        slaveNeedArm  = false;
        slaveReceived = false;
        interrupts();
        return;
    }
    slaveArm();
}

void TwoWire::serviceAll()
{
    for (int i = 0; i < I2C_CHANNELS; i++) {
        if (slaves[i] != nullptr) {
            slaves[i]->slaveService();
        }
    }
}
