/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "WString.h"

#include <ctype.h>
#include <stdlib.h>

#include "Print.h"

/* Appends everything printed to a String, so number formatting reuses Print. */
class StringAppender: public Print
{
  public:
    explicit StringAppender(String &s) : target(s)
    {
    }
    size_t write(uint8_t c) override
    {
        return target.concat((char)c) ? 1 : 0;
    }
    size_t write(const uint8_t *data, size_t size) override
    {
        return target.concat(data, (unsigned int)size) ? size : 0;
    }

  private:
    String &target;
};

/* ------------------------------------------------------------------------- */
/*                         construction and storage                          */
/* ------------------------------------------------------------------------- */
String::String(const char *cstr)
{
    if (cstr) {
        copy(cstr, (unsigned int)strlen(cstr));
    }
}

String::String(const char *cstr, unsigned int length)
{
    if (cstr) {
        copy(cstr, length);
    }
}

String::String(const String &other)
{
    *this = other;
}

String::String(String &&other) noexcept
{
    *this = static_cast<String &&>(other);
}

String::String(const __FlashStringHelper *str) : String(reinterpret_cast<const char *>(str))
{
}

String::String(char c)
{
    char s[2] = {c, '\0'};
    copy(s, 1);
}

String::String(unsigned char value, unsigned char base) : String((unsigned long)value, base)
{
}
String::String(int value, unsigned char base) : String((long)value, base)
{
}
String::String(unsigned int value, unsigned char base) : String((unsigned long)value, base)
{
}
String::String(long value, unsigned char base) : String((long long)value, base)
{
}
String::String(unsigned long value, unsigned char base) : String((unsigned long long)value, base)
{
}

String::String(long long value, unsigned char base)
{
    copy("", 0);
    concatPrinted(value, base);
}

String::String(unsigned long long value, unsigned char base)
{
    copy("", 0);
    concatPrinted(value, base);
}

String::String(float value, unsigned char decimalPlaces) : String((double)value, decimalPlaces)
{
}

String::String(double value, unsigned char decimalPlaces)
{
    copy("", 0);
    concatPrinted(value, decimalPlaces);
}

String::~String()
{
    free(buffer);
}

void String::invalidate()
{
    free(buffer);
    buffer = nullptr;
    cap    = 0;
    len    = 0;
}

bool String::grow(unsigned int size)
{
    char *p = (char *)realloc(buffer, size + 1U);

    if (!p) {
        return false;
    }
    buffer = p;
    cap    = size;
    return true;
}

bool String::reserve(unsigned int size)
{
    if (buffer && cap >= size) {
        return true;
    }
    if (!grow(size)) {
        return false;
    }
    if (len == 0) {
        buffer[0] = '\0';
    }
    return true;
}

String &String::copy(const char *cstr, unsigned int length)
{
    if (!reserve(length)) {
        invalidate();
        return *this;
    }
    memmove(buffer, cstr, length);
    len         = length;
    buffer[len] = '\0';
    return *this;
}

String &String::operator=(const String &rhs)
{
    if (this == &rhs) {
        return *this;
    }
    if (rhs.buffer) {
        copy(rhs.buffer, rhs.len);
    } else {
        invalidate();
    }
    return *this;
}

String &String::operator=(String &&rhs) noexcept
{
    if (this != &rhs) {
        free(buffer);
        buffer     = rhs.buffer;
        cap        = rhs.cap;
        len        = rhs.len;
        rhs.buffer = nullptr;
        rhs.cap    = 0;
        rhs.len    = 0;
    }
    return *this;
}

String &String::operator=(const char *cstr)
{
    if (cstr) {
        copy(cstr, (unsigned int)strlen(cstr));
    } else {
        invalidate();
    }
    return *this;
}

String &String::operator=(const __FlashStringHelper *str)
{
    return *this = reinterpret_cast<const char *>(str);
}

/* ------------------------------------------------------------------------- */
/*                                  concat                                   */
/* ------------------------------------------------------------------------- */
bool String::concat(const char *cstr, unsigned int length)
{
    unsigned int newLen = len + length;

    if (!cstr) {
        return false;
    }
    if (length == 0) {
        return buffer != nullptr || reserve(0);
    }
    /* cstr may point into our own buffer, which reserve() can move */
    if (buffer && cstr >= buffer && cstr < buffer + len) {
        unsigned int offset = (unsigned int)(cstr - buffer);
        if (!reserve(newLen)) {
            return false;
        }
        cstr = buffer + offset;
    } else if (!reserve(newLen)) {
        return false;
    }
    memmove(buffer + len, cstr, length);
    len         = newLen;
    buffer[len] = '\0';
    return true;
}

bool String::concat(const String &str)
{
    return str.buffer ? concat(str.buffer, str.len) : false;
}

bool String::concat(const char *cstr)
{
    return cstr ? concat(cstr, (unsigned int)strlen(cstr)) : false;
}

bool String::concat(const __FlashStringHelper *str)
{
    return concat(reinterpret_cast<const char *>(str));
}

bool String::concat(char c)
{
    return concat(&c, 1);
}

template <typename T> bool String::concatPrinted(T value, int arg)
{
    StringAppender out(*this);
    unsigned int before = len;

    out.print(value, arg);
    return buffer != nullptr && len > before;
}

bool String::concat(unsigned char value)
{
    return concatPrinted((unsigned long)value, 10);
}
bool String::concat(int value)
{
    return concatPrinted((long)value, 10);
}
bool String::concat(unsigned int value)
{
    return concatPrinted((unsigned long)value, 10);
}
bool String::concat(long value)
{
    return concatPrinted(value, 10);
}
bool String::concat(unsigned long value)
{
    return concatPrinted(value, 10);
}
bool String::concat(long long value)
{
    return concatPrinted(value, 10);
}
bool String::concat(unsigned long long value)
{
    return concatPrinted(value, 10);
}
bool String::concat(float value)
{
    return concatPrinted((double)value, 2);
}
bool String::concat(double value)
{
    return concatPrinted(value, 2);
}

/* ------------------------------------------------------------------------- */
/*                                comparison                                 */
/* ------------------------------------------------------------------------- */
int String::compareTo(const char *cstr) const
{
    return strcmp(c_str(), cstr ? cstr : "");
}

int String::compareTo(const String &s) const
{
    return compareTo(s.c_str());
}

bool String::equals(const String &s) const
{
    return len == s.len && compareTo(s) == 0;
}

bool String::equals(const char *cstr) const
{
    return compareTo(cstr) == 0;
}

bool String::equalsIgnoreCase(const String &s) const
{
    if (len != s.len) {
        return false;
    }
    for (unsigned int i = 0; i < len; i++) {
        if (tolower((unsigned char)buffer[i]) != tolower((unsigned char)s.buffer[i])) {
            return false;
        }
    }
    return true;
}

bool String::startsWith(const String &prefix, unsigned int offset) const
{
    if (offset > len || prefix.len > len - offset) {
        return false;
    }
    return strncmp(c_str() + offset, prefix.c_str(), prefix.len) == 0;
}

bool String::startsWith(const String &prefix) const
{
    return startsWith(prefix, 0);
}

bool String::endsWith(const String &suffix) const
{
    if (suffix.len > len) {
        return false;
    }
    return strcmp(c_str() + len - suffix.len, suffix.c_str()) == 0;
}

/* ------------------------------------------------------------------------- */
/*                                characters                                 */
/* ------------------------------------------------------------------------- */
char String::charAt(unsigned int index) const
{
    return (index < len) ? buffer[index] : '\0';
}

void String::setCharAt(unsigned int index, char c)
{
    if (index < len) {
        buffer[index] = c;
    }
}

char String::operator[](unsigned int index) const
{
    return charAt(index);
}

char &String::operator[](unsigned int index)
{
    static char dummy;

    if (index >= len) {
        dummy = '\0';
        return dummy;
    }
    return buffer[index];
}

void String::getBytes(unsigned char *buf, unsigned int bufsize, unsigned int index) const
{
    unsigned int n;

    if (!buf || bufsize == 0) {
        return;
    }
    if (index >= len) {
        buf[0] = '\0';
        return;
    }
    n = len - index;
    if (n > bufsize - 1U) {
        n = bufsize - 1U;
    }
    memcpy(buf, buffer + index, n);
    buf[n] = '\0';
}

/* ------------------------------------------------------------------------- */
/*                                  search                                   */
/* ------------------------------------------------------------------------- */
int String::indexOf(char ch, unsigned int fromIndex) const
{
    const char *p;

    if (fromIndex >= len) {
        return -1;
    }
    p = (const char *)memchr(buffer + fromIndex, ch, len - fromIndex);
    return p ? (int)(p - buffer) : -1;
}

int String::indexOf(char ch) const
{
    return indexOf(ch, 0);
}

int String::indexOf(const String &str, unsigned int fromIndex) const
{
    const char *p;

    if (fromIndex > len || str.len > len) {
        return -1;
    }
    p = strstr(c_str() + fromIndex, str.c_str());
    return p ? (int)(p - c_str()) : -1;
}

int String::indexOf(const String &str) const
{
    return indexOf(str, 0);
}

int String::lastIndexOf(char ch, unsigned int fromIndex) const
{
    if (len == 0) {
        return -1;
    }
    if (fromIndex >= len) {
        fromIndex = len - 1;
    }
    for (int i = (int)fromIndex; i >= 0; i--) {
        if (buffer[i] == ch) {
            return i;
        }
    }
    return -1;
}

int String::lastIndexOf(char ch) const
{
    return lastIndexOf(ch, len ? len - 1 : 0);
}

int String::lastIndexOf(const String &str, unsigned int fromIndex) const
{
    if (str.len == 0 || str.len > len) {
        return -1;
    }
    if (fromIndex > len - str.len) {
        fromIndex = len - str.len;
    }
    for (int i = (int)fromIndex; i >= 0; i--) {
        if (strncmp(buffer + i, str.buffer, str.len) == 0) {
            return i;
        }
    }
    return -1;
}

int String::lastIndexOf(const String &str) const
{
    return lastIndexOf(str, len);
}

String String::substring(unsigned int beginIndex, unsigned int endIndex) const
{
    if (beginIndex > endIndex) {
        unsigned int t = beginIndex;
        beginIndex     = endIndex;
        endIndex       = t;
    }
    if (endIndex > len) {
        endIndex = len;
    }
    if (beginIndex >= endIndex) {
        return String();
    }
    return String(buffer + beginIndex, endIndex - beginIndex);
}

/* ------------------------------------------------------------------------- */
/*                               modification                                */
/* ------------------------------------------------------------------------- */
void String::replace(char find, char replaceWith)
{
    for (unsigned int i = 0; i < len; i++) {
        if (buffer[i] == find) {
            buffer[i] = replaceWith;
        }
    }
}

void String::replace(const String &find, const String &replaceWith)
{
    String result;
    unsigned int pos = 0;
    int hit;

    if (len == 0 || find.len == 0) {
        return;
    }
    if (!result.reserve(len)) {
        return;
    }
    while ((hit = indexOf(find, pos)) >= 0) {
        result.concat(buffer + pos, (unsigned int)hit - pos);
        result.concat(replaceWith);
        pos = (unsigned int)hit + find.len;
    }
    result.concat(buffer + pos, len - pos);
    if (result.buffer) {
        *this = static_cast<String &&>(result);
    }
}

void String::remove(unsigned int index, unsigned int count)
{
    if (index >= len || count == 0) {
        return;
    }
    if (count > len - index) {
        count = len - index;
    }
    memmove(buffer + index, buffer + index + count, len - index - count + 1U);
    len -= count;
}

void String::remove(unsigned int index)
{
    remove(index, (unsigned int)-1);
}

void String::toLowerCase()
{
    for (unsigned int i = 0; i < len; i++) {
        buffer[i] = (char)tolower((unsigned char)buffer[i]);
    }
}

void String::toUpperCase()
{
    for (unsigned int i = 0; i < len; i++) {
        buffer[i] = (char)toupper((unsigned char)buffer[i]);
    }
}

void String::trim()
{
    unsigned int start = 0;
    unsigned int stop  = len;

    if (len == 0) {
        return;
    }
    while (start < stop && isspace((unsigned char)buffer[start])) {
        start++;
    }
    while (stop > start && isspace((unsigned char)buffer[stop - 1])) {
        stop--;
    }
    len = stop - start;
    if (start) {
        memmove(buffer, buffer + start, len);
    }
    buffer[len] = '\0';
}

/* ------------------------------------------------------------------------- */
/*                                  parsing                                  */
/* ------------------------------------------------------------------------- */
long String::toInt() const
{
    return strtol(c_str(), nullptr, 10);
}

float String::toFloat() const
{
    return (float)toDouble();
}

double String::toDouble() const
{
    return strtod(c_str(), nullptr);
}
