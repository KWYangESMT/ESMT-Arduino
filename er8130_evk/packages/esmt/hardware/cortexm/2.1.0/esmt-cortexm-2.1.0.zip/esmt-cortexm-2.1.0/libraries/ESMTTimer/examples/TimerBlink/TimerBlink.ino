// Blinks LED_BUILTIN from a timer interrupt while loop() prints how many
// times it toggled. Written for the TimerOne library: it builds unchanged.

#include <TimerOne.h>

volatile unsigned long toggles;

void blink()
{
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
    toggles++;
}

void setup()
{
    Serial.begin(115200);
    pinMode(LED_BUILTIN, OUTPUT);
    Timer1.initialize(250000); // 0.25 s
    Timer1.attachInterrupt(blink);
}

void loop()
{
    noInterrupts();
    unsigned long copy = toggles; // read the shared value in one piece
    interrupts();

    Serial.print("toggles: ");
    Serial.println(copy);
    delay(1000);
}
