/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef PRINTABLE_H
#define PRINTABLE_H

#include <stddef.h>

class Print;

/** @brief Interface for objects that know how to print themselves (Print::print(const Printable &)). */
class Printable
{
  public:
    virtual ~Printable()
    {
    }
    virtual size_t printTo(Print &p) const = 0;
};

#endif /* PRINTABLE_H */
