/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef SPI_H
#define SPI_H

#include <Arduino.h>

#define SPI_MODE0 0x00 /**< CPOL 0, CPHA 0 */
#define SPI_MODE1 0x01 /**< CPOL 0, CPHA 1 */
#define SPI_MODE2 0x02 /**< CPOL 1, CPHA 0 */
#define SPI_MODE3 0x03 /**< CPOL 1, CPHA 1 */

/* setClockDivider(): divisors of the 40 MHz system clock, as on other boards */
#define SPI_CLOCK_DIV2 2
#define SPI_CLOCK_DIV4 4
#define SPI_CLOCK_DIV8 8
#define SPI_CLOCK_DIV16 16
#define SPI_CLOCK_DIV32 32
#define SPI_CLOCK_DIV64 64
#define SPI_CLOCK_DIV128 128

#define SPI_HAS_TRANSACTION 1

/** @brief Clock, bit order and mode of one SPI device. */
class SPISettings
{
  public:
    SPISettings() : clock(4000000UL), bitOrder(MSBFIRST), dataMode(SPI_MODE0)
    {
    }
    SPISettings(uint32_t clockHz, uint8_t order, uint8_t mode) : clock(clockHz), bitOrder(order), dataMode(mode)
    {
    }

    uint32_t clock;
    uint8_t bitOrder;
    uint8_t dataMode;
};

/**
 * @brief SPI master on one WISE SPI channel.
 *
 * SS / chip select is not driven by the library: the sketch toggles its own
 * chip-select pin with digitalWrite(). The clock is the closest supported
 * rate at or below the request (100 kHz, 200 kHz, 400 kHz, 500 kHz, 800 kHz,
 * 1, 2, 4, 5, 10, 20 MHz). Transfers are interrupt driven, so they need
 * interrupts enabled.
 */
class SPIClass
{
  public:
    SPIClass(uint8_t channel, uint8_t sck, uint8_t miso, uint8_t mosi);

    /** @brief Change the pins; call before begin(). */
    void setPins(uint8_t sck, uint8_t miso, uint8_t mosi);

    void begin();
    void end();

    void beginTransaction(SPISettings settings);
    void endTransaction();

    uint8_t transfer(uint8_t data);
    uint16_t transfer16(uint16_t data);
    /** @brief Full duplex in place: buf is sent and replaced by the received bytes. */
    void transfer(void *buf, size_t count);
    /** @brief Send txBuf and store the received bytes in rxBuf (either may be NULL). */
    void transfer(const void *txBuf, void *rxBuf, size_t count);

    /* Settings outside a transaction (older Arduino API) */
    void setBitOrder(uint8_t order);
    void setDataMode(uint8_t mode);
    void setClockDivider(uint8_t divider);
    void setFrequency(uint32_t clockHz);

    /* Kept for compatibility; transactions here do not mask interrupts. */
    void usingInterrupt(int interruptNumber)
    {
        (void)interruptNumber;
    }
    void notUsingInterrupt(int interruptNumber)
    {
        (void)interruptNumber;
    }

  private:
    uint8_t channel;
    uint8_t pinSck, pinMiso, pinMosi;
    bool started    = false;
    bool configured = false;
    SPISettings current;
    SPISettings applied;

    void apply();
};

extern SPIClass SPI;

#endif /* SPI_H */
