/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "Arduino.h"
#include "wiring_private.h"

extern "C" {
#include "wise_core.h"
}

/*
 * tone(): a 50 % square wave from a PWM channel (shared with analogWrite()).
 * One tone at a time; a tone on another pin stops the current one. A timed
 * tone is stopped from the core service loop, so it ends on time as long as
 * the sketch keeps returning from loop() or waits in delay().
 */

#define TONE_NO_PIN 0xFF

static uint8_t tonePin = TONE_NO_PIN;
static unsigned long toneStart;
static unsigned long toneDuration; /* 0 = until noTone() */

void tone(uint8_t pin, unsigned int frequency, unsigned long duration)
{
    uint32_t period;

    if (pin >= NUM_DIGITAL_PINS) {
        return;
    }
    if (frequency == 0) {
        noTone(pin);
        return;
    }
    if (tonePin != TONE_NO_PIN && tonePin != pin) {
        noTone(tonePin);
    }

    period = SystemCoreClock / frequency;
    if (_esmt_pwm_output(pin, period, period / 2U) != 0) {
        return;
    }

    tonePin      = pin;
    toneStart    = millis();
    toneDuration = duration;
}

void noTone(uint8_t pin)
{
    if (pin >= NUM_DIGITAL_PINS) {
        return;
    }
    _esmt_pwm_detach(pin);
    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);
    if (pin == tonePin) {
        tonePin = TONE_NO_PIN;
    }
}

extern "C" void _esmt_tone_service(void)
{
    if (tonePin != TONE_NO_PIN && toneDuration != 0 && (millis() - toneStart) >= toneDuration) {
        noTone(tonePin);
    }
}
