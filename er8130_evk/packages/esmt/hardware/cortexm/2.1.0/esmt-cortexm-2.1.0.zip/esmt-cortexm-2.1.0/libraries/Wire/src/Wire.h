/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef WIRE_H
#define WIRE_H

#include <Arduino.h>

/** @brief Bytes one transfer can carry, master or slave (driver limit is 255). */
#define WIRE_BUFFER_SIZE 128
#define BUFFER_LENGTH WIRE_BUFFER_SIZE

#define WIRE_HAS_END 1
#define WIRE_HAS_TIMEOUT 1

/**
 * @brief I2C (Arduino Wire API) on one WISE I2C channel, master or slave.
 *
 * Master: endTransmission(false) followed by requestFrom() on the same
 * address is sent as one combined transfer with a repeated START (register
 * reads). endTransmission() result codes: 0 success, 1 data too long, 2
 * address not acknowledged (only detected for zero-length writes, see
 * Wire.cpp), 4 other error or timeout.
 *
 * Slave: begin(address), onReceive(), onRequest(). Both handlers run in the
 * I2C interrupt, as on AVR. The driver sends the first byte of a reply before
 * it can ask the sketch, so the reply is prepared ahead: onRequest() is
 * called when it is registered and after every transaction, and what it
 * writes is sent at the next read. When the master writes and then reads with
 * a repeated START (endTransmission(false)), onReceive() and onRequest() also
 * run at the start of the read, but the first reply byte still comes from the
 * reply prepared before the write. A master that ends the write with a STOP
 * (plain endTransmission()) gets the whole reply up to date. onRequest() should
 * only fill the reply: it can be called more than once per read.
 * A slave is not a master at the same time.
 */
class TwoWire: public Stream
{
  public:
    TwoWire(uint8_t channel, uint8_t sda, uint8_t scl);

    /** @brief Change the pins; call before begin(). */
    void setPins(uint8_t sda, uint8_t scl);

    /** @brief Start as master. */
    void begin();
    /** @brief Start as slave on a 7-bit address. */
    void begin(uint8_t address);
    void begin(int address)
    {
        begin((uint8_t)address);
    }
    void end();
    void setClock(uint32_t hz);

    /** @brief Per-transfer timeout (rounded up to whole ms); reset re-initialises the bus after a timeout. */
    void setWireTimeout(uint32_t timeout_us = 25000, bool reset_with_timeout = false);
    bool getWireTimeoutFlag() const
    {
        return timeoutFlag;
    }
    void clearWireTimeoutFlag()
    {
        timeoutFlag = false;
    }

    void beginTransmission(uint8_t address);
    void beginTransmission(int address)
    {
        beginTransmission((uint8_t)address);
    }
    uint8_t endTransmission(bool sendStop = true);

    /* One signature, as in ArduinoCore-API: int or uint8_t arguments convert
     * to it. Extra int overloads made calls such as Adafruit_BusIO's
     * requestFrom((uint8_t), (uint8_t), (uint8_t)) ambiguous. */
    size_t requestFrom(uint8_t address, size_t quantity, bool sendStop = true);

    /** @brief Slave: called with the byte count after the master wrote; read the bytes with read(). */
    void onReceive(void (*handler)(int));
    /** @brief Slave: fill the reply for the master's next read with write(). */
    void onRequest(void (*handler)(void));

    size_t write(uint8_t data) override;
    size_t write(const uint8_t *data, size_t quantity) override;
    using Print::write;
    /* As in the AVR Wire library: Wire.write(0x00) would otherwise be
     * ambiguous between write(uint8_t) and write(const char *). */
    size_t write(int data)
    {
        return write((uint8_t)data);
    }
    size_t write(unsigned int data)
    {
        return write((uint8_t)data);
    }
    size_t write(long data)
    {
        return write((uint8_t)data);
    }
    size_t write(unsigned long data)
    {
        return write((uint8_t)data);
    }

    int available() override;
    int read() override;
    int peek() override;
    void flush() override
    {
    }

  private:
    uint8_t channel;
    uint8_t pinSda, pinScl;
    bool started        = false;
    uint32_t busHz      = 100000;
    uint32_t timeoutMs  = 25;
    bool resetOnTimeout = false;
    bool timeoutFlag    = false;

    uint8_t txAddress = 0;
    uint8_t txBuffer[WIRE_BUFFER_SIZE]; /* master: write data; slave: the reply */
    size_t txLength     = 0;
    bool txOverflow     = false;
    bool transmitting   = false;
    bool pendingRestart = false; /* write held back for a repeated START */

    uint8_t rxBuffer[WIRE_BUFFER_SIZE]; /* master: read data; slave: armed receive buffer */
    volatile size_t rxLength = 0;
    volatile size_t rxIndex  = 0;

    /* slave mode */
    uint8_t slaveAddress = 0; /* 0 = master */
    void (*userReceive)(int)  = nullptr;
    void (*userRequest)(void) = nullptr;
    bool inRequest              = false;
    volatile bool slaveBusy     = false; /* between ADDRESS_HIT and TRANSFER_DONE */
    volatile bool slaveNeedArm  = false; /* re-arm the receive path from the core loop */
    volatile bool slaveReceived = false; /* onReceive() already ran for the armed buffer */

    void start();
    void configure();
    uint8_t sendWrite(bool sendStop);
    void failed();

    void slaveArm();
    void slaveDeliver(uint8_t count);
    void slavePrepareReply();
    void slaveService();
    static void slaveEvent(uint8_t ch, uint32_t event, void *context);
    static void serviceAll();
};

extern TwoWire Wire;

#endif /* WIRE_H */
