/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef __UART_ER8130_H
#define __UART_ER8130_H

#include "esmt_chip_specific.h"
#include "types.h"

#define UART_OSCR 8
#define ENABLE_DLAB() REG_W32(UART_LCR_ADDR, UART_DLAB_MASK)
#define DISABLE_DLAB() REG_W32(UART_LCR_ADDR, REG_R32(UART_LCR_ADDR) & ~UART_DLAB_MASK)
#define GET_DIVISOR_VAL(br) ((SystemCoreClock + ((br << 2))) / (br << 3))

/*---------------------------------------------------------------------------------------------------------*/
/* Define UART Interrupt Mask */
/*---------------------------------------------------------------------------------------------------------*/
#define UART_INTEN_ELSI_Msk     (uint32_t)(0x1ul << 2)  //!<		Enable receiver line status interrupt
#define UART_INTEN_ETHEI_Msk    (uint32_t)(0x1ul << 1) //!<		Enable transmitter holding register interrupt
#define UART_INTEN_ERBI_Msk     (uint32_t)(0x1ul << 0)  //!<		Enable received data available interrupt

#define UART_INTEN_MASK         (UART_INTEN_ELSI_Msk | UART_INTEN_ETHEI_Msk | UART_INTEN_ERBI_Msk)

#define UART_TIMEOUT 100000

void uart_config_er8130(uint32_t uart_base, uint32_t baudrate, uint8_t data, uint8_t parity, uint8_t stop);
void uart_set_fcr_er8130(uint32_t uart_base, uint8_t fcr);
uint8_t uart_get_int_status_er8130(uint32_t uart_base);
void uart_write_byte_er8130(uint32_t uart_base, uint8_t ch);
int8_t uart_read_byte_er8130(uint32_t uart_base, uint8_t *ch, uint8_t *lsr);
void uart_irq_en_er8130(uint32_t uart_base, uint8_t int_type);
void uart_irq_dis_er8130(uint32_t uart_base);
int8_t uart_wait_tx_done_er8130(uint32_t uart_base);
uint8_t uart_get_lsr_er8130(uint32_t uart_base);
void uart_set_break_er8130(uint32_t uart_base, uint8_t enable);
void uart_set_flow_control_er8130(uint32_t uart_base, uint8_t enable);

#endif
