// Receives with a callback while loop() does other work (blinks the LED).
// The callback runs from the core loop, not in the interrupt, so it may
// use Serial. Pair with RadioSender.

#include <ESMTRadio.h>

const long FREQUENCY = 915000000; // Hz, the same as the sender

void onPacket(int size)
{
    Serial.print("received ");
    Serial.print(size);
    Serial.print(" bytes: ");
    while (Radio.available()) {
        Serial.write(Radio.read());
    }
    Serial.print("  RSSI ");
    Serial.print(Radio.packetRssi());
    Serial.println(" dBm");
}

void setup()
{
    Serial.begin(115200);
    pinMode(LED_BUILTIN, OUTPUT);
    if (!Radio.begin(FREQUENCY)) {
        Serial.println("Radio.begin failed");
        while (true) {
            delay(1000);
        }
    }
    Radio.onReceive(onPacket); // also starts receiving
    Serial.println("RadioReceiverCallback");
}

void loop()
{
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
    delay(500);
}
