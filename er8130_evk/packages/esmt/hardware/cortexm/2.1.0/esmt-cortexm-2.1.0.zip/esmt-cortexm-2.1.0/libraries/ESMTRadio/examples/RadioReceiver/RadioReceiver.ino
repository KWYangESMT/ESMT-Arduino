// Prints every packet it receives, with its RSSI. Pair with RadioSender.

#include <ESMTRadio.h>

const long FREQUENCY = 915000000; // Hz, the same as the sender

void setup()
{
    Serial.begin(115200);
    if (!Radio.begin(FREQUENCY)) {
        Serial.println("Radio.begin failed");
        while (true) {
            delay(1000);
        }
    }
    Radio.receive();
    Serial.println("RadioReceiver");
}

void loop()
{
    int size = Radio.parsePacket();
    if (size > 0) {
        Serial.print("received ");
        Serial.print(size);
        Serial.print(" bytes: ");
        while (Radio.available()) {
            Serial.write(Radio.read());
        }
        Serial.print("  RSSI ");
        Serial.print(Radio.packetRssi());
        Serial.println(" dBm");
    }
}
