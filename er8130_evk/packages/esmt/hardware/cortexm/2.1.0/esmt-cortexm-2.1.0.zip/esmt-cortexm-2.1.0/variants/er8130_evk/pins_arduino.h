/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/**
 * @file pins_arduino.h
 * @brief Pin map of the ER8130 EVK (subg_soc_9006).
 *
 * Arduino pin N is GPIO N (CHIP_GPIO_NUM = 16). Any GPIO can output PWM
 * (6 channels). Analog inputs are not GPIOs: A0 is the dedicated external
 * analog input (ANAGPIO), A1 the battery voltage, A2 the temperature sensor.
 *
 * EVK wiring: LEDs on GPIO2/GPIO3, a button on GPIO13; UART0 (GPIO0/1) is
 * the console and GPIO14/15 are SWD. GPIO5-8 and GPIO10-12 are free for the
 * sketch; GPIO4 and GPIO9 are not.
 *
 * The seven free pins take the SPI (GPIO5-8), Wire (GPIO11/12) and Serial1
 * (GPIO10/8) defaults, so Serial1 RX shares GPIO8 with SS: a sketch using SPI
 * and Serial1 together picks another SS pin. Serial2 has no free pins left
 * and uses the SWD pins (debugger off while it runs).
 */

#ifndef PINS_ARDUINO_H
#define PINS_ARDUINO_H

#include <stdint.h>

#define NUM_DIGITAL_PINS 16
#define NUM_ANALOG_INPUTS 3

/* UART0 = Serial, also the upload port of the Arduino loader */
#define PIN_SERIAL_UART 0
#define PIN_SERIAL_TX 0
#define PIN_SERIAL_RX 1

/* Serial1 = UART1, Serial2 = UART2 (any GPIO; setPins() before begin()) */
#define PIN_SERIAL1_TX 10
#define PIN_SERIAL1_RX 8 /* shared with SS */
#define PIN_SERIAL2_TX 14
#define PIN_SERIAL2_RX 15

#define LED_BUILTIN 2
#define LED_BUILTIN_2 3
#define PIN_BUTTON 13

/* SPI library: SPI channel 0. Any GPIO can carry these (pin mux); SPI.setPins()
 * changes them. SS is a plain GPIO driven by the sketch. */
#define SPI_INTERFACE 0
#define PIN_SPI_SCK 5
#define PIN_SPI_MOSI 6
#define PIN_SPI_MISO 7
#define PIN_SPI_SS 8

/* Wire library: I2C channel 0; Wire.setPins() changes the pins. External
 * pull-ups are required on SDA and SCL. */
#define WIRE_INTERFACE 0
#define PIN_WIRE_SCL 12
#define PIN_WIRE_SDA 11

/* GPIOs shared with a system function at reset: GPIO10 with the TCXO (the
 * EVK does not use it), GPIO14 and GPIO15 with SWD (debugger). The core
 * releases them (esmtPinClaim()) when a sketch gives them another use; SWD
 * then stays off until the next reset, so a debugger must connect under
 * reset. */
#define PIN_SYS_TCXO 10
#define PIN_SYS_SWD_A 14
#define PIN_SYS_SWD_B 15

#ifdef __cplusplus
static const uint8_t SS   = PIN_SPI_SS;
static const uint8_t MOSI = PIN_SPI_MOSI;
static const uint8_t MISO = PIN_SPI_MISO;
static const uint8_t SCK  = PIN_SPI_SCK;
static const uint8_t SDA  = PIN_WIRE_SDA;
static const uint8_t SCL  = PIN_WIRE_SCL;
#endif

/* Port registers, for libraries that drive pins directly (Adafruit_BusIO's
 * fast pin I/O on ARM). All 16 GPIOs are one port: bit n is GPIO n of the
 * IOCTRL GPIO_DO (output) and GPIO_DI (input) registers. The pin must already
 * be set up with pinMode(); a read-modify-write of the output register is not
 * atomic against interrupts that write other pins. */
#define ESMT_GPIO_DO_REG 0x40014084UL
#define ESMT_GPIO_DI_REG 0x4001408CUL
#define digitalPinToPort(pin) (0)
#define digitalPinToBitMask(pin) ((uint32_t)1UL << (pin))
#define portOutputRegister(port) ((volatile uint32_t *)ESMT_GPIO_DO_REG)
#define portInputRegister(port) ((volatile uint32_t *)ESMT_GPIO_DI_REG)

#define PIN_A0 16
#define PIN_A1 17
#define PIN_A2 18
#define A0 PIN_A0
#define A1 PIN_A1
#define A2 PIN_A2

#endif /* PINS_ARDUINO_H */
