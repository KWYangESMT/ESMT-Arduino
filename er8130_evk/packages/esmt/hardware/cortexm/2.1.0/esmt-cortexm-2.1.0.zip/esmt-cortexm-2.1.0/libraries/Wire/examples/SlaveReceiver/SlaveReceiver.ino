// SlaveReceiver: this board is I2C slave 0x08 and prints what a master writes.
//
// Wiring: SDA (GPIO11) and SCL (GPIO12) to the master's SDA and SCL, common
// ground, pull-up resistors (4.7 kOhm) on both lines. Pair with an Arduino
// master that runs the "master_writer" pattern:
//   Wire.beginTransmission(8); Wire.write("x is "); Wire.write(x); Wire.endTransmission();

#include <Wire.h>

volatile bool gotData;
char text[WIRE_BUFFER_SIZE + 1];
volatile int textLength;

// Runs in the I2C interrupt: copy the bytes, print from loop().
void receiveEvent(int count)
{
    (void)count; // the bytes are read with Wire.available()
    int n = 0;
    while (Wire.available() && n < (int)sizeof(text) - 1) {
        text[n++] = (char)Wire.read();
    }
    text[n]    = '\0';
    textLength = n;
    gotData    = true;
}

void setup()
{
    Serial.begin(115200);
    Wire.begin(8);
    Wire.onReceive(receiveEvent);
    Serial.println(F("I2C slave 0x08 waiting for writes"));
}

void loop()
{
    if (gotData) {
        noInterrupts();
        gotData = false;
        String line(text);
        interrupts();
        Serial.print(F("got "));
        Serial.print(textLength);
        Serial.print(F(" bytes: "));
        Serial.println(line);
    }
}
