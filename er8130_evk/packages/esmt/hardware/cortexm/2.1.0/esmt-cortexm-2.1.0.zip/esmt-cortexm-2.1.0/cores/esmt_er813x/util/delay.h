/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/**
 * @file delay.h
 * @brief _delay_ms() / _delay_us() for libraries written for AVR boards.
 */

#ifndef ESMT_UTIL_DELAY_H
#define ESMT_UTIL_DELAY_H

#include "Arduino.h"

#define _delay_ms(ms) delay((unsigned long)(ms))
#define _delay_us(us) delayMicroseconds((unsigned int)(us))

#endif /* ESMT_UTIL_DELAY_H */
