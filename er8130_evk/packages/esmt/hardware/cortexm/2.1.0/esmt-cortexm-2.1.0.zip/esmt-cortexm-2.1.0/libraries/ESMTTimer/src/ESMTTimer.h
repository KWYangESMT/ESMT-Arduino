/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef ESMT_TIMER_H
#define ESMT_TIMER_H

#include <Arduino.h>

/** Longest period in microseconds (32-bit counter at 40 MHz, about 107 s). */
#define ESMT_TIMER_MAX_PERIOD_US 107374181UL

/**
 * @brief One general-purpose hardware timer (GPTMR channel 0 to 4; channel 5
 * is the core's time base).
 *
 * The method names follow the TimerOne library:
 * @code
 * Timer1.initialize(500000);        // period in microseconds, starts counting
 * Timer1.attachInterrupt(blink);    // blink() runs every 0.5 s
 * @endcode
 * once(us, fn) runs fn a single time after us microseconds.
 *
 * The callback runs in the timer interrupt, like TimerOne: keep it short, make
 * variables it shares with loop() volatile, and do not wait in it (no delay(),
 * no Serial output that may block). Periods under about 20 us leave little
 * time for loop(). LowPower.idle() keeps the timers running (their interrupt
 * wakes it); LowPower.sleep() powers them down: call start() again after it.
 */
class ESMTTimer
{
  public:
    constexpr explicit ESMTTimer(uint8_t channel): channel(channel)
    {
    }

    /** @brief Set a periodic period (1 us to ESMT_TIMER_MAX_PERIOD_US) and start counting. @return false for a bad period. */
    bool initialize(unsigned long periodUs = 1000000UL);
    bool begin(unsigned long periodUs)
    {
        return initialize(periodUs);
    }

    /** @brief Change the period; a running timer restarts its count. @return false for a bad period. */
    bool setPeriod(unsigned long periodUs);
    unsigned long getPeriod() const
    {
        return period;
    }

    /** @brief Call isr from the timer interrupt at every period end (a period of 1 s if none was set). */
    void attachInterrupt(void (*isr)());
    /** @brief Set the period too, then attach. */
    void attachInterrupt(void (*isr)(), unsigned long periodUs);
    /** @brief No more calls; the timer keeps counting. */
    void detachInterrupt();

    /** @brief Start from the beginning of a period. */
    void start();
    void restart()
    {
        start();
    }
    /** @brief Pause counting. */
    void stop();
    /** @brief Continue counting from where stop() left it. */
    void resume();
    /** @brief True while counting. */
    bool isRunning() const;
    /** @brief Microseconds since the current period began. */
    unsigned long read() const;

    /** @brief Call isr once, us microseconds from now (it then stops). @return false for a bad time. */
    bool once(unsigned long us, void (*isr)());

    /** @brief Stop and release the timer. */
    void end();

    /** @brief Not for sketches: interrupt entry. */
    static void _isr(void *context, uint8_t idx);

  private:
    const uint8_t channel;
    unsigned long period = 0;
    bool oneShot         = false;
    bool configured      = false;
    void (*volatile callback)() = nullptr;

    bool configure(unsigned long periodUs, bool single);
};

extern ESMTTimer Timer0;
extern ESMTTimer Timer1;
extern ESMTTimer Timer2;
extern ESMTTimer Timer3;
extern ESMTTimer Timer4;

#endif /* ESMT_TIMER_H */
