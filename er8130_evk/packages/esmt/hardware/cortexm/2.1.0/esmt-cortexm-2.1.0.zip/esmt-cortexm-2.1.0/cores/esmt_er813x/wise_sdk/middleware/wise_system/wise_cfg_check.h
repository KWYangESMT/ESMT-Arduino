#ifndef __WISE_CFG_CHECK_H 
#define __WISE_CFG_CHECK_H

#ifndef ES_UART0_RX_BUF_SIZE
#define ES_UART0_RX_BUF_SIZE                            0
#endif

#ifndef ES_UART1_RX_BUF_SIZE
#define ES_UART1_RX_BUF_SIZE                            0
#endif

#ifndef ES_UART2_RX_BUF_SIZE
#define ES_UART2_RX_BUF_SIZE                            0
#endif

#ifndef ES_UART0_TX_BUF_SIZE
#define ES_UART0_TX_BUF_SIZE                            0
#endif

#ifndef ES_UART1_TX_BUF_SIZE
#define ES_UART1_TX_BUF_SIZE                            0
#endif

#ifndef ES_UART2_TX_BUF_SIZE
#define ES_UART2_TX_BUF_SIZE                            1
#endif

#ifndef DMA_CH0_FUNC
#define DMA_CH0_FUNC                                    SYS_DMA_FUNC_UNSED
#endif

#ifndef DMA_CH1_FUNC
#define DMA_CH1_FUNC                                    SYS_DMA_FUNC_UNSED
#endif

#ifndef DMA_CH2_FUNC
#define DMA_CH2_FUNC                                    SYS_DMA_FUNC_UNSED
#endif

#ifndef DMA_CH3_FUNC
#define DMA_CH3_FUNC                                    SYS_DMA_FUNC_UNSED
#endif

#ifndef DMA_CH4_FUNC
#define DMA_CH4_FUNC                                    SYS_DMA_FUNC_UNSED
#endif

#ifndef DMA_CH5_FUNC
#define DMA_CH5_FUNC                                    SYS_DMA_FUNC_UNSED
#endif

#ifndef ES_DEVICE_LFOSC_SELECT
#define ES_DEVICE_LFOSC_SELECT                          SYS_LFOSC_CLK_SRC_INTERNAL_16K
#define ES_DEVICE_LFOSC_OPTION                          LFOSC_16K_MODE_TEMP_COMP
#endif 

#ifndef BOARD_40M_GAIN_CTRL
#define BOARD_40M_GAIN_CTRL                             1
#endif

#ifndef BOARD_40M_GAIN_CTRL_S
#define BOARD_40M_GAIN_CTRL_S                           15
#endif

#ifndef BOARD_40M_MAINCAP_I_EN
#define BOARD_40M_MAINCAP_I_EN                          1 /* 0/1, XO_40M_MAINCAP_I_EN */
#endif

#ifndef BOARD_40M_MAINCAP_O_EN
#define BOARD_40M_MAINCAP_O_EN                          1 /* 0/1, XO_40M_MAINCAP_O_EN */
#endif

#ifndef BOARD_SRAM_RETAIN
#define BOARD_SRAM_RETAIN                               1
#endif

#ifndef BOARD_32K_CAP_LPXTAL_I
#define BOARD_32K_CAP_LPXTAL_I                          63 /* 0-63, LV_LPXTAL_CAP_I_CTRL */
#endif

#ifndef BOARD_32K_CAP_LPXTAL_O
#define BOARD_32K_CAP_LPXTAL_O                          63 /* 0-63, LV_LPXTAL_CAP_O_CTRL */
#endif

#ifndef BOARD_32K_MAINCAP_I_EN
#define BOARD_32K_MAINCAP_I_EN                          1 /* 0/1, LV_LPXTAL_MAINCAP_I_EN */
#endif

#ifndef BOARD_32K_MAINCAP_O_EN
#define BOARD_32K_MAINCAP_O_EN                          1 /* 0/1, LV_LPXTAL_MAINCAP_O_EN */
#endif

#ifndef BOARD_32K_LPXTAL_GAIN
#define BOARD_32K_LPXTAL_GAIN                           0 /* 0-63, LV_LPXTAL_GAIN_CTRL (XO_CONFIG_2). 0 = keep analog default */
#endif

/* Enable only when EXT32K is selected and the sleep-current issue must be masked. */
#ifndef BOARD_EXT32K_LP_WORKAROUND
#define BOARD_EXT32K_LP_WORKAROUND                      1 /* 0 = disable, 1 = enable */
#endif

/* ULPLDO tuning is only meaningful on platforms that expose the 9006 ULPLDO control path. */
#ifndef BOARD_ULPLDO_VREF
#define BOARD_ULPLDO_VREF 0 /* 0 = normal, 1 = ultra low */
#endif

/* ENMODE drives the ULPLDO 0.9V/0.6V enable bits together when enabled. */
#ifndef BOARD_ULPLDO_ENMODE
#define BOARD_ULPLDO_ENMODE 1 /* 0 = disable, 1 = enable */
#endif

#if defined(BOARD_CONFIG_FILE)
#include BOARD_CONFIG_FILE
#else
#include "board_default_cfg.h"
#endif

#endif
