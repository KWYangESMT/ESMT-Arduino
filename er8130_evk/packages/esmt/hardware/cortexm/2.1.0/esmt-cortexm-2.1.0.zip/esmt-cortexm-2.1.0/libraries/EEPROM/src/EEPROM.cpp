/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "EEPROM.h"

extern "C" {
#include "wise_core.h"
#include "wise_flash_api.h"
}

/*
 * Storage format (two sectors used in turn, flash offsets):
 *
 *   +0      header: magic "EEPR", seq (u32), size (u16), version (u16), ~seq (u32)
 *   +16     image : ESMT_EEPROM_SIZE bytes, the contents at the last compaction
 *   +16+N   log   : 4-byte records {addr_lo, addr_hi, value, check}, until the
 *                   sector ends; an all-0xFF record marks the end
 *
 * The contents = image, then every valid log record in order. The sector with
 * a valid header and the higher seq is the live one.
 *
 * Power loss is safe: a log record is 4 bytes programmed into erased flash
 * (no erase); a half-written record fails its check and is skipped. During a
 * compaction the header of the new sector is written last, so until it is
 * there the old sector (and its log) stays the live one.
 */

#ifndef ESMT_EEPROM_FLASH_START
#define ESMT_EEPROM_FLASH_START 0x7E000UL /* sketch data area, docs/bootloader_design.md section 3 */
#endif

#define APPINFO_ADDR 0x0F000UL     /* written by the Arduino bootloader */
#define APPINFO_MAGIC 0x50504145UL /* "EAPP" */

#define HDR_MAGIC 0x52504545UL /* "EEPR" */
#define HDR_VERSION 1U
#define HDR_LEN 16U
#define REC_LEN 4U
#define LOG_START ((HDR_LEN + ESMT_EEPROM_SIZE + REC_LEN - 1U) & ~(REC_LEN - 1U))

EEPROMClass EEPROM;

static uint8_t mirror[ESMT_EEPROM_SIZE];
static uint32_t sectorSize;
static uint32_t base[2]; /* flash offsets of the two sectors */
static uint8_t live;     /* index of the live sector */
static uint32_t liveSeq;
static uint32_t writePos; /* offset in the live sector of the next free record */

static uint32_t get32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void put32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16);
    p[3] = (uint8_t)(v >> 24);
}

static uint8_t _check(uint8_t lo, uint8_t hi, uint8_t value)
{
    return (uint8_t)~(uint8_t)(lo + hi + value);
}

static bool _header(uint32_t sector, uint32_t *seq)
{
    uint8_t h[HDR_LEN];

    if (WISE_SUCCESS != wise_flash_read(sector, h, HDR_LEN)) {
        return false;
    }
    if (get32(&h[0]) != HDR_MAGIC || get32(&h[12]) != ~get32(&h[4])) {
        return false;
    }
    if ((h[8] | (h[9] << 8)) != ESMT_EEPROM_SIZE || (h[10] | (h[11] << 8)) != HDR_VERSION) {
        return false; /* other size or format: start over */
    }
    *seq = get32(&h[4]);
    return true;
}

/* Rebuild the contents from the live sector: image, then the log. */
static void _load(void)
{
    uint8_t chunk[64];
    uint32_t pos = LOG_START;

    (void)wise_flash_read(base[live] + HDR_LEN, mirror, ESMT_EEPROM_SIZE);

    while (pos + REC_LEN <= sectorSize) {
        uint32_t n = sectorSize - pos;
        if (n > sizeof(chunk)) {
            n = sizeof(chunk);
        }
        n &= ~(REC_LEN - 1U);
        (void)wise_flash_read(base[live] + pos, chunk, n);

        for (uint32_t i = 0; i < n; i += REC_LEN, pos += REC_LEN) {
            const uint8_t *r = &chunk[i];
            uint32_t addr    = (uint32_t)r[0] | ((uint32_t)r[1] << 8);

            if (r[0] == 0xFF && r[1] == 0xFF && r[2] == 0xFF && r[3] == 0xFF) {
                writePos = pos; /* end of the log */
                return;
            }
            if (r[3] == _check(r[0], r[1], r[2]) && addr < ESMT_EEPROM_SIZE) {
                mirror[addr] = r[2];
            }
            /* else: a record cut by power loss; skip it */
        }
    }
    writePos = sectorSize; /* log full */
}

/* Write the current contents into sector idx with the given seq. */
static bool _store(uint8_t idx, uint32_t seq)
{
    uint8_t h[HDR_LEN];

    if (WISE_SUCCESS != wise_flash_sector_erase(base[idx])) {
        return false;
    }
    if (WISE_SUCCESS != wise_flash_write(base[idx] + HDR_LEN, mirror, ESMT_EEPROM_SIZE)) {
        return false;
    }
    put32(&h[0], HDR_MAGIC);
    put32(&h[4], seq);
    h[8]  = (uint8_t)ESMT_EEPROM_SIZE;
    h[9]  = (uint8_t)(ESMT_EEPROM_SIZE >> 8);
    h[10] = (uint8_t)HDR_VERSION;
    h[11] = 0;
    put32(&h[12], ~seq);
    /* header last: the sector counts only once everything else is there */
    if (WISE_SUCCESS != wise_flash_write(base[idx], h, HDR_LEN)) {
        return false;
    }
    live     = idx;
    liveSeq  = seq;
    writePos = LOG_START;
    return true;
}

bool EEPROMClass::begin()
{
    WISE_FLASH_INFO_T info;
    uint8_t magic[4];
    uint32_t seq0 = 0, seq1 = 0;
    bool ok0, ok1;

    if (state != 0) {
        return state == 1;
    }
    state = 2; /* disabled unless everything below holds */

    /* Only under the Arduino bootloader (see EEPROM.h). */
    if (WISE_SUCCESS != wise_flash_read(APPINFO_ADDR, magic, sizeof(magic)) || get32(magic) != APPINFO_MAGIC) {
        return false;
    }

    if (WISE_SUCCESS != wise_flash_get_info(&info) || info.minEraseSize == 0) {
        return false;
    }
    sectorSize = info.minEraseSize;
    if (LOG_START + 16U * REC_LEN > sectorSize || ESMT_EEPROM_FLASH_START + 2U * sectorSize > info.flashSize) {
        return false; /* does not fit this flash */
    }
    base[0] = ESMT_EEPROM_FLASH_START;
    base[1] = ESMT_EEPROM_FLASH_START + sectorSize;

    ok0 = _header(base[0], &seq0);
    ok1 = _header(base[1], &seq1);
    if (ok0 || ok1) {
        live    = (ok1 && (!ok0 || seq1 > seq0)) ? 1 : 0;
        liveSeq = live ? seq1 : seq0;
        _load();
    } else {
        memset(mirror, 0xFF, sizeof(mirror)); /* blank EEPROM */
        if (!_store(0, 1)) {
            return false;
        }
    }

    state = 1;
    return true;
}

uint8_t EEPROMClass::read(int index)
{
    if (!begin() || index < 0 || index >= ESMT_EEPROM_SIZE) {
        return 0xFF;
    }
    return mirror[index];
}

void EEPROMClass::write(int index, uint8_t value)
{
    uint8_t rec[REC_LEN];

    if (!begin() || index < 0 || index >= ESMT_EEPROM_SIZE || mirror[index] == value) {
        return;
    }
    mirror[index] = value;

    /* A flash write takes about 2 ms (a compaction longer): a sketch that writes in
       a loop without delay() is busy, not stuck, so it must not run into the watchdog. */
    esmtWatchdogFeed();

    if (writePos + REC_LEN > sectorSize) {
        /* log full: the new value goes into the compacted image */
        if (!_store((uint8_t)(live ^ 1U), liveSeq + 1U)) {
            state = 2;
        }
        return;
    }

    rec[0] = (uint8_t)index;
    rec[1] = (uint8_t)(index >> 8);
    rec[2] = value;
    rec[3] = _check(rec[0], rec[1], rec[2]);
    if (WISE_SUCCESS != wise_flash_write(base[live] + writePos, rec, REC_LEN)) {
        state = 2;
        return;
    }
    writePos += REC_LEN;
}

EERef::operator uint8_t() const
{
    return EEPROM.read(index);
}

EERef &EERef::operator=(uint8_t value)
{
    EEPROM.write(index, value);
    return *this;
}
