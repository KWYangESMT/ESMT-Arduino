/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "ESMTLowPower.h"

extern "C" {
#include "wise_core.h"
#include "wise_sys_api.h"
#include "wise_tick_api.h"
#include "wise_wutmr_api.h"
}

/*
 * idle() / sleep() follow wise_system_idle() / wise_system_sleep() in
 * middleware/wise_system/wise_common.c (one-shot wake-up timer around
 * wise_sys_set_cpu_pd() / wise_sys_enter_sleep_mode(), interrupts masked so
 * the wake interrupt is handled after the state is restored); the Arduino
 * core does the peripheral restore itself (esmtLowPowerExit()).
 */

ESMTLowPowerClass LowPower;

void ESMTLowPowerClass::powerDown(uint32_t ms, bool system)
{
    esmtLowPowerEnter();
    noInterrupts();

    if (ms > 0) {
        wise_wutmr_enable_int();
        (void)wise_wutmr_start(ms, WISE_WUTMR_ONE_SHOT);
    }

    if (system) {
        (void)wise_sys_enter_sleep_mode();
    } else {
        wise_sys_set_cpu_pd();
    }

    if (ms > 0) {
        wise_wutmr_stop();
        wise_wutmr_disable_int();
    }

    esmtLowPowerExit(system);
    interrupts(); /* the interrupt that woke us runs now */
}

void ESMTLowPowerClass::idle()
{
    powerDown(0, false);
}

void ESMTLowPowerClass::idle(uint32_t ms)
{
    powerDown(ms, false);
}

void ESMTLowPowerClass::sleep()
{
    powerDown(0, true);
}

void ESMTLowPowerClass::sleep(uint32_t ms)
{
    powerDown(ms, true);
}

void ESMTLowPowerClass::shutdown(uint32_t ms)
{
    SYS_SHUTDOWN_CFT_T cfg;
    uint32_t src = 0;

    if (ms > 0) {
        src |= SHUTDOWN_WAKE_SRC_WUTMR;
    }
    if (wakePin < NUM_DIGITAL_PINS) {
        src |= SHUTDOWN_WAKE_SRC_GPIO;
    }
    cfg.wake_src    = (SHUTDOWN_WAKE_SRC_T)src;
    cfg.shutdown_ms = ms;
    cfg.wake_io_idx = (wakePin < NUM_DIGITAL_PINS) ? wakePin : 0;

    esmtLowPowerEnter();
    noInterrupts();
    wise_sys_enter_shutdown_mode(cfg);

    /* The chip should be off by now. If shutdown did not happen, restart
     * instead of hanging with the watchdog paused: a deep-sleep wake starts
     * the sketch from setup() as well. */
    wise_tick_delay_ms(1000);
    wise_sys_chip_reset();
    for (;;) {
    }
}

void ESMTLowPowerClass::deepSleep()
{
    shutdown(0);
}

void ESMTLowPowerClass::deepSleep(uint32_t ms)
{
    shutdown(ms);
}

void ESMTLowPowerClass::attachInterruptWakeup(uint32_t pin, voidFuncPtr callback, uint32_t mode)
{
    if (pin >= NUM_DIGITAL_PINS) {
        return;
    }
    wakePin = (uint8_t)pin;
    attachInterrupt((uint8_t)pin, callback, (int)mode);
}
