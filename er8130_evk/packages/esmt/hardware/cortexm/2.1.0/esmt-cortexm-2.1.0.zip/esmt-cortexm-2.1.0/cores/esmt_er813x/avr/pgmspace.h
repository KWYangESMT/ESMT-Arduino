/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/**
 * @file pgmspace.h
 * @brief AVR program-memory API for libraries written for AVR boards.
 *
 * On Cortex-M, flash and RAM share one address space, so PROGMEM data is
 * plain const data (the linker puts it in flash) and every pgm_read_* or *_P
 * function is the ordinary read or string function.
 */

#ifndef ESMT_AVR_PGMSPACE_H
#define ESMT_AVR_PGMSPACE_H

#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define PROGMEM
#define PGM_P const char *
#define PGM_VOID_P const void *
#define PSTR(s) (s)

typedef void prog_void;
typedef char prog_char;
typedef unsigned char prog_uchar;
typedef int8_t prog_int8_t;
typedef uint8_t prog_uint8_t;
typedef int16_t prog_int16_t;
typedef uint16_t prog_uint16_t;
typedef int32_t prog_int32_t;
typedef uint32_t prog_uint32_t;

/* Reads through memcpy: AVR tables are often unaligned (packed structs). */
static inline uint8_t _esmt_pgm_u8(const void *p)
{
    return *(const uint8_t *)p;
}
static inline uint16_t _esmt_pgm_u16(const void *p)
{
    uint16_t v;
    memcpy(&v, p, sizeof(v));
    return v;
}
static inline uint32_t _esmt_pgm_u32(const void *p)
{
    uint32_t v;
    memcpy(&v, p, sizeof(v));
    return v;
}
static inline float _esmt_pgm_float(const void *p)
{
    float v;
    memcpy(&v, p, sizeof(v));
    return v;
}
static inline const void *_esmt_pgm_ptr(const void *p)
{
    const void *v;
    memcpy(&v, p, sizeof(v));
    return v;
}

/* Some libraries (Adafruit_SSD1306) define a plain pgm_read_byte for non-AVR
 * boards before they include this header: replace theirs without a warning. */
#undef pgm_read_byte
#undef pgm_read_word
#undef pgm_read_dword
#undef pgm_read_float
#undef pgm_read_ptr
#define pgm_read_byte(addr) _esmt_pgm_u8((const void *)(addr))
#define pgm_read_word(addr) _esmt_pgm_u16((const void *)(addr))
#define pgm_read_dword(addr) _esmt_pgm_u32((const void *)(addr))
#define pgm_read_float(addr) _esmt_pgm_float((const void *)(addr))
#define pgm_read_ptr(addr) _esmt_pgm_ptr((const void *)(addr))

#define pgm_read_byte_near(addr) pgm_read_byte(addr)
#define pgm_read_word_near(addr) pgm_read_word(addr)
#define pgm_read_dword_near(addr) pgm_read_dword(addr)
#define pgm_read_float_near(addr) pgm_read_float(addr)
#define pgm_read_ptr_near(addr) pgm_read_ptr(addr)
#define pgm_read_byte_far(addr) pgm_read_byte(addr)
#define pgm_read_word_far(addr) pgm_read_word(addr)
#define pgm_read_dword_far(addr) pgm_read_dword(addr)
#define pgm_read_float_far(addr) pgm_read_float(addr)
#define pgm_read_ptr_far(addr) pgm_read_ptr(addr)
#define pgm_get_far_address(var) ((uint32_t)(uintptr_t)&(var))

#define memchr_P memchr
#define memcmp_P memcmp
#define memccpy_P memccpy
#define memcpy_P memcpy
#define memmem_P memmem
#define strcat_P strcat
#define strchr_P strchr
#define strcmp_P strcmp
#define strcpy_P strcpy
#define strcasecmp_P strcasecmp
#define strlen_P strlen
#define strncat_P strncat
#define strncmp_P strncmp
#define strncasecmp_P strncasecmp
#define strncpy_P strncpy
#define strnlen_P strnlen
#define strrchr_P strrchr
#define strstr_P strstr

#define printf_P printf
#define sprintf_P sprintf
#define snprintf_P snprintf
#define vsnprintf_P vsnprintf

#endif /* ESMT_AVR_PGMSPACE_H */
