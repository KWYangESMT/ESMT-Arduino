/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/* Core-internal helpers shared between wiring_*.c files. Not for sketches. */

#ifndef WIRING_PRIVATE_H
#define WIRING_PRIVATE_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Stop PWM on a pin and return it to GPIO function.
 * @return 1 if PWM was attached to the pin, 0 if there was nothing to do.
 */
int _esmt_pwm_detach(uint8_t pin);

/**
 * @brief Drive a pin with PWM: period and active time in SystemCoreClock ticks.
 * @return 0 on success, -1 if the pin is invalid or all PWM channels are busy.
 */
int _esmt_pwm_output(uint8_t pin, uint32_t period, uint32_t active);

/** @brief Stop a timed tone() when its duration has passed; run from esmt_core_service(). */
void _esmt_tone_service(void);

/** @brief Fold the tick counter into the 64-bit time base (see wiring_time.c). */
void _esmt_time_refresh(void);

/** @brief Chip start-up on the wise_core API (see esmt_system.c). Called once from main(). */
void _esmt_system_init(void);

/** @brief Periodic wise_core work, run from esmt_core_service(). */
void _esmt_system_service(void);

/** @brief Bring up the Serial UART at 115200 8N1 with the RX interrupt (see HardwareSerial.cpp). */
void _esmt_serial_init(void);
/** @brief Call serialEvent() / serialEvent1() / serialEvent2() for ports with data. */
void _esmt_serial_event_run(void);

/** @brief Wait until every open Serial port has sent its last byte (before a sleep). */
void _esmt_serial_flush_all(void);
/** @brief Configure every open Serial port again (after a sleep powered the UARTs down). */
void _esmt_serial_restore_all(void);

/** @brief Check one Serial RX byte for the uploader's reset sequence; runs in the RX interrupt. */
void _esmt_upload_escape_feed(uint8_t c);

#ifdef __cplusplus
}
#endif

#endif /* WIRING_PRIVATE_H */
