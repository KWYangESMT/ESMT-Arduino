/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef EEPROM_H
#define EEPROM_H

#include <Arduino.h>

/** @brief Emulated EEPROM size in bytes (1 to 2048; default as on an AVR Uno). */
#ifndef ESMT_EEPROM_SIZE
#define ESMT_EEPROM_SIZE 1024
#endif

#if (ESMT_EEPROM_SIZE < 1) || (ESMT_EEPROM_SIZE > 2048)
#error "ESMT_EEPROM_SIZE must be 1..2048"
#endif

class EEPROMClass;

/** @brief One EEPROM byte, as returned by EEPROM[index]. */
class EERef
{
  public:
    EERef(int index) : index(index)
    {
    }

    operator uint8_t() const;
    EERef &operator=(uint8_t value);
    EERef &operator=(const EERef &other)
    {
        return *this = (uint8_t)other;
    }
    EERef &update(uint8_t value)
    {
        return *this = value;
    }

    EERef &operator+=(uint8_t v)
    {
        return *this = (uint8_t)(*this + v);
    }
    EERef &operator-=(uint8_t v)
    {
        return *this = (uint8_t)(*this - v);
    }
    EERef &operator*=(uint8_t v)
    {
        return *this = (uint8_t)(*this * v);
    }
    EERef &operator/=(uint8_t v)
    {
        return *this = (uint8_t)(*this / v);
    }
    EERef &operator%=(uint8_t v)
    {
        return *this = (uint8_t)(*this % v);
    }
    EERef &operator&=(uint8_t v)
    {
        return *this = (uint8_t)(*this & v);
    }
    EERef &operator|=(uint8_t v)
    {
        return *this = (uint8_t)(*this | v);
    }
    EERef &operator^=(uint8_t v)
    {
        return *this = (uint8_t)(*this ^ v);
    }
    EERef &operator<<=(uint8_t v)
    {
        return *this = (uint8_t)(*this << v);
    }
    EERef &operator>>=(uint8_t v)
    {
        return *this = (uint8_t)(*this >> v);
    }
    EERef &operator++()
    {
        return *this += 1;
    }
    EERef &operator--()
    {
        return *this -= 1;
    }
    uint8_t operator++(int)
    {
        uint8_t old = *this;
        ++(*this);
        return old;
    }
    uint8_t operator--(int)
    {
        uint8_t old = *this;
        --(*this);
        return old;
    }

    int index;
};

/**
 * @brief Arduino EEPROM API, emulated in flash.
 *
 * Lives in the sketch data area (the last 8 KB of a 512 KB flash, from 0x7E000, see
 * docs/bootloader_design.md section 3), which neither uploads nor the loader
 * touch, so the contents survive uploads, resets and power loss. A write
 * that changes a byte appends a 4-byte record to a log (microseconds, no
 * erase); when the log is full the contents are compacted into the other
 * sector (one sector erase, tens of milliseconds). An erased EEPROM reads
 * 0xFF, as on AVR.
 *
 * Works only under the Arduino bootloader (it checks the APP INFO record the
 * loader writes). A sketch started any other way, e.g. flashed with a
 * debugger, gets a disabled EEPROM: reads return 0xFF, writes do nothing,
 * ok() is false.
 */
class EEPROMClass
{
  public:
    constexpr EEPROMClass()
    {
    }

    /** @brief Optional: load the contents now (otherwise on first use); same as ok(). */
    bool begin();
    /** @brief True when EEPROM storage is usable on this board. */
    bool ok()
    {
        return begin();
    }

    uint8_t read(int index);
    /** @brief Store a byte. Writing the value already there costs nothing. */
    void write(int index, uint8_t value);
    void update(int index, uint8_t value)
    {
        write(index, value);
    }
    EERef operator[](int index)
    {
        return EERef(index);
    }
    uint16_t length() const
    {
        return ESMT_EEPROM_SIZE;
    }

    template <typename T> T &get(int index, T &value)
    {
        uint8_t *p = (uint8_t *)&value;
        for (size_t i = 0; i < sizeof(T); i++) {
            p[i] = read(index + (int)i);
        }
        return value;
    }
    template <typename T> const T &put(int index, const T &value)
    {
        const uint8_t *p = (const uint8_t *)&value;
        for (size_t i = 0; i < sizeof(T); i++) {
            write(index + (int)i, p[i]);
        }
        return value;
    }

    /** @brief Writes are stored at once; kept for code written for ESP boards. */
    bool commit()
    {
        return ok();
    }

  private:
    uint8_t state = 0; /* 0 = not loaded, 1 = usable, 2 = disabled */
};

extern EEPROMClass EEPROM;

#endif /* EEPROM_H */
