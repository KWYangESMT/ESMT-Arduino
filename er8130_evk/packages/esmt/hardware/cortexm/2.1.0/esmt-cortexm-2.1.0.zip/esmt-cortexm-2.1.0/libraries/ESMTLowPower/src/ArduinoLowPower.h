/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/* Sketches written for the ArduinoLowPower library include this name. */
#include "ESMTLowPower.h"
