#!/usr/bin/env python3
# Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
# All rights reserved.
"""Upload a sketch to an ESMT ER813x board over UART0.

Flow (no reset wiring needed):

1. Send ESCAPE at several baud rates. A running Arduino sketch sees it in its
   UART RX interrupt and resets the chip (cores/esmt_er813x/esmt_system.c).
   A stuck sketch is reset by the core's watchdog instead; if neither works,
   the user presses the reset button.
2. Find the Arduino loader (app/esmt_arduino/bootloader, protocol "EABP" in
   docs/bootloader_design.md): it answers a HELLO frame in its short listen
   window after a reset. Boards that still run AppLoader are not supported:
   burn the Arduino loader first (bootloader/README.md).
3. Send the .bin, verify it, then start the sketch (EABP BOOT).

Requires Python 3.8+ and pyserial.
"""

from __future__ import annotations

import argparse
import struct
import sys
import time
import zlib
from pathlib import Path

ESCAPE = b"\x1b[ESMT-UPLOAD-9006]"  # must match uploadEscape[] in esmt_system.c
ESCAPE_BAUDS = (115200, 57600, 38400, 19200, 9600, 230400, 460800, 921600)
LOADER_BAUD = 115200

class UploadError(Exception):
    pass


# --------------------------------------------------------------------------
# EABP - ESMT Arduino Boot Protocol (docs/bootloader_design.md, section 5)
# --------------------------------------------------------------------------
EABP_REQ = 0xA5
EABP_RSP = 0x5A
EABP_MAX_PAYLOAD = 1024 + 8

CMD_HELLO = 0x01
CMD_SET_BAUD = 0x02
CMD_BEGIN = 0x10
CMD_WRITE = 0x11
CMD_VERIFY = 0x12
CMD_READ = 0x13
CMD_BOOT = 0x20

ST_OK = 0x00
STATUS_NAMES = {
    0x00: "OK",
    0x01: "unknown command",
    0x02: "bad length or argument",
    0x03: "address outside the sketch region",
    0x04: "flash erase or write failed",
    0x05: "verify failed",
    0x06: "sequence error",
    0x07: "no valid sketch",
}

# HELLO baud bitmap bit -> rate
EABP_BAUDS = (115200, 230400, 460800, 921600)
HELLO_FORMAT = "<HHIIIIHH"  # loader ver, protocol ver, chip id, flash size, region start, region size, max write, bauds


def crc16_ccitt(data: bytes, crc: int = 0xFFFF) -> int:
    """CRC16-CCITT (poly 0x1021, init 0xFFFF, no reflection, no final XOR)."""
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return crc


def crc32(data: bytes) -> int:
    """CRC32 IEEE 802.3 (zlib)."""
    return zlib.crc32(data) & 0xFFFFFFFF


def eabp_request(cmd: int, seq: int, payload: bytes = b"") -> bytes:
    body = bytes([cmd, seq & 0xFF]) + struct.pack("<H", len(payload)) + payload
    return bytes([EABP_REQ]) + body + struct.pack("<H", crc16_ccitt(body))


def eabp_take_response(buf: bytearray):
    """Remove and return the first valid response (cmd, seq, status, payload) in buf.

    Returns None when no complete valid frame is there yet. Bytes before a
    response, and responses with a bad CRC, are discarded.
    """
    while True:
        start = buf.find(bytes([EABP_RSP]))
        if start < 0:
            buf.clear()
            return None
        if start:
            del buf[:start]
        if len(buf) < 6:
            return None
        length = buf[4] | (buf[5] << 8)
        if length > EABP_MAX_PAYLOAD:
            del buf[:1]
            continue
        end = 6 + length + 2
        if len(buf) < end:
            return None
        body = bytes(buf[1 : 6 + length])
        if crc16_ccitt(body) != (buf[6 + length] | (buf[7 + length] << 8)):
            del buf[:1]
            continue
        del buf[:end]
        return body[0], body[1], body[2], body[5:]


class Eabp:
    """Request/response client. A resend keeps its sequence number, so the
    loader answers it from its cache instead of running it twice."""

    def __init__(self, link: "Link", seq: int = 1):
        self.link = link
        self.seq = seq  # the probe HELLOs use 0

    def request(self, cmd: int, payload: bytes = b"", timeout: float = 0.3, tries: int = 3):
        frame = eabp_request(cmd, self.seq, payload)
        for _ in range(tries):
            self.link.write(frame)
            end = time.monotonic() + timeout
            while time.monotonic() < end:
                rsp = eabp_take_response(self.link.rx)
                if rsp is None:
                    self.link.poll()
                    continue
                rcmd, rseq, status, data = rsp
                if rcmd == cmd and rseq == self.seq:
                    self.seq = (self.seq + 1) & 0xFF
                    return status, data
        raise UploadError(f"no answer from the loader to command 0x{cmd:02X}")

    def check(self, cmd: int, payload: bytes = b"", timeout: float = 0.3) -> bytes:
        status, data = self.request(cmd, payload, timeout)
        if status != ST_OK:
            raise UploadError(f"loader refused command 0x{cmd:02X}: {STATUS_NAMES.get(status, hex(status))}")
        return data


def parse_hello(data: bytes) -> dict:
    if len(data) < struct.calcsize(HELLO_FORMAT):
        raise UploadError("short HELLO answer from the loader")
    fields = struct.unpack_from(HELLO_FORMAT, data)
    keys = ("loader", "protocol", "chip_id", "flash_size", "region_start", "region_size", "max_write", "bauds")
    return dict(zip(keys, fields))


class Link:
    """Serial port with a small receive buffer and a transcript for -v."""

    def __init__(self, port: str, verbose: bool):
        try:
            import serial  # pyserial
        except ImportError as exc:
            raise UploadError("pyserial is not installed: py -3 -m pip install pyserial") from exc
        self.verbose = verbose
        try:
            self.ser = serial.Serial(port, LOADER_BAUD, timeout=0.02, write_timeout=2)
        except serial.SerialException as exc:
            raise UploadError(f"cannot open {port}: {exc}") from exc
        self.rx = bytearray()

    def close(self) -> None:
        self.ser.close()

    def set_baud(self, baud: int) -> None:
        self.ser.flush()
        self.ser.baudrate = baud

    def write(self, data: bytes) -> None:
        self.ser.write(data)

    def poll(self) -> bytes:
        chunk = self.ser.read(256)
        if chunk:
            self.rx += chunk
            if self.verbose:
                # backslashreplace keeps the echo ASCII, so any console code page can print it
                sys.stdout.write(chunk.decode("ascii", "backslashreplace").replace("\r", ""))
                sys.stdout.flush()
        return chunk



def log(msg: str) -> None:
    print(msg, flush=True)


# --------------------------------------------------------------------------
# Steps
# --------------------------------------------------------------------------
def send_escape(link: Link) -> None:
    for baud in ESCAPE_BAUDS:
        link.set_baud(baud)
        link.write(ESCAPE)
        link.ser.flush()
        time.sleep(len(ESCAPE) * 10.0 / baud + 0.002)
    link.set_baud(LOADER_BAUD)
    link.ser.reset_input_buffer()


def _probe_eabp(link: Link, seconds: float):
    """Send HELLO frames for a while; return the parsed HELLO, or None."""
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        link.write(eabp_request(CMD_HELLO, 0))
        stop = min(end, time.monotonic() + 0.02)
        while time.monotonic() < stop:
            link.poll()
            rsp = eabp_take_response(bytearray(link.rx))
            if rsp and rsp[0] == CMD_HELLO and rsp[2] == ST_OK:
                link.rx.clear()
                return parse_hello(rsp[3])
    return None


def enter_loader(link: Link, wait: float, escape: bool) -> dict:
    """Find the Arduino loader after the reset; return its parsed HELLO."""
    start = time.monotonic()
    last_escape = start
    hinted = False

    while time.monotonic() - start < wait:
        now = time.monotonic()
        if not hinted and now - start > 6:
            log("No loader yet - press the reset button on the board.")
            hinted = True
        # If the window passed (or the sketch missed the first sequence), the
        # sketch runs again: send the reset sequence again.
        if escape and now - last_escape > 3.5:
            send_escape(link)
            last_escape = time.monotonic()

        # The loader listens 0.5-1 s after a reset, so probe often.
        link.rx.clear()
        hello = _probe_eabp(link, 0.5)
        if hello:
            return hello

    raise UploadError(
        f"no Arduino loader answered within {wait:.0f} s (check the port, or press reset); "
        "a board that still runs AppLoader needs the Arduino loader burned first"
    )


def eabp_upload(link: Link, image: bytes, hello: dict, baud: int = LOADER_BAUD) -> None:
    """Send the image to the Arduino loader and start it."""
    client = Eabp(link)

    if len(image) > hello["region_size"]:
        raise UploadError(f"sketch is {len(image)} bytes, the board takes at most {hello['region_size']}")

    if baud != LOADER_BAUD:
        bit = EABP_BAUDS.index(baud) if baud in EABP_BAUDS else -1
        if bit < 0 or not (hello["bauds"] >> bit) & 1:
            raise UploadError(f"the loader does not support {baud} baud")
        client.check(CMD_SET_BAUD, struct.pack("<I", baud))
        link.set_baud(baud)
        try:
            client.check(CMD_HELLO)
        except UploadError:
            # the loader falls back to 115200 after 1 s without a frame
            link.set_baud(LOADER_BAUD)
            time.sleep(1.1)
            log(f"{baud} baud did not work, continuing at {LOADER_BAUD}.")

    log(f"Sending {len(image)} bytes...")
    t0 = time.monotonic()
    client.check(CMD_BEGIN, struct.pack("<I", len(image)), timeout=2.0)

    step = hello["max_write"]
    last_pct = -1
    for offset in range(0, len(image), step):
        chunk = image[offset : offset + step]
        client.check(CMD_WRITE, struct.pack("<I", offset) + chunk, timeout=2.0)  # may erase a sector first
        pct = (offset + len(chunk)) * 100 // len(image)
        if pct // 10 != last_pct // 10:
            log(f"  {pct:3d}%  {offset + len(chunk)}/{len(image)} bytes")
            last_pct = pct

    # 3 s for a 184 KB image, scaled with the size (the loader reads back and CRCs all of it)
    verify_timeout = max(3.0, 3.0 * len(image) / 0x2E000)
    status, data = client.request(CMD_VERIFY, struct.pack("<I", crc32(image)), timeout=verify_timeout)
    if status != ST_OK:
        got = struct.unpack_from("<I", data)[0] if len(data) >= 4 else 0
        raise UploadError(f"verify failed: board CRC32 0x{got:08X}, image 0x{crc32(image):08X}")

    log(f"Done in {time.monotonic() - t0:.1f} s. Starting the sketch.")
    client.check(CMD_BOOT)


def upload(args) -> None:
    image = Path(args.file).read_bytes()
    if not image:
        raise UploadError(f"{args.file} is empty")

    link = Link(args.port, args.verbose)
    try:
        if not args.no_escape:
            log("Resetting the board into its loader...")
            send_escape(link)
        hello = enter_loader(link, args.wait, not args.no_escape)
        log(f"Arduino loader {hello['loader'] >> 8}.{hello['loader'] & 0xFF}, protocol {hello['protocol']}.")
        eabp_upload(link, image, hello, args.baud)
    finally:
        link.close()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Upload a .bin to an ESMT ER813x board through the Arduino loader.")
    parser.add_argument("--port", required=True, help="serial port, e.g. COM5 or /dev/ttyUSB0")
    parser.add_argument("--file", required=True, help="application image (.bin)")
    parser.add_argument("--wait", type=float, default=30.0, help="seconds to wait for the loader (default 30)")
    parser.add_argument("--no-escape", action="store_true", help="do not send the reset sequence")
    parser.add_argument(
        "--baud",
        type=int,
        default=LOADER_BAUD,
        choices=EABP_BAUDS,
        help="transfer rate with the Arduino loader (default 115200)",
    )
    parser.add_argument("-v", "--verbose", action="store_true", help="show what the loader sends")
    args = parser.parse_args(argv)

    try:
        upload(args)
    except UploadError as exc:
        print(f"esmt_upload: error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
