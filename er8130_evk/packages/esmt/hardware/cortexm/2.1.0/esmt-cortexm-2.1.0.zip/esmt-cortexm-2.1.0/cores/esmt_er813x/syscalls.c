/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/*
 * newlib system calls for Arduino sketches (replaces middleware/retarget).
 *
 * stdout/stderr (printf, SDK debug_print, the HardFault report) go to the
 * Serial UART with blocking writes, so they still work inside fault handlers
 * and with interrupts off. "\n" becomes "\r\n" like retarget.c; Serial.print()
 * does not go through here and sends bytes unchanged.
 */

#include <errno.h>
#include <stddef.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "Arduino.h"
#include "wise_sys_api.h"
#include "wise_uart_api.h"

int _write(int file, char *ptr, int len)
{
    (void)file;

    for (int i = 0; i < len; i++) {
        if (ptr[i] == '\n') {
            (void)wise_uart_write_char(PIN_SERIAL_UART, '\r');
        }
        (void)wise_uart_write_char(PIN_SERIAL_UART, (uint8_t)ptr[i]);
    }

    return len;
}

int _read(int file, char *ptr, int len)
{
    (void)file;
    (void)ptr;
    (void)len;
    errno = EBADF;
    return -1;
}

int _close(int file)
{
    (void)file;
    errno = EBADF;
    return -1;
}

int _fstat(int file, struct stat *st)
{
    (void)file;
    st->st_mode = S_IFCHR;
    return 0;
}

int _isatty(int file)
{
    (void)file;
    return 1;
}

int _lseek(int file, int offset, int whence)
{
    (void)file;
    (void)offset;
    (void)whence;
    errno = ESPIPE;
    return -1;
}

int _getpid(void)
{
    return 1;
}

int _kill(int pid, int sig)
{
    (void)pid;
    (void)sig;
    errno = EINVAL;
    return -1;
}

/* abort() and exit() end here: reset, so the board goes back to the loader
 * instead of hanging (same as the HardFault path). */
void _exit(int status)
{
    (void)status;
    wise_sys_chip_reset();
    while (1) {}
}

/* Heap between __HeapBase and __HeapLimit (default_9006.ld); malloc() gets
 * NULL instead of running into the stack. */
extern char __HeapBase;
extern char __HeapLimit;

void *_sbrk(ptrdiff_t incr)
{
    static char *cur = NULL;
    char *prev;

    if (cur == NULL) {
        cur = &__HeapBase;
    }

    if ((cur + incr) > &__HeapLimit) {
        errno = ENOMEM;
        return (void *)-1;
    }

    prev  = cur;
    cur  += incr;
    return prev;
}
