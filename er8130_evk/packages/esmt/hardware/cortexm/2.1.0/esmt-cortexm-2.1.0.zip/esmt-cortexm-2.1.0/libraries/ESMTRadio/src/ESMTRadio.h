/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef ESMT_RADIO_H
#define ESMT_RADIO_H

#include <Arduino.h>

/** Largest payload of one packet, in bytes (1-byte length header). */
#define ESMT_RADIO_MAX_PACKET 255

/**
 * @brief Sub-GHz packet radio of the ER813x (GFSK), with a LoRa-library
 * style API.
 *
 * Packets: preamble, sync word, a 1-byte length, the payload (1 to 255
 * bytes) and a CRC-16, the same format as the WISE shell "rf" commands
 * (WISEDemoApp), so a sketch and a board running the shell can talk.
 *
 * @code
 * Radio.begin(915000000);              // Hz
 * Radio.beginPacket();
 * Radio.print("hello");
 * Radio.endPacket();                   // blocks until sent
 *
 * Radio.receive();                     // listen continuously
 * int size = Radio.parsePacket();      // 0 when nothing came in
 * while (Radio.available()) Serial.write(Radio.read());
 * @endcode
 *
 * Both radios need the same frequency, data rate, deviation, sync word and
 * CRC setting. Received packets wait in the driver (3 packets); a packet
 * with a bad CRC is dropped unless the CRC is disabled.
 *
 * onReceive() and onTxDone() callbacks run from the core loop (between
 * loop() passes and inside delay()), not in the interrupt, so they may use
 * Serial and the radio.
 *
 * After LowPower.sleep() the radio is off: call receive() again.
 */
class ESMTRadioClass: public Stream
{
  public:
    /**
     * @brief Start the radio on a frequency.
     * @param frequency Carrier frequency in Hz (for example 868000000, 915000000).
     * @return 1 on success, 0 if the driver rejected the setup.
     */
    int begin(long frequency);
    /** @brief Stop receiving and release the radio. */
    void end();

    /** @brief Start a new outgoing packet (drops the unsent one). @return 1, or 0 while an async send is busy. */
    int beginPacket();
    /**
     * @brief Send the packet.
     * @param async false: wait until it is sent; true: return at once, onTxDone() and isTransmitting() tell when it is done.
     * @return 1 when sent (async: started), 0 on an error or an empty packet.
     */
    int endPacket(bool async = false);
    /** @brief True while an async send is in progress. */
    bool isTransmitting();

    /**
     * @brief Take the next received packet.
     * @return its payload size, 0 if none is waiting. Read it with read()/available().
     */
    int parsePacket();
    /** @brief RSSI of the last packet from parsePacket(), in dBm. */
    int packetRssi();
    /** @brief Signal strength on the channel now, in dBm (only while receiving). */
    int rssi();

    size_t write(uint8_t byte) override;
    size_t write(const uint8_t *buffer, size_t size) override;
    using Print::write;
    int available() override;
    int read() override;
    int peek() override;
    void flush() override
    {
    }

    /** @brief Call fn(size) from the core loop for every received packet; also starts receiving. nullptr stops it. */
    void onReceive(void (*callback)(int));
    /** @brief Call fn() from the core loop when an async send finishes. */
    void onTxDone(void (*callback)());

    /**
     * @brief Listen continuously. A send pauses listening and the driver
     * resumes it afterwards, so call this once, not after every send: it
     * restarts the receiver and drops packets not yet taken.
     */
    void receive();
    /** @brief Stop listening; the radio powers down between sends. */
    void idle();
    /** @brief Same as idle(): the radio is off whenever it is neither sending nor receiving. */
    void sleep()
    {
        idle();
    }

    /** @brief Transmit power in dBm, -6 to 11 (clamped). */
    void setTxPower(int dbm);
    /** @brief Carrier frequency in Hz. @return 1 on success. */
    int setFrequency(long frequency);
    /**
     * @brief Data rate in bit/s: 12500, 50000, 100000, 125000, 250000, 500000
     * (default) or 1000000. Sets the deviation to a quarter of it (modulation index 0.5).
     * @return 1 on success, 0 for an unsupported rate.
     */
    int setDataRate(long bps);
    /**
     * @brief Frequency deviation in Hz. The driver supports a modulation index
     * (2 x deviation / data rate) of 0.5 or 1 (at 12.5 kbit/s: 0.5 or 4).
     * @return 1 on success, 0 for another value.
     */
    int setFrequencyDeviation(long hz);
    /** @brief 4-byte sync word (default 0xD8EC6B99); both sides must match. */
    void setSyncWord(uint32_t syncWord);
    /** @brief Preamble length in bytes, 1 to 4 (default 4). */
    void setPreambleLength(int bytes);
    /** @brief Check (default) or skip the CRC-16 of each packet. */
    void enableCrc();
    void disableCrc();

    /** @brief Packets received OK / with a bad CRC since begin(). */
    unsigned long packetsReceived();
    unsigned long crcErrors();

    /** @brief Not for sketches: radio interrupt and core-loop hooks. */
    static void _event(uint32_t evt);
    static void _service();

  private:
    bool started   = false;
    bool listening = false;
    long frequency = 0;
    long dataRate  = 500000;
    long deviation = 125000;
    uint32_t syncWord = 0xD8EC6B99UL;
    uint8_t preambleLen = 4;
    bool crc            = true;
    int8_t txPowerDbm   = 11;

    uint8_t txBuf[ESMT_RADIO_MAX_PACKET + 1]; /* [0] = length */
    uint16_t txLen = 0;
    uint8_t rxBuf[ESMT_RADIO_MAX_PACKET];
    uint16_t rxLen = 0;
    uint16_t rxPos = 0;
    int8_t lastRssi = 0;

    volatile bool txBusy   = false;
    volatile bool txFinish = false;
    void (*userReceive)(int) = nullptr;
    void (*userTxDone)()     = nullptr;

    int configure();
    void listen();
};

extern ESMTRadioClass Radio;

#endif /* ESMT_RADIO_H */
