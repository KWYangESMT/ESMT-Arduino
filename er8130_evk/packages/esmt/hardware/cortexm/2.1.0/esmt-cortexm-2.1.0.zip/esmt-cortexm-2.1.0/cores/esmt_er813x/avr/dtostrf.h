/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

/**
 * @file dtostrf.h
 * @brief AVR libc number-to-string functions (also declared by Arduino.h).
 *
 * itoa() and utoa() come from newlib's stdlib.h.
 */

#ifndef ESMT_AVR_DTOSTRF_H
#define ESMT_AVR_DTOSTRF_H

#ifdef __cplusplus
extern "C" {
#endif

/** @brief Format val with prec decimals, right-aligned in width (left-aligned if width < 0); returns buf. */
char *dtostrf(double val, signed char width, unsigned char prec, char *buf);
/** @brief Signed long to text in radix 2..36; returns buf. */
char *ltoa(long val, char *buf, int radix);
/** @brief Unsigned long to text in radix 2..36; returns buf. */
char *ultoa(unsigned long val, char *buf, int radix);

#ifdef __cplusplus
}
#endif

#endif /* ESMT_AVR_DTOSTRF_H */
