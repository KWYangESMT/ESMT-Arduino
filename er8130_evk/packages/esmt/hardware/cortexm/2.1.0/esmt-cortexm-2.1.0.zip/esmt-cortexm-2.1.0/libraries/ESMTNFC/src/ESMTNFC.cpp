/*
 * Copyright (C) 2026 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "ESMTNFC.h"

#include <string.h>

extern "C" {
#include "wise_core.h"
#include "wise_nfc_api.h"
}

/* The chip headers define NFC as the register block; this file only uses
 * the wise_nfc_* functions, so the name is free for the Arduino object. */
#undef NFC

/*
 * Follows the WISEDemoApp NFC demo (app/WISEDemoApp/src/demo_nfc): full
 * work mode, lock mode value 1, the tag header of wise_nfc_set_uri(). The
 * NDEF message is built here and written with wise_nfc_block_write_data()
 * instead of wise_nfc_set_uri(), which keeps the old records and needs about
 * 2 KB of stack. Only the public wise_nfc_* API is used.
 */

#define NDEF_FIRST_BLOCK 4
#define NDEF_TLV         0x03
#define NDEF_TERMINATOR  0xFE
#define NDEF_MB          0x80
#define NDEF_ME          0x40
#define NDEF_SR          0x10
#define TNF_WELL_KNOWN   0x01

/* Largest message: TLV header (4 bytes when >= 255) + message + terminator. */
#define MSG_MAX (ESMT_NFC_CAPACITY - 5)

/* Tag header blocks 0-3 (UID / lock bytes, capability container: NDEF
 * version 1.0, 992 bytes, read/write), as wise_nfc_set_uri() writes them. */
static const uint32_t tagHeader[4] = {0xC8743400UL, 0x801CE3E1UL, 0x0000009EUL, 0x007C10E1UL};

/* NFC Forum URI record prefixes; longer ones first where they overlap. */
static const struct {
    uint8_t code;
    const char *text;
} uriPrefixes[] = {
    {0x02, "https://www."},
    {0x01, "http://www."},
    {0x04, "https://"},
    {0x03, "http://"},
    {0x05, "tel:"},
    {0x06, "mailto:"},
};

ESMTNFCClass NFC;

bool ESMTNFCClass::begin()
{
    WISE_NFC_CFG_T cfg;

    cfg.work_mode = NFC_WORK_MDOE_FULL;
    cfg.lock_mode = (NFC_MEM_LOCK_MODE_E)1; /* the value the SDK demos use */
    if (eventSource == 0) {
        eventSource = NFC_EVENT_TX;
    }
    cfg.int_idx = (NFC_INT_IDX_E)eventSource;

    wise_nfc_init();
    wise_nfc_config(&cfg); /* chip power, clears blocks 0-254 */
    wise_nfc_block_write_data(0, 4, (uint32_t *)tagHeader);

    started    = true;
    building   = false;
    pending    = false;
    msgLen     = 0;
    quietCount = eventCount;
    quietSince = millis() - ESMT_NFC_HOLD_MS;
    clear();

    /* wise_nfc_config() enables the interrupt, but the handler only clears
     * it once a callback has been registered: without one, the first
     * reader in the field keeps the CPU in the interrupt until the
     * watchdog resets the board. So the counter is always registered. */
    eventSeen = eventCount;
    wise_nfc_register_int_callback((NFC_INT_IDX_E)eventSource, _isr, nullptr);
    esmtAddService(_service);
    return true;
}

void ESMTNFCClass::end()
{
    if (!started) {
        return;
    }
    if (eventSource) {
        wise_nfc_unregister_int_callback((NFC_INT_IDX_E)eventSource);
    }
    wise_nfc_switch_pwr_src(NFC_PWR_MODE_PASSIVE);
    wise_nfc_deinit();
    started = false;
    pending = false;
}

/* ------------------------------------------------------------- message --- */

void ESMTNFCClass::beginMessage()
{
    msgLen     = 0;
    lastRecord = 0;
    building   = true;
    overflow   = false;
}

size_t ESMTNFCClass::spaceLeft() const
{
    return building && !overflow ? MSG_MAX - msgLen : 0;
}

bool ESMTNFCClass::append(uint8_t tnf, const uint8_t *type, uint8_t typeLen, const uint8_t *prefix,
                          size_t prefixLen, const uint8_t *payload, size_t payloadLen)
{
    size_t total = prefixLen + payloadLen;
    bool sr      = total <= 255;
    size_t size  = 2 + (sr ? 1 : 4) + typeLen + total;

    if (!building || overflow || size > MSG_MAX - msgLen) {
        overflow = true;
        return false;
    }

    uint8_t *p = msg + msgLen;
    *p++       = (uint8_t)((msgLen == 0 ? NDEF_MB : 0) | (sr ? NDEF_SR : 0) | (tnf & 0x07));
    *p++       = typeLen;
    if (sr) {
        *p++ = (uint8_t)total;
    } else {
        *p++ = (uint8_t)(total >> 24);
        *p++ = (uint8_t)(total >> 16);
        *p++ = (uint8_t)(total >> 8);
        *p++ = (uint8_t)total;
    }
    memcpy(p, type, typeLen);
    p += typeLen;
    if (prefixLen) {
        memcpy(p, prefix, prefixLen);
        p += prefixLen;
    }
    if (payloadLen) {
        memcpy(p, payload, payloadLen);
    }
    lastRecord  = msgLen;
    msgLen     += size;
    return true;
}

bool ESMTNFCClass::addRecord(uint8_t tnf, const uint8_t *type, uint8_t typeLen, const uint8_t *payload,
                             size_t payloadLen)
{
    return append(tnf, type, typeLen, nullptr, 0, payload, payloadLen);
}

bool ESMTNFCClass::addUri(const char *uri)
{
    uint8_t code = 0;

    if (uri == nullptr || *uri == '\0') {
        overflow = true;
        return false;
    }
    for (size_t i = 0; i < sizeof(uriPrefixes) / sizeof(uriPrefixes[0]); i++) {
        size_t n = strlen(uriPrefixes[i].text);
        if (strncmp(uri, uriPrefixes[i].text, n) == 0) {
            code  = uriPrefixes[i].code;
            uri  += n;
            break;
        }
    }
    static const uint8_t type = 'U';
    return append(TNF_WELL_KNOWN, &type, 1, &code, 1, (const uint8_t *)uri, strlen(uri));
}

bool ESMTNFCClass::addText(const char *text, const char *lang)
{
    uint8_t head[64];
    size_t langLen = lang ? strlen(lang) : 0;

    if (text == nullptr || langLen > 63) {
        overflow = true;
        return false;
    }
    head[0] = (uint8_t)langLen; /* UTF-8, language length */
    memcpy(head + 1, lang, langLen);
    static const uint8_t type = 'T';
    return append(TNF_WELL_KNOWN, &type, 1, head, 1 + langLen, (const uint8_t *)text, strlen(text));
}

bool ESMTNFCClass::endMessage()
{
    if (!building) {
        return false;
    }
    building = false;
    if (overflow || msgLen == 0) {
        pending = false; /* a held message was replaced by this one */
        return false;
    }
    msg[lastRecord] |= NDEF_ME;
    return store();
}

bool ESMTNFCClass::writePending() const
{
    return pending;
}

/* A reader is active if the interrupt source fired in the last
 * ESMT_NFC_HOLD_MS (an interrupt not yet seen counts as just now). */
bool ESMTNFCClass::readerActive()
{
    unsigned long count = eventCount;

    if (count != quietCount) {
        quietCount = count;
        quietSince = millis();
        return true;
    }
    return millis() - quietSince < ESMT_NFC_HOLD_MS;
}

/* Write the message now, or hold it until the reader is quiet. */
bool ESMTNFCClass::store()
{
    if (!started) {
        return false;
    }
    if (readerActive()) {
        pending = true;
        return true;
    }
    pending = false;
    return writeMessage();
}

bool ESMTNFCClass::setUri(const char *uri)
{
    beginMessage();
    addUri(uri);
    return endMessage();
}

bool ESMTNFCClass::setText(const char *text, const char *lang)
{
    beginMessage();
    addText(text, lang);
    return endMessage();
}

void ESMTNFCClass::clear()
{
    building = false;
    msgLen   = 0;
    store();
}

/* TLV byte i of the area that starts at block 4: header, message, terminator. */
static uint8_t tlvByte(const uint8_t *msg, size_t msgLen, size_t i)
{
    size_t head = msgLen < 255 ? 2 : 4;

    if (i == 0) {
        return NDEF_TLV;
    }
    if (head == 2) {
        if (i == 1) {
            return (uint8_t)msgLen;
        }
    } else if (i < 4) {
        return i == 1 ? 0xFF : (i == 2 ? (uint8_t)(msgLen >> 8) : (uint8_t)msgLen);
    }
    if (i < head + msgLen) {
        return msg[i - head];
    }
    return i == head + msgLen ? NDEF_TERMINATOR : 0;
}

bool ESMTNFCClass::writeMessage()
{
    if (!started) {
        return false;
    }
    size_t total  = (msgLen < 255 ? 2 : 4) + msgLen + 1;
    size_t blocks = (total + 3) / 4;
    uint32_t word;

    /* A reader in the field sees an empty message, never a half-written
     * one: block 4 is made empty first and gets the real header last. */
    word = NDEF_TLV | ((uint32_t)NDEF_TERMINATOR << 16);
    wise_nfc_block_write_data(NDEF_FIRST_BLOCK, 1, &word);

    for (size_t b = 1; b < blocks; b++) {
        word = 0;
        for (size_t k = 0; k < 4; k++) {
            word |= (uint32_t)tlvByte(msg, msgLen, b * 4 + k) << (8 * k);
        }
        wise_nfc_block_write_data((uint8_t)(NDEF_FIRST_BLOCK + b), 1, &word);
    }

    word = 0;
    for (size_t k = 0; k < 4; k++) {
        word |= (uint32_t)tlvByte(msg, msgLen, k) << (8 * k);
    }
    wise_nfc_block_write_data(NDEF_FIRST_BLOCK, 1, &word);
    return true;
}

int ESMTNFCClass::readMessage(uint8_t *buffer, size_t size)
{
    if (!started) {
        return -1;
    }

    /* Walk the TLVs from block 4: NULL TLVs are skipped, lock / memory
     * control TLVs jumped over, until the NDEF TLV or the terminator. */
    uint32_t word    = 0;
    int cached       = -1;
    const size_t end = ESMT_NFC_CAPACITY;
    auto byteAt      = [&](size_t i) -> uint8_t {
        int block = (int)(i / 4);
        if (block != cached) {
            wise_nfc_block_read_data((uint8_t)(NDEF_FIRST_BLOCK + block), 1, &word);
            cached = block;
        }
        return (uint8_t)(word >> (8 * (i % 4)));
    };

    size_t pos = 0;
    while (pos < end) {
        uint8_t t = byteAt(pos++);
        if (t == 0x00) {
            continue;
        }
        if (t == NDEF_TERMINATOR || pos >= end) {
            return -1;
        }
        size_t len = byteAt(pos++);
        if (len == 0xFF) {
            if (pos + 2 > end) {
                return -1;
            }
            len  = ((size_t)byteAt(pos) << 8) | byteAt(pos + 1);
            pos += 2;
        }
        if (len > end - pos) {
            return -1;
        }
        if (t == NDEF_TLV) {
            for (size_t i = 0; i < len && i < size; i++) {
                buffer[i] = byteAt(pos + i);
            }
            return (int)len;
        }
        pos += len;
    }
    return -1;
}

/* -------------------------------------------------------------- blocks --- */

bool ESMTNFCClass::readBlock(uint8_t block, uint32_t *data, uint8_t count)
{
    if (!started || data == nullptr || count == 0 || (unsigned)block + count > 256) {
        return false;
    }
    wise_nfc_block_read_data(block, count, data);
    return true;
}

bool ESMTNFCClass::writeBlock(uint8_t block, const uint32_t *data, uint8_t count)
{
    if (!started || data == nullptr || count == 0 || (unsigned)block + count > 256) {
        return false;
    }
    wise_nfc_block_write_data(block, count, (uint32_t *)data);
    return true;
}

/* -------------------------------------------------------------- events --- */

void ESMTNFCClass::onEvent(void (*callback)(int), int source)
{
    if (source < NFC_EVENT_POR || source > NFC_EVENT_1) {
        return;
    }
    userEvent = callback;
    if (started && source != eventSource) {
        /* The counter stays registered on the active source (see begin()). */
        wise_nfc_unregister_int_callback((NFC_INT_IDX_E)eventSource);
        wise_nfc_register_int_callback((NFC_INT_IDX_E)source, _isr, nullptr);
        wise_nfc_set_interrupt_idx((NFC_INT_IDX_E)source);
    }
    eventSource = source; /* before begin(), begin() selects it */
    eventSeen   = eventCount;
}

unsigned long ESMTNFCClass::events()
{
    return eventCount;
}

void ESMTNFCClass::_isr(void *context, uint8_t idx)
{
    (void)context;
    (void)idx;
    NFC.eventCount++;
}

/* Core loop: write a held message once the reader is quiet, and deliver
 * the event callback outside the interrupt. delay() in
 * the callback runs the core loop again, so the callback is not re-entered:
 * interrupts that arrive meanwhile give one more call after it returns. */
void ESMTNFCClass::_service()
{
    static bool busy;

    if (!NFC.started) {
        return;
    }
    if (NFC.pending && !NFC.building && !NFC.readerActive()) {
        NFC.pending = false;
        NFC.writeMessage();
    }
    if (busy || NFC.userEvent == nullptr) {
        return;
    }
    unsigned long count = NFC.eventCount;
    if (count != NFC.eventSeen) {
        busy          = true;
        NFC.eventSeen = count;
        NFC.userEvent(NFC.eventSource);
        busy = false;
    }
}
