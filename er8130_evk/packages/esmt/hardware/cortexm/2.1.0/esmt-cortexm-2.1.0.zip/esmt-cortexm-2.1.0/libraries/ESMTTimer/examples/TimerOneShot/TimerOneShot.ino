// Type a number of milliseconds in the Serial Monitor (115200): a one-shot
// timer fires after that time, and loop() reports how late it was.

#include <ESMTTimer.h>

volatile bool fired;
volatile unsigned long firedAt;

void onTimer()
{
    firedAt = micros();
    fired   = true;
}

void setup()
{
    Serial.begin(115200);
    Serial.println("Type a delay in ms");
}

void loop()
{
    if (Serial.available()) {
        long ms = Serial.parseInt();
        if (ms > 0) {
            fired = false;
            unsigned long start = micros();
            Timer2.once(ms * 1000UL, onTimer);
            while (!fired) {
            }
            Serial.print("fired after ");
            Serial.print(firedAt - start);
            Serial.println(" us");
        }
    }
}
