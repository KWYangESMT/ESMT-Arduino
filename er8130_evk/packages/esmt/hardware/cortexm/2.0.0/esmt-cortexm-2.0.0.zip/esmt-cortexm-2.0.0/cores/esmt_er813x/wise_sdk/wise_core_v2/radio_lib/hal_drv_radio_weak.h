#ifndef __HAL_DRV_RADIO_WEAK_H__
#define __HAL_DRV_RADIO_WEAK_H__

#include <stdint.h>

void hal_drv_radio_test(uint32_t val);
void hal_drv_radio_chsd_init(void);
void hal_drv_radio_fpga_init(FPGA_INFO_T *fpga_info);
void hal_drv_radio_set_la_init(uint8_t la_output_fmt);
void hal_drv_radio_chsd_set_zero_if(void);
uint8_t hal_drv_radio_get_tx_test_pattern(void);
void hal_drv_radio_set_tx_test_pattern(uint8_t pat_id);
void hal_drv_radio_fpga_init_step2(FPGA_INFO_T *fpga_info);
void hal_drv_radio_set_csma_cfg(CSMA_CFG_T *csma_cfg);
void hal_drv_radio_get_csma_cfg(CSMA_CFG_T *csma_cfg);
void hal_drv_radio_tx_csma_en(uint8_t enable);
void hal_drv_radio_get_rx_status(int8_t phy_idx, HAL_RX_STATS_T *rx_sts);
void hal_drv_radio_set_tx_wait_for_ack(uint8_t enable);


#endif /* __HAL_DRV_RADIO_WEAK_H__ */
