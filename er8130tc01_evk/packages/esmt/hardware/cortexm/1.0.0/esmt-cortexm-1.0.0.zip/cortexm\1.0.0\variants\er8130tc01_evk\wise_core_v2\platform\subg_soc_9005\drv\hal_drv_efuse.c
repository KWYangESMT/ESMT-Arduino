/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "drv/hal_drv_efuse.h"
#include "hdl/efuse_er8130.h"

int8_t hal_drv_efuse_read_word(uint16_t addr, uint32_t *data)
{
    return efuse_read_word_er8130(addr, data);
}

int8_t hal_drv_efuse_write_word(uint16_t addr, uint32_t data)
{
    return efuse_write_word_er8130(addr, data);
}
