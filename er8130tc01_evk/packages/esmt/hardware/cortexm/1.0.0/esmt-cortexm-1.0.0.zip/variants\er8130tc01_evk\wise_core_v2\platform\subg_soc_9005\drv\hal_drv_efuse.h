/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef _EFUSE_ER8130_H_
#define _EFUSE_ER8130_H_

#include "esmt_chip_specific.h"
#include "types.h"

int8_t hal_drv_efuse_read_word(uint16_t addr, uint32_t *data);
int8_t hal_drv_efuse_write_word(uint16_t addr, uint32_t data);

#endif
