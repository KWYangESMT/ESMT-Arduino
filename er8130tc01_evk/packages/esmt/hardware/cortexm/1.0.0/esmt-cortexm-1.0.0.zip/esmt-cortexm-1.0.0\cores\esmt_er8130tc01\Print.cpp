#include "Print.h"

#ifdef __cplusplus
extern "C" {
#endif
#include <stdio.h>
#include "util.h"
#ifdef __cplusplus
}
#endif


size_t Print::print(const char *s) 
{
    if (s == nullptr) 
    {
        return 0;
    }

    size_t n = 0;
    while (*s) 
    {
        n += this->write((uint8_t)*s++);
    }
    
    return n;
}

size_t Print::println(void) 
{
    size_t n = 0;
    
    n += write('\r');
    n += write('\n');

    return n;
}

size_t Print::println(const char *s) 
{
    size_t n = print(s);
    n += println();
    return n;
}

size_t Print::printNumber(unsigned long n, uint8_t base) 
{
    char buf[32];
    char *p = &buf[sizeof(buf) - 1];
    
    *p = '\0';

    if (base < 2) 
        base = 10;

    do 
    {
        unsigned long m = n % base;
        *--p = (m < 10) ? ('0' + m) : ('A' + (m - 10));
        n /= base;
    } while (n);

    return print(p);
}

size_t Print::println(int v) 
{
    size_t n = 0;
    
    if (v < 0) 
    {
        n += write('-');
        v = -v;
    }
    
    n += printNumber((unsigned long)v, 10);
    n += println();
    return n;
}

size_t Print::println(unsigned int v) 
{
    size_t n = printNumber((unsigned long)v, 10);
    n += println();
    return n;
}

size_t Print::println(long v) 
{
    size_t n = 0;
    
    if (v < 0) 
    {
        n += write('-');
        v = -v;
    }
    
    n += printNumber((unsigned long)v, 10);
    n += println();
    return n;
}

size_t Print::println(unsigned long v) 
{
    size_t n = printNumber(v, 10);
    n += println();
    return n;
}

