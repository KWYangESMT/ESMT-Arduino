/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "hal_intf_efuse.h"
#include "esmt_chip_specific.h"
#include "drv/hal_drv_efuse.h"

HAL_STATUS hal_intf_efuse_read_word(uint16_t addr, uint32_t *data)
{
    return (HAL_STATUS)hal_drv_efuse_read_word(addr, data);
}

HAL_STATUS hal_intf_efuse_write_word(uint16_t addr, uint32_t data)
{
    return (HAL_STATUS)hal_drv_efuse_write_word(addr, data);
}
