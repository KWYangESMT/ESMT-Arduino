#include "Arduino.h"
#include "wise_tick_api.h"
#include "wise_wutmr_api.h"

E_PLATFORM_STATE_T _platformState = E_PLATFORM_STATE_IDLE;


unsigned long millis(void) 
{
    uint32_t tickCounter = wise_wutmr_get_counter();
    
    return wise_wutmr_clk_to_ms(tickCounter);
}

unsigned long micros(void) 
{
    uint32_t ms = millis();
    
    return ((unsigned long)ms) * 1000UL;
}

void delay(unsigned long ms) 
{
    wise_tick_delay_ms(ms);
}

void init(void) 
{
    initVariant();
}

E_PLATFORM_STATE_T platform_proc()
{
    _variant_proc();
    
    return _platformState;
}

void platform_set_state(E_PLATFORM_STATE_T state)
{
    _platformState = state;
}


