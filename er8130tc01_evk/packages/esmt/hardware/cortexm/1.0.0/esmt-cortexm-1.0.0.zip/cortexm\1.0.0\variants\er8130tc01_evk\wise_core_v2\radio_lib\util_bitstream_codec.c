#include <stdio.h>
#include <string.h>

#include "util_bitstream_codec.h"
#include "util.h"

int nrz_encode(const uint8_t* input, int input_bit_len, uint8_t* output) 
{
    for (int i = 0; i < input_bit_len; i++) 
    {
        int byte_index = i / 8;
        int bit_offset = 7 - (i % 8);
        uint8_t bit = (input[byte_index] >> bit_offset) & 1;

        if (bit)
            output[byte_index] |= (1 << bit_offset);
        else
            output[byte_index] &= ~(1 << bit_offset);
    }
    
    return input_bit_len;
}

int nrz_decode(const uint8_t* input, int input_bit_len, uint8_t* output) 
{
    for (int i = 0; i < input_bit_len; i++) 
    {
        int byte_index = i / 8;
        int bit_offset = 7 - (i % 8);
        uint8_t bit = (input[byte_index] >> bit_offset) & 1;

        if (bit)
            output[byte_index] |= (1 << bit_offset);
        else
            output[byte_index] &= ~(1 << bit_offset);
    }

    return input_bit_len;
}

#define MAX_OUTPUT_LEN    256

static const uint8_t wmbus_encode_nibble_3of6[16] = {
    0x16, 0x0D, 0x0E, 0x0B,
    0x1C, 0x19, 0x1A, 0x13,
    0x2C, 0x25, 0x26, 0x23,
    0x34, 0x31, 0x32, 0x29
};

uint8_t wmbus_decode_nibble_3of6(uint8_t byte)
{
    uint8_t out = 0xFF; // Error fallback
    switch (byte) {
        case 0x16: out = 0x00; break;
        case 0x0D: out = 0x01; break;
        case 0x0E: out = 0x02; break;
        case 0x0B: out = 0x03; break;
        case 0x1C: out = 0x04; break;
        case 0x19: out = 0x05; break;
        case 0x1A: out = 0x06; break;
        case 0x13: out = 0x07; break;
        case 0x2C: out = 0x08; break;
        case 0x25: out = 0x09; break;
        case 0x26: out = 0x0A; break;
        case 0x23: out = 0x0B; break;
        case 0x34: out = 0x0C; break;
        case 0x31: out = 0x0D; break;
        case 0x32: out = 0x0E; break;
        case 0x29: out = 0x0F; break;
        default: break;
    }
    return out;
}


uint32_t wmbus_encode_3of6(const uint8_t *input, uint32_t input_len, uint8_t *output) {
	uint32_t i,j;
    uint32_t bit_index = 0;

    /* It is necessary to clear output buffer in advance */
    //memset(output_bits, 0, MAX_OUTPUT_LEN*2);
    
    for (i = 0; i < input_len; ++i) {
        uint8_t byte = input[i];
        uint8_t hi = wmbus_encode_nibble_3of6[(byte >> 4) & 0x0F];
        uint8_t lo = wmbus_encode_nibble_3of6[byte & 0x0F];

        /* endcode bit by bit */
        for (j = 0; j < 6; ++j, ++bit_index){
            output[bit_index / 8] |= ((hi >> (5 - j)) & 1) << (7 - (bit_index % 8));
        }
        for (j = 0; j < 6; ++j, ++bit_index){
            output[bit_index / 8] |= ((lo >> (5 - j)) & 1) << (7 - (bit_index % 8));
        }
    }

    /* Postamble */
    uint8_t postamble = 0x55;
    uint32_t postamble_len = (input_len % 2) ? 4 : 8;

    for (j = 0; j < postamble_len; ++j, ++bit_index){
        output[bit_index / 8] |= ((postamble >> (7 - (j % 8))) & 1) << (7 - (bit_index % 8));
    }

    return (bit_index +7)/8;
}

uint32_t wmbus_decode_3of6(const uint8_t *input_bits, uint32_t input_len, uint8_t *output) {
    uint32_t bit_index = 0, output_index = 0;
    uint32_t input_bits_len = input_len*8;

    /* It is necessary to clear output buffer in advance */
    //memset(output, 0, MAX_OUTPUT_LEN);

    while (bit_index + 12 <= input_bits_len && output_index < MAX_OUTPUT_LEN) {
        uint8_t hi = 0, lo = 0;
        uint8_t j;
        for (j = 0; j < 6; ++j){
            hi = (hi << 1) | ((input_bits[(bit_index + j) / 8] >> (7 - ((bit_index + j) % 8))) & 1);
        }
        for (j = 0; j < 6; ++j){
            lo = (lo << 1) | ((input_bits[(bit_index + 6 + j) / 8] >> (7 - ((bit_index + 6 + j) % 8))) & 1);
        }
        bit_index += 12;


        uint8_t nh = wmbus_decode_nibble_3of6(hi);
        uint8_t nl = wmbus_decode_nibble_3of6(lo);
        if (nh == 0xFF || nl == 0xFF)
        {
            debug_print("3of6 invalid byte\n");
            return 0;
            //break;
        }
        output[output_index++] = (nh << 4) | nl;
    }

    return output_index;
}

uint32_t manchester_encode(const uint8_t* input, uint32_t input_len, uint8_t* output) {
    uint32_t input_bit_len = input_len * 8;
    uint32_t out_bit_index = 0;

    uint32_t in_byte, in_bit, out_byte, out_bit;
    uint8_t bit, first, second;
    for (uint32_t i = 0; i < input_bit_len; i++) {
        in_byte = i / 8;
        in_bit = 7 - (i % 8);
        bit = (input[in_byte] >> in_bit) & 1;

        first = bit ? 0 : 1;
        second = bit ? 1 : 0;

        out_byte = out_bit_index / 8;
        out_bit = 7 - (out_bit_index % 8);

        if (first) {
            output[out_byte] |= (1 << out_bit);
        }
        else {
            output[out_byte] &= ~(1 << out_bit);
        }
        out_bit_index++;

        out_byte = out_bit_index / 8;
        out_bit = 7 - (out_bit_index % 8);
        if (second) {
            output[out_byte] |= (1 << out_bit);
        }
        else {
            output[out_byte] &= ~(1 << out_bit);
        }
        out_bit_index++;
    }

    return out_bit_index/8;
}

uint32_t manchester_decode(const uint8_t* input, uint32_t input_len, uint8_t* output) {
    
    uint32_t input_bit_len = input_len * 8;
    uint32_t out_bit_index = 0;

    uint32_t byte1, bit1, byte2, bit2;
    uint8_t first, second;

    if((input_len % 2) != 0) 
    {
        return 0;
    }
    
    for (int i = 0; i < input_bit_len; i += 2) {
        byte1 = i / 8;
        bit1 = 7 - (i % 8);
        byte2 = (i + 1) / 8;
        bit2 = 7 - ((i + 1) % 8);

        first = (input[byte1] >> bit1) & 1;
        second = (input[byte2] >> bit2) & 1;

        if (first == 1 && second == 0){
            output[out_bit_index / 8] &= ~(1 << (7 - (out_bit_index % 8)));
        }
        else if (first == 0 && second == 1){
            output[out_bit_index / 8] |= (1 << (7 - (out_bit_index % 8)));
        }
        else{
            return -1;
        }

        out_bit_index++;
    }

    return out_bit_index/8;
}


int32_t util_bitstream_encode(uint8_t type, const uint8_t *input, uint32_t input_len, uint8_t *output, uint32_t *output_len)
{
    switch(type)
    {
        case BS_TYPE_NRZ:
            return nrz_encode(input, input_len, (uint8_t *)output_len);
        break;
        
        case BS_TYPE_MANCHESTER:
            return manchester_encode(input, input_len, output);
        break;
        
        case BS_TYPE_3_OF_6:
            return wmbus_encode_3of6(input, input_len, output);
        break;
    
        default:
            return -1;
    }

    return 0;
}

int32_t util_bitstream_decode(uint8_t type, const uint8_t *input_bits, uint32_t input_len, uint8_t *output)
{
    uint32_t decLen = 0;
    int32_t retVal = -1;
    
    switch(type)
    {
        case BS_TYPE_NRZ:
            return nrz_decode(input_bits, input_len, output);
        break;
        
        case BS_TYPE_MANCHESTER:
        {
            decLen =  manchester_decode(input_bits, input_len, output);
            if(decLen == 0)
                return -1;
            
            retVal = (int32_t)decLen;
        }
        break;
        
        case BS_TYPE_3_OF_6:
        {
            decLen = wmbus_decode_3of6(input_bits, input_len, output);
            if(decLen == 0)
                return -1;
            
            retVal = (int32_t)decLen;
        }
        break;
    
        default:
            return -1;
    }

    return retVal;
}

void print_bytes(const uint8_t *buf, size_t len) {
    size_t i; 
	for (i = 0; i < len; ++i)
        printf("%02X ", buf[i]);
    printf("\n");
}

void test_3of6_case(const uint8_t *data, size_t len) {
    uint8_t encoded[512] = {0};
    uint8_t decoded[256] = {0};
    uint32_t encoded_len = 0;
    uint32_t decoded_len = 0;


    printf("Input:    ");
    print_bytes(data, len);

    memset(encoded, 0, 512);
    encoded_len = wmbus_encode_3of6(data, len, encoded);
    printf("3 out of 6 Encoded:  ");
    print_bytes(encoded, encoded_len);

    memset(decoded, 0, 216);
    decoded_len = wmbus_decode_3of6(encoded, encoded_len, decoded);
    printf("3 out of 6 Decoded:  ");
    print_bytes(decoded, decoded_len);

    if ((decoded_len != len) || (memcmp(data, decoded, len) != 0)){
        printf("Result: FAIL\n\n");
    }
    else{
        printf("Result: PASS\n\n");
    }
}

void test_man_case(const uint8_t *data, size_t len) {
    uint8_t encoded[512] = {0};
    uint8_t decoded[256] = {0};
    uint32_t encoded_len = 0;
    uint32_t decoded_len = 0;


    printf("Input:    ");
    print_bytes(data, len);


    memset(encoded, 0, 512);
    encoded_len = manchester_encode(data, len, encoded);
    printf("Manchester Encoded:  ");
    print_bytes(encoded, encoded_len);

    memset(decoded, 0, 216);
    decoded_len = manchester_decode(encoded, len * 2, decoded);
    printf("Manchester Decoded:  ");
    print_bytes(decoded, decoded_len);

    if ((decoded_len != len) || (memcmp(data, decoded, len) != 0)){
        printf("Result: FAIL\n\n");
    }
    else{
        printf("Result: PASS\n\n");
    }
}

void verify_codec(void){
    const uint8_t t1[] = { 0x12, 0x34, 0xAB, 0xCD };
    const uint8_t t2[] = { 0x12, 0x34, 0xAB, 0xCD, 0xEF };
    const uint8_t t3[] = { 0x00, 0xFF, 0x55, 0xAA, 0x66, 0x99 };
    const uint8_t t4[] = { 0x0F, 0x44, 0xAE, 0x0C, 0x78, 0x56, 0x34, 0x12, 0x01, 0x07, 0x44, 0x47, 0x78, 0x0B, 0x13, 0x43, 0x65, 0x87, 0x1E, 0x6D};

    test_3of6_case(t1, sizeof(t1));
    test_3of6_case(t2, sizeof(t2));
    test_3of6_case(t3, sizeof(t3));
    test_3of6_case(t4, sizeof(t4));

    test_man_case(t1, sizeof(t1));
    test_man_case(t2, sizeof(t2));
    test_man_case(t3, sizeof(t3));
    test_man_case(t4, sizeof(t4));
}
