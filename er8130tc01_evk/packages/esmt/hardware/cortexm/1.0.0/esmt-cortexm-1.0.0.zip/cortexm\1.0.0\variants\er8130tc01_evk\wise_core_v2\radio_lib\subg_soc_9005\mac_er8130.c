/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "regfiles/mac_reg_er8130.h"
#include "mac_er8130.h"
#include "hal_intf_radio.h"
#include "util.h"
#include "drv/hal_drv_sys.h"

static uint8_t osr_default[] = {
    8, // 12.5kHz
    8, // 50kHz
    8, // 100kHz
    8, // 125kHz
    8, // 200kHz
    8, // 250kHz
    8, // 500kHz
    8,  // 1MHz
    8,  // 2MHz
};

static MAC_INFO_T mac_info = {0};
MAC_INFO_T *mac_get_mac_info_er81xx(void)
{
    return &mac_info;
}

void mac_set_mod_type_er81xx(uint32_t mod_type)
{
    uint32_t val;
    uint32_t type;

    type = (mod_type == MOD_TYPE_BPSK) ? (1) : (0);

    val = REG_R32(MAC_DATCOL_BBP_MOD_ADDR);
    val = (val & ~MAC_DATCOL_BBP_MOD_MASK) |
          ((type << MAC_DATCOL_BBP_MOD_POS) & MAC_DATCOL_BBP_MOD_MASK) |
          MAC_DATCOL_AGC_RESTR_DIS_MASK;
    REG_W32(MAC_DATCOL_BBP_MOD_ADDR, val);
}

void mac_get_rx_val_len_er81xx(RADIO_RX_INFO_T *rx_info)
{
    rx_info->rx_meta.data_len = REG_R32(MAC_RXLEN_ADDR) >> MAC_RXLEN_POS;
}

void mac_tx_start_er81xx(uint8_t *tx_buf, uint32_t tx_len)
{
    uint32_t cca_en = 0x0; // 0x01 = launch tx with CSMA-CA
    uint32_t reg_val;
    uint32_t tx_en = 1;

    reg_val = REG_R32(MAC_TXEN_ADDR);
    reg_val = (reg_val & ~(MAC_TXEN_MASK + MAC_TXENCCA_MASK + MAC_TXLEN_MASK)) |
              ((tx_en << MAC_TXEN_POS) & MAC_TXEN_MASK) |
              ((cca_en << MAC_TXENCCA_POS) & MAC_TXENCCA_MASK) |
              ((tx_len << MAC_TXLEN_POS) & MAC_TXLEN_MASK);
    REG_W32(MAC_TXEN_ADDR, reg_val);
}

void mac_tx_stop_er81xx(void)
{
    uint32_t tx_stop = 1;
    uint32_t tx_en = 0;
    uint32_t reg_val;



    reg_val = REG_R32(MAC_TXEN_ADDR);
    reg_val = (reg_val & ~(MAC_TXSTOP_MASK + MAC_TXEN_MASK)) |
              ((tx_en << MAC_TXEN_POS) & MAC_TXEN_MASK) |
              ((tx_stop << MAC_TXSTOP_POS) & MAC_TXSTOP_MASK);
    REG_W32(MAC_TXEN_ADDR, reg_val);

    while (1) {
        reg_val = REG_R32(MAC_TXEN_ADDR);

        if (!(reg_val & (MAC_TXEN_MASK | MAC_TXENCCA_MASK))) {
            break;
        }
    };
}
uint8_t mac_rx_stop_er81xx(uint8_t phy_mode)
{
    (void)phy_mode; // Unused parameter
    uint32_t time_out = 1000; // 20ms for rx turn off
    uint32_t cnt = 0;
    uint8_t to = 0;

    // Disable RX enable bit
    REG_W32(MAC_RXEN_ADDR, REG_R32(MAC_RXEN_ADDR) & ~MAC_RXEN_MASK);

    while (REG_R32(MAC_RF_RX_BSY_ADDR) & MAC_RF_RX_BSY_MASK) {
        // 10 us delay
        hal_drv_sys_tick_delay_us(10);
        cnt++;

        if (cnt >= time_out) {
            printf("%s: mac rx stop time out\n", __func__);
            to = 1;
            break;
        }
    }

    return to;
}

void mac_rx_start_er81xx(uint8_t phy_mode)
{
    uint32_t reg      = 0;
    uint8_t rx_802_en = (phy_mode == PHY_MODE_802154) ? 1 : 0;
    uint8_t rx_trn_en = (phy_mode == PHY_MODE_TRANSPARENT || phy_mode == PHY_MODE_MBUS) ? 1 : 0;
    uint8_t rx_cca_en = (phy_mode == PHY_MODE_CCA) ? 1 : 0;

    reg = REG_R32(MAC_RXEN_ADDR);
    reg = (reg & ~(MAC_RXEN_802_MASK + MAC_RXEN_TRN_MASK + MAC_RX_CCA_MASK)) |
           ((rx_802_en << MAC_RXEN_802_POS) & MAC_RXEN_802_MASK) |
           ((rx_trn_en << MAC_RXEN_TRN_POS) & MAC_RXEN_TRN_MASK) |
           ((rx_cca_en << MAC_RX_CCA_POS) & MAC_RX_CCA_MASK);
    REG_W32(MAC_RXEN_ADDR, reg);
    REG_W32(MAC_RXEN_ADDR, REG_R32(MAC_RXEN_ADDR) | MAC_RXEN_MASK);
}

void mac_set_rx_restart_er81xx(uint8_t enable)
{
    uint32_t reg = REG_R32(MAC_RXEN_ADDR);
    reg &= ~(MAC_RXEN_RESTR_MASK);
    reg |= ((enable << MAC_RXEN_RESTR_POS) & MAC_RXEN_RESTR_MASK);
    REG_W32(MAC_RXEN_ADDR, reg);
    
}

void mac_event_get_status_er81xx(EVENT_INFO_U *event_info)
{
    uint32_t int_info = 0;

    int_info = REG_R32(MAC_INT_ST_ADDR);

    event_info->event_b.rx_ok   = (int_info & MAC_INT_RX_MASK) ? (1) : (0);
    event_info->event_b.rx_err  = (int_info & MAC_INT_RXERR_MASK) ? (1) : (0);
    event_info->event_b.tx_ok   = (int_info & MAC_INT_TX_MASK) ? (1) : (0);
    event_info->event_b.tx_err  = (int_info & MAC_INT_TXERR_MASK) ? (1) : (0);
    event_info->event_b.rx_to   = (int_info & MAC_INT_RXTOUT_MASK) ? (1) : (0);
    event_info->event_b.tmr_evt = (int_info & MAC_INT_TMREVT_MASK) ? (1) : (0);
    event_info->event_b.syncw   = (int_info & MAC_INT_SYNCW_MASK) ? (1) : (0);
}

void mac_event_clear_status_er81xx(uint32_t event_status)
{
    REG_W32(MAC_INT_ST_RX_ADDR, event_status);
}

void mac_set_tx_sync_word_er81xx(uint32_t mod_type, uint32_t *sync_word, uint8_t sync_word_len)
{
    uint32_t reg;
    uint8_t tx_sync_wd_num = 0;
    uint8_t tx_pre1_en;
    uint8_t tx_pre1_num;
    uint8_t tx_pre1_pat;
    uint8_t tx_bpsk_pkt_format_en;

    if (mod_type == MOD_TYPE_GFSK || mod_type == MOD_TYPE_FSK) {
        // GFSK use 1 pattern only
        tx_sync_wd_num        = (sync_word_len - 1);
        tx_pre1_en            = 0;
        tx_pre1_num           = 0;
        tx_pre1_pat           = 0;
        tx_bpsk_pkt_format_en = 0;
    }

    if (mod_type == MOD_TYPE_BPSK) {
        // BPSK use 2 different pattern
        tx_sync_wd_num        = 0; //(N+1) = 1byte
        tx_pre1_en            = 1;
        tx_pre1_num           = 15; // (N+1) = 16byte
        tx_pre1_pat           = 0xFF;
        tx_bpsk_pkt_format_en = 1;
    }

    // MAC_TX_CFG3 (0x034)
    reg  = REG_R32(MAC_TX_SFD_NUM_ADDR);
    reg  = (reg & ~(MAC_TX_SFD_NUM_MASK + MAC_TX_PRE1_EN_MASK + MAC_TX_PRE1_NUM_MASK +
                    MAC_TX_PRE1_PAT_MASK + MAC_TX_BPSK_PKT_FORMAT_EN_MASK)) |
           ((tx_sync_wd_num << MAC_TX_SFD_NUM_POS) & MAC_TX_SFD_NUM_MASK) |
           ((tx_pre1_en << MAC_TX_PRE1_EN_POS) & MAC_TX_PRE1_EN_MASK) |
           ((tx_pre1_num << MAC_TX_PRE1_NUM_POS) & MAC_TX_PRE1_NUM_MASK) |
           ((tx_pre1_pat << MAC_TX_PRE1_PAT_POS) & MAC_TX_PRE1_PAT_MASK) |
           ((tx_bpsk_pkt_format_en << MAC_TX_BPSK_PKT_FORMAT_EN_POS) & MAC_TX_BPSK_PKT_FORMAT_EN_MASK);
    REG_W32(MAC_TX_SFD_NUM_ADDR, reg);

    // add sync word part1
    // MAC_TX_CFG4
    REG_W32(MAC_TX_CFG4_ADDR, sync_word[0]);

    // add sync word part2 here
    // MAC_TX_CFG5
    REG_W32(MAC_TX_CFG5_ADDR, sync_word[1]);
}

void mac_set_tx_wmbus_sync_word_er81xx(uint8_t wmbus_mode, uint32_t data_rate)
{
    uint32_t reg;
    uint32_t syncword = 0x0;
    uint8_t sw_len;

    switch(wmbus_mode) {
    case HAL_WMBUS_MODE_S:
        sw_len = 4;
        syncword = 0x55547696;
        break;
    case HAL_WMBUS_MODE_T:
        if (data_rate == 100000) {
            sw_len = 4;
            syncword = 0x5555543D;
        }
        if (data_rate == 32768) {
            sw_len = 4;
            syncword = 0x55547696;
        }
        break;
    case HAL_WMBUS_MODE_C:
        if (data_rate == 100000) {
            sw_len = 4;
            syncword = 0x543D54CD;
        }
        if (data_rate == 50000) {
            sw_len = 4;
            syncword = 0x543D54CD;
        }
        break;
    case HAL_WMBUS_MODE_R:
        sw_len = 4;
        syncword = 0x55547696;
        mac_set_tx_preamble_er81xx(0xAA, 0x8);
        break;
    default:
        printf("%s: wmbus_mode is bad = %d\n", __func__, wmbus_mode);
        break;
    }

    // MAC_TX_CFG3 (0x034)
    reg  = REG_R32(MAC_TX_SFD_NUM_ADDR);
    reg  = (reg & ~(MAC_TX_SFD_NUM_MASK)) |
           (((sw_len-1) << MAC_TX_SFD_NUM_POS) & MAC_TX_SFD_NUM_MASK);
    REG_W32(MAC_TX_SFD_NUM_ADDR, reg);

    // MAC_TX_CFG4 (0x038)
    syncword = bit_reverse(syncword, sw_len);
    REG_W32(MAC_TX_CFG4_ADDR, syncword);

}

void mac_set_tx_data_rate_er81xx(uint32_t data_rate)
{
    // MAC_TX_DATDLV (0x030)
    uint32_t reg;
    uint32_t dlv_prd;

    // set data delivery period: unit is 0.5us
    dlv_prd = DATA_RATE_2M / data_rate;

    reg     = REG_R32(MAC_DATDLV_DUAL_PRD_ADDR);
    reg     = (reg & ~MAC_DATDLV_DUAL_PRD_MASK) |
            ((dlv_prd << MAC_DATDLV_DUAL_PRD_POS) & MAC_DATDLV_DUAL_PRD_MASK);
    REG_W32(MAC_DATDLV_DUAL_PRD_ADDR, reg);
}

void mac_set_tx_preamble_er81xx(uint32_t pream, uint8_t pream_len)
{
    // MAC_TX_CFG2 (0x02C)
    uint32_t reg;

    reg = REG_R32(MAC_TX_PRE_NUM_ADDR);
    reg = (reg & ~(MAC_TX_PRE_NUM_MASK + MAC_TX_PRE_PAT_MASK)) |
          (((pream_len - 1) << MAC_TX_PRE_NUM_POS) & MAC_TX_PRE_NUM_MASK) |
          ((pream << MAC_TX_PRE_PAT_POS) & MAC_TX_PRE_PAT_MASK);
    REG_W32(MAC_TX_PRE_NUM_ADDR, reg);
}

void mac_set_tx_phy_format_cfg_er81xx(uint32_t mod_type, uint8_t tx_hw_opt)
{
    // MAC_TX_CFG (0x028)
    uint32_t reg;
    uint8_t hw_pream_en      = (tx_hw_opt & FRAME_HW_PREAMBLE) ? (1) : (0);
    uint8_t hw_sync_wrd_en   = (tx_hw_opt & FRAME_HW_SYNC_WORD) ? (1) : (0);
    uint8_t hw_802154_hdr_en = (tx_hw_opt & FRAME_HW_PHR) ? (1) : (0);
    uint8_t hw_crc_en        = (tx_hw_opt & FRAME_HW_CRC) ? (1) : (0);
    uint8_t hw_fec_en        = (tx_hw_opt & FRAME_HW_FEC) ? (1) : (0);
    uint8_t hw_manch_en      = (tx_hw_opt & FRAME_HW_MANCH) ? (1) : (0);
    

    reg = REG_R32(MAC_TX_APPENDPRE_ADDR);
    reg = (reg & ~(MAC_TX_APPENDPRE_MASK + MAC_TX_APPENDSFD_MASK +
                   MAC_TX_APPENDPHR_MASK + MAC_TX_APPENDFCS_MASK)) |
          ((hw_pream_en << MAC_TX_APPENDPRE_POS) & MAC_TX_APPENDPRE_MASK) |
          ((hw_sync_wrd_en << MAC_TX_APPENDSFD_POS) & MAC_TX_APPENDSFD_MASK) |
          ((hw_802154_hdr_en << MAC_TX_APPENDPHR_POS) & MAC_TX_APPENDPHR_MASK) |
          ((hw_crc_en << MAC_TX_APPENDFCS_POS) & MAC_TX_APPENDFCS_MASK) |
          ((hw_fec_en << MAC_TX_FEC_EN_POS) & MAC_TX_FEC_EN_MASK) |
          ((hw_manch_en << MAC_TX_MANCH_EN_POS) & MAC_TX_MANCH_EN_MASK);
    REG_W32(MAC_TX_APPENDPRE_ADDR, reg);
}

void mac_set_rx_manchester_er81xx(uint8_t enable)
{
    uint32_t reg = 0;

    reg = REG_R32(MAC_RX_FEA_ADDR);
    reg = (reg & ~MAC_RX_MANCH_EN_MASK) |
          ((enable << MAC_RX_MANCH_EN_POS) & MAC_RX_MANCH_EN_MASK);
    REG_W32(MAC_RX_FEA_ADDR, reg);
}

void mac_set_tx_whitening_er81xx(uint32_t mod_type, uint8_t enable)
{
    // MAC_TX_CFG (0x028)
    uint8_t hw_pn9_phr = 0;
    uint8_t hw_pn9_dat = 0;
    uint8_t hw_pn9_fcs = 0;
    uint32_t reg;

    // BPSK will force enable whitening
    if (mod_type == MOD_TYPE_BPSK || enable) {
        hw_pn9_phr = 1;
        hw_pn9_dat = 1;
        hw_pn9_fcs = 1;
    }

    reg  = REG_R32(MAC_TX_APPENDPRE_ADDR);
    reg |= (reg & ~(MAC_TX_PN9PHR_MASK + MAC_TX_PN9DAT_MASK + MAC_TX_PN9FCS_MASK)) |
           ((hw_pn9_phr << MAC_TX_PN9PHR_POS) & MAC_TX_PN9PHR_MASK) |
           ((hw_pn9_dat << MAC_TX_PN9DAT_POS) & MAC_TX_PN9DAT_MASK) |
           ((hw_pn9_fcs << MAC_TX_PN9FCS_POS) & MAC_TX_PN9FCS_MASK);
    REG_W32(MAC_TX_APPENDPRE_ADDR, reg);
}

void mac_set_rx_maxlen_er81xx(uint32_t rx_max_len)
{
    uint32_t reg;

    reg  = REG_R32(MAC_MAXRXLEN_ADDR);
    reg = (reg & ~MAC_MAXRXLEN_MASK) |
           ((rx_max_len << MAC_MAXRXLEN_POS) & MAC_MAXRXLEN_MASK);
    REG_W32(MAC_MAXRXLEN_ADDR, reg);
}

void mac_set_rx_802154_keepfmt_er81xx(uint8_t keep)
{
    uint32_t reg;

    reg  = REG_R32(MAC_RX_802_ADDR);
    reg |= (reg & ~(MAC_RX_KEEPPHR_MASK + MAC_RX_KEEPFCS_MASK)) |
           ((keep << MAC_RX_KEEPPHR_POS) & MAC_RX_KEEPPHR_MASK) |
           ((keep << MAC_RX_KEEPFCS_POS) & MAC_RX_KEEPFCS_MASK);
    REG_W32(MAC_RX_802_ADDR, reg);
}

void mac_set_panid_er81xx(uint16_t panid)
{
    uint32_t reg;
    uint8_t en = (panid == 0xFFFF) ? 0 : 1;

    reg = REG_R32(MAC_RX_802FILT_ADDR) & ~(MAC_RX_REJ_DUPID_MASK);

    if (en) {
        reg |= ((en << MAC_RX_REJ_DUPID_POS) & MAC_RX_REJ_DUPID_MASK);
    }

    REG_W32(MAC_RX_802FILT_ADDR, reg);

    reg = REG_R32(MAC_INFO0_ADDR);
    reg = (reg & ~(MAC_PAN_ID_MASK)) |
          ((panid << MAC_PAN_ID_POS) & MAC_PAN_ID_MASK);
    REG_W32(MAC_INFO0_ADDR, reg);
}

void mac_set_short_addr_er81xx(uint16_t s_addr)
{
    uint32_t reg, mask;

    mask = REG_R32(MAC_RX_802FILT_ADDR) & ~(MAC_RX_REJ_DUADR_MASK);
    reg  = REG_R32(MAC_INFO1_ADDR) & ~(MAC_SADDR_MASK);

    if (VALIDATE_SADDR(s_addr)) {
        mask |= MAC_RX_REJ_DUADR_MASK;
        reg  |= ((s_addr << MAC_SADDR_POS) & MAC_SADDR_MASK);
    }

    REG_W32(MAC_RX_802FILT_ADDR, mask);
    REG_W32(MAC_INFO1_ADDR, reg);
}

void mac_set_long_addr_er81xx(const uint8_t *l_addr)
{
    uint32_t mask;
    uint32_t laddr_h = 0, laddr_l = 0;

    mask = REG_R32(MAC_RX_802FILT_ADDR) & ~(MAC_RX_REJ_DUADR_MASK);
    //      laddr_l = (uint32_t)((*(laddr+3) << 24) | (*(laddr+2) << 16) |
    //      (*(laddr+1) << 8) | (*(laddr+0) << 0)); laddr_h =
    //      (uint32_t)((*(laddr+7) << 24) | (*(laddr+6) << 16) | (*(laddr+5) <<
    //      8) | (*(laddr+4) << 0));
    laddr_l = LOAD_LE_32(&l_addr[0]);
    laddr_h = LOAD_LE_32(&l_addr[4]);

    if (VALIDATE_LADDR(laddr_l, laddr_h)) {
        mask |= MAC_RX_REJ_DUADR_MASK;
    } else {
        laddr_l = 0;
        laddr_h = 0;
    }

    REG_W32(MAC_RX_802FILT_ADDR, mask);
    REG_W32(MAC_INFO2_ADDR, laddr_l);
    REG_W32(MAC_INFO3_ADDR, laddr_h);
}

uint8_t mac_get_osr_er81xx(uint32_t mod_type, uint8_t dr_idx)
{
    // BPSK uses osr 8 for all data rate.
    // It should be modified if other modulation types are needed in the future.
    return (mod_type == MOD_TYPE_GFSK) ? osr_default[dr_idx] : 8;
}

void mac_enable_interrupt_er81xx(uint32_t int_mask)
{
    //uint32_t int_musk = (MAC_INT_EN_RX_MASK | MAC_INT_EN_RXERR_MASK | MAC_INT_EN_SYNCW_MASK |
    //                     MAC_INT_EN_TX_MASK | MAC_INT_EN_TXERR_MASK);

    // user_def_spi_tx(spi_cmd, &int_musk, 4);
    REG_W32(MAC_INT_EN_RX_ADDR, int_mask);
    NVIC_EnableIRQ((IRQn_Type)MAC_IRQn);
}

void mac_disable_interrupt_er81xx(void)
{
    //      uint32_t int_musk = (
    //                         MAC_INT_EN_RX_MASK |
    //                         MAC_INT_EN_RXERR_MASK
    //                     );

    // user_def_spi_tx(spi_cmd, &int_musk, 4);
    REG_W32(MAC_INT_EN_RX_ADDR, 0x0);
    NVIC_DisableIRQ((IRQn_Type)MAC_IRQn);
    //      MAC_INFO("int musk : 0x%x \n", int_musk);
}

uint32_t mac_get_interrupt_status_er81xx(void)
{
    return REG_R32(MAC_INT_ST_ADDR);
}

void mac_clear_interrupt_status_er81xx(uint32_t status)
{
    REG_W32(MAC_INT_ST_ADDR, status);
}


uint32_t mac_get_iqk_ch_er81xx(uint8_t mat_type)
{
#if RADIO_PHY_0_SUPPORT
    uint32_t iqk_ch; 
    
    switch(mat_type){
    case BOARD_MATCHING_915MHZ:
        iqk_ch = 915500000;
        break;
    case BOARD_MATCHING_868MHZ:
        iqk_ch = 868000000;
        break;
    case BOARD_MATCHING_490MHZ:
        iqk_ch = 490000000;
        break;
    default:
        printf("%s: mat_type is bad = %d \n", __func__, mat_type);
        iqk_ch = 915500000;
        break;
    }

    return iqk_ch;
#else
    return 0;
#endif
}

void mac_enable_rx_timeout_er81xx(uint8_t to_base, uint8_t to_num)
{
    uint32_t reg = REG_R32(MAC_RX_FEA_ADDR);

    reg &= ~(MAC_RX_TIMEOUT_THD_MASK | MAC_RX_TIMEOUT_NUM_MASK);
    reg |= ((to_base << MAC_RX_TIMEOUT_THD_POS) & MAC_RX_TIMEOUT_THD_MASK);
    reg |= ((to_num << MAC_RX_TIMEOUT_NUM_POS) & MAC_RX_TIMEOUT_NUM_MASK);
    // if the rx timeout isr is set, these flags will be disabled at MAC ISR
    // when the mcu is woken up
    reg |= (MAC_WU_RX_EN_MASK | MAC_RX_TIMEOUT_EN_MASK | MAC_RX_TIMEOUT_DSLEEP_MASK);
    REG_W32(MAC_RX_FEA_ADDR, reg);
}

void mac_disable_rx_timeout_er81xx(void)
{
    uint32_t reg = REG_R32(MAC_RX_FEA_ADDR);

    reg &= ~(MAC_WU_RX_EN_MASK | MAC_RX_TIMEOUT_EN_MASK | MAC_RX_TIMEOUT_DSLEEP_MASK);
    REG_W32(MAC_RX_FEA_ADDR, reg);
}

void mac_set_rx_payload_order_er81xx(uint8_t bit_rev, uint8_t byte_rev)
{
    uint32_t reg = REG_R32(MAC_MISC_REG_ADDR);
    reg &= ~(MAC_DMA_RX_BIT_REVERSE_MASK | MAC_DMA_RX_BYTE_REVERSE_MASK);
    reg |= ((bit_rev << MAC_DMA_RX_BIT_REVERSE_POS) & MAC_DMA_RX_BIT_REVERSE_MASK);
    reg |= ((byte_rev << MAC_DMA_RX_BYTE_REVERSE_POS) & MAC_DMA_RX_BYTE_REVERSE_MASK);
    REG_W32(MAC_MISC_REG_ADDR, reg);
}

void mac_set_tx_payload_order_er81xx(uint8_t bit_rev, uint8_t byte_rev)
{
    uint32_t reg = REG_R32(MAC_MISC_REG_ADDR);
    reg &= ~(MAC_DMA_TX_BIT_REVERSE_MASK | MAC_DMA_TX_BYTE_REVERSE_MASK);
    reg |= ((bit_rev << MAC_DMA_TX_BIT_REVERSE_POS) & MAC_DMA_TX_BIT_REVERSE_MASK);
    reg |= ((byte_rev << MAC_DMA_TX_BYTE_REVERSE_POS) & MAC_DMA_TX_BYTE_REVERSE_MASK);
    REG_W32(MAC_MISC_REG_ADDR, reg);
}

void mac_set_crc_inverse_er81xx(uint8_t enable)
{
    uint32_t reg = REG_R32(MAC_CRC_REG_ADDR);
    reg &= ~(MAC_CRC_INV_MASK);
    reg |= ((enable << MAC_CRC_INV_POS) & MAC_CRC_INV_MASK);
    REG_W32(MAC_CRC_REG_ADDR, reg);
}

void mac_set_crc_bit_endian_er81xx(uint8_t din, uint8_t dout)
{
    uint32_t reg = REG_R32(MAC_CRC_REG_ADDR);
    reg &= ~(MAC_CRC_ENDIAN_IN_MASK | MAC_CRC_ENDIAN_OUT_MASK);
    reg |= (((din ^ 0x1) << MAC_CRC_ENDIAN_IN_POS) & MAC_CRC_ENDIAN_IN_MASK);
    reg |= (((dout ^ 0x1) << MAC_CRC_ENDIAN_OUT_POS) & MAC_CRC_ENDIAN_OUT_MASK);
    REG_W32(MAC_CRC_REG_ADDR, reg);
}

void mac_set_crc_byte_endian_er81xx(uint8_t endian)
{
    uint32_t reg = REG_R32(MAC_CRC_REG_ADDR);
    reg &= ~(MAC_CRC_MSB_MASK);
    reg |= ((endian << MAC_CRC_MSB_POS) & MAC_CRC_MSB_MASK);
    REG_W32(MAC_CRC_REG_ADDR, reg);
}

void mac_set_crc_config_er81xx(uint8_t bit, uint32_t poly, uint32_t init_val)
{
    uint32_t reg = REG_R32(MAC_CRC_REG_ADDR);
    reg &= ~(MAC_CRC_BIT_MASK);
    reg |= ((bit << MAC_CRC_BIT_POS) & MAC_CRC_BIT_MASK);
    REG_W32(MAC_CRC_REG_ADDR, reg);

    REG_W32(MAC_CRC_REG_EXT0_ADDR, poly);

    if (bit == 16) {
        init_val = (init_val & 0xFFFF) << bit;
    } else if (bit == 24) {
        init_val = (init_val & 0xFFFFFF) << (32 - bit);
    } else {
    }

    REG_W32(MAC_CRC_REG_EXT2_ADDR, init_val);
}

void mac_enable_crc_check_er81xx(uint8_t enable)
{
    uint32_t reg = REG_R32(MAC_RX_802_ADDR);
    reg &= ~(MAC_RX_CRCCHKEN_MASK | MAC_RX_TRN_CRCCHKEN_MASK);
    reg |= ((enable << MAC_RX_CRCCHKEN_POS) & MAC_RX_CRCCHKEN_MASK);
    reg |= ((enable << MAC_RX_TRN_CRCCHKEN_POS) & MAC_RX_TRN_CRCCHKEN_MASK);
    REG_W32(MAC_RX_802_ADDR, reg);
}

void mac_enable_phr_check_er81xx(uint8_t enable)
{
    uint32_t reg = REG_R32(MAC_RX_802_ADDR);
    reg &= ~(MAC_RX_TRN_PHRCHKEN_MASK);
    reg |= ((enable << MAC_RX_TRN_PHRCHKEN_POS) & MAC_RX_TRN_PHRCHKEN_MASK);
    REG_W32(MAC_RX_802_ADDR, reg);
}

void mac_set_rx_phr_config_er81xx(uint8_t len, uint8_t offset, uint8_t inv_en, uint16_t bits)
{
    uint16_t mask = 0;
    uint32_t reg = REG_R32(MAC_RX_802_ADDR);
    reg &= ~(MAC_RX_PHR2B_MASK);
    reg |= ((((len == 2) ? 1 : 0) << MAC_RX_PHR2B_POS) & MAC_RX_PHR2B_MASK);
    REG_W32(MAC_RX_802_ADDR, reg);
    
    reg = REG_R32(MAC_RXPHR_REG_ADDR);
    reg &= ~(MAC_RXLEN_SFT_MASK | MAC_RX_PHRINV_MASK | MAC_RXPHR_MSK_MASK);
    // NOTE:: 1-byte phr is 7-bits, 2-bytes phr is 11-bits
    mask = ((1U << bits) - 1U) & ((len == 2) ? (PHR_TWO_BYTE_MASK) : (PHR_ONE_BYTE_MASK));
    if (inv_en) {
        mask = bit_reverse(mask, len);
        // due to the TXPHR limitation, the offset is fixed to 4-bits if inv_en is enabled.
        // and RXPHR's inverse bits is 11 bits, TXPHR's inverse bits is 12 bits
        // so the offset is fixed to 5-bits if inv_en is enabled.
        offset = 4 + 1;
    }
    reg |= ((offset << MAC_RXLEN_SFT_POS) & MAC_RXLEN_SFT_MASK);
    reg |= ((inv_en << MAC_RX_PHRINV_POS) & MAC_RX_PHRINV_MASK);
    reg |= ((mask << MAC_RXPHR_MSK_POS) & MAC_RXPHR_MSK_MASK);
    
    REG_W32(MAC_RXPHR_REG_ADDR, reg);
}

void mac_set_tx_phr_config_er81xx(uint8_t len, uint8_t offset, uint8_t inv_en)
{
    const uint8_t phr_2byte = (len == 2);
    // NOTE::
    // 1-byte phr is 8-bits, 2-bytes phr is 12-bits
    const uint8_t max_offset = (phr_2byte ? 11 : 7);
    
    uint32_t reg = REG_R32(MAC_TX_CFG_ADDR);
    reg = (reg & ~MAC_TX_PHR2B_MASK) | ((phr_2byte << MAC_TX_PHR2B_POS) & MAC_TX_PHR2B_MASK);
    REG_W32(MAC_TX_CFG_ADDR, reg);

    // due to the HW design limitation, the inverse range only effects on the lowest 12 bits,
    // so the offset is fixed to 4-bits if inv_en is enabled.
    offset = inv_en ? 4 : ((offset > max_offset) ? max_offset : offset);

    reg = REG_R32(MAC_TXPHR_REG_ADDR);
    reg = (reg & ~(MAC_TXLEN_SFT_MASK | MAC_TX_PHRINV_MASK | MAC_TXPHR_PAT_MASK)) |
          ((offset << MAC_TXLEN_SFT_POS) & MAC_TXLEN_SFT_MASK) |
          ((inv_en << MAC_TX_PHRINV_POS) & MAC_TX_PHRINV_MASK);
    REG_W32(MAC_TXPHR_REG_ADDR, reg);
}

uint8_t mac_get_rx_fsm_busy_er81xx(void)
{
    uint32_t reg_val;

    reg_val = REG_R32(MAC_RX_FSM_BSY_ADDR);

    return (uint8_t)((reg_val & MAC_RX_FSM_BSY_MASK) >> MAC_RX_FSM_BSY_POS);
}

