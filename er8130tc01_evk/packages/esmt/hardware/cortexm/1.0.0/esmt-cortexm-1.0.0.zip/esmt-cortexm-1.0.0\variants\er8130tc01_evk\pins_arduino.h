#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

static const uint8_t LED_BUILTIN = 2;

#define NUM_DIGITAL_PINS   4
#define NUM_ANALOG_INPUTS  1

#ifdef __cplusplus
}
#endif
