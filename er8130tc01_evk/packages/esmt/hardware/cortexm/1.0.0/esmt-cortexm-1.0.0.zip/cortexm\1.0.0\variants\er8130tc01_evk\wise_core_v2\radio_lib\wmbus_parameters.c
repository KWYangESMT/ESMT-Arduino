#include <stdio.h>

#include "wise_core.h"
#include "wmbus_parameters.h"
#include "wise_radio_api.h"
#include "wise_radio_wmbus_api.h"
#include "util.h"

#ifdef CHIP_RADIO_HAS_W_MBUS

#ifdef REDUCE_WMBUS_PARAMS
const wmbus_rf_param_t radioWmbusCfg[] = 
{
    // WMBUS MODE S1
    {
        .mode                               = WMBUS_MODE_S1,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_typ_hz                    = 868300000,
            .fsk_deviation_typ_hz           = 50000,
            //.chip_rate_typ_cps              = 32768,
            .data_rate                      = E_DATA_RATE_32P768K,
        },

        .o2m                                = {WMBUS_PARAM_NA}, //NA

        .gfsk_bt                            = WMBUS_PARAM_NA,
    },

    // WMBUS MODE S1M
    {
        .mode                               = WMBUS_MODE_S1M,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_typ_hz                    = 868300000,
            .fsk_deviation_typ_hz           = 50000,
            //.chip_rate_typ_cps              = 32768,
            .data_rate                      = E_DATA_RATE_32P768K,
        },

        .o2m                                = {WMBUS_PARAM_NA}, //NA

        .gfsk_bt                            = WMBUS_PARAM_NA,
    },

    // WMBUS MODE S2
    {
        .mode                               = WMBUS_MODE_S2 | MBUS_MODE_FLAG_O2M,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_typ_hz                    = 868300000,
            .fsk_deviation_typ_hz           = 50000,
            //.chip_rate_typ_cps              = 32768,
            .data_rate                      = E_DATA_RATE_32P768K,
        },

        .o2m =
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,
            
            .freq_typ_hz                    = 868300000,
            .fsk_deviation_typ_hz           = 50000,
            //.chip_rate_typ_cps              = 32768,
            .data_rate                      = E_DATA_RATE_32P768K,
        },

        .gfsk_bt                            = WMBUS_PARAM_NA,
    },

    // WMBUS MODE T1
    {
        .mode                               = WMBUS_MODE_T1,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_3OUTOF6,

            .freq_typ_hz                    = 868950000,
            .fsk_deviation_typ_hz           = 50000,
            //.chip_rate_typ_cps              = 100000,
            .data_rate                      = E_DATA_RATE_100K,
        },

        .o2m                                = {WMBUS_PARAM_NA}, //NA

        .gfsk_bt                            = WMBUS_PARAM_NA,
    },

    // WMBUS MODE T2
    {
        .mode                               = WMBUS_MODE_T2 | MBUS_MODE_FLAG_O2M,

        .m2o = //E_FRAME_CODEC_3OUTOF6
        {
            .codec                          = E_FRAME_CODEC_3OUTOF6,

            .freq_typ_hz                    = 868950000,
            .fsk_deviation_typ_hz           = 50000,
            //.chip_rate_typ_cps              = 100000,
            .data_rate                      = E_DATA_RATE_100K,
        },

        .o2m = //E_FRAME_CODEC_MANCHESTER
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_typ_hz                    = 868300000,
            .fsk_deviation_typ_hz           = 50000,
            //.chip_rate_typ_cps              = 32768,
            .data_rate                      = E_DATA_RATE_32P768K,
        },

        .gfsk_bt                            = WMBUS_PARAM_NA,
    },

    // WMBUS MODE C1
    {
        .mode                               = WMBUS_MODE_C1,

        .m2o =
        {
            .codec                          = E_FRAME_CODEC_NRZ,

            .freq_typ_hz                    = 868950000,
            .fsk_deviation_typ_hz           = 45000,
            //.chip_rate_typ_cps              = 100000,
            .data_rate                      = E_DATA_RATE_100K,
        },

        .o2m                                = {WMBUS_PARAM_NA}, //NA
        
        .gfsk_bt                            = WMBUS_PARAM_NA,
    },

    // WMBUS MODE C2
    {
        .mode                               = WMBUS_MODE_C2 | MBUS_MODE_FLAG_O2M,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_NRZ,

            .freq_typ_hz                    = 868950000,
            .fsk_deviation_typ_hz           = 45000,
            //.chip_rate_typ_cps              = 100000,
            .data_rate                      = E_DATA_RATE_100K,
        },

        .o2m =
        {
            .codec                          = E_FRAME_CODEC_NRZ,

            .freq_typ_hz                    = 869525000,
            .fsk_deviation_typ_hz           = 25000,
            //.chip_rate_typ_cps              = 50000,
            .data_rate                      = E_DATA_RATE_50K,
        },

        .gfsk_bt                            = WMBUS_GFSK_BW_0_50,
    },

    // WMBUS MODE R2
    {
        .mode                               = WMBUS_MODE_R2 | MBUS_MODE_FLAG_O2M,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_typ_hz                    = 868330000,
            .fsk_deviation_typ_hz           = 6000,
            //.chip_rate_typ_cps              = 4800,
            .data_rate                      = E_DATA_RATE_4P8K,
        },

        .o2m = 
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_typ_hz                    = 868030000,
            .fsk_deviation_typ_hz           = 6000,
            //.chip_rate_typ_cps              = 4800,
            .data_rate                      = E_DATA_RATE_4P8K,
        },

        .gfsk_bt                            = WMBUS_PARAM_NA,
    },

    // WMBUS MODE F2
    {
        .mode                               = WMBUS_MODE_F2,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_NRZ,

            .freq_typ_hz                    = 433820000,
            .fsk_deviation_typ_hz           = 5500,
            //.chip_rate_typ_cps              = 4800,
            .data_rate                      = E_DATA_RATE_4P8K,
        },

        .o2m = 
        {
            .codec                          = E_FRAME_CODEC_NRZ,
            
            .freq_typ_hz                    = 433820000,
            .fsk_deviation_typ_hz           = 5500,
            //.chip_rate_typ_cps              = 4800,
            .data_rate                      = E_DATA_RATE_4P8K,
        },

        .gfsk_bt                            = WMBUS_PARAM_NA,
    },
};
#else
const wmbus_rf_param_t radioWmbusCfg[] = 
{
    // WMBUS MODE S1
    {
        .mode                               = WMBUS_MODE_S1,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_min_hz                    = 868250000,
            .freq_typ_hz                    = 868300000,
            .freq_max_hz                    = 868350000,
            .freq_tolerance_ppm             = 60,

            .fsk_deviation_min_hz           = 40000,
            .fsk_deviation_typ_hz           = 50000,
            .fsk_deviation_max_hz           = 80000,

            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 32768,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,
            .chip_rate_tolerance_pct_ppm    = 15000,
            .data_rate_bps                  = 16384,
        },

        .o2m                                = {WMBUS_PARAM_NA}, //NA

        .gfsk_bt                            = WMBUS_PARAM_NA,
        
        .bit_jitter_us                      = 3,
        
        .preamble_chips                     = WMBUS_S_PREAMBLE_SYNC_WORD_LONG_LEN,
        .postamble_min_chips                = WMBUS_S_POSTAMBLE_MIN,
        .postamble_max_chips                = WMBUS_S_POSTAMBLE_MAX,

        .synchronization_min_chips          = WMBUS_PARAM_NA,
        .synchronization_max_chips          = WMBUS_PARAM_NA,
    },

    // WMBUS MODE S1M
    {
        .mode                               = WMBUS_MODE_S1M,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_min_hz                    = 868250000,
            .freq_typ_hz                    = 868300000,
            .freq_max_hz                    = 868350000,
            .freq_tolerance_ppm             = 60,

            .fsk_deviation_min_hz           = 40000,
            .fsk_deviation_typ_hz           = 50000,
            .fsk_deviation_max_hz           = 80000,

            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 32768,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,
            .chip_rate_tolerance_pct_ppm    = 15000,
            .data_rate_bps                  = 16384,
        },

        .o2m                                = {WMBUS_PARAM_NA}, //NA

        .gfsk_bt                            = WMBUS_PARAM_NA,
        
        .bit_jitter_us                      = 3,

        .preamble_chips                     = WMBUS_S_PREAMBLE_SYNC_WORD_SHORT_LEN,
        .postamble_min_chips                = WMBUS_S_POSTAMBLE_MIN,
        .postamble_max_chips                = WMBUS_S_POSTAMBLE_MAX,

        .synchronization_min_chips          = WMBUS_PARAM_NA,
        .synchronization_max_chips          = WMBUS_PARAM_NA,
    },

    // WMBUS MODE S2
    {
        .mode                               = WMBUS_MODE_S2 | MBUS_MODE_FLAG_O2M,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_min_hz                    = 868250000,
            .freq_typ_hz                    = 868300000,
            .freq_max_hz                    = 868350000,
            .freq_tolerance_ppm             = 60,

            .fsk_deviation_min_hz           = 40000,
            .fsk_deviation_typ_hz           = 50000,
            .fsk_deviation_max_hz           = 80000,

            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 32768,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,
            .chip_rate_tolerance_pct_ppm    = 15000,
            .data_rate_bps                  = 16384,
        },

        .o2m =
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,
            
            .freq_min_hz                    = 868278000,
            .freq_typ_hz                    = 868300000,
            .freq_max_hz                    = 868322000,
            .freq_tolerance_ppm             = 25,

            .fsk_deviation_min_hz           = 40000,
            .fsk_deviation_typ_hz           = 50000,
            .fsk_deviation_max_hz           = 80000,

            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 32768,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,
            .chip_rate_tolerance_pct_ppm    = 15000,
            .data_rate_bps                  = 16384,
        },

        .gfsk_bt                            = WMBUS_PARAM_NA,
        
        .bit_jitter_us                      = 3,

        .preamble_chips                     = WMBUS_S_PREAMBLE_SYNC_WORD_SHORT_LEN,
        .postamble_min_chips                = WMBUS_S_POSTAMBLE_MIN,
        .postamble_max_chips                = WMBUS_S_POSTAMBLE_MAX,
        
        .synchronization_min_chips          = WMBUS_PARAM_NA,
        .synchronization_max_chips          = WMBUS_PARAM_NA,
    },

    // WMBUS MODE T1
    {
        .mode                               = WMBUS_MODE_T1,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_3OUTOF6,

            .freq_min_hz                    = 868900000,
            .freq_typ_hz                    = 868950000,
            .freq_max_hz                    = 869000000,
            .freq_tolerance_ppm             = 60,

            .fsk_deviation_min_hz           = 40000,
            .fsk_deviation_typ_hz           = 50000,
            .fsk_deviation_max_hz           = 80000,

            .chip_rate_min_cps              = 90000,
            .chip_rate_typ_cps              = 100000,
            .chip_rate_max_cps              = 110000,
            .chip_rate_tolerance_pct_ppm    = 10000,

            .data_rate_bps                  = WMBUS_T_M2O_DATA_RATE,
        },

        .o2m                                = {WMBUS_PARAM_NA}, //NA

        .gfsk_bt                            = WMBUS_PARAM_NA,
        .bit_jitter_us                      = WMBUS_PARAM_NA,
        
        .preamble_chips                     = WMBUS_T_PREAMBLE_SYNC_WORD_MTR_FORMAT_A_LEN,
        .postamble_min_chips                = WMBUS_T_POSTAMBLE_MIN,
        .postamble_max_chips                = WMBUS_T_POSTAMBLE_MAX,

        .synchronization_min_chips          = WMBUS_PARAM_NA,
        .synchronization_max_chips          = WMBUS_PARAM_NA,
    },

    // WMBUS MODE T2
    {
        .mode                               = WMBUS_MODE_T2 | MBUS_MODE_FLAG_O2M,

        .m2o = //E_FRAME_CODEC_3OUTOF6
        {
            .codec                          = E_FRAME_CODEC_3OUTOF6,

            .freq_min_hz                    = 868900000,
            .freq_typ_hz                    = 868950000,
            .freq_max_hz                    = 869000000,
            .freq_tolerance_ppm             = 60,

            .fsk_deviation_min_hz           = 40000,
            .fsk_deviation_typ_hz           = 50000,
            .fsk_deviation_max_hz           = 80000,

            .chip_rate_min_cps              = 90000,
            .chip_rate_typ_cps              = 100000,
            .chip_rate_max_cps              = 110000,
            .chip_rate_tolerance_pct_ppm    = 10000,

            .data_rate_bps                  = WMBUS_T_M2O_DATA_RATE,
        },

        .o2m = //E_FRAME_CODEC_MANCHESTER
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_min_hz                    = 868278000,
            .freq_typ_hz                    = 868300000,
            .freq_max_hz                    = 868322000,
            .freq_tolerance_ppm             = 25,

            .fsk_deviation_min_hz           = 40000,
            .fsk_deviation_typ_hz           = 50000,
            .fsk_deviation_max_hz           = 80000,

            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 32768,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,
            
            .chip_rate_tolerance_pct_ppm    = 15000,
            .data_rate_bps                  = WMBUS_T_O2M_DATA_RATE,
        },

        .gfsk_bt                            = WMBUS_PARAM_NA,
        
        .bit_jitter_us                      = 3,
        
        .preamble_chips                     = WMBUS_T_PREAMBLE_SYNC_WORD_GW_FORMAT_A_LEN,
        .postamble_min_chips                = WMBUS_T_POSTAMBLE_MIN,
        .postamble_max_chips                = WMBUS_T_POSTAMBLE_MAX,

        .synchronization_min_chips          = WMBUS_PARAM_NA,
        .synchronization_max_chips          = WMBUS_PARAM_NA,
    },

    // WMBUS MODE C1
    {
        .mode                               = WMBUS_MODE_C1,

        .m2o =
        {
            .codec                          = E_FRAME_CODEC_NRZ,

            .freq_min_hz                    = 868928000,
            .freq_typ_hz                    = 868950000,
            .freq_max_hz                    = 869720000,
            .freq_tolerance_ppm             = 25,

            .fsk_deviation_min_hz           = 33750,
            .fsk_deviation_typ_hz           = 45000,
            .fsk_deviation_max_hz           = 56250,

            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 100000,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,
            
            .chip_rate_tolerance_pct_ppm    = 100,
            .data_rate_bps                  = 100000,
        },

        .o2m                                = {WMBUS_PARAM_NA}, //NA
        
        .gfsk_bt                            = WMBUS_PARAM_NA,
        
        .bit_jitter_us                      = WMBUS_PARAM_NA,

        .preamble_chips                     = WMBUS_PARAM_NA,
        .postamble_min_chips                = WMBUS_C_PREAMBLE_LEN_MIN,
        .postamble_max_chips                = WMBUS_C_PREAMBLE_LEN_MAX,
        
        .synchronization_min_chips          = WMBUS_C_SYNC_MIN,
        .synchronization_max_chips          = WMBUS_C_SYNC_MAX,
    },

    // WMBUS MODE C2
    {
        .mode                               = WMBUS_MODE_C2 | MBUS_MODE_FLAG_O2M,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_NRZ,

            .freq_min_hz                    = 868928000,
            .freq_typ_hz                    = 868950000,
            .freq_max_hz                    = 869720000,
            .freq_tolerance_ppm             = 25,

            .fsk_deviation_min_hz           = 33750,
            .fsk_deviation_typ_hz           = 45000,
            .fsk_deviation_max_hz           = 56250,

            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 100000,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,
            
            .chip_rate_tolerance_pct_ppm    = 100,
            .data_rate_bps                  = 100000,
        },

        .o2m =
        {
            .codec                          = E_FRAME_CODEC_NRZ,

            .freq_min_hz                    = 869503000,
            .freq_typ_hz                    = 869525000,
            .freq_max_hz                    = 869547000,
            .freq_tolerance_ppm             = 25,

            .fsk_deviation_min_hz           = 18750,
            .fsk_deviation_typ_hz           = 25000,
            .fsk_deviation_max_hz           = 31250,

            
            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 50000,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,
            
            .chip_rate_tolerance_pct_ppm    = 100,
            .data_rate_bps                  = 50000,
        },

        .gfsk_bt                            = WMBUS_GFSK_BW_0_50,


        .bit_jitter_us                      = WMBUS_PARAM_NA,

        .preamble_chips                     = WMBUS_PARAM_NA,
        .postamble_min_chips                = WMBUS_C_PREAMBLE_LEN_MIN,
        .postamble_max_chips                = WMBUS_C_PREAMBLE_LEN_MAX,
        
        .synchronization_min_chips          = WMBUS_C_SYNC_MIN,
        .synchronization_max_chips          = WMBUS_C_SYNC_MAX,
    },

    // WMBUS MODE R2
    {
        .mode                               = WMBUS_MODE_R2 | MBUS_MODE_FLAG_O2M,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_min_hz                    = WMBUS_PARAM_NA,
            .freq_typ_hz                    = 868330000,
            .freq_max_hz                    = WMBUS_PARAM_NA,
            .freq_tolerance_ppm             = 20,

            .fsk_deviation_min_hz           = 4800,
            .fsk_deviation_typ_hz           = 6000,
            .fsk_deviation_max_hz           = 7200,

            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 4800,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,

            .chip_rate_tolerance_pct_ppm    = 1500,
            .data_rate_bps                  = WMBUS_R_M2O_DATA_RATE,
        },

        .o2m = 
        {
            .codec                          = E_FRAME_CODEC_MANCHESTER,

            .freq_min_hz                    = WMBUS_PARAM_NA,
            .freq_typ_hz                    = 868030000,
            .freq_max_hz                    = WMBUS_PARAM_NA,
            .freq_tolerance_ppm             = 20,

            .fsk_deviation_min_hz           = 4800,
            .fsk_deviation_typ_hz           = 6000,
            .fsk_deviation_max_hz           = 7200,

            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 4800,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,
            
            .chip_rate_tolerance_pct_ppm    = 1500,
            .data_rate_bps                  = WMBUS_R_O2M_DATA_RATE,
        },

        .gfsk_bt                            = WMBUS_PARAM_NA,
        
        .bit_jitter_us                      = WMBUS_PARAM_NA,
        
        .preamble_chips                     = WMBUS_R_PREAMBLE_SYNC_WORD_FORMAT_A_LEN,
        .postamble_min_chips                = WMBUS_R_POSTAMBLE_MIN,
        .postamble_max_chips                = WMBUS_R_POSTAMBLE_MAX,

        .synchronization_min_chips          = WMBUS_PARAM_NA,
        .synchronization_max_chips          = WMBUS_PARAM_NA,
    },

    // WMBUS MODE F2
    {
        .mode                               = WMBUS_MODE_F2,

        .m2o = 
        {
            .codec                          = E_FRAME_CODEC_NRZ,

            .freq_min_hz                    = 433813000,
            .freq_typ_hz                    = 433820000,
            .freq_max_hz                    = 433827000,
            .freq_tolerance_ppm             = 16,

            .fsk_deviation_min_hz           = 4800,
            .fsk_deviation_typ_hz           = 5500,
            .fsk_deviation_max_hz           = 7000,

            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 4800,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,

            .chip_rate_tolerance_pct_ppm    = 100,
            .data_rate_bps                  = WMBUS_F_M2O_DATA_RATE,
        },

        .o2m = 
        {
            .codec                          = E_FRAME_CODEC_NRZ,

            .freq_min_hz                    = 433813000,
            .freq_typ_hz                    = 433820000,
            .freq_max_hz                    = 433827000,
            .freq_tolerance_ppm             = 16,

            .fsk_deviation_min_hz           = 4800,
            .fsk_deviation_typ_hz           = 5500,
            .fsk_deviation_max_hz           = 7000,

            .chip_rate_min_cps              = WMBUS_PARAM_NA,
            .chip_rate_typ_cps              = 4800,
            .chip_rate_max_cps              = WMBUS_PARAM_NA,
            
            .chip_rate_tolerance_pct_ppm    = 100,
            .data_rate_bps                  = WMBUS_F_M2O_DATA_RATE,
        },

        .gfsk_bt                            = WMBUS_PARAM_NA,
        
        .bit_jitter_us                      = WMBUS_PARAM_NA,
        
        .preamble_chips                     = WMBUS_F_PREAMBLE_SYNC_WORD_LEN,
        .postamble_min_chips                = WMBUS_F_POSTAMBLE_MIN,
        .postamble_max_chips                = WMBUS_F_POSTAMBLE_MAX,

        .synchronization_min_chips          = WMBUS_PARAM_NA,
        .synchronization_max_chips          = WMBUS_PARAM_NA,
    },
};
#endif

static const wmbus_mode_n_channel_index_info_t wmbus_mode_n_channel_table[WMBUS_N_CHANNEL_COUNT] = {
    //subband           index   base_freq   spacing gfsk_bps    4gfsk_bps   tolerance   ch_range    tx_pwr  tx_duty(0.0001%)
    { WMBUS_SUBBAND_A,  1,      169406250,  12500,  2400,       0,          2000,       5,          500,    100000},
    { WMBUS_SUBBAND_A,  2,      169406250,  12500,  4800,       0,          1500,       5,          500,    100000},
    { WMBUS_SUBBAND_A,  3,      169406250,  12500,  0,          6400,       1500,       5,          500,    100000},
    { WMBUS_SUBBAND_A,  4,      169437500,  50000,  0,          19200,      2500,       0,          500,    100000},

    { WMBUS_SUBBAND_B,  5,      169481250,  12500,  2400,       0,          2000,       0,          10,     1000},
    { WMBUS_SUBBAND_B,  6,      169481250,  12500,  4800,       0,          1500,       0,          10,     1000},

    { WMBUS_SUBBAND_C,  7,      169493750,  12500,  2400,       0,          1500,       7,          10,     10},
    { WMBUS_SUBBAND_C,  8,      169493750,  12500,  4800,       0,          1500,       7,          10,     10},
    { WMBUS_SUBBAND_C,  9,      169493750,  12500,  0,          6400,       1500,       7,          10,     10},

    { WMBUS_SUBBAND_D,  10,     169593750,  12500,  2400,       0,          2000,       17,         10,     1000},
    { WMBUS_SUBBAND_D,  11,     169593750,  12500,  4800,       0,          1500,       17,         10,     1000},
    { WMBUS_SUBBAND_D,  12,     169593750,  12500,  0,          6400,       1500,       17,         10,     1000},
    { WMBUS_SUBBAND_D,  13,     169625000,  50000,  0,          19200,      2500,       3,          10,     1000}
};

static const wmbus_mode_n_modulation_t wmbus_mode_n_modulation_table[] = {
    //data_rate dev_min dev_typ dev_max gfsk_bw             symbol_tolerance    preamble_len                sync_len            postemble_len
    { 2400,     1680,   2400,   3120,   WMBUS_GFSK_BW_0_50, 100,                WMBUS_N_PREAMBLE_LEN_MIN,   WMBUS_N_SYNC_MIN,   0},
    { 4800,     1680,   2400,   3120,   WMBUS_GFSK_BW_0_50, 100,                WMBUS_N_PREAMBLE_LEN_MIN,   WMBUS_N_SYNC_MIN,   0},
    { 6400,     2240,   1060,   4160,   WMBUS_GFSK_BW_0_50, 100,                WMBUS_N_PREAMBLE_LEN_MIN,   WMBUS_N_SYNC_MIN,   0},
    { 19200,    5040,   2400,   9360,   WMBUS_GFSK_BW_0_50, 100,                WMBUS_N_PREAMBLE_LEN_MIN,   WMBUS_N_SYNC_MIN,   0}
};

const wmbus_mode_n_channel_index_info_t* wmbus_mode_n_get_channel_info(uint8_t index);
uint32_t wmbus_mode_n_get_center_frequency(uint8_t index, uint8_t n);
void wmbus_mode_n_dump_channel_properties(void);
const wmbus_mode_n_modulation_t* wmbus_mode_n_find_modulation(uint16_t data_rate_bps);
void wmbus_mode_n_print_modulation(const wmbus_mode_n_modulation_t* modulation);
void dump_mode_freq_parameters(void);

extern uint16_t _wmbus_gen_sync_pattern(wmbus_mode_t mode, uint8_t *buffer);

const wmbus_mode_n_channel_index_info_t* wmbus_mode_n_get_channel_info(uint8_t index)
{
    for (int i = 0; i < WMBUS_N_CHANNEL_COUNT; ++i) {
        if (wmbus_mode_n_channel_table[i].index == index) {
            return &wmbus_mode_n_channel_table[i];
        }
    }
    return 0;
}

uint32_t wmbus_mode_n_get_center_frequency(uint8_t index, uint8_t n)
{
	const wmbus_mode_n_channel_index_info_t* chan_info = NULL;
    chan_info = wmbus_mode_n_get_channel_info(index);

    if (!chan_info || n > chan_info->channel_range) {
        return 0;
    }
    return chan_info->base_frequency_hz + (n * chan_info->channel_spacing_hz);
}

void wmbus_mode_n_dump_channel_properties(void){
    debug_print("WMBus Mode N - Frequency Mapping Test\n");

    for (uint8_t index = 1; index <= WMBUS_N_CHANNEL_COUNT; ++index) {
        const wmbus_mode_n_channel_index_info_t* info = wmbus_mode_n_get_channel_info(index);
        if (!info) continue;

        debug_print("Sub-band %c, Index %u\n", 'A' + info->subband, info->index);
        debug_print("  Base Freq: %lu Hz, Spacing: %lu Hz\n", info->base_frequency_hz, info->channel_spacing_hz);
        debug_print("  GFSK: %lu bps, 4GFSK: %lu bps, Tolerance: %lu Hz\n",
               info->gfsk_bps, info->four_gfsk_bps, info->freq_tolerance_hz);

        for (uint8_t n = 0; n <= info->channel_range; ++n) {
            uint32_t freq = wmbus_mode_n_get_center_frequency(index, n);
            debug_print(" n=%d -> center freq = %lu Hz\n", n, freq);
        }
        debug_print("Tx power: %lu, Tx duty cycle: %lu \n",info->tx_power_mw, info->tx_duty_cycle);
        debug_print("\n");
    }
}

const wmbus_mode_n_modulation_t* wmbus_mode_n_find_modulation(uint16_t data_rate_bps) {
    for (int i = 0; i < sizeof(wmbus_mode_n_modulation_table)/sizeof(wmbus_mode_n_modulation_table[0]); ++i) {
        if (wmbus_mode_n_modulation_table[i].data_rate_bps == data_rate_bps)
            return &wmbus_mode_n_modulation_table[i];
    }
    return NULL;
}

void wmbus_mode_n_print_modulation(const wmbus_mode_n_modulation_t* t) {
    if (!t) {
        debug_print("Timing not found\n");
        return;
    }
    debug_print("Data rate: %lu bps\n", t->data_rate_bps);
    debug_print("Deviation: min=%lu Hz, typ=%lu Hz, max=%lu Hz\n", t->deviation_hz_min, t->deviation_hz_typ, t->deviation_hz_max);
    debug_print("BT: %d\n", t->gfsk_relative_bw_0_5_0);
    debug_print("Bit/symbol tolerance: %lu ppm\n", t->bit_symbol_tolerance_ppm);
    debug_print("Preamble length: %u bits\n", t->preamble_length_bits);
    debug_print("Sync length: %u bits\n", t->sync_length_bits);
    debug_print("Postamble length: %u bits\n", t->postamble_length_bits);
}


//Mode S, T, C, R, F
void print_radio_config(const wmbus_rf_param_t *cfg, int index) {
#ifndef REDUCE_WMBUS_PARAMS
    debug_print("== Entry [%d] ==\n", index);
    debug_print("Mode: %lu\n", MBUS_MODE_INDEX(cfg->mode));

    debug_print("M2O (via .uni_dir):\n");
    debug_print("Codec: %u\n", cfg->m2o.codec);
    debug_print("  freq_min_hz       = %lu\n", cfg->m2o.freq_min_hz);
    debug_print("  freq_typ_hz       = %lu\n", cfg->m2o.freq_typ_hz);
    debug_print("  freq_max_hz       = %lu\n", cfg->m2o.freq_max_hz);
    debug_print("  freq_tolerance_ppm= %lu\n", cfg->m2o.freq_tolerance_ppm);
    debug_print("  fsk_dev_min_hz    = %lu\n", cfg->m2o.fsk_deviation_min_hz);
    debug_print("  fsk_dev_typ_hz    = %lu\n", cfg->m2o.fsk_deviation_typ_hz);
    debug_print("  fsk_dev_max_hz    = %lu\n", cfg->m2o.fsk_deviation_max_hz);

    debug_print("  Chip Rate: %lu cps\n", cfg->m2o.chip_rate_typ_cps);
    debug_print("  Chip Rate Tolerance: %lu ppm\n", cfg->m2o.chip_rate_tolerance_pct_ppm);
    debug_print("  Data Rate: %lu bps\n", cfg->m2o.data_rate_bps);

    if((MBUS_MODE_INDEX(cfg->mode) == WMBUS_MODE_S2) ||
        (MBUS_MODE_INDEX(cfg->mode) == WMBUS_MODE_T2) ||
        (MBUS_MODE_INDEX(cfg->mode) == WMBUS_MODE_C2) ||
        (MBUS_MODE_INDEX(cfg->mode) == WMBUS_MODE_R2))
    {
        debug_print("O2M part:\n");
        debug_print("Codec: %u\n", cfg->o2m.codec);
        debug_print("  freq_min_hz       = %lu\n", cfg->o2m.freq_min_hz);
        debug_print("  freq_typ_hz       = %lu\n", cfg->o2m.freq_typ_hz);
        debug_print("  freq_max_hz       = %lu\n", cfg->o2m.freq_max_hz);
        debug_print("  freq_tolerance_ppm= %lu\n", cfg->o2m.freq_tolerance_ppm);
        debug_print("  fsk_dev_min_hz    = %lu\n", cfg->o2m.fsk_deviation_min_hz);
        debug_print("  fsk_dev_typ_hz    = %lu\n", cfg->o2m.fsk_deviation_typ_hz);
        debug_print("  fsk_dev_max_hz    = %lu\n", cfg->o2m.fsk_deviation_max_hz);

        debug_print("  Chip Rate: %lu cps\n",  cfg->o2m.chip_rate_typ_cps);
        debug_print("  Chip Rate Tolerance: %lu ppm\n",  cfg->o2m.chip_rate_tolerance_pct_ppm);
        debug_print("  Data Rate: %lu bps\n",  cfg->o2m.data_rate_bps);

    }

    debug_print("Bit Jitter: %u us\n", cfg->bit_jitter_us);
    debug_print("Preamble: %lu chips\n", cfg->preamble_chips);
    debug_print("Postamble Min: %lu chips\n", cfg->postamble_min_chips);
    debug_print("Postamble Max: %lu chips\n", cfg->postamble_max_chips);
   
    debug_print("-----------------------------\n");
#endif
}

uint8_t wmbus_one_band_mode_num = sizeof(radioWmbusCfg) / sizeof(radioWmbusCfg[0]);

void dump_mode_freq_parameters(void){
    for (uint8_t i = 0; i < wmbus_one_band_mode_num; i++) {
        print_radio_config(&radioWmbusCfg[i], i);
    }
}

void debug_dump_wmbus_parameters()
{
    const uint16_t data_rates[] = {WMBUS_N_BITRATE_2K4, WMBUS_N_BITRATE_4K8, WMBUS_N_BITRATE_6K4, WMBUS_N_BITRATE_19K2};
    
    //Mode S,T,C,R
    dump_mode_freq_parameters();

    //Mode N
	wmbus_mode_n_dump_channel_properties(); 
        
    for (uint8_t i = 0; i < sizeof(data_rates)/sizeof(data_rates[0]); ++i) {
        const wmbus_mode_n_modulation_t* modulation = wmbus_mode_n_find_modulation(data_rates[i]);
        debug_print("\n--- Timing for %u bps ---\n", data_rates[i]);
        wmbus_mode_n_print_modulation(modulation);
    }

    extern uint8_t wmbus_one_band_mode_num;
    //Generate preamble and sync word  for every mode
    uint8_t buffer[72];
    uint16_t buffer_len = 0;
    for (uint8_t i = 0; i < wmbus_one_band_mode_num; ++i) {
        buffer_len = _wmbus_gen_sync_pattern(i, buffer);
        debug_print("MODE_%d (%d bytes): ", i, buffer_len);
        for (uint16_t j = 0; j < buffer_len; j++) {
            debug_print("%02X ", buffer[j]);
        }
        debug_print("\n");
    }
    //mode N
    buffer_len = _wmbus_gen_sync_pattern(WMBUS_MODE_N, buffer);
    debug_print("MODE_%d (%d bytes): ", WMBUS_MODE_N, buffer_len);
    for (uint16_t j = 0; j < buffer_len; j++) {
        debug_print("%02X ", buffer[j]);
    }
    debug_print("\n");
}

#endif //CHIP_RADIO_HAS_W_MBUS

