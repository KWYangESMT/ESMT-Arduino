#pragma once
#include <stdint.h>
#include "Print.h"

class HardwareSerial: public Print
{
    public:
        explicit HardwareSerial(uint8_t intf) : _intf(intf) {}
        void begin() { begin(ARDUINO_SERIAL_UART_BAUD); }
        void begin(uint32_t baud);
        
        int  available();
        int  read();
        size_t write(uint8_t c) override;
        size_t write(const uint8_t *buffer, size_t size) override;

        int pushChar(uint8_t c);
        
    private:
        void rxFifoReset();
        
        uint8_t _intf;

        uint8_t* rxFifo;
        uint32_t rxFifoSize = ARDUINO_SERIAL_UART_RX_BUF_SIZE;
        uint32_t rxFifoRPos = 0;
        uint32_t rxFifoWPos = 0;
        uint32_t rxDataLen = 0;
};

extern HardwareSerial Serial;
