/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "wise_core.h"
#include "hal_intf_radio.h"
#include "hal_intf_pmu.h"

#include "hal_drv_radio.h"

#include "drv/hal_drv_pmu.h"
#include "drv/hal_drv_sys.h"
#include "drv/hal_drv_dma.h"

#include "ana_er8130.h"
#include "bbp_er8130.h"
#include "mac_er8130.h"

#ifdef ES_DEVICE_TRX_RADIO
#include "xcvr04/peri/platform/common/trx_ctrl/hal_trx_ctrl.h"
#include "xcvr04/peri/platform/common/drv/hal_drv_trx_pmu.h"
#include "xcvr04/peri/platform/common/drv/hal_drv_trx_sys.h"

#include "xcvr04/ana_xcvr04.h"
#include "xcvr04/bbp_xcvr04.h"
#include "xcvr04/mac_xcvr04.h"

#include "xcvr04/host_intf/host_intf_api.h"
#endif

#include "util_debug_log.h"

//kevinyang, 20250427, moved from wise_core.h, should be moved to right place
/**
 * @enum align_clk_src
 * @brief Enum for alignment clock sources.
 *
 * This enumeration defines the possible clock sources for alignment.
 */
enum align_clk_src {
    ALIGN_CLK_SRC_40M = 0, /**< 40 MHz clock source. */
    ALIGN_CLK_SRC_TPM = 1, /**< TPM clock source. */
};

/**
 * @enum mcu_clk_factor
 * @brief Enum for MCU clock division factors.
 *
 * This enumeration defines the division factors for the MCU clock.
 */
enum mcu_clk_factor {
    CLK_DIV_1 = 0, /**< Divide by 1. */
    CLK_DIV_2,     /**< Divide by 2. */
    CLK_DIV_4,     /**< Divide by 4. */
    CLK_DIV_8,     /**< Divide by 8. */
};

static RADIO_ADAPT_T radio_adpt[RADIO_PHY_NUM] = {0};

static const TX_PWR_MAPPING TX_PWR_TABLE[] =
{
    //pwr_dbm   gain_val
    {-5,        2},
    {-1,        3},
    { 1,        4},
    { 3,        5},
    { 4,        6},
    { 5,        7},
    { 6,        8},
    { 7,        9},
    { 8,        10},
    { 9,        13},
    { 10,       16},
    { 11,       19},
    { 12,       27},
};

void *hal_drv_radio_get_adapt(int8_t phy_idx)
{
    return (void *)&radio_adpt[phy_idx];
}

void hal_drv_radio_set_adapt(int8_t phy_idx)
{
    radio_adpt[phy_idx].phy_idx = phy_idx;

    if (phy_idx == PHY_IDX_0) {
        radio_adpt[phy_idx].pa_type = hal_drv_sys_get_pa_type();
        radio_adpt[phy_idx].match_type = hal_drv_sys_get_board_match_type();
        radio_adpt[phy_idx].mac = MAC_GET_MAC_INFO();
        radio_adpt[phy_idx].bbp = BBP_GET_BBP_INFO();
        radio_adpt[phy_idx].ana = ANA_GET_ANA_INFO();

        hal_drv_pmu_set_dyn_gate(MODEM_DYN_GATED | ANCTL_DYN_GATED | FLCTL_DYN_GATED);
        hal_drv_pmu_set_clk_src_align(ALIGN_CLK_SRC_TPM);
        hal_drv_pmu_set_mcu_clk_factor(CLK_DIV_1);
    }

#ifdef ES_DEVICE_TRX_RADIO

    if (phy_idx == PHY_IDX_1) {
        radio_adpt[phy_idx].pa_type = hal_drv_trx_sys_get_pa_type();
        radio_adpt[phy_idx].match_type = hal_drv_trx_sys_get_board_match_type();
        radio_adpt[phy_idx].mac = TRX_GET_MAC_INFO();
        radio_adpt[phy_idx].bbp = TRX_GET_BBP_INFO();
        radio_adpt[phy_idx].ana = TRX_GET_ANA_INFO();
    }

#endif
}

#define MS_TO_CNT(m) (m*100000)
void hal_drv_radio_delay_ms(uint32_t ms)
{
    for (uint32_t i=0; i<ms; i++) {
        __asm volatile("nop");
    }
}

void hal_drv_radio_delay_10us(void)
{
    for (uint32_t i=0; i<15; i++) {
        __asm volatile("nop");
    }
}

void hal_drv_radio_set_isr_cb(int8_t phy_idx, HAL_ISR_CALLBACK cb_proc,
                              void *cb_data)
{
    radio_adpt[phy_idx].isr_callback = cb_proc;
    radio_adpt[phy_idx].isr_cb_data  = cb_data;

#ifdef ES_DEVICE_TRX_RADIO

    if (phy_idx == PHY_IDX_1) {
        host_intf_register_radio_int_callback(cb_proc, cb_data);
    }

#endif
}

uint32_t hal_drv_radio_get_int_status(int8_t phy_idx)
{
    uint32_t status = mac_get_interrupt_status_er81xx();

    if(status & MAC_INT_RX_MASK)
        radio_adpt[phy_idx].mac->radio_rx_info.rx_msr.rx_status.rx_ok++;
    if(status & MAC_INT_RXERR_MASK)
        radio_adpt[phy_idx].mac->radio_rx_info.rx_msr.rx_status.rx_err++;
    
    return status;
}

void hal_drv_radio_clear_status(int8_t phy_idx, uint32_t status)
{
    mac_clear_interrupt_status_er81xx(status);
}

void hal_drv_radio_get_rx_info(int8_t phy_idx, void *rx_meta)
{
    MAC_INFO_T *mac_info = radio_adpt[phy_idx].mac;

    MAC_GET_RX_VAL_LEN(phy_idx, &mac_info->radio_rx_info);
    BBP_GET_RX_INFO(phy_idx, &mac_info->radio_rx_info);
    ANA_GET_CH_FREQ(phy_idx, &mac_info->radio_rx_info);

    memcpy(rx_meta, (void *) & (mac_info->radio_rx_info.rx_meta), sizeof(RADIO_FRAME_META_T));
}

void hal_drv_radio_set_pwr_mode(int8_t phy_idx, uint8_t mode)
{
    if (mode == PWR_MODE_SLEEP || mode == PWR_MODE_DEEP_SLEEP) {
    hal_drv_dma_modem_backup();
    }
    ANA_SET_PWR_MODE(phy_idx, mode);
}

void hal_drv_radio_set_tx_pwr(int8_t phy_idx, uint8_t lv)
{
    ANA_SET_TX_PWR_LV(phy_idx, radio_adpt[phy_idx].radio_cfg.mod_type, lv);
}

const TX_PWR_MAPPING* hal_drv_radio_get_tx_pwr_table(uint8_t* levelNum)
{
    *levelNum = sizeof(TX_PWR_TABLE)/sizeof(TX_PWR_MAPPING);

    return TX_PWR_TABLE;
}

uint8_t hal_drv_radio_get_phy_mode(int8_t phy_idx)
{
    return radio_adpt[phy_idx].radio_cfg.phy_mode;
}

void hal_drv_radio_set_phy_mode(int8_t phy_idx, uint8_t phy_mode)
{
    radio_adpt[phy_idx].radio_cfg.phy_mode = phy_mode;
    
    // patch for 9005 CCA mode
    if (phy_mode == PHY_MODE_CCA)
            BBP_SET_AGC_GAIN_UPDATE_LOOP(3);
    else
            BBP_SET_AGC_GAIN_UPDATE_LOOP(0);
}

void hal_drv_radio_set_int_en_mask(int8_t phy_idx, uint32_t mask)
{
    radio_adpt[phy_idx].int_mask = mask;
}

uint32_t hal_drv_radio_get_int_en_mask(int8_t phy_idx)
{
    return radio_adpt[phy_idx].int_mask;
}

void hal_drv_radio_enable_interrupt(int8_t phy_idx)
{
    MAC_ENABLE_INTERRUPT(phy_idx, radio_adpt[phy_idx].int_mask);
}

void hal_drv_radio_disable_interrupt(int8_t phy_idx)
{
    MAC_DISABLE_INTERRUPT(phy_idx);
}

HAL_STATUS hal_drv_radio_wait_rssi_rdy(int8_t phy_idx)
{
    HAL_STATUS status = HAL_NO_ERR;
    //uint32_t to = 1000, to_cnt = 0;

    // 0 is ready, 1 is waitting
    //this resiger work, but timeing is wrong 
    //while (BBP_CHK_RSSI_RDY(phy_idx) && (to_cnt++ < to)) {
    //    SYS_DELAY(phy_idx, 1);
    //}

    //status = (to_cnt >= to) ? HAL_ERR : HAL_NO_ERR;

    //it need to delay 100ms for getting cca value correctly
    SYS_DELAY(phy_idx, 100000);

    return status;
}

uint8_t hal_drv_radio_rx_stop(int8_t phy_idx)
{
    return MAC_RX_STOP(phy_idx, radio_adpt[phy_idx].radio_cfg.phy_mode);
}

void hal_drv_radio_print_rx_info(int8_t phy_idx)
{
    MAC_INFO_T *mac_info = radio_adpt[phy_idx].mac;

    if (mac_info->radio_rx_info.rx_msr.out_en) {
        printf("XT> tm41 %ld %ld %d %04x %d %ld#\n",
               mac_info->radio_rx_info.rx_msr.rx_status.rx_ok,
               mac_info->radio_rx_info.rx_msr.rx_status.rx_err,
               mac_info->radio_rx_info.rx_msr.agc_idx,
               mac_info->radio_rx_info.rx_meta.rssi,
               mac_info->radio_rx_info.rx_msr.ib_pwr,
               mac_info->radio_rx_info.rx_msr.gfo_est);

        if (radio_adpt[phy_idx].radio_cfg.phy_mode == PHY_MODE_CCA) {
            SYS_DELAY(phy_idx, 50000);
        }
    }
}

void hal_drv_radio_set_ctrl_mode(int8_t phy_idx, uint8_t ctrl_mode)
{
    ANA_SET_CTRL_MODE(phy_idx, ctrl_mode);
}

void hal_drv_radio_rx_start(int8_t phy_idx, uint32_t rx_max_len)
{
    MAC_SET_RX_MAX_LEN(phy_idx, rx_max_len);
    uint32_t dr = ANA_GET_RX_DATA_RATE(phy_idx);
    MAC_RX_START(phy_idx, radio_adpt[phy_idx].radio_cfg.phy_mode);
    hal_drv_radio_delay_10us();
    BBP_SET_DDC_IF_PHI(radio_adpt[phy_idx].radio_cfg.phy_mode, dr);
}

void hal_drv_radio_set_rx_restart(int8_t phy_idx, uint8_t enable)
{
    MAC_SET_RX_RESTART(phy_idx, enable);
}

uint8_t hal_drv_radio_get_rx_busy(int8_t phy_idx)
{
    return MAC_GET_RX_BSY(phy_idx);
}

void hal_drv_radio_enable_singletone(int8_t phy_idx, uint32_t pwr_lv, uint8_t enable)
{
    ANA_ENABLE_SINGLETONE(phy_idx, radio_adpt[phy_idx].radio_cfg.mod_type, pwr_lv, enable);
}

void hal_drv_radio_set_ch(int8_t phy_idx, uint32_t ch)
{
    radio_adpt[phy_idx].radio_cfg.ch_freq = ch;

    ANA_SET_CH_FREQ(phy_idx, ch);
}

void hal_drv_radio_set_data_rate(int8_t phy_idx, uint8_t phy_mode, uint32_t data_rate)
{
    radio_adpt[phy_idx].radio_cfg.data_rate = data_rate;

    /*=====set tx data rate =====*/
    MAC_SET_TX_DATA_RATE(phy_idx, data_rate);

    /*=====set rx data rate =====*/
    ANA_SET_RX_DATA_RATE(phy_idx, phy_mode, data_rate);
}

void hal_drv_radio_set_freq_devia(int8_t phy_idx, uint32_t freq_devia)
{
    ANA_SET_FREQ_DEVIA(phy_idx, freq_devia);
}

void hal_drv_radio_set_osr(int8_t phy_idx, uint32_t mod_type, HAL_DATA_RATE_T dr_idx)
{
    uint8_t osr = MAC_GET_OSR(phy_idx, mod_type, dr_idx);

    radio_adpt[phy_idx].osr = osr;

    BBP_SET_OSR(phy_idx, osr);

    ANA_SET_OSR(phy_idx, osr);

    if (phy_idx == PHY_IDX_0) {
        hal_drv_pmu_set_bbp_cic_clk(osr, dr_idx);

        if (radio_adpt[phy_idx].radio_cfg.phy_mode == PHY_MODE_MBUS)
            hal_drv_pmu_set_bbp_mbus_cic_clk(dr_idx);
    }

#ifdef ES_DEVICE_TRX_RADIO

    if (phy_idx == PHY_IDX_1) {
        hal_drv_trx_pmu_set_bbp_cic_clk(osr, dr_idx);
    }

#endif
}

void hal_drv_radio_tx_start(int8_t phy_idx, uint8_t *tx_buf, uint32_t tx_len)
{
    ANA_GET_TX_RAMP_BACKUP(phy_idx);
    
    MAC_TX_START(phy_idx, tx_buf, tx_len);
}

void hal_drv_radio_tx_stop(int8_t phy_idx)
{
    MAC_TX_STOP(phy_idx);
}

void _hal_drv_radio_set_mod_type(int8_t phy_idx, uint32_t mod_type)
{
    MAC_SET_MOD_TYPE(phy_idx, mod_type);
    ANA_SET_MOD_TYPE(phy_idx, mod_type);
}

void _hal_drv_radio_set_tx_init(int8_t phy_idx)
{
    uint32_t mod_type       = radio_adpt[phy_idx].radio_cfg.mod_type;
    uint32_t data_rate      = radio_adpt[phy_idx].radio_cfg.data_rate;
    uint8_t pa_type         = radio_adpt[phy_idx].pa_type;
    uint8_t mat_type        = radio_adpt[phy_idx].match_type;
    HAL_DATA_RATE_T dr_idx  = radio_adpt[phy_idx].dr_idx;
    uint8_t tx_pwr_lv       = radio_adpt[phy_idx].radio_cfg.tx_pwr_lv;

    /*=====ANA=====*/
    ANA_SET_PA_CFG(phy_idx, pa_type, mat_type, mod_type, data_rate);
    ANA_SET_PA_PWR_TBL(phy_idx, mod_type);
    ANA_SET_SYNTHESIZE(phy_idx, mod_type);
    ANA_SET_TX_PWR_LV(phy_idx, mod_type, tx_pwr_lv);
    ANA_SET_TX_RAMP_CFG(phy_idx, mod_type);

    /*=====BBP=====*/
    BBP_SET_TX_FILT(phy_idx, mod_type, dr_idx);
}

void _hal_drv_radio_set_tx_cfg(int8_t phy_idx, RADIO_CFG_T *radio_cfg)
{
    MAC_SET_TX_PHY_FORMAT_CFG(phy_idx, radio_cfg->mod_type, radio_cfg->frame_hw_opt);

    MAC_SET_TX_PREAMBLE(phy_idx, radio_cfg->pream, radio_cfg->pream_len);

    MAC_SET_TX_SYNCWORD(phy_idx, radio_cfg->mod_type, radio_cfg->sync_word, radio_cfg->sync_word_len);

    if (radio_cfg->phy_mode == PHY_MODE_MBUS)
        MAC_SET_TX_WMBUS_SYNCWORD(phy_idx, radio_cfg->wmbus_mode, radio_cfg->data_rate);

    MAC_SET_TX_WHITENING(phy_idx, radio_cfg->mod_type, (radio_cfg->frame_hw_opt & FRAME_HW_WHITENING ? 1 : 0));
    
}

void _hal_drv_radio_set_rx_init(int8_t phy_idx)
{
    //uint32_t mod_type       = radio_adpt[phy_idx].radio_cfg.mod_type;
    uint32_t data_rate      = radio_adpt[phy_idx].radio_cfg.data_rate;
    uint8_t mod_idx         = radio_adpt[phy_idx].mod_idx;
    uint8_t phy_mode        = radio_adpt[phy_idx].radio_cfg.phy_mode;
    uint8_t wmbus_mode      = radio_adpt[phy_idx].radio_cfg.wmbus_mode;

    /*=====ANA=====*/
    ANA_SET_RX_ATOP_CFG(phy_idx);

    ANA_SET_GAIN_SRC(phy_idx, ANA_GAIN_SRC_BBP);

    ANA_SET_RX_GAIN(phy_idx);

    ANA_SET_RX_FILT(phy_idx, phy_mode, data_rate, mod_idx);

    /*=====BBP=====*/
    
    BBP_SETUP(phy_idx, phy_mode, data_rate, mod_idx, wmbus_mode);

}

void _hal_drv_radio_set_rx_cfg(int8_t phy_idx, RADIO_CFG_T *radio_cfg)
{
    MAC_SET_RX_802154_KEEP_FMT(phy_idx, ENABLE);

    MAC_SET_RX_MAX_LEN(phy_idx, radio_cfg->rx_max_len);

    MAC_SET_RX_MANCHESTER(phy_idx, (radio_cfg->frame_hw_opt & FRAME_HW_MANCH ? 1 : 0));

    BBP_SET_RX_SYNCWORD(phy_idx, radio_cfg->sync_word, radio_cfg->sync_word_len);

    BBP_SET_RX_PN9(phy_idx, (radio_cfg->frame_hw_opt & FRAME_HW_WHITENING ? 1 : 0));

    BBP_SET_RX_FEC(phy_idx, (radio_cfg->frame_hw_opt & FRAME_HW_FEC ? 1 : 0));
}

uint32_t _iqk_val_cal_average(const int16_t *iqk_val_p, const int16_t *iqk_val_a, int idx)
{
    int64_t sum_p = 0;
    int64_t sum_a = 0;
    int16_t avg_p = 0;
    int16_t avg_a = 0;
    uint32_t i;
    uint32_t result;

    //sign value calculation
    for (i = 0; i < idx; i++) {
        sum_p += iqk_val_p[i];
        sum_a += iqk_val_a[i];
    }

    //avoid overflow
    avg_p = (int16_t)(sum_p / idx);
    avg_a = (int16_t)(sum_a / idx);

    result = ((uint32_t)avg_a << 16) | ((uint32_t)avg_p & 0xFFFF);

    return result;
}

void _do_iqk_auto_mode(int8_t phy_idx, uint8_t mat_type)
{
    HAL_STATUS status   = HAL_NO_ERR;
    uint8_t mode = IQK_MODE_AUTO;
    uint8_t iqk_do_times = 10;
    uint16_t timeout;
    uint8_t idx;
    uint32_t iqk_val_rst = 0;

    uint32_t iqk_ch_freq = MAC_GET_IQK_CH_FREQ(phy_idx, mat_type);
    int16_t iqk_val_p[iqk_do_times];
    int16_t iqk_val_a[iqk_do_times];

    printf("wait for doing iqk [%d] times at ch freq : [%ld]MHz\n", iqk_do_times, iqk_ch_freq);

    for (idx = 0; idx < iqk_do_times; idx++) {
        // this channel is set for iqk only
        ANA_SET_CH_FREQ(phy_idx, iqk_ch_freq);

        ANA_SET_IQK_CFG(phy_idx, mode);
        BBP_SET_IQK_CFG(phy_idx, radio_adpt[phy_idx].bbp, radio_adpt[phy_idx].dr_idx);

        MAC_RX_START(phy_idx, radio_adpt[phy_idx].radio_cfg.phy_mode);

        // wait 800ms for rx start after reset (it's need this time to calculate data)
        SYS_DELAY(phy_idx, 800000);

        timeout = 5000;
        while (timeout--) {
            if (!(ANA_GET_RX_STATUS(phy_idx)&ST_RX_IQ)) {
                //IQK done
                break;
            }
            
            if (timeout == 0) {
                printf("[iqk error!] get iqk status time out!!\n");
                status = HAL_ERR;
            }                
        }

        MAC_RX_STOP(phy_idx, radio_adpt[phy_idx].radio_cfg.phy_mode);

        BBP_SET_IQK_LMT(phy_idx, radio_adpt[phy_idx].bbp);

        // clear iqk special setting
        ANA_CLEAN_IQK_CFG(phy_idx, mode);
        BBP_CLEAN_IQK_CFG(phy_idx);

        // record iqk value
        iqk_val_rst = BBP_GET_IQK_VAL(phy_idx);
        //printf("-------------->iqk_val_rst = 0x%08x\n", iqk_val_rst);

        iqk_val_p[idx] = (int16_t)(iqk_val_rst & 0xffff);
        iqk_val_a[idx] = (int16_t)((iqk_val_rst >> 16) & 0xffff);
        printf(">>");
    }

    printf("\n");

    iqk_val_rst = _iqk_val_cal_average(iqk_val_p, iqk_val_a, iqk_do_times);

    BBP_SET_IQK_VAL(phy_idx, iqk_val_rst);

    printf("final iqk val = 0x%08lx\n", iqk_val_rst);

    if (status == HAL_NO_ERR) {
        printf("<<do iqk success>>\n");
    } else {
        printf("<<do iqk fail!>>\n");
    }

}

void _do_iqk_manual_mode(int8_t phy_idx, uint8_t mat_type)
{
    HAL_STATUS status   = HAL_NO_ERR;
    uint8_t mode = IQK_MODE_MANUAL;
    uint8_t iqk_do_times = 64;
    uint8_t idx;
    uint32_t iqk_val_rst = 0;

    uint32_t iqk_ch_freq = MAC_GET_IQK_CH_FREQ(phy_idx, mat_type);
    int16_t iqk_val_p[iqk_do_times];
    int16_t iqk_val_a[iqk_do_times];

    printf("wait for doing iqk [%d] times at ch freq : [%ld]MHz\n", iqk_do_times, iqk_ch_freq);


    // this channel is set for iqk only
    ANA_SET_CH_FREQ(phy_idx, iqk_ch_freq);

    ANA_SET_IQK_CFG(phy_idx, mode);
    BBP_SET_IQK_CFG(phy_idx, radio_adpt[phy_idx].bbp, radio_adpt[phy_idx].dr_idx);

    MAC_RX_START(phy_idx, radio_adpt[phy_idx].radio_cfg.phy_mode);

    // wait 500ms for rx start after reset (it's need this time to calculate data)
    SYS_DELAY(phy_idx, 500000);

    // reset BB core and wait 500ms for BB doing iqk at first time
    MODULE_SW_RESET(phy_idx, PMU_SW_RST_BBP);
    SYS_DELAY(phy_idx, 500000);

    //after first time doing iqk
    for (idx = 0; idx < iqk_do_times; idx++) {
        // reset BB core
        MODULE_SW_RESET(phy_idx, PMU_SW_RST_BBP);

        // wait 200ms for BB doing iqk
        SYS_DELAY(phy_idx, 200000);

        // record iqk value
        iqk_val_rst = BBP_GET_IQK_VAL(phy_idx);
        //printf("%d-------------->iqk_val_rst = 0x%08x\n",idx, iqk_val_rst);

        iqk_val_p[idx] = (int16_t)(iqk_val_rst & 0xffff);
        iqk_val_a[idx] = (int16_t)((iqk_val_rst >> 16) & 0xffff);
        //printf("iqk_val_p[%d] = %d\n",idx, iqk_val_p[idx]);
        //printf("iqk_val_a[%d] = %d\n",idx, iqk_val_a[idx]);
        printf(">>");
    }

    printf("\n");


    MAC_RX_STOP(phy_idx, radio_adpt[phy_idx].radio_cfg.phy_mode);

    BBP_SET_IQK_LMT(phy_idx, radio_adpt[phy_idx].bbp);

    // clear iqk special setting
    ANA_CLEAN_IQK_CFG(phy_idx, mode);
    BBP_CLEAN_IQK_CFG(phy_idx);

    iqk_val_rst = _iqk_val_cal_average(iqk_val_p, iqk_val_a, iqk_do_times);

    BBP_SET_IQK_VAL(phy_idx, iqk_val_rst);

    printf("final iqk val = 0x%08lx\n", iqk_val_rst);

    if (status == HAL_NO_ERR) {
        printf("<<do iqk success>>\n");
    } else {
        printf("<<do iqk fail!>>\n");
    }

}

void _radio_do_iqk(int8_t phy_idx, IQK_MODE mode, uint8_t mat_type)
{
    printf("===== [start to do iqk (manual(0)/auto(1): %d)] =====\n", mode);

    if (mode == IQK_MODE_AUTO)
        _do_iqk_auto_mode(phy_idx, mat_type);

    if (mode == IQK_MODE_MANUAL)
        _do_iqk_manual_mode(phy_idx, mat_type);
}

void _hal_drv_radio_do_iqk(int8_t phy_idx, uint8_t mat_type)
{
    uint8_t phy0_do_iqk = FALSE;

    if (phy_idx == PHY_IDX_0) {
        if (phy0_do_iqk) {
            _radio_do_iqk(PHY_IDX_0, IQK_MODE_AUTO, mat_type);
        } else {
            //printf("<<phy_idx: (%d) iqk is disabled>>\n", phy_idx);
        }
    }

#ifdef ES_DEVICE_TRX_RADIO
    uint8_t phy1_do_iqk = FALSE;

    if (phy_idx == PHY_IDX_1) {
        if (phy1_do_iqk) {
            _radio_do_iqk(PHY_IDX_1, IQK_MODE_AUTO, mat_type);
        } else {
            printf("<<phy_idx: (%d) iqk is disabled>>\n", phy_idx);
        }
    }

#endif

}

void hal_drv_radio_trig_tpm_calib(int8_t phy_idx, RADIO_CFG_T *radio_cfg)
{
    //set tpm dmi 
    ANA_SET_TPM_DMI(phy_idx, radio_cfg->phy_mode, radio_cfg->mod_type, radio_cfg->data_rate);

    //set tpm cal
    ANA_SET_TPM_CAL(phy_idx, radio_cfg->mod_type, radio_cfg->data_rate);

    //trigger tx for enabling tpm cal onece

    hal_drv_radio_set_tx_pwr(phy_idx, 0);
    
    hal_drv_radio_set_ch(phy_idx, radio_cfg->ch_freq);

    hal_drv_pmu_module_clk_enable(MAC_MODULE | BBP_MODULE | ANA_MODULE);

    ANA_TOGGLE_TX_EN(phy_idx);

    while(!ANA_IS_TPM_CAL_DONE()) {
        printf("tpm cal is calculating!\n");
    }

    //wait for mac done
    SYS_DELAY(phy_idx, 1000);

    hal_drv_pmu_module_clk_disable(MAC_MODULE | BBP_MODULE | ANA_MODULE);
}

void hal_drv_radio_get_tpm_cal_val(TPM_CAL_PARA *tpm_cal_val)
{
    tpm_cal_val->tpm_din_hb = ANA_GET_TPM_DIN_HB();
    tpm_cal_val->kvc = ANA_GET_KVC();
}

void hal_drv_radio_set_tpm_cal_val(TPM_CAL_PARA *tpm_cal_val)
{
    ANA_SET_TPM_DIN_HB(tpm_cal_val->tpm_din_hb);
    ANA_SET_KVC(tpm_cal_val->kvc);
}

uint8_t _hal_drv_radio_get_data_rate_idx(uint32_t data_rate)
{
    uint8_t dr_idx = 0;

    switch (data_rate) {
    case DATA_RATE_2M:
        dr_idx = E_HAL_DR_2M;
        break;

    case DATA_RATE_1M:
        dr_idx = E_HAL_DR_1M;
        break;

    case DATA_RATE_500K:
        dr_idx = E_HAL_DR_500K;
        break;

    case DATA_RATE_250K:
        dr_idx = E_HAL_DR_250K;
        break;

    case DATA_RATE_200K:
        dr_idx = E_HAL_DR_200K;
        break;

    case DATA_RATE_125K:
        dr_idx = E_HAL_DR_125K;
        break;

    case DATA_RATE_100K:
        dr_idx = E_HAL_DR_100K;
        break;

    case DATA_RATE_50K:
        dr_idx = E_HAL_DR_50K;
        break;

    case DATA_RATE_32P768K:
        dr_idx = E_HAL_DR_32P768K;
        break;

    case DATA_RATE_12P5K:
        dr_idx = E_HAL_DR_12P5K;
        break;
    
    case DATA_RATE_4P8K:
        dr_idx = E_HAL_DR_4P8K;
        break;        
    default:
        DBG_PRINT("data rate did not support\n");
        dr_idx = E_HAL_DR_500K;
        break;
    }

    return dr_idx;
}

uint8_t _hal_drv_radio_get_mod_idx(int32_t data_rate, int32_t freq_devia)
{
   int32_t numer = 2 * freq_devia * 100;
   int32_t rounded = (numer + data_rate/2) / data_rate; // e.g. 25 = 0.25
   uint8_t mod_idx; 
   
   switch(rounded) {
    case 50:
        mod_idx = MOD_IDX_0P5;
        printf("mod_idx = 0.5\n");
        break;
    case 100:
        mod_idx = MOD_IDX_1;
        printf("mod_idx = 1\n");
        break;
    case 200:
        mod_idx = MOD_IDX_2;
        printf("mod_idx = 2\n");
        break;
    case 400:
        mod_idx = MOD_IDX_4;
        printf("mod_idx = 4\n");
        break;
    default:
        mod_idx = MOD_IDX_0P5;
        //printf("mod_idx is bad = %ld(need to divided by 100) (set default to 0.5)\n", rounded);
        break;
   }
   
   return mod_idx;
}

void _hal_drv_radio_set_special_cfg(int8_t phy_idx, RADIO_CFG_T *radio_cfg)
{
#if WMBUS_SCENARIO_REDUCE_FALSE_ALARM
    /*==== for WMBSU special case =====*/
    if (radio_cfg->phy_mode == PHY_MODE_MBUS) {
        BBP_SET_WMBUS_RX_EXTRA_CFG(radio_cfg->wmbus_mode, radio_cfg->data_rate);
    }
#endif

    /*=====for user special config=====*/
    ANA_SET_USER_CFG(phy_idx);
    BBP_SET_USER_CFG(phy_idx);
}


HAL_STATUS hal_drv_radio_set_phy(int8_t phy_idx, RADIO_CFG_T *radio_cfg)
{
    HAL_STATUS status = HAL_NO_ERR;

    radio_adpt[phy_idx].mod_idx = _hal_drv_radio_get_mod_idx((int32_t)radio_cfg->data_rate, (int32_t)radio_cfg->freq_devia);
    radio_adpt[phy_idx].dr_idx = _hal_drv_radio_get_data_rate_idx(radio_cfg->data_rate);

    /*===== set basic config ===== */
    _hal_drv_radio_set_mod_type(phy_idx, radio_cfg->mod_type);
    hal_drv_radio_set_data_rate(phy_idx, radio_cfg->phy_mode, radio_cfg->data_rate);
    hal_drv_radio_set_freq_devia(phy_idx, radio_cfg->freq_devia);

    ANA_SET_BASIC_CFG(phy_idx);
//  BBP_SET_BASIC_CFG(phy_idx, radio_adpt[phy_idx].bbp, radio_cfg->mod_type, radio_adpt[phy_idx].dr_idx);

    /*===== general setting ===== */
    ANA_SET_CTRL_MODE(phy_idx, CTRL_MODE_AUTO);

    ANA_SET_ADC_CFG(phy_idx, radio_cfg->phy_mode, radio_cfg->data_rate);

    ANA_SET_DCDC_CFG(phy_idx, radio_adpt[phy_idx].pa_type, radio_adpt[phy_idx].match_type);

    ANA_SET_XTAL_CFG(phy_idx);

    ANA_SET_MODULE_PD_RST(phy_idx);

    ANA_SET_CHARGE_PUMP(phy_idx, radio_cfg->phy_mode, radio_cfg->data_rate);

    ANA_DO_FILTER_CALIBRATION(phy_idx);

    /*===== phr config =====*/
    if (radio_cfg->frame_hw_opt & FRAME_HW_PHR) {
        debug_print("HW_PHR\n");
        if (radio_cfg->phy_mode == PHY_MODE_TRANSPARENT) {
            //MAC_ENABLE_CRC_CHECK(phy_idx, ENABLE);
            MAC_ENABLE_PHR_CHECK(phy_idx, ENABLE);
        }
        MAC_SET_RX_PHR_CONFIG(phy_idx, 
                            radio_cfg->hdr_bytes, 
                            radio_cfg->length_bit_offset, 
                            ((radio_cfg->hdr_config & PHR_CFG_BIT_ENDIAN_MSB_FIRST) && (radio_cfg->hdr_bytes > 1)) ? 1 : 0, 
                            radio_cfg->length_bit_size);
        MAC_SET_TX_PHR_CONFIG(phy_idx,
                            radio_cfg->hdr_bytes,
                            radio_cfg->length_bit_offset,
                            ((radio_cfg->hdr_config & PHR_CFG_BIT_ENDIAN_MSB_FIRST) && (radio_cfg->hdr_bytes > 1)) ? 1 : 0);

    }
    
    /*===== crc config =====*/
    if (radio_cfg->frame_hw_opt & FRAME_HW_CRC) {   
        debug_print("HW_CRC\n");
        MAC_SET_CRC_BIT_ENDIAN(phy_idx, 
                            (radio_cfg->crc_config & CRC_CFG_INPUT_MSB_FIRST) ? 0 : 1, 
                            (radio_cfg->crc_config & CRC_CFG_OUTPUT_MSB_FIRST) ? 0 : 1);
        MAC_SET_CRC_BYTE_ENDIAN(phy_idx, (radio_cfg->crc_config & CRC_CFG_OUTPUT_BYTE_MSB_FIRST) ? 1 : 0);
        MAC_SET_CRC_INVERSE(phy_idx, (radio_cfg->crc_config & CRC_CFG_INVERT) ? 1 : 0);
        MAC_SET_CRC_CONFIG(phy_idx, radio_cfg->crc_width, radio_cfg->crc_polynomial, radio_cfg->crc_seed);
        MAC_ENABLE_CRC_CHECK(phy_idx, ENABLE);
    }
    /*=====tx=====*/
    _hal_drv_radio_set_tx_init(phy_idx);
    _hal_drv_radio_set_tx_cfg(phy_idx, radio_cfg);

    /*=====rx=====*/
    hal_drv_radio_set_bbp_rate(phy_idx, 
                               radio_cfg->phy_mode,
                               radio_cfg->mod_type, 
                               radio_cfg->data_rate, 
                               radio_adpt[phy_idx].mod_idx);
    _hal_drv_radio_set_rx_init(phy_idx);
    _hal_drv_radio_set_rx_cfg(phy_idx, radio_cfg);

    /*===== for special case =====*/
    _hal_drv_radio_set_special_cfg(phy_idx, radio_cfg);

    /*=====do iqk=====*/
    _hal_drv_radio_do_iqk(phy_idx, radio_adpt[phy_idx].match_type);

#if 0 //kevinyang, 20250818, controled by intf layer
    /*=====enable interrupt=====*/
    radio_adpt[phy_idx].int_mask = (MAC_INT_EN_RX_MASK | 
                                    MAC_INT_EN_RXERR_MASK | 
                                    MAC_INT_EN_SYNCW_MASK |
                                    MAC_INT_EN_TX_MASK | 
                                    MAC_INT_EN_TXERR_MASK); //default
    MAC_ENABLE_INTERRUPT(phy_idx, radio_adpt[phy_idx].int_mask);
#endif

    return status;
}

void hal_drv_radio_set_panid(int8_t phy_idx, uint16_t pan_id)
{
    MAC_SET_PANID(phy_idx, pan_id);
}

void hal_drv_radio_set_short_addr(int8_t phy_idx, uint16_t s_addr)
{
    MAC_SET_SHORT_ADDR(phy_idx, s_addr);
}

void hal_drv_radio_set_long_addr(int8_t phy_idx, const uint8_t *l_addr)
{
    MAC_SET_LONG_ADDR(phy_idx, l_addr);
}

typedef struct {
    uint8_t base;
    uint8_t multp;
} rx_to_cfg_t;

rx_to_cfg_t _calc_rx_to_cfg(uint32_t ms)
{
    uint32_t base_options[] = {200, 400, 1000, 20000}; // units: us
    uint8_t max_multp = 64;

    uint32_t target_us = ms * 1000;
    uint32_t best_diff = 0xFFFFFFFF;
    rx_to_cfg_t best_config = {0, 0};

    for (size_t i = 0; i < sizeof(base_options)/sizeof(base_options[0]); ++i) {
        uint32_t base = base_options[i];
        uint32_t est_mul = target_us / base;
        if (est_mul == 0) est_mul = 1;
        if (est_mul > max_multp) est_mul = max_multp;

        for (int delta = -1; delta <= 1; ++delta) {
            uint8_t mul = est_mul + delta;
            if (mul < 1 || mul > max_multp) continue;

            uint32_t total = base * mul;
            uint32_t diff = (total > target_us) ? (total - target_us) : (target_us - total);

            if (diff < best_diff) {
                best_diff = diff;
                best_config.base = i;
                best_config.multp = mul;

                if (diff == 0) return best_config;
            }
        }
    }
    return best_config;
}

void hal_drv_radio_enable_rx_timeout(int8_t phy_idx, uint32_t rx_to_ms)
{
    rx_to_cfg_t cfg = _calc_rx_to_cfg(rx_to_ms);
//    printf("rxto: base=%d, multp=%d\n", cfg.base, cfg.multp - 1);
    MAC_ENABLE_RX_TIMEOUT(phy_idx, cfg.base, cfg.multp - 1);
}

void hal_drv_radio_disable_rx_timeout(int8_t phy_idx)
{
    MAC_DISABLE_RX_TIMEOUT(phy_idx);
}

void hal_drv_radio_set_bbp_rate(int8_t phy_idx, uint8_t phy_mode, uint8_t mod_type, uint32_t data_rate, uint8_t mod_idx)
{
    BBP_SET_BT_RATE(phy_idx, phy_mode, mod_type, data_rate, mod_idx);
    hal_drv_pmu_set_bbp_rate(phy_mode, mod_type, data_rate, mod_idx);
}

#ifdef ES_DEVICE_TRX_RADIO
void hal_drv_radio_get_rx_fifo(uint8_t *rx_buf, uint32_t rx_len)
{
    hal_trx_read_rx_fifo((uint32_t *)rx_buf, rx_len);
}

void hal_drv_radio_reset_rx_fifo(void)
{
    hal_trx_reset_rx_fifo();
}
#endif

void hal_drv_radio_set_ed_thres(uint16_t thres)
{
    BBP_SET_ED_THRES(thres);
}

static uint8_t _agc_idx_auto_adjust(int8_t phy_idx, uint8_t init_idx)
{
    uint8_t idx = init_idx;

    BBP_SET_AGC_MODE(AGC_DEBUG_MODE, idx);
    SYS_DELAY(phy_idx, AGC_SETTLE_DELAY_US);

    for (uint8_t i = 0; i < AGC_AUTO_ADJUST_MAX_ITERATIONS; i++) {
        uint16_t raw_pwr = BBP_GET_AGC_IBPWR();

#if 0
        // translate dBm for display only
        int16_t pwr_dbm;
        if (raw_pwr >= AGC_PWR_RAW_POSITIVE_THRESHOLD) {
            pwr_dbm = -((int16_t)((0x400 - raw_pwr) >> 3));  // negative value
        } else {
            pwr_dbm = (int16_t)(raw_pwr >> 3);
        }

        printf("[AGC] Iter %d: idx=%d, pwr=%ddBm (0x%03X)\n", i, idx, pwr_dbm, raw_pwr);
#endif
        // Check if power is within target range
        if (raw_pwr >= AGC_TARGET_PWR_MIN_RAW && raw_pwr <= AGC_TARGET_PWR_MAX_RAW) {
            break;  // Target achieved
        }

        // Determine if adjustment is needed and in which direction
        uint8_t need_adjustment = 0;

        if (raw_pwr < AGC_PWR_RAW_POSITIVE_THRESHOLD || raw_pwr > AGC_TARGET_PWR_MAX_RAW) {
            // Power too high: reduce gain index
            if (idx > 0) {
                idx--;
                need_adjustment = 1;
            }
        } else if (raw_pwr < AGC_TARGET_PWR_MIN_RAW) {
            // Power too low: increase gain index
            if (idx < AGC_MAX_INDEX) {
                idx++;
                need_adjustment = 1;
            }
        }

        if (need_adjustment) {
            BBP_SET_AGC_MODE(AGC_DEBUG_MODE, idx);
            SYS_DELAY(phy_idx, AGC_SETTLE_DELAY_US);
        }
    }

    return idx;
}

uint16_t hal_drv_radio_rx_calib(int8_t phy_idx, uint8_t phy_mode, uint8_t times)
{
    int32_t sum = 0;
    uint16_t avg_raw = 0;
    int16_t ed_thres = 0x7FFF;
    uint8_t idx = BBP_GET_AGC_IDX();
    uint8_t thres_level = (phy_mode == PHY_MODE_MBUS) ? AGC_MBUS_ED_THRES_LEVEL : AGC_NORM_ED_THRES_LEVEL;
    

    if (times == 0)
        goto no_calib;
    
    // find the adjusted AGC index
    idx = _agc_idx_auto_adjust(phy_idx, idx);

    BBP_SET_AGC_MODE(AGC_DEBUG_MODE, idx);
    SYS_DELAY(phy_idx, AGC_SETTLE_DELAY_US);
    for (uint32_t i = 0; i < times; ++i) {
        sum += BBP_GET_AGC_IBPWR();
        SYS_DELAY(phy_idx, AGC_SETTLE_DELAY_US);
        // printf("[%s] IBPWR: %d\n", __func__, -((int16_t)((0x400 - BBP_GET_AGC_IBPWR()) >> 3)));
    }

    avg_raw = (uint16_t)(sum / times);

    // translate to dBm
    int16_t avg_dbm;
    if (avg_raw >= AGC_PWR_RAW_POSITIVE_THRESHOLD) {
        avg_dbm = -((int16_t)((0x400 - avg_raw) >> 3));  // negative value
    } else {
        avg_dbm = (int16_t)(avg_raw >> 3);
    }
    ed_thres = avg_dbm + thres_level;

    BBP_SET_ED_THRES(ed_thres);
    BBP_SET_AGC_MODE(AGC_NORMAL_MODE, idx);

no_calib:
    // set the adjusted AGC index to the register
    BBP_SET_AGC_IDX(idx);
    return (uint16_t)ed_thres;
}

void hal_drv_radio_enable_cdr_est(uint8_t enable)
{
    BBP_ENABLE_CDR_EST(enable);
}

void hal_drv_radio_set_dcdc_default_val(void)
{
    ANA_SET_DCDC_DEFAUL_VAL();
}

void hal_drv_radio_set_rx_data_rate(int8_t phy_idx, uint8_t phy_mode, uint32_t data_rate)
{
    ANA_SET_RX_DATA_RATE(phy_idx, phy_mode, data_rate);
}

HAL_STATUS hal_drv_radio_set_rx_config(int8_t phy_idx, RADIO_CFG_T *radio_cfg)
{
    HAL_STATUS status = HAL_NO_ERR;

    radio_adpt[phy_idx].mod_idx = _hal_drv_radio_get_mod_idx((int32_t)radio_cfg->data_rate, (int32_t)radio_cfg->freq_devia);

    ANA_SET_ADC_CFG(phy_idx, radio_cfg->phy_mode, radio_cfg->data_rate);

    _hal_drv_radio_set_rx_cfg(phy_idx, radio_cfg);

    BBP_SETUP(phy_idx,
              radio_adpt[phy_idx].radio_cfg.phy_mode, 
              radio_adpt[phy_idx].radio_cfg.data_rate, 
              radio_adpt[phy_idx].mod_idx,
              radio_adpt[phy_idx].radio_cfg.wmbus_mode);
    BBP_SET_AGC_IDX(BBP_GET_BACKUP_AGC_IDX());
              
    hal_drv_radio_set_data_rate(phy_idx, radio_cfg->phy_mode, radio_cfg->data_rate);

    hal_drv_radio_set_bbp_rate(phy_idx,
                              radio_adpt[phy_idx].radio_cfg.phy_mode, 
                              radio_adpt[phy_idx].radio_cfg.mod_type, 
                              radio_adpt[phy_idx].radio_cfg.data_rate, 
                              radio_adpt[phy_idx].mod_idx);

    _hal_drv_radio_set_special_cfg(phy_idx, radio_cfg);

    return status;
}

HAL_STATUS hal_drv_radio_set_tx_config(int8_t phy_idx, RADIO_CFG_T *radio_cfg)
{
    HAL_STATUS status = HAL_NO_ERR;

    radio_adpt[phy_idx].mod_idx = _hal_drv_radio_get_mod_idx((int32_t)radio_cfg->data_rate, (int32_t)radio_cfg->freq_devia);

    hal_drv_radio_set_data_rate(phy_idx, radio_cfg->phy_mode, radio_cfg->data_rate);
    hal_drv_radio_set_freq_devia(phy_idx, radio_cfg->freq_devia);
    _hal_drv_radio_set_tx_cfg(phy_idx, radio_cfg);

    return status;
}



#ifdef TARGET_LIB
RAM_TEXT void MAC_IRQHandler()
#else
WEAK_ISR RAM_TEXT  void MAC_IRQHandler()
#endif
{
    if (radio_adpt[PHY_IDX_0].isr_callback) {
        radio_adpt[PHY_IDX_0].isr_callback(radio_adpt[PHY_IDX_0].isr_cb_data);
    }
}
