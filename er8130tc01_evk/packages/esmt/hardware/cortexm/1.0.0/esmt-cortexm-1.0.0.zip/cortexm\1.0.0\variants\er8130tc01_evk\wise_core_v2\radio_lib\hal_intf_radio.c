/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "hal_intf_radio.h"
#include "hal_intf_pmu.h"
#include "drv/hal_drv_dma.h"
#include "drv/hal_drv_wutmr.h"
#include "hal_drv_radio.h"
#ifdef ES_DEVICE_TRX_RADIO
#include "xcvr04/peri/platform/common/hal/hal_intf_trx_pmu.h"
#endif

#include "util_debug_log.h"

#ifndef HAL_DRV_RADIO_VERSION
#error "HAL_DRV_RADIO_VERSION is not define"
#endif
#include "wise_gpio_api.h"

#define HAL_RF_SET_BIT(v, b)                    (v |= b)
#define HAL_RF_CLEAR_BIT(v, b)                  (v &= ~b)
#define HAL_RF_CHECK_BIT(v, b)                  ((v & b) ? 1 : 0)

static uint32_t _hal_int_drv_to_intf(uint32_t macInt);
static uint32_t _hal_int_intf_to_drv(uint32_t intfInt);


void *hal_intf_radio_get_adapt(int8_t phy_idx)
{
    return hal_drv_radio_get_adapt(phy_idx);
}

void hal_intf_radio_set_adapt(int8_t phy_idx)
{
    hal_drv_radio_set_adapt(phy_idx);
}

HAL_STATUS hal_intf_radio_init(int8_t phy_idx, RADIO_CFG_T *radio_cfg)
{
    HAL_STATUS status = HAL_NO_ERR;

    // do sw reset before setting
    if (phy_idx == PHY_IDX_0) {
        hal_intf_pmu_module_sw_reset(MAC_MODULE | BBP_MODULE | ANA_MODULE);
    }

#ifdef ES_DEVICE_TRX_RADIO
        if (phy_idx == PHY_IDX_1) {
            hal_intf_trx_pmu_module_sw_reset(0xffffffff);
        }
#endif

    if (hal_drv_radio_set_phy(phy_idx, radio_cfg) != HAL_NO_ERR) {
        DBG_PRINT("radio set phy fail !\n");
        status = HAL_ERR;
        goto finish;
    }

finish:
    return status;
}

void hal_intf_radio_deinit(void)
{
}

void hal_intf_radio_set_isr_callback(int8_t phy_idx, HAL_ISR_CALLBACK cb_proc, void *cb_data)
{
    hal_drv_radio_set_isr_cb(phy_idx, cb_proc, cb_data);
}

uint32_t hal_intf_radio_get_int_status(int8_t phy_idx)
{
    uint32_t int_status = 0;
    
    uint32_t halStatus = hal_drv_radio_get_int_status(phy_idx);
    uint32_t halEnMask = hal_drv_radio_get_int_en_mask(phy_idx);

    halStatus &= halEnMask; //kevinyang, 20250916, only clear enabled interrupt
    
    hal_drv_radio_clear_status(phy_idx, halStatus);
    
    int_status |= ((halStatus & MAC_INT_RX_MASK) ? HAL_RADIO_INT_RX_FIN : 0);
    int_status |= ((halStatus & (MAC_INT_RXERR_MASK|MAC_INT_RXTOUT_MASK)) ? HAL_RADIO_INT_RX_ERR : 0);
    int_status |= ((halStatus & MAC_INT_TX_MASK) ? HAL_RADIO_INT_TX_FIN : 0);
    int_status |= ((halStatus & MAC_INT_TXERR_MASK) ? HAL_RADIO_INT_TX_ERR : 0);
    int_status |= ((halStatus & MAC_INT_SYNCW_MASK) ? HAL_RADIO_INT_RX_SYNCWORD : 0);
    
    return int_status;
}

static uint32_t _hal_int_drv_to_intf(uint32_t macInt)
{
    uint32_t intIntf = 0;

    if(HAL_RF_CHECK_BIT(macInt, MAC_INT_RX_MASK))
        HAL_RF_SET_BIT(intIntf, HAL_RADIO_INT_RX_FIN);

    if(HAL_RF_CHECK_BIT(macInt, MAC_INT_EN_RXERR_MASK))
        HAL_RF_SET_BIT(intIntf, HAL_RADIO_INT_RX_ERR);

    if(HAL_RF_CHECK_BIT(macInt, MAC_INT_EN_TX_MASK))
        HAL_RF_SET_BIT(intIntf, HAL_RADIO_INT_TX_FIN);

    if(HAL_RF_CHECK_BIT(macInt, MAC_INT_EN_TXERR_MASK))
        HAL_RF_SET_BIT(intIntf, HAL_RADIO_INT_TX_ERR);

    if(HAL_RF_CHECK_BIT(macInt, MAC_INT_EN_SYNCW_MASK))
        HAL_RF_SET_BIT(intIntf, HAL_RADIO_INT_RX_SYNCWORD);
        
    return intIntf;
}

static uint32_t _hal_int_intf_to_drv(uint32_t intfInt)
{
    uint32_t intDrv = 0;
    
    if(HAL_RF_CHECK_BIT(intfInt, HAL_RADIO_INT_RX_FIN))
        HAL_RF_SET_BIT(intDrv, MAC_INT_RX_MASK);
    
    if(HAL_RF_CHECK_BIT(intfInt, HAL_RADIO_INT_RX_ERR))
        HAL_RF_SET_BIT(intDrv, MAC_INT_EN_RXERR_MASK);

    if(HAL_RF_CHECK_BIT(intfInt, HAL_RADIO_INT_TX_FIN))
        HAL_RF_SET_BIT(intDrv, MAC_INT_EN_TX_MASK);

    if(HAL_RF_CHECK_BIT(intfInt, HAL_RADIO_INT_TX_ERR))
        HAL_RF_SET_BIT(intDrv, MAC_INT_EN_TXERR_MASK);

    if(HAL_RF_CHECK_BIT(intfInt, HAL_RADIO_INT_RX_SYNCWORD))
        HAL_RF_SET_BIT(intDrv, MAC_INT_EN_SYNCW_MASK);
    return intDrv;
}

uint32_t hal_intf_radio_get_int_mask_status(int8_t phy_idx, uint32_t intMask)
{
    uint32_t intStatus = 0;

    uint32_t halStatus = hal_drv_radio_get_int_status(phy_idx);

    intStatus = (_hal_int_drv_to_intf(halStatus)) & intMask;
    halStatus = _hal_int_intf_to_drv(intStatus);

    hal_drv_radio_clear_status(phy_idx, halStatus);


    return intStatus;
}

void hal_intf_radio_set_int_en(int8_t phy_idx, uint32_t enMask)
{
    uint32_t macIntEn = 0;

    hal_drv_radio_disable_interrupt(phy_idx);
    macIntEn = hal_drv_radio_get_int_en_mask(phy_idx);
    
    if(HAL_RF_CHECK_BIT(enMask, HAL_RADIO_INT_RX_FIN))
        HAL_RF_SET_BIT(macIntEn, MAC_INT_RX_MASK);
    else
        HAL_RF_CLEAR_BIT(macIntEn, MAC_INT_RX_MASK);

    if(HAL_RF_CHECK_BIT(enMask, HAL_RADIO_INT_RX_ERR))
        HAL_RF_SET_BIT(macIntEn, MAC_INT_EN_RXERR_MASK);
    else
        HAL_RF_CLEAR_BIT(macIntEn, MAC_INT_EN_RXERR_MASK);

    if(HAL_RF_CHECK_BIT(enMask, HAL_RADIO_INT_TX_FIN))
        HAL_RF_SET_BIT(macIntEn, MAC_INT_EN_TX_MASK);
    else
        HAL_RF_CLEAR_BIT(macIntEn, MAC_INT_EN_TX_MASK);

    if(HAL_RF_CHECK_BIT(enMask, HAL_RADIO_INT_TX_ERR))
        HAL_RF_SET_BIT(macIntEn, MAC_INT_EN_TXERR_MASK);
    else
        HAL_RF_CLEAR_BIT(macIntEn, MAC_INT_EN_TXERR_MASK);

    if(HAL_RF_CHECK_BIT(enMask, HAL_RADIO_INT_RX_SYNCWORD))
        HAL_RF_SET_BIT(macIntEn, MAC_INT_EN_SYNCW_MASK);
    else
        HAL_RF_CLEAR_BIT(macIntEn, MAC_INT_EN_SYNCW_MASK);
    
    hal_drv_radio_set_int_en_mask(phy_idx, macIntEn);
    hal_drv_radio_enable_interrupt(phy_idx);
}

uint32_t hal_intf_radio_get_int_en(int8_t phy_idx)
{
    uint32_t halIntEn = 0;
    
    uint32_t macIntEn = hal_drv_radio_get_int_en_mask(phy_idx);

    halIntEn = _hal_int_drv_to_intf(macIntEn);
    /*
    if(HAL_RF_CHECK_BIT(macIntEn, MAC_INT_RX_MASK))
        HAL_RF_SET_BIT(halIntEn, HAL_RADIO_INT_RX_FIN);

    if(HAL_RF_CHECK_BIT(macIntEn, MAC_INT_EN_RXERR_MASK))
        HAL_RF_SET_BIT(halIntEn, HAL_RADIO_INT_RX_ERR);

    if(HAL_RF_CHECK_BIT(macIntEn, MAC_INT_EN_TX_MASK))
        HAL_RF_SET_BIT(halIntEn, HAL_RADIO_INT_TX_FIN);

    if(HAL_RF_CHECK_BIT(macIntEn, MAC_INT_EN_TXERR_MASK))
        HAL_RF_SET_BIT(halIntEn, HAL_RADIO_INT_TX_ERR);

    if(HAL_RF_CHECK_BIT(macIntEn, MAC_INT_EN_SYNCW_MASK))
        HAL_RF_SET_BIT(halIntEn, HAL_RADIO_INT_RX_SYNCWORD);
    */

    return halIntEn;
}


void hal_intf_radio_get_rx_info(int8_t phy_idx, void *rx_meta)
{
    hal_drv_radio_get_rx_info(phy_idx, rx_meta);
}

void hal_intf_radio_set_pwr_mode(int8_t phy_idx, uint8_t mode)
{
    hal_drv_radio_set_pwr_mode(phy_idx, mode);
}

void hal_intf_radio_set_tx_pwr(int8_t phy_idx, uint8_t lv)
{
#ifdef ANA_MAX_TX_POWER_VALUE
    if(lv > ANA_MAX_TX_POWER_VALUE)
        lv = ANA_MAX_TX_POWER_VALUE;
#endif

    hal_drv_radio_set_tx_pwr(phy_idx, lv);
}

int8_t hal_intf_radio_tx_pwr_dbm_to_raw(int8_t pwr_dbm)
{
    uint8_t levelNum = 0;
    const TX_PWR_MAPPING* mappingTable = hal_drv_radio_get_tx_pwr_table(&levelNum);
    uint8_t left = 0;
    uint8_t right = levelNum - 1;
    uint8_t idx_low = 0, idx_high = 0;
    
    if(pwr_dbm < mappingTable[0].pwr_dbm)
        return mappingTable[0].gain_val;
    if(pwr_dbm > mappingTable[levelNum-1].pwr_dbm)
        return mappingTable[levelNum-1].gain_val;

    while(left <= right)
    {
        uint8_t mid = left + (right - left)/2;

        if(mappingTable[mid].pwr_dbm == pwr_dbm)
            return mappingTable[mid].gain_val;
        else if(mappingTable[mid].pwr_dbm < pwr_dbm)
            left = mid + 1;
        else
        {
            if(mid == 0)
                break;

            right = mid - 1;
        }
    }

    idx_low = right;
    idx_high = left;

    if((abs(mappingTable[idx_low].pwr_dbm - pwr_dbm)) <= abs(mappingTable[idx_high].pwr_dbm - pwr_dbm))
        return mappingTable[idx_low].gain_val;
    else
        return mappingTable[idx_high].gain_val;
}

int8_t hal_intf_radio_tx_pwr_raw_to_dbm(int8_t gain_val)
{
    uint8_t levelNum = 0;
    const TX_PWR_MAPPING* mappingTable = hal_drv_radio_get_tx_pwr_table(&levelNum);
    uint8_t left = 0;
    uint8_t right = levelNum - 1;
    uint8_t idx_low = 0, idx_high = 0;

    if(gain_val < 0)
        gain_val = 0;
    else if(gain_val > ANA_MAX_TX_POWER_VALUE)
        gain_val = ANA_MAX_TX_POWER_VALUE;
    
    while(left <= right)
    {
        uint8_t mid = left + (right - left)/2;

        if(mappingTable[mid].gain_val == gain_val)
            return mappingTable[mid].pwr_dbm;
        else if(mappingTable[mid].gain_val < gain_val)
            left = mid + 1;
        else
        {
            if(mid == 0)
                break;

            right = mid - 1;
        }
    }

    idx_low = right;
    idx_high = left;

    if((abs(mappingTable[idx_low].gain_val - gain_val)) <= abs(mappingTable[idx_high].gain_val - gain_val))
        return mappingTable[idx_low].pwr_dbm;
    else
        return mappingTable[idx_high].pwr_dbm;
}

void hal_intf_radio_rx_start(int8_t phy_idx, uint8_t *rx_buf, uint32_t rx_len)
{
    hal_drv_dma_p2m2p_config_and_trigger(DMA_CHANNEL_1, DMA_PERI_REQ_MAC_RX, (uint32_t)rx_buf, rx_len);
    hal_drv_radio_rx_start(phy_idx, rx_len);
}

uint8_t hal_intf_radio_rx_stop(int8_t phy_idx)
{
    return hal_drv_radio_rx_stop(phy_idx);
}

void hal_intf_radio_set_rx_restart(int8_t phy_idx, uint8_t enable)
{
    hal_drv_radio_set_rx_restart(phy_idx, enable);
}

uint8_t hal_intf_radio_get_rx_busy(int8_t phy_idx)
{
    return hal_drv_radio_get_rx_busy(phy_idx);
}

uint16_t hal_intf_radio_get_cca_rssi(int8_t phy_idx)
{
    RADIO_FRAME_META_T rx_meta = {0};
    uint8_t phy_mode_bk;
    uint32_t intMask = 0;


    phy_mode_bk = hal_drv_radio_get_phy_mode(phy_idx);

    hal_drv_radio_set_phy_mode(phy_idx, PHY_MODE_CCA);

    intMask = hal_drv_radio_get_int_en_mask(phy_idx);
    if(intMask != 0)
        hal_drv_radio_disable_interrupt(phy_idx);

    hal_intf_radio_rx_start(phy_idx, NULL, 0);

    if (hal_drv_radio_wait_rssi_rdy(phy_idx) == HAL_ERR) {
        printf("get cca rssi timeout \n");
    }

    hal_intf_radio_rx_stop(phy_idx);

    if(intMask != 0)
        hal_drv_radio_enable_interrupt(phy_idx);
    
    hal_drv_radio_get_rx_info(phy_idx, (void *)&rx_meta);

    hal_drv_radio_print_rx_info(phy_idx);

    hal_drv_radio_set_phy_mode(phy_idx, phy_mode_bk);

    return rx_meta.rssi;
}

void hal_intf_radio_enable_singletone(int8_t phy_idx, uint32_t pwr_lv, uint8_t enable)
{
    hal_drv_radio_enable_singletone(phy_idx, pwr_lv, enable);
}

void hal_intf_radio_print_rx_info(int8_t phy_idx)
{
    hal_drv_radio_print_rx_info(phy_idx);
}

void hal_intf_radio_set_ch(int8_t phy_idx, uint32_t ch)
{
    hal_drv_radio_set_ch(phy_idx, ch);
}

void hal_intf_radio_tx_start(int8_t phy_idx, uint8_t *tx_buf, uint32_t tx_len)
{
    hal_drv_dma_p2m2p_config_and_trigger(DMA_CHANNEL_0, DMA_PERI_REQ_MAC_TX, (uint32_t)tx_buf, tx_len);

    hal_drv_radio_tx_start(phy_idx, tx_buf, tx_len);
}

void hal_intf_radio_tx_stop(int8_t phy_idx)
{
    hal_drv_radio_tx_stop(phy_idx);
}

void hal_intf_radio_set_panid(int8_t phy_idx, uint16_t pan_id)
{
    hal_drv_radio_set_panid(phy_idx, pan_id);
}

void hal_intf_radio_set_short_addr(int8_t phy_idx, uint16_t short_addr)
{
    hal_drv_radio_set_short_addr(phy_idx, short_addr);
}

void hal_intf_radio_set_long_addr(int8_t phy_idx, const uint8_t *long_addr)
{
    hal_drv_radio_set_long_addr(phy_idx, long_addr);
}

HAL_STATUS hal_intf_radio_set_synthesizer(int8_t phy_idx, uint32_t ch)
{
    HAL_STATUS status        = HAL_NO_ERR;
    RADIO_ADAPT_T *adapt     = (RADIO_ADAPT_T *)hal_intf_radio_get_adapt(phy_idx);
    RADIO_CFG_T *p_hal_radio = &adapt->radio_cfg;

    if (!adapt) {
        DBG_PRINT("radio adapter has not been initialized !\n");
        status = HAL_ERR;
    }

    p_hal_radio->ch_freq = ch;

    // NOTE:: workaround for the modem backup feature
    hal_drv_radio_set_data_rate(phy_idx, p_hal_radio->phy_mode, p_hal_radio->data_rate);

    hal_drv_radio_set_ch(phy_idx, p_hal_radio->ch_freq);

    // NOTE:: cic clock should be updated after triggering the synthesizer
    // hal_drv_radio_set_bbp_rate(phy_idx, 
    //                            p_hal_radio->phy_mode,
    //                            p_hal_radio->mod_type, 
    //                            p_hal_radio->data_rate, 
    //                            adapt->mod_idx);
    return status;
}

HAL_STATUS hal_intf_radio_wor_start(int8_t phy_idx, uint32_t fsh_time_ms, uint32_t rx_to_ms)
{
#ifdef CHIP_RADIO_HAS_WOR
    HAL_STATUS status = HAL_NO_ERR;

    if (rx_to_ms > MAX_RX_TIMOUT) {
        status = HAL_ERR;
    } else {
        // setup wakeup timer
        hal_drv_wutmr_set_interrupt_disable();
        hal_drv_wutmr_set_time(fsh_time_ms);
        hal_drv_wutmr_set_enable(1); // set periodic mode

        // enable timeout function
        hal_drv_radio_enable_rx_timeout(phy_idx, rx_to_ms);

        // exter to sleep mode
        hal_intf_radio_rx_stop(phy_idx);
        hal_intf_radio_set_pwr_mode(phy_idx, PWR_MODE_SLEEP);
        hal_intf_pmu_set_pwr_mode(PWR_MODE_SLEEP);
        // --------Sleep--------
        // System in WOR mode
        // --------Wakeup-------
        hal_drv_radio_disable_rx_timeout(phy_idx);
        hal_drv_wutmr_set_disable();
    }

    return status;
#else
    return HAL_ERR;
#endif
}

#ifdef CHIP_RADIO_HAS_BLE
HAL_STATUS hal_intf_radio_ble_init(int8_t phy_idx, RADIO_CFG_T *radio_cfg)
{
    HAL_STATUS status = HAL_NO_ERR;

    // do sw reset before setting
    if (phy_idx == PHY_IDX_0) {
        hal_intf_pmu_module_sw_reset(0xffffffff);
    }

    if (hal_drv_radio_ble_set_phy(phy_idx, radio_cfg) != HAL_NO_ERR) {
        DBG_PRINT("radio set phy fail !\n");
        status = HAL_ERR;
    }

    return status;
}
#endif //CHIP_RADIO_HAS_BLE

#ifdef ES_DEVICE_TRX_RADIO
void hal_intf_radio_get_rx_fifo(uint8_t *rx_buf, uint32_t rx_len)
{
    hal_drv_radio_get_rx_fifo(rx_buf, rx_len);
}

void hal_intf_radio_reset_rx_fifo(void)
{
    hal_drv_radio_reset_rx_fifo();
}
#endif

uint16_t hal_intf_radio_rx_calib(int8_t phy_idx, uint8_t phy_mode, uint8_t mod_type, uint16_t rx_sig_thres)
{
#ifdef CHIP_RADIO_NEED_RX_CAL
    uint8_t phy_mode_bk;
    uint16_t sig_thres = rx_sig_thres;
    uint32_t intStatus = 0;
    uint32_t intMask = 0;

    if (rx_sig_thres != RX_INVALID_SIG_THRES) {
        hal_drv_radio_set_ed_thres(rx_sig_thres);
        goto no_calib;
    }

    phy_mode_bk = hal_drv_radio_get_phy_mode(phy_idx);

    hal_drv_radio_set_phy_mode(phy_idx, PHY_MODE_CCA);

    intMask = hal_drv_radio_get_int_en_mask(phy_idx);
    if(intMask != 0)
        hal_drv_radio_disable_interrupt(phy_idx);

    // disable cdr estimation to work around the cdr issue at mbus mode
    hal_drv_radio_enable_cdr_est(0);

    hal_intf_radio_rx_start(phy_idx, NULL, 0);

    sig_thres = hal_drv_radio_rx_calib(phy_idx, phy_mode, 5);

    hal_intf_radio_rx_stop(phy_idx);

    if (phy_mode == PHY_MODE_MBUS && mod_type == MOD_TYPE_FSK) {
        hal_drv_radio_enable_cdr_est(1);
    }
    // prevent signal from entering the MAC during calibration
    intStatus = hal_drv_radio_get_int_status(phy_idx);
    hal_drv_radio_clear_status(phy_idx, intStatus);

    if(intMask != 0)
        hal_drv_radio_enable_interrupt(phy_idx);
    
    hal_drv_radio_set_phy_mode(phy_idx, phy_mode_bk);

no_calib:
    return sig_thres;
#else
    return RX_INVALID_SIG_THRES;
#endif
}

void hal_intf_radio_trig_tpm_calib(int8_t phy_idx, RADIO_CFG_T * radio_cfg)
{
    hal_drv_radio_trig_tpm_calib(phy_idx, radio_cfg);
}

void hal_intf_radio_get_tpm_cal_val(TPM_CAL_PARA *tpm_cal_val)
{
    hal_drv_radio_get_tpm_cal_val(tpm_cal_val);
}

void hal_intf_radio_set_tpm_cal_val(TPM_CAL_PARA *tpm_cal_val)
{
    hal_drv_radio_set_tpm_cal_val(tpm_cal_val);
}

void hal_intf_radio_set_dcdc_default_val(void)
{
    hal_drv_radio_set_dcdc_default_val();
}

HAL_STATUS hal_intf_radio_rx_config(int8_t phy_idx, RADIO_CFG_T *radio_cfg)
{
    HAL_STATUS status = HAL_NO_ERR;
    wise_gpio_write(8, GPIO_LOW);
    if (hal_drv_radio_set_rx_config(phy_idx, radio_cfg) != HAL_NO_ERR) {
        DBG_PRINT("radio set radio rx fail !\n");
        status = HAL_ERR;
        goto finish;
    }
    wise_gpio_write(8, GPIO_HIGH);
finish:
    return status;
}

HAL_STATUS hal_intf_radio_tx_config(int8_t phy_idx, RADIO_CFG_T *radio_cfg)
{
    HAL_STATUS status = HAL_NO_ERR;
    
    if (hal_drv_radio_set_tx_config(phy_idx, radio_cfg) != HAL_NO_ERR) {
        DBG_PRINT("radio set radio tx config fail !\n");
        status = HAL_ERR;
    }

    return status;
}

HAL_STATUS hal_intf_radio_iq_calib(int8_t phy_idx, uint32_t ch_freq)
{
    HAL_STATUS status = HAL_NO_ERR;

#ifdef CHIP_RADIO_SUPPORT_IQK
    hal_drv_radio_do_iqk(phy_idx, ch_freq);
#endif

    return status;
}

void hal_intf_radio_test(void)
{

}

void hal_intf_radio_set_ulpldo(uint8_t enable)
{
#if (ESMT_SOC_CHIP_ID == 0x9006)
    hal_drv_radio_set_ulpldo(enable);
#endif
}

