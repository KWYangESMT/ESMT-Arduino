#include "Arduino.h"

#ifdef __cplusplus
extern "C" {
#endif
#include "wise_core.h"
#include "wise_flash_api.h"
#include "wise_gpio_api.h"
#include "wise_spi_api.h"
#include "wise_sys_api.h"
#include "wise_tick_api.h"
#include "wise_uart_api.h"
#include "wise_wutmr_api.h"

#include "wise_file_system.h"
#include "wise_ctrl_packet.h"
#include "wise_ctrl_cmd.h"
#ifdef __cplusplus
}
#endif

#define BOARD_TCXO_OUTPUT_EN                        0   //0: disable, 1:enable
#define BOARD_PA_TYPE                               0   //0: 10db, 1: 14db
#define BOARD_BAND_MATCHING                         0   //0: 915, 1: 868, 2: 490
#define BOARD_40M_GAIN_CTRL                         1   //1 ~ 8
#define BOARD_40M_GAIN_CTRL_S                       8
#define BOARD_40M_CAP_XTAL_I                        64  //default = 64
#define BOARD_40M_CAP_XTAL_O                        64  //default = 64
#define BOARD_SRAM_RETAIN                           1   //0: 32k, 1: 64K

#ifndef ARDUINO_SERIAL_UART
#define ARDUINO_SERIAL_UART                         0
#endif

#ifndef ARDUINO_SERIAL_UART_BAUD
#define ARDUINO_SERIAL_UART_BAUD                    115200
#endif

#ifndef ARDUINO_SERIAL_UART_TX_PIN
#define ARDUINO_SERIAL_UART_TX_PIN                  0
#endif

#ifndef ARDUINO_SERIAL_UART_RX_PIN
#define ARDUINO_SERIAL_UART_RX_PIN                  1
#endif

#ifndef ARDUINO_SERIAL_UART_RX_BUF_SIZE
#define ARDUINO_SERIAL_UART_RX_BUF_SIZE             256
#endif

static const WISE_SYS_BOARD_PROPERTY_T boardProperty = 
{
    .tcxo_output_en = BOARD_TCXO_OUTPUT_EN,
    .pa_type = BOARD_PA_TYPE,
    .matching_type = BOARD_BAND_MATCHING,
    .gain_ctrl_40m = BOARD_40M_GAIN_CTRL,
    .gain_ctrl_40m_s = BOARD_40M_GAIN_CTRL_S,
    .cap_xtal_i = BOARD_40M_CAP_XTAL_I,
    .cap_xtal_o = BOARD_40M_CAP_XTAL_O,
    .sram_retain = BOARD_SRAM_RETAIN,
};

uint8_t uartRxBuffer0[ARDUINO_SERIAL_UART_RX_BUF_SIZE];

#if (ARDUINO_SERIAL_UART == 0)
const uint8_t _UART_IO_FUNC_TX = MODE_PIO_FUNC_UART0_TX;
const uint8_t _UART_IO_FUNC_RX = MODE_PIO_FUNC_UART0_RX;
#elif (ARDUINO_SERIAL_UART == 1)
const uint8_t _UART_IO_FUNC_TX = MODE_PIO_FUNC_UART1_TX;
const uint8_t _UART_IO_FUNC_RX = MODE_PIO_FUNC_UART1_RX;
#elif (ARDUINO_SERIAL_UART == 2)
const uint8_t _UART_IO_FUNC_TX = MODE_PIO_FUNC_UART2_TX;
const uint8_t _UART_IO_FUNC_RX = MODE_PIO_FUNC_UART2_RX;
#else
#error "unknown uart interface"
#endif

static uint8_t _ctrlCmdInprogress = 0;
static uint8_t rebootRequest = 0;
static uint32_t rebootReqStart = 0;
static uint32_t rebootReqTimeMs = 0;

extern "C" void SystemInit(void);
extern "C" void initVariant(void);
extern "C" void _variant_proc();
extern "C" int8_t wise_request_reboot(uint32_t afterMs);

void _serail_init(uint8_t intf, uint32_t baud);
void _variant_proc();

static void _platform_init();
static void _peripheral_init();
static void _soft_init();
static int32_t _ctrl_pkt_handler(uint8_t *buffer, int len);
static int32_t _ctrl_pkt_output(uint8_t *buffer, int len);

void initVariant(void) 
{
    _platform_init();
    _peripheral_init();

    _serail_init(ARDUINO_SERIAL_UART, ARDUINO_SERIAL_UART_BAUD);
}

static void _platform_init()
{
    WISE_LFOSC_SRC_T oscCfg = {0};
    
    if (WISE_SUCCESS != wise_core_init()) 
    {
        while (1);
    }

    oscCfg.clk_src = SYS_LFOSC_CLK_SRC_INTERNAL_16K;
    oscCfg.mode.mode_select = LFOSC_16K_MODE_TEMP_COMP;
    oscCfg.calFinish = 0;
    
    wise_sys_lfosc_clk_src_config(oscCfg);
    wise_sys_lfosc_clk_calibration();

    wise_wutmr_init();
    wise_wutmr_enable();

    wise_sys_set_board_property(&boardProperty);

    wise_gpio_init();
    wise_tick_init();
    wise_flash_init();

    _soft_init();
}

static void _peripheral_init()
{
    wise_uart_init();

    wise_gpio_func_cfg(ARDUINO_SERIAL_UART_TX_PIN, _UART_IO_FUNC_TX);
    wise_gpio_func_cfg(ARDUINO_SERIAL_UART_RX_PIN, _UART_IO_FUNC_RX);
}

static int32_t _ctrl_pkt_handler(uint8_t *buffer, int len)
{
    if (len > 0) 
    {
        wise_ctrl_cmd_process(buffer, len);
    }

    return WISE_SUCCESS;
}

static int32_t _ctrl_pkt_output(uint8_t *buffer, int len)
{
    if (len > 0) 
    {
        wise_uart_write(ARDUINO_SERIAL_UART, buffer, len);
    }
    return WISE_SUCCESS;
}

static void _soft_init()
{
    wise_fs_init();
    wise_ctrl_cmd_init();
    wise_pkt_init(_ctrl_pkt_output, _ctrl_pkt_handler);
}

void _variant_proc()
{
    uint8_t inputC;
    
    if(WISE_SUCCESS == wise_uart_read_char(ARDUINO_SERIAL_UART, &inputC))
    {
        if(0 == wise_pkt_input(inputC))
        {
            Serial.pushChar(inputC);
        }
        else
        {
            if(!_ctrlCmdInprogress)
            {
                platform_set_state(E_PLATFORM_STATE_BUSY);
                _ctrlCmdInprogress = 1;
            }
        }
    }

    wise_pkt_proc();
    if((PKT_OUTPUT_STS_IDLE == wise_pkt_querry_output_buf()) && (PKT_RX_STS_IDLE == wise_pkt_rx_state()) && _ctrlCmdInprogress)
    {
        platform_set_state(E_PLATFORM_STATE_IDLE);
        _ctrlCmdInprogress = 0;
    }

    if(rebootRequest)
    {
        uint32_t now = wise_tick_get_counter();

        if((now - rebootReqStart) >= MS_TO_CLK(rebootReqTimeMs))
        {
            wise_sys_chip_reset();
        }
    }
}

void _serail_init(uint8_t intf, uint32_t baud)
{
    WISE_BUFFER_T uartRxBuffer = {ARDUINO_SERIAL_UART_RX_BUF_SIZE, (uint32_t)uartRxBuffer0};
    WISE_BUFFER_T uartTxBuffer = {0};
    WISE_UART_CFG_T uartConfig =
    {
        ARDUINO_SERIAL_UART_BAUD,
        E_UART_DATA_8_BIT,
        E_UART_PARITY_NONE,
        E_UART_STOP_1_BIT,
        0,
    };
    static uint8_t serialInited = 0;

    if(serialInited)
        return;
    
    uartConfig.baudrate = baud;
    
    wise_uart_config(intf, &uartConfig);
    wise_uart_set_buffer(intf, &uartRxBuffer, &uartTxBuffer);
    wise_uart_enable(intf, WISE_UART_FLAG_RX | WISE_UART_FLAG_TX);
    wise_uart_enable_interrupt(intf);

    serialInited = 1;
}

int8_t wise_request_reboot(uint32_t afterMs)
{
    rebootReqTimeMs = afterMs;
    rebootReqStart = wise_tick_get_counter();
    rebootRequest = 1;
    
    return WISE_SUCCESS;
}

