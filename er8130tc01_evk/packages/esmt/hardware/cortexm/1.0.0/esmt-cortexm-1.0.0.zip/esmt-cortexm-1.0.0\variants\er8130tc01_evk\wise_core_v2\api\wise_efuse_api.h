/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef _WISE_EFUSE_API_H_
#define _WISE_EFUSE_API_H_

#include "wise_core.h"
#include "cmsis/include/er8xxx.h"
#include "types.h"
#include "hal_intf_efuse.h"

//depreciated API, not supported yet in ER8130A
void wise_efuse_read_word(uint16_t addr, uint32_t * data);
void wise_efuse_write_word(uint16_t addr, uint32_t data);

#endif /* _WISE_EFUSE_API_H_ */
