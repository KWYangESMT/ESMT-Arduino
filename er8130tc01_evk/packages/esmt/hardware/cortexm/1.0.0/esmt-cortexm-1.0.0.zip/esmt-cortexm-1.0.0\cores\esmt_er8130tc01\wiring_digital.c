#include "Arduino.h"

void pinMode(uint8_t pin, uint8_t mode) {
    if (mode == OUTPUT) {
        wise_gpio_set_direction(pin, GPIO_DIR_OUTPUT);
    } else {
        wise_gpio_set_direction(pin, GPIO_DIR_INPUT);
    }
}

void digitalWrite(uint8_t pin, uint8_t val) {
    wise_gpio_write(pin, val ? GPIO_HIGH : GPIO_LOW);
}

int digitalRead(uint8_t pin) {
    return (wise_gpio_read(pin) == GPIO_HIGH) ? HIGH : LOW;
}
