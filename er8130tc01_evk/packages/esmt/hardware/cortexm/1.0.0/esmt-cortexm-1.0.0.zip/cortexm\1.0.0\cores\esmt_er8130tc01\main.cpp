#include "Arduino.h"

#ifdef __cplusplus
extern "C" {
#endif
#include <stdio.h>

#include "wise_uart_api.h"
#include "util.h"
#ifdef __cplusplus
}
#endif

extern void setup(void);
extern void loop(void);


extern "C" int main(void) 
{
    init();

    /*
    extern uint32_t __RAM_TEXT_FROM__;
    extern uint32_t __RAM_TEXT_START__;
    extern uint32_t __RAM_TEXT_END__;

    extern uint32_t __etext;
    extern uint32_t __data_start__;
    extern uint32_t __data_end__;

    extern uint32_t __preinit_array_start;
    extern uint32_t __preinit_array_end;

    extern uint32_t __init_array_start;
    extern uint32_t __init_array_end;

    extern uint32_t __fini_array_start;
    extern uint32_t __fini_array_end;
    
    debug_print("__etext=%p __data_start__=%p __data_end__=%p\n", &__etext, &__data_start__, &__data_end__);
    debug_print("__RAM_TEXT_FROM__=%p __RAM_TEXT_START__=%p __RAM_TEXT_END__=%p\n", &__RAM_TEXT_FROM__, &__RAM_TEXT_START__, &__RAM_TEXT_END__);

    debug_print("__preinit_array_start=%p __preinit_array_end=%p\n", &__preinit_array_start, &__preinit_array_end);
    debug_print("__init_array_start=%p __init_array_end=%p\n", &__init_array_start, &__init_array_start);
    debug_print("__fini_array_start=%p __fini_array_end=%p\n", &__fini_array_start, &__fini_array_end);
    */
    
    setup();
    
    while (1) 
    {
        if(E_PLATFORM_STATE_IDLE == platform_proc())
        {
            loop();
        }
    }
}
