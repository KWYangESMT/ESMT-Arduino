/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "esmt_chip_specific.h"
#include "ana_er8130.h"
#include "drv/hal_drv_pmu.h"
#include "util_debug_log.h"
#include "drv/hal_drv_sys.h" // testing, should be removed
#include "hal_intf_nfc.h"

static const uint32_t ana_setup_arr[] = {
    //ASARADC (0x40011080)
    ANA_ASARADC_CONFIG_1_ADDR, 0x786D5E4C,

    //DC-DC (0x40011200)
    ANA_DCDC_CONFIG_0_ADDR, 0x0E000000,
    //ANA_DCDC_CONFIG_1_ADDR, 0x01800000,

    //IRC_CPPLL (0x40011280)
    ANA_IRC_CPPLL_CONFIG_1_ADDR, 0x82A5D870,
    ANA_IRC_CPPLL_CONFIG_2_ADDR, 0x18006E00,

    //RX_CONFIG
    ANA_RX_GAIN_FILTSET_ADDR, 0x8BCF7E7F,
    ANA_RX_CONFIG_5_ADDR, 0x040E05C8,
    ANA_RX_CONFIG_8_ADDR, 0x00000081,

    // the settling time for DCDC and crystal (0x1A10)
    ANA_PMU_CONFIG_2_ADDR, 0x80001002,

    //ANCTL (0x40011E18)
    ANA_ANCTL_CONFIG_6_ADDR, 0x0254A400,

    //ANCTL (0x40011E30)
    ANA_ANCTL_CONFIG_7_5_ADDR, 0xFDFFFF3F,

    //ANCTL for DC-DC (0x40011E50 & 0x40011E54 & 0x40011E58 & 0x40011E5C))
    //ANCTL (0x40011E50)
    ANA_ANCTL_DCDC_REG0_ADDR, 0x00000000,
    //ANCTL (0x40011E54)
    ANA_ANCTL_DCDC_REG1_ADDR, 0x00000040,
    //ANCTL (0x40011E58)
    ANA_ANCTL_DCDC_REG2_ADDR, 0x00000000,
};

static const uint32_t ana_setup_arr_user_cfg[] = {

};

static const uint32_t fsk_pa_pwr_tbl[] = {
    0x03020101, 0x07060504, 0x0D0C0A08, 0x12100F0E, 0x19171513, 0x1F1E1D1B, 0x27252321, 0x2F2D2B29,
    0x38363331, 0x3F3E3C3A, 0x46444241, 0x4F4E4D49, 0x5E595551, 0x6B68625F, 0x7F7F7871,
};

static const uint32_t bpsk_pa_pwr_tbl[] = {
    0x03020100, 0x07060504, 0x0b0a0908, 0x0f0e0d0c, 0x13121110, 0x17161514, 0x1c1b1a19, 0x21201f1d, 0x27252422, 0x2c2b2928, 0x33312f2e,
    0x3a383634, 0x423f3e3b, 0x4c494744, 0x5a56534f, 0x6e68625e, 0x7f7f7b75, 0x7f7f7f7f, 0x7f7f7f7f, 0x7f7f7f7f, 0x7f7f7f7f, 0x7f7f7f7f,
    0x7f7f7f7f, 0x7f7f7f7f, 0x7f7f7f7f, 0x7f7f7f7f, 0x7f7f7f7f, 0x7f7f7f7f, 0x7f7f7f7f, 0x7f7f7f7f, 0x7f7f7f7f, 0x7f7f7f7f,
};

static const uint32_t bpsk_ramp_pa_pwr_tbl[] = {
    0x04030201, 0x08070605, 0x0D0C0B09, 0x12100F0E, 0x16151413, 0x1B1A1917, 0x201F1E1C, 0x27262322, 0x2F2D2B29,
    0x35333130, 0x3D3C3A37, 0x43413F3E, 0x4A474644, 0x534F4E4B, 0x5A575753, 0x5E5E5B5A, 0x6363625F, 0x6B6A6966,
    0x71706F6D, 0x76757371, 0x7A777776, 0x7E7D7D7B, 0x7F7F7F7E, 0x7F7F7F7F, 0x7F7F7F7F,
};

static struct ana_gain_t ana_gain_def = {
    3, // lna
    3, // mix
    7, // filter
    12 // pga
};

static struct ana_filt_t ana_filt_def_1m[MOD_IDX_MAX] = {
    // filt_cal, filt_en, freq sel, cap_sel
    {1, 1, 0, 0}, // h=0.5, normal: {1, 0, 1, 0}
    {1, 1, 3, 1}, // h=1,   normal: {1, 0, 3, 1}
    {0, 0, 0, 0}, // h=2,
    {0, 0, 0, 0}  // h=4
};

static struct ana_filt_t ana_filt_def_500k[MOD_IDX_MAX] = {
    // filt_cal, filt_en, freq sel, cap_sel
    {1, 1, 3, 3}, // h=0.5
    {1, 1, 2, 2}, // h=1
    {0, 1, 0, 0}, // h=2
    {1, 1, 2, 2}  // h=4
};

static struct ana_filt_t ana_filt_def_250k[MOD_IDX_MAX] = {
    // filt_cal, filt_en, freq sel, cap_sel
    {1, 1, 1, 3}, // h=0.5
    {1, 1, 2, 2}, // h=1
    {0, 1, 0, 0}, // h=2
    {1, 1, 2, 2}  // h=4
};

static struct ana_filt_t ana_filt_def_other[MOD_IDX_MAX] = {
    // filt_cal, filt_en, freq sel, cap_sel
    {1, 1, 7, 15}, // h=0.5
    {1, 1, 3, 3},  // h=1
    {0, 1, 0, 0},  // h=2
    {1, 1, 2, 2}   // 4
};

static struct ana_filt_t ana_filt_mbus_100k     = {1, 1, 7, 15};
static struct ana_filt_t ana_filt_mbus_32p768kk = {1, 1, 3, 7};
static struct ana_filt_t ana_filt_mbus_4p8k     = {1, 1, 7, 15};

static struct ana_para_t ana_para = {
    4,              // tx_fs_parm, data rate: 500kHz
    CTRL_MODE_AUTO, // ctrl_mode
};

static ANA_INFO_T ana_info[RADIO_PHY_NUM];
ANA_INFO_T *ana_get_ana_info_er81xx(void)
{
    return ana_info;
}

#ifdef WORKAROUND_490MHZ

TPM_INFO_TBL tpm_info_table[MOD_IDX_MAX][E_HAL_DR_MAX] = {
    [MOD_IDX_0P5] = {
        [E_HAL_DR_12P5K] = { .div_int_if = 0x11, .div_frac_if = 0x00,
                             .div_int_hb = 0x11, .div_frac_hb = 0x52,
                             .div_int_lb = 0x10, .div_frac_lb = 0x3FFAE },
        [E_HAL_DR_50K]   = { .div_int_if = 0x11, .div_frac_if = 0x00,
                             .div_int_hb = 0x11, .div_frac_hb = 0x148,
                             .div_int_lb = 0x10, .div_frac_lb = 0x3FEB8 },
        [E_HAL_DR_100K]  = { .div_int_if = 0x11, .div_frac_if = 0x00,
                             .div_int_hb = 0x11, .div_frac_hb = 0x28F,
                             .div_int_lb = 0x10, .div_frac_lb = 0x3FD71 },
        [E_HAL_DR_125K]  = { .div_int_if = 0x11, .div_frac_if = 0x00,
                             .div_int_hb = 0x11, .div_frac_hb = 0x333,
                             .div_int_lb = 0x10, .div_frac_lb = 0x3FCCD },
        [E_HAL_DR_200K]  = { .div_int_if = 0x11, .div_frac_if = 0x00,
                             .div_int_hb = 0x11, .div_frac_hb = 0x51F,
                             .div_int_lb = 0x10, .div_frac_lb = 0x3FAE1 },
        [E_HAL_DR_250K]  = { .div_int_if = 0x11, .div_frac_if = 0x00,
                             .div_int_hb = 0x11, .div_frac_hb = 0x666,
                             .div_int_lb = 0x10, .div_frac_lb = 0x3F99A },
        [E_HAL_DR_500K]  = { .div_int_if = 0x11, .div_frac_if = 0x00,
                             .div_int_hb = 0x11, .div_frac_hb = 0xCCD,
                             .div_int_lb = 0x10, .div_frac_lb = 0x3F333 },
        [E_HAL_DR_1M]    = { .div_int_if = 0x11, .div_frac_if = 0x00,
                             .div_int_hb = 0x11, .div_frac_hb = 0x199A,
                             .div_int_lb = 0x10, .div_frac_lb = 0x3E666 }

    },
    /* future MOD_IDX_1, _2, _4 can go here; if unsupported, leave zeroed */
};


uint8_t _get_data_rate_idx(uint32_t data_rate)
{
    uint8_t dr_idx = 0;

    switch (data_rate) {
    case DATA_RATE_2M:
        dr_idx = E_HAL_DR_2M;
        break;

    case DATA_RATE_1M:
        dr_idx = E_HAL_DR_1M;
        break;

    case DATA_RATE_500K:
        dr_idx = E_HAL_DR_500K;
        break;

    case DATA_RATE_250K:
        dr_idx = E_HAL_DR_250K;
        break;

    case DATA_RATE_200K:
        dr_idx = E_HAL_DR_200K;
        break;

    case DATA_RATE_125K:
        dr_idx = E_HAL_DR_125K;
        break;

    case DATA_RATE_100K:
        dr_idx = E_HAL_DR_100K;
        break;

    case DATA_RATE_50K:
        dr_idx = E_HAL_DR_50K;
        break;

    case DATA_RATE_12P5K:
        dr_idx = E_HAL_DR_12P5K;
        break;

    default:
        DBG_PRINT("data rate did not support\n");
        dr_idx = E_HAL_DR_500K;
        break;
    }

    return dr_idx;
}

bool init_tpm_tbl_490mhz(TPM_INFO_TBL* tpm_tbl, uint8_t dr_idx, uint8_t mod_idx)
{
    if (dr_idx >= E_HAL_DR_MAX || mod_idx >= MOD_IDX_MAX) {
        printf("%s bad index [dr = %u mod idx %u]\n",__func__, dr_idx, mod_idx);
        return FALSE;
    }

    *tpm_tbl = tpm_info_table[mod_idx][dr_idx];

    return TRUE;
}

static inline uint32_t PACK_CFG(uint32_t div_int, uint32_t div_frac) {
    return ((div_int << 18) & 0x7C0000) | (div_frac & 0x3FFFF);
}


#endif

void ana_set_freq_devia_er81xx(uint32_t freq_devia)
{
    uint32_t cfg;

    //er8130_tc01 hw design
    cfg = (freq_devia * 2);
#if 0
    if (phy_mode == PHY_MODE_MBUS) {
        //        reg = data_rate;
        if (data_rate == MBUS_DATA_RATE_4P8K) {
            reg = 6000;
        } else if (data_rate == MBUS_DATA_RATE_32P768K) {
            reg = 50000;
        } else {
            reg = data_rate;
        }
    }
#endif    
    REG_W32(ANA_SYNTH_CAL_CONFIG_1_ADDR, cfg);
}

#ifdef WORKAROUND_490MHZ
static uint8_t cur_dr_idx = 0;
static uint8_t cur_mod_idx = MOD_IDX_0P5;
#endif

void ana_set_ch_freq_er81xx(uint32_t ch)
{
    uint32_t reg = 0, en = 0;
   
    // set tx channel frequency
    en  = (ch >= 2400000000UL) ? (1) : (0);
    reg = REG_R32(ANA_ANCTL_TX_FREQ_ADDR);
    reg = (reg & ~ANA_ANCTL_TX_FREQ_MASK) | 
          ((en << ANA_ANCTL_TX_FREQ_POS) & ANA_ANCTL_TX_FREQ_MASK);
    REG_W32(ANA_ANCTL_TX_FREQ_ADDR, reg);

    // set rx channel frequency
    en  = (ch >= 2400000000UL) ? (1) : (0);
    reg = REG_R32(ANA_ANCTL_RX_FREQ_ADDR);
    reg = (reg & ~ANA_ANCTL_RX_FREQ_MASK) | 
          ((en << ANA_ANCTL_RX_FREQ_POS) & ANA_ANCTL_RX_FREQ_MASK);
    REG_W32(ANA_ANCTL_RX_FREQ_ADDR, reg);

    // set the freq synthessy engine
    // 0x1980[31:0] -> freq
    REG_W32(ANA_SYNTH_CAL_CONFIG_0_ADDR, ch);

    // 0x1990[0] ->SYNTH_CAL_TRIGGER
    REG_W32(ANA_SYNTH_CAL_TRIGGER_ADDR, ENABLE);

    
#ifdef WORKAROUND_490MHZ
    if (ch == 490000000UL) {
        TPM_INFO_TBL tpm_tbl_490mhz;
        printf("490 special: \n");
     
        if (!init_tpm_tbl_490mhz(&tpm_tbl_490mhz, cur_dr_idx, cur_mod_idx)) {
            printf("init_tpm_tbl_490mhz fail \n");
            return;
        }

        //0x1994
        REG_W32(0x40011994, PACK_CFG(tpm_tbl_490mhz.div_int_if, tpm_tbl_490mhz.div_frac_if));

        //0x1998
        REG_W32(0x40011998, PACK_CFG(tpm_tbl_490mhz.div_int_hb, tpm_tbl_490mhz.div_frac_hb));

        //0x199C
        REG_W32(0x4001199C, PACK_CFG(tpm_tbl_490mhz.div_int_lb, tpm_tbl_490mhz.div_frac_lb));
        

        //0x1394[15] = 0
        reg = REG_R32(ANA_FREQSYNTH_CONFIG_6_ADDR);
        reg = (reg & ~ANA_FS_BANDSEL_MASK);
        REG_W32(ANA_FREQSYNTH_CONFIG_6_ADDR, reg);
        
    }
#endif
}

uint32_t ana_get_ch_freq_er81xx(RADIO_RX_INFO_T *rx_info)
{
    uint32_t ch_freq = REG_R32(ANA_SYNTH_CAL_CONFIG_0_ADDR);

    rx_info->rx_meta.channel = ch_freq;

    return ch_freq;
}

void ana_set_synth_cal_if_er81xx(uint32_t data_rate)
{
    // NOTE:: this setting will be included in the synthesizer's computation process
    uint32_t reg = 0;
    uint32_t lo;

    switch (data_rate) {
    case DATA_RATE_1M:
        lo = ANA_LO_750K;
        break;
    case DATA_RATE_500K:
        lo = ANA_LO_500K;
        break;
    case DATA_RATE_250K:
    case DATA_RATE_200K:
    case DATA_RATE_125K:
    case DATA_RATE_100K:
    case DATA_RATE_50K:
    case DATA_RATE_12P5K:
    default:
        lo = ANA_LO_250K;
        break;
    }

    // reg 0x198C
    reg = REG_R32(ANA_SYNTH_CAL_CONFIG_3_ADDR);
    reg = (reg & ~ANA_SYNTH_CAL_IF_FREQ_MASK) | 
          ((lo << ANA_SYNTH_CAL_IF_FREQ_POS) & ANA_SYNTH_CAL_IF_FREQ_MASK);
    REG_W32(ANA_SYNTH_CAL_CONFIG_3_ADDR, reg);

#ifdef WORKAROUND_490MHZ
    cur_dr_idx = _get_data_rate_idx(data_rate);
#endif
}

void ana_set_adc_clk_er8130(uint8_t phy_mode, uint32_t data_rate)
{
    uint32_t reg     = 0;
    uint32_t clk_div = 0;
    
    // Handle MBUS mode clock selection
    if (phy_mode == PHY_MODE_MBUS) {
        switch (data_rate) {
            case DATA_RATE_4P8K:
            case DATA_RATE_32P768K:
            case DATA_RATE_50K:
                clk_div = ADC_CLK_4M;
                break;
            case DATA_RATE_100K:
            default:
                clk_div = ADC_CLK_8M;
                break;
        }
    } else {
        // Handle non-MBUS mode clock selection based on data rate
        switch (data_rate) {
            case DATA_RATE_1M:
            case DATA_RATE_500K:
            case DATA_RATE_250K:
            case DATA_RATE_200K:
            case DATA_RATE_125K:
            case DATA_RATE_100K:
            case DATA_RATE_50K:
            case DATA_RATE_12P5K:
                clk_div = ADC_CLK_8M;
                break;

            default:
                clk_div = ADC_CLK_8M;
                break;
        }
    }
    
    // Update ADC clock divider register (0x40011180)
    reg = REG_R32(ANA_CTQBPSD_CONFIG_1_ADDR);
    reg = (reg & ~ANA_DASARADC_DIV_N_MASK) | 
          ((clk_div << ANA_DASARADC_DIV_N_POS) & ANA_DASARADC_DIV_N_MASK);
    REG_W32(ANA_CTQBPSD_CONFIG_1_ADDR, reg);
}

void ana_set_charge_pump_er81xx(uint8_t phy_mode, uint32_t data_rate)
{
    uint32_t reg      = 0;
    uint32_t cp_ictrl = 0;

    if (phy_mode == PHY_MODE_MBUS) {
        return;
    }

    switch (data_rate) {
    case DATA_RATE_1M:
    case DATA_RATE_500K:
    case DATA_RATE_250K:
    case DATA_RATE_200K:
    case DATA_RATE_125K:
    case DATA_RATE_100K:
    case DATA_RATE_50K:
    case DATA_RATE_12P5K:
        cp_ictrl = 4;
        break;
    default:
        cp_ictrl = 4;
        break;
    }
    // reg 0x40011384
    reg = REG_R32(ANA_FREQSYNTH_CONFIG_2_ADDR);
    reg = (reg & ~ANA_FS_CP_ICTRL_MASK) | 
          ((cp_ictrl << ANA_FS_CP_ICTRL_POS) & ANA_FS_CP_ICTRL_MASK);
    REG_W32(ANA_FREQSYNTH_CONFIG_2_ADDR, reg);
}

void ana_set_rx_data_rate_er81xx(uint8_t phy_mode, uint32_t data_rate)
{
    uint32_t reg = 0;

    // set rx data rate
    reg = REG_R32(ANA_SYNTH_CAL_RX_BIT_RATE_ADDR);
    reg = (reg & ~ANA_SYNTH_CAL_RX_BIT_RATE_MASK) | 
          ((data_rate << ANA_SYNTH_CAL_RX_BIT_RATE_POS) & ANA_SYNTH_CAL_RX_BIT_RATE_MASK);
    REG_W32(ANA_SYNTH_CAL_RX_BIT_RATE_ADDR, reg);

    ana_set_synth_cal_if_er81xx(data_rate);
}

uint32_t ana_get_data_rate_er81xx(void)
{
    return REG_R32(ANA_SYNTH_CAL_CONFIG_2_ADDR);
}

void ana_set_mod_type_er81xx(uint32_t mod_type)
{
    uint32_t reg = 0;
    uint32_t mod_id = 0;

    //0x1E04[7:5]
    switch(mod_type) {
    case MOD_TYPE_BPSK:
        mod_id = 0x0;
        break;
    case MOD_TYPE_QPSK:
        mod_id = 0x1;
        break;
    case MOD_TYPE_OQPSK:
        mod_id = 0x2;
        break;
    case MOD_TYPE_FSK:
    case MOD_TYPE_GFSK:
        mod_id = 0x3;
        break;
    case MOD_TYPE_4FSK:
        mod_id = 0x4;
        break;
    case MOD_TYPE_BPSK_RAMP:
        mod_id = 0x5;
        break;
    case MOD_TYPE_OOK:
        printf("er8130_tc01 did not support OOK\n");
        //mod_id = 0x0;
        break;
    default:
        //FSK as default 
        mod_id = 0x3;
        break;
    }

    // ANCTL_CONFIG_1 (0xE04)
    reg = REG_R32(ANA_ANCTL_TX_MOD_ADDR);
    reg = (reg & ~ANA_ANCTL_TX_MOD_MASK) | 
          ((mod_id << ANA_ANCTL_TX_MOD_POS) & ANA_ANCTL_TX_MOD_MASK);
    REG_W32(ANA_ANCTL_TX_MOD_ADDR, reg);
}

void ana_set_tpm_cal_er81xx(uint32_t mod_type, uint32_t data_rate)
{
    uint32_t reg = 0; 
    uint32_t enable = 1;

    //0x1E04
    reg = REG_R32(ANA_ANCTL_TPM_CAL_EN_ADDR);
    reg = (reg & ~ANA_ANCTL_TPM_CAL_EN_MASK) | 
          ((enable << ANA_ANCTL_TPM_CAL_EN_POS) & ANA_ANCTL_TPM_CAL_EN_MASK);
    REG_W32(ANA_ANCTL_TPM_CAL_EN_ADDR, reg);
}


void ana_set_tpm_dmi_er81xx(uint8_t phy_mode, uint32_t mod_type, uint32_t data_rate)
{
    uint32_t reg = 0;
    uint32_t tx_fs_parm;

    uint8_t gsf_en                = 0;
    uint8_t tpm_dmi_en            = 0;
    uint8_t dpm_en                = 0;
    uint8_t dpm_mode              = 0;
    uint8_t single_bit_en         = 0;
    uint8_t pwr_ctl_phase_sensing = 0;
    uint8_t pwr_ctl_en            = 0;

    switch (mod_type) {
    case MOD_TYPE_OOK:
    case MOD_TYPE_FSK:
        gsf_en                = 0;
        tpm_dmi_en            = 1;
        dpm_en                = 0;
        dpm_mode              = 0;
        single_bit_en         = 1;
        pwr_ctl_phase_sensing = 1;
        pwr_ctl_en            = 0;
        break;
        
    case MOD_TYPE_GFSK:
        gsf_en                = 1;
        tpm_dmi_en            = 1;
        dpm_en                = 0;
        dpm_mode              = 0;
        single_bit_en         = 1;
        pwr_ctl_phase_sensing = 1;
        pwr_ctl_en            = 0;

        break;

    case MOD_TYPE_BPSK:
        gsf_en                = 0;
        tpm_dmi_en            = 1;
        dpm_en                = 1;
        dpm_mode              = 0;
        single_bit_en         = 1;
        pwr_ctl_phase_sensing = 1;
        pwr_ctl_en            = 0;

        break;

    case MOD_TYPE_BPSK_RAMP:
        gsf_en                = 0;
        tpm_dmi_en            = 1;
        dpm_en                = 0;
        dpm_mode              = 0;
        single_bit_en         = 1;
        pwr_ctl_phase_sensing = 1;
        pwr_ctl_en            = 0;

        break;

    default:
        printf("did not support mod_type = %ld\n", mod_type);

        break;
    }

    // only GFSK & BPSK
    if (mod_type == MOD_TYPE_GFSK) {
        tx_fs_parm = ANA_CLK / (data_rate * 10);
    } else if (mod_type == MOD_TYPE_BPSK) {
        tx_fs_parm = ANA_CLK / (data_rate * 20);
    } else {
        tx_fs_parm = ANA_CLK / (data_rate * 10);
    }

#ifdef WORKAROUND_WMBUS
    if (phy_mode == PHY_MODE_MBUS) {
        //force TPM_DMI sampling frequency parameter = 4
        tx_fs_parm = 4;
        //force [27:25]"ANCTL_TX_STRWPROD" & [30:28]"ANCTL_TX_ENDWPROD" = 0x0
        REG_W32(0x40011E0C, 0x000000E4);
    }
#endif

    ana_para.tx_fs_parm = tx_fs_parm;

    // set fs parm (0x13B0)
    reg = REG_R32(ANA_TPM_DMI_FS_PARM_ADDR);
    reg = (reg & ~ANA_TPM_DMI_FS_PARM_MASK) | 
          ((ana_para.tx_fs_parm << ANA_TPM_DMI_FS_PARM_POS) & ANA_TPM_DMI_FS_PARM_MASK);
    REG_W32(ANA_TPM_DMI_FS_PARM_ADDR, reg);

    // TPM_DMI_CONFIG_1 (0x3B0)
    reg = REG_R32(ANA_TPM_DMI_CONFIG_1_ADDR);
    reg = (reg & ~(ANA_TPM_DMI_GSF_EN_MASK + ANA_TPM_DMI_EN_MASK + ANA_TPM_DMI_DPM_EN_MASK + ANA_TPM_DMI_DPM_MODE_MASK +
                   ANA_TPM_DMI_SINGLE_BIT_MODE_MASK + ANA_TPM_DMI_DPM_PWRCTL_PHASE_SENSING_MASK + ANA_TPM_DMI_DPM_PWRCTL_EN_MASK)) |
          ((gsf_en << ANA_TPM_DMI_GSF_EN_POS) & ANA_TPM_DMI_GSF_EN_MASK) | 
          ((tpm_dmi_en << ANA_TPM_DMI_EN_POS) & ANA_TPM_DMI_EN_MASK) |
          ((dpm_en << ANA_TPM_DMI_DPM_EN_POS) & ANA_TPM_DMI_DPM_EN_MASK) | 
          ((dpm_mode << ANA_TPM_DMI_DPM_MODE_POS) & ANA_TPM_DMI_DPM_MODE_MASK) |
          ((single_bit_en << ANA_TPM_DMI_SINGLE_BIT_MODE_POS) & ANA_TPM_DMI_SINGLE_BIT_MODE_MASK) |
          ((pwr_ctl_phase_sensing << ANA_TPM_DMI_DPM_PWRCTL_PHASE_SENSING_POS) & ANA_TPM_DMI_DPM_PWRCTL_PHASE_SENSING_MASK) |
          ((pwr_ctl_en << ANA_TPM_DMI_DPM_PWRCTL_EN_POS) & ANA_TPM_DMI_DPM_PWRCTL_EN_MASK);
    REG_W32(ANA_TPM_DMI_CONFIG_1_ADDR, reg);
}

void ana_set_rx_gain_er81xx(void)
{
    (void)ana_gain_def;
#if 0
    uint32_t gn_reg;

    // RX_GAIN_FILTSET (0x1604)
    gn_reg = REG_R32(ANA_RX_LNA_GAIN_ADDR);
    gn_reg =
        (gn_reg & ~(ANA_RX_LNA_GAIN_MASK + ANA_RX_MIX_GAIN_MASK +
                    ANA_RX_FILTGAIN_MASK + ANA_RX_PGAGAIN_MASK)) |
        ((ana_gain_def.lna << ANA_RX_LNA_GAIN_POS) & ANA_RX_LNA_GAIN_MASK) |
        ((ana_gain_def.mix << ANA_RX_MIX_GAIN_POS) & ANA_RX_MIX_GAIN_MASK) |
        ((ana_gain_def.filt << ANA_RX_FILTGAIN_POS) & ANA_RX_FILTGAIN_MASK) |
        ((ana_gain_def.pga << ANA_RX_PGAGAIN_POS) & ANA_RX_PGAGAIN_MASK);
    REG_W32(ANA_RX_LNA_GAIN_ADDR, gn_reg);
#endif
}

void ana_set_rx_filt_er81xx(uint8_t phy_mode, uint32_t data_rate, uint8_t mod_idx)
{
    uint32_t reg;
    uint32_t mask = (ANA_RX_FILTIFEN_MASK + ANA_RX_FILTIFRESSEL_MASK + ANA_RX_FILTCAPSEL_MASK + ANA_RX_FILTCAPCAL_MASK + ANA_RX_FILTIFRESVALUE_MASK);
    struct ana_filt_t *filt = NULL;

    if (phy_mode == PHY_MODE_MBUS) {
        switch (data_rate) {
        case DATA_RATE_100K:
            filt = &ana_filt_mbus_100k;
            break;
        case DATA_RATE_32P768K:
            filt = &ana_filt_mbus_32p768kk;
            break;
        case DATA_RATE_4P8K:
            filt = &ana_filt_mbus_4p8k;
            break;
        default:
            filt = &ana_filt_mbus_100k;
            break;
        }
    } else {
        switch (data_rate) {
        case DATA_RATE_2M:
        case DATA_RATE_1M:
            filt = &ana_filt_def_1m[mod_idx];
            break;

        case DATA_RATE_500K:
            filt = &ana_filt_def_500k[mod_idx];
            break;

        case DATA_RATE_250K:
            filt = &ana_filt_def_250k[mod_idx];
            break;

        case DATA_RATE_200K:
        case DATA_RATE_125K:
        case DATA_RATE_100K:
        case DATA_RATE_50K:
        case DATA_RATE_12P5K:
            filt = &ana_filt_def_other[mod_idx];
            break;
        }
    }
    // filter calibration mode select
    //    reg =
    //        (REG_R32(ANA_RX_FILTCAPCAL_MODE_ADDR) & ~ANA_RX_FILTCAPCAL_MODE_MASK) |
    //        ((filt->filt_cal << ANA_RX_FILTCAPCAL_MODE_POS) &
    //         ANA_RX_FILTCAPCAL_MODE_MASK);
    //    REG_W32(ANA_RX_FILTCAPCAL_MODE_ADDR, reg);

    // filter setting
    reg = (REG_R32(ANA_RX_GAIN_FILTSET_ADDR) & ~mask) | 
          ((filt->filt_en << ANA_RX_FILTIFEN_POS) & ANA_RX_FILTIFEN_MASK) |
          ((filt->freq_sel << ANA_RX_FILTIFRESSEL_POS) & ANA_RX_FILTIFRESSEL_MASK) |
          ((filt->cap_sel << ANA_RX_FILTCAPSEL_POS) & ANA_RX_FILTCAPSEL_MASK) | 
          ((15 << ANA_RX_FILTCAPCAL_POS) & ANA_RX_FILTCAPCAL_MASK) |
          ((17 << ANA_RX_FILTIFRESVALUE_POS) & ANA_RX_FILTIFRESVALUE_MASK);
    REG_W32(ANA_RX_FILTIFRESSEL_ADDR, reg);
}

void ana_set_ctrl_mode_er81xx(uint8_t ctrl_mode)
{
    uint32_t cfg;

    cfg = REG_R32(ANA_ANCTL_CONFIG_0_ADDR);

    switch (ctrl_mode) {
    case CTRL_MODE_MANUAL:
        cfg &= (~(ANA_ANCTL_SEL_CTL_MASK + ANA_ANCTL_OSC_SEL_CTL_MASK + ANA_ANCTL_RX_SEL_CTL_MASK));
        break;
    case CTRL_MODE_AUTO:
        cfg |= (ANA_ANCTL_SEL_CTL_MASK + ANA_ANCTL_OSC_SEL_CTL_MASK + ANA_ANCTL_RX_SEL_CTL_MASK);
        break;
    default:
        printf("[error!] ctrl_mode did not support: %d", ctrl_mode);
        cfg |= (ANA_ANCTL_SEL_CTL_MASK + ANA_ANCTL_OSC_SEL_CTL_MASK + ANA_ANCTL_RX_SEL_CTL_MASK);
    }

    REG_W32(ANA_ANCTL_CONFIG_0_ADDR, cfg);
}

void ana_set_gain_src_er81xx(uint8_t gain_src)
{
    uint32_t cfg;

    // 0x1e3c
    cfg = REG_R32(ANA_ANCTL_GAIN_SEL_BBP_ADDR);
    cfg = (cfg & ~(ANA_ANCTL_GAIN_SEL_BBP_MASK + ANA_ANCTL_SEL_RX_FORCELNAGAIN_MASK + ANA_ANCTL_SEL_RX_RFAGC_HALT_MASK));

    if (gain_src == ANA_GAIN_SRC_BBP) {
        cfg |= (ANA_ANCTL_GAIN_SEL_BBP_MASK + ANA_ANCTL_SEL_RX_FORCELNAGAIN_MASK + ANA_ANCTL_SEL_RX_RFAGC_HALT_MASK);
    }

    REG_W32(ANA_ANCTL_GAIN_SEL_BBP_ADDR, cfg);
}

IQK_BACKUP *iqk_bk_info_er81xx = NULL;
void ana_set_iqk_cfg_er81xx(IQK_MODE mode)
{
    iqk_bk_info_er81xx = malloc(sizeof(IQK_BACKUP));

    uint32_t cfg;
    uint8_t rx_1g_cal_src_en = 1;
    uint8_t iq_en            = 1;

    uint8_t lan_gain  = 1;
    uint8_t mix_gain  = 3;
    uint8_t filt_gain = 7;
    uint8_t pga_gain  = 4;

    uint8_t rx_time_str         = 3;
    uint8_t rx_time_ldcap       = 3;
    uint8_t rx_time_adc_warm_up = 7;

    // uint8_t iqk_hang = 1;

    // 0x1600[22]
    cfg                             = REG_R32(ANA_RX_1GCALSOURCE_EN_ADDR);
    iqk_bk_info_er81xx->rx_pwr_para = cfg;
    cfg = (cfg & ~ANA_RX_1GCALSOURCE_EN_MASK) | 
          ((rx_1g_cal_src_en << ANA_RX_1GCALSOURCE_EN_POS) & ANA_RX_1GCALSOURCE_EN_MASK);
    REG_W32(ANA_RX_1GCALSOURCE_EN_ADDR, cfg);

    // switch gain src to ANA
    ana_set_gain_src_er81xx(ANA_GAIN_SRC_CSR);

    // 0x1604
    // set best gain for iqk & set rf rx filter to max width
    cfg = REG_R32(ANA_RX_GAIN_FILTSET_ADDR);
    iqk_bk_info_er81xx->rx_filter_para = cfg;
    cfg = (cfg & ~(ANA_RX_LNA_GAIN_MASK + ANA_RX_MIX_GAIN_MASK + ANA_RX_FILTGAIN_MASK + ANA_RX_PGAGAIN_MASK)) |
          ((lan_gain << ANA_RX_LNA_GAIN_POS) & ANA_RX_LNA_GAIN_MASK) | 
          ((mix_gain << ANA_RX_MIX_GAIN_POS) & ANA_RX_MIX_GAIN_MASK) |
          ((filt_gain << ANA_RX_FILTGAIN_POS) & ANA_RX_FILTGAIN_MASK) | 
          ((pga_gain << ANA_RX_PGAGAIN_POS) & ANA_RX_PGAGAIN_MASK);
    REG_W32(ANA_RX_GAIN_FILTSET_ADDR, cfg);

    // 0x1E3C
    cfg = REG_R32(ANA_ANCTL_BBP_IQCAL_EN_ADDR);
    cfg = (cfg & ~ANA_ANCTL_BBP_IQCAL_EN_MASK) | 
          ((iq_en << ANA_ANCTL_BBP_IQCAL_EN_POS) & ANA_ANCTL_BBP_IQCAL_EN_MASK);
    REG_W32(ANA_ANCTL_BBP_IQCAL_EN_ADDR, cfg);

    // 0x1E18 max settle time for iqk
    cfg = REG_R32(ANA_ANCTL_CONFIG_6_ADDR);
    iqk_bk_info_er81xx->rx_mac_time_para = cfg;
    cfg = (cfg & ~(ANA_ANCTL_RX_TIM_STR_MASK + ANA_ANCTL_RX_TIM_LDCAP_MASK + ANA_ANCTL_RX_TIM_ADCWARMUP_MASK)) |
          ((rx_time_str << ANA_ANCTL_RX_TIM_STR_POS) & ANA_ANCTL_RX_TIM_STR_MASK) |
          ((rx_time_ldcap << ANA_ANCTL_RX_TIM_LDCAP_POS) & ANA_ANCTL_RX_TIM_LDCAP_MASK) |
          ((rx_time_adc_warm_up << ANA_ANCTL_RX_TIM_ADCWARMUP_POS) & ANA_ANCTL_RX_TIM_ADCWARMUP_MASK);
    REG_W32(ANA_ANCTL_CONFIG_6_ADDR, cfg);

    if (mode == IQK_MODE_MANUAL) {
#if 0 
      // er81xx did not support manual mode iqk                                
      // 0x1EF8
        cfg = REG_R32(ana, ANA_ANCTL_BBP_IQCAL_HANG_ADDR);
        cfg = (cfg & ~ANA_ANCTL_BBP_IQCAL_HANG_MASK) |
              ((iqk_hang << ANA_ANCTL_BBP_IQCAL_HANG_POS)&ANA_ANCTL_BBP_IQCAL_HANG_MASK);
        REG_W32(ana, ANA_ANCTL_BBP_IQCAL_HANG_ADDR, iqk_hang);
#endif
    }
}

void ana_clean_iqk_cfg_er81xx(IQK_MODE mode)
{
    // uint32_t cfg;
    // uint8_t iqk_hang = 0;

    if (mode == IQK_MODE_MANUAL) {
#if 0 
      // er81xx did not support manual mode iqk                                
      // 0x1EF8
        cfg = REG_R32(ana, ANA_ANCTL_BBP_IQCAL_HANG_ADDR);
        cfg = (cfg & ~ANA_ANCTL_BBP_IQCAL_HANG_MASK) |
              ((iqk_hang << ANA_ANCTL_BBP_IQCAL_HANG_POS)&ANA_ANCTL_BBP_IQCAL_HANG_MASK);
        REG_W32(ana, ANA_ANCTL_BBP_IQCAL_HANG_ADDR, iqk_hang);
#endif
    }

    REG_W32(ANA_RX_POWSET_ADDR, iqk_bk_info_er81xx->rx_pwr_para);
    REG_W32(ANA_RX_FILTIFRESSEL_ADDR, iqk_bk_info_er81xx->rx_filter_para);
    REG_W32(ANA_ANCTL_CONFIG_6_ADDR, iqk_bk_info_er81xx->rx_mac_time_para);

    // switch gain src to BBP
    ana_set_gain_src_er81xx(ANA_GAIN_SRC_BBP);

    free(iqk_bk_info_er81xx);
}

void ana_set_pa_pwr_tbl_er81xx(uint32_t mod_type)
{
    uint32_t i;
    uint8_t pwr_step_num = 0;

    switch (mod_type) {
    case MOD_TYPE_OOK:
    case MOD_TYPE_FSK:
    case MOD_TYPE_GFSK:
        pwr_step_num = sizeof(fsk_pa_pwr_tbl) / sizeof(fsk_pa_pwr_tbl[0]);

        for (i = 0; i < pwr_step_num; i++) {
            REG_W32(ANA_ANCTL_PWR01_ADDR + (i * 4), fsk_pa_pwr_tbl[i]);
        }

        break;

    case MOD_TYPE_BPSK:
        pwr_step_num = sizeof(bpsk_pa_pwr_tbl) / sizeof(bpsk_pa_pwr_tbl[0]);

        for (i = 0; i < pwr_step_num; i++) {
            REG_W32(ANA_ANCTL_PWR01_ADDR + (i * 4), bpsk_pa_pwr_tbl[i] * 3);
        }

        break;

    case MOD_TYPE_BPSK_RAMP:
        pwr_step_num = sizeof(bpsk_ramp_pa_pwr_tbl) / sizeof(bpsk_ramp_pa_pwr_tbl[0]);

        for (i = 0; i < pwr_step_num; i++) {
            REG_W32(ANA_ANCTL_PWR01_ADDR + (i * 4), bpsk_ramp_pa_pwr_tbl[i]);
        }

        break;

    default:
        printf("%s: pa pwr arr did not support mod_type = %ld\n", __func__, mod_type);
        break;
    }
}

void ana_set_basic_cfg_er81xx(void)
{
    uint32_t i = 0, cfg_len;

    cfg_len = sizeof(ana_setup_arr) / sizeof(ana_setup_arr[0]);

    for (i = 0; i < cfg_len; i += 2) {
        REG_W32(ana_setup_arr[i], ana_setup_arr[i + 1]);
    }
}

void ana_set_xtal_gain_ctrl_er81xx(uint8_t val)
{
    uint32_t reg;

    //0x1580[7:4] = gain_ctrl
    reg  = REG_R32(ANA_XO_CONFIG_1_ADDR); 
    reg  = (reg & ~(ANA_XO_40M_GAIN_CTRL_MASK)) |
           (((val << ANA_XO_40M_GAIN_CTRL_POS) & ANA_XO_40M_GAIN_CTRL_MASK));
    REG_W32(ANA_XO_CONFIG_1_ADDR, reg);
}

void ana_set_xtal_cfg_er81xx(void)
{
    uint32_t reg;
    uint32_t xtal_cfg = hal_drv_sys_get_xtal_cfg();
    uint8_t xtal_i = (xtal_cfg&0xFFFF);
    uint8_t xtal_o = ((xtal_cfg>>16)&0xFFFF);

    //0x1580[7:4] = gain_ctrl
    //0x1580[14:8] = xtal_i
    //0x1580[21:15] = xtal_o
    reg  = REG_R32(ANA_XO_CONFIG_1_ADDR); 
    reg  = (reg & ~(ANA_XO_40M_CAP_I_CTRL_MASK + ANA_XO_40M_CAP_O_CTRL_MASK)) |
           (((xtal_i << ANA_XO_40M_CAP_I_CTRL_POS) & ANA_XO_40M_CAP_I_CTRL_MASK)) |
           (((xtal_o << ANA_XO_40M_CAP_O_CTRL_POS) & ANA_XO_40M_CAP_O_CTRL_MASK));
    REG_W32(ANA_XO_CONFIG_1_ADDR, reg);
}


void _set_dcdc_hi_para(uint8_t mat_type, ANCTL_DCDC_PARA *dcdc_para)
{
    switch(mat_type) {
    case BOARD_MATCHING_915MHZ:
        //(0x1204)
        dcdc_para->en_random12  = 0;
        dcdc_para->en_ipn       = 3;
        //(0xE5C)
        dcdc_para->tar_idle     = 0;
        dcdc_para->tar_tx_1g    = 0;
        dcdc_para->tar_rx_1g    = 0;
        dcdc_para->tar_tx_2g    = 0;
        dcdc_para->tar_rx_2g    = 0;
        //(0xE60)
        dcdc_para->ldo_sel_rx   = 0;
        dcdc_para->ldo_sel_tx   = 1;
        //(0xE64)
        dcdc_para->iqbuf_rx     = 3; //default value
        dcdc_para->iqbuf_tx     = 1;
        dcdc_para->fs_cp_tx     = 4;
        dcdc_para->fs_cp_rx     = 4;
        break;
    case BOARD_MATCHING_868MHZ:
        //(0x1204)
        dcdc_para->en_random12  = 0;
        dcdc_para->en_ipn       = 3;

        //(0xE5C)
        dcdc_para->tar_idle     = 0;
        dcdc_para->tar_tx_1g    = 0;
        dcdc_para->tar_rx_1g    = 0;
        dcdc_para->tar_tx_2g    = 0;
        dcdc_para->tar_rx_2g    = 0;
        //(0xE60)
        dcdc_para->ldo_sel_rx   = 0;
        dcdc_para->ldo_sel_tx   = 1;
        //(0xE64)
        dcdc_para->iqbuf_rx     = 3; //default value
        dcdc_para->iqbuf_tx     = 1;
        dcdc_para->fs_cp_tx     = 4;
        dcdc_para->fs_cp_rx     = 4; 
        break;
    case BOARD_MATCHING_490MHZ:
        //(0x1204)
        dcdc_para->en_random12  = 0;
        dcdc_para->en_ipn       = 3;

        //(0xE5C)
        dcdc_para->tar_idle     = 0;
        dcdc_para->tar_tx_1g    = 0;
        dcdc_para->tar_rx_1g    = 0;
        dcdc_para->tar_tx_2g    = 0;
        dcdc_para->tar_rx_2g    = 0;
        //(0xE60)
        dcdc_para->ldo_sel_rx   = 0;
        dcdc_para->ldo_sel_tx   = 0;
        //(0xE64)
        dcdc_para->iqbuf_rx     = 3; //default value
        dcdc_para->iqbuf_tx     = 1;
        dcdc_para->fs_cp_tx     = 4;
        dcdc_para->fs_cp_rx     = 4;
        break;
    default:
        printf("%s : mat_type is bad : %d\n", __func__, mat_type);
        break;
    }

}

void _set_dcdc_low_para(uint8_t mat_type, ANCTL_DCDC_PARA *dcdc_para)
{
    switch(mat_type) {
    case BOARD_MATCHING_915MHZ:
        //(0x1204)
        dcdc_para->en_random12  = 0;
        dcdc_para->en_ipn       = 2;
    
        //(0xE5C)
        dcdc_para->tar_idle     = 1;
        dcdc_para->tar_tx_1g    = 1;
        dcdc_para->tar_rx_1g    = 1;
        dcdc_para->tar_tx_2g    = 0;
        dcdc_para->tar_rx_2g    = 0;
        //(0xE60)
        dcdc_para->ldo_sel_rx   = 0;
        dcdc_para->ldo_sel_tx   = 0;
        //(0xE64)
        dcdc_para->iqbuf_rx     = 0; //default value
        dcdc_para->iqbuf_tx     = 1;
        dcdc_para->fs_cp_tx     = 4; 
        dcdc_para->fs_cp_rx     = 4;
        break;
    case BOARD_MATCHING_868MHZ:
        //(0x1204)
        dcdc_para->en_random12  = 0;
        dcdc_para->en_ipn       = 2;
    
        //(0xE5C)
        dcdc_para->tar_idle     = 1;
        dcdc_para->tar_tx_1g    = 1;
        dcdc_para->tar_rx_1g    = 1;
        dcdc_para->tar_tx_2g    = 0;
        dcdc_para->tar_rx_2g    = 0;
        //(0xE60)
        dcdc_para->ldo_sel_rx   = 0;
        dcdc_para->ldo_sel_tx   = 0;
        //(0xE64)
        dcdc_para->iqbuf_rx     = 3; //default value
        dcdc_para->iqbuf_tx     = 1;
        dcdc_para->fs_cp_tx     = 4;
        dcdc_para->fs_cp_rx     = 4;
        break;
    case BOARD_MATCHING_490MHZ:
        //(0x1204)
        dcdc_para->en_random12  = 0;
        dcdc_para->en_ipn       = 2;
    
        //(0xE5C)
        dcdc_para->tar_idle     = 1;
        dcdc_para->tar_tx_1g    = 1;
        dcdc_para->tar_rx_1g    = 1;
        dcdc_para->tar_tx_2g    = 0;
        dcdc_para->tar_rx_2g    = 0;
        //(0xE60)
        dcdc_para->ldo_sel_rx   = 0;
        dcdc_para->ldo_sel_tx   = 0;
        //(0xE64)
        dcdc_para->iqbuf_rx     = 3; //default value
        dcdc_para->iqbuf_tx     = 1;
        dcdc_para->fs_cp_tx     = 4;
        dcdc_para->fs_cp_rx     = 4;
        break;
    default:
        printf("%s : mat_type is bad : %d\n", __func__, mat_type);
        break;
    }
}

void ana_set_dcdc_default_val_er81xx(void)
{
    uint32_t cfg;
    uint8_t en1p5 = 0;
    uint8_t sw12 = 3;
    uint8_t random = 0;
    uint8_t ipn_en = 1;

    // ANA_DCDC_CONFIG_1_ADDR (0x1200)
    cfg = REG_R32(ANA_DCDC_CONFIG_0_ADDR);
    cfg = (cfg & ~(ANA_DCDC_EN1P5_MASK)) |
          ((en1p5 << ANA_DCDC_EN1P5_POS) & ANA_DCDC_EN1P5_MASK);
    REG_W32(ANA_DCDC_CONFIG_0_ADDR, cfg);
    
    // ANA_DCDC_CONFIG_1_ADDR (0x1204)
    cfg = REG_R32(ANA_DCDC_CONFIG_1_ADDR);
    cfg = (cfg & ~(ANA_DCDC_SW12_F_MASK + ANA_DCDC_EN_RANDOM12_MASK + ANA_DCDC_EN_IPN_MASK)) |
          ((sw12 << ANA_DCDC_SW12_F_POS) & ANA_DCDC_SW12_F_MASK)|
          ((random << ANA_DCDC_EN_RANDOM12_POS) & ANA_DCDC_EN_RANDOM12_MASK)|
          ((ipn_en << ANA_DCDC_EN_IPN_POS) & ANA_DCDC_EN_IPN_MASK);
    REG_W32(ANA_DCDC_CONFIG_1_ADDR, cfg);
}

void ana_set_dcdc_cfg_er81xx(uint8_t pa_type, uint8_t mat_type)
{
    uint32_t cfg;
    ANCTL_DCDC_PARA dcdc_para;
    
    switch (pa_type) {
    case PA_TYPE_HI: 
        // pa hi = dcdc low cur setting
        _set_dcdc_hi_para(mat_type, &dcdc_para);
        break;
    case PA_TYPE_LOW:
        // pa low = dadc hi cur setting
        _set_dcdc_low_para(mat_type, &dcdc_para);
        break;
    default:
        _set_dcdc_hi_para(mat_type, &dcdc_para);
        printf("%s: pa_type is wrong \n", __func__);
        break;
    
    }

    // ANA_DCDC_CONFIG_1_ADDR (0x1204)
    cfg = REG_R32(ANA_DCDC_CONFIG_1_ADDR);
    cfg = (cfg & ~(ANA_DCDC_EN_RANDOM12_MASK + ANA_DCDC_EN_IPN_MASK)) |
          ((dcdc_para.en_random12 << ANA_DCDC_EN_RANDOM12_POS) & ANA_DCDC_EN_RANDOM12_MASK) |
          ((dcdc_para.en_ipn << ANA_DCDC_EN_IPN_POS) & ANA_DCDC_EN_IPN_MASK);
    REG_W32(ANA_DCDC_CONFIG_1_ADDR, cfg);

    // ANCTL_DCDC_REG3 (0x1E5C)
    cfg = REG_R32(ANA_ANCTL_DCDC_REG3_ADDR);
    cfg = (cfg & ~(ANA_ANCTL_DCDC_TAR_IDLE_MASK + ANA_ANCTL_DCDC_TAR_TX_1G_MASK + ANA_ANCTL_DCDC_TAR_RX_1G_MASK + ANA_ANCTL_DCDC_TAR_TX_2G_MASK +
                   ANA_ANCTL_DCDC_TAR_RX_2G_MASK)) |
          ((dcdc_para.tar_idle << ANA_ANCTL_DCDC_TAR_IDLE_POS) & ANA_ANCTL_DCDC_TAR_IDLE_MASK) |
          ((dcdc_para.tar_tx_1g << ANA_ANCTL_DCDC_TAR_TX_1G_POS) & ANA_ANCTL_DCDC_TAR_TX_1G_MASK) |
          ((dcdc_para.tar_rx_1g << ANA_ANCTL_DCDC_TAR_RX_1G_POS) & ANA_ANCTL_DCDC_TAR_RX_1G_MASK) |
          ((dcdc_para.tar_tx_2g << ANA_ANCTL_DCDC_TAR_TX_2G_POS) & ANA_ANCTL_DCDC_TAR_TX_2G_MASK) |
          ((dcdc_para.tar_rx_2g << ANA_ANCTL_DCDC_TAR_RX_2G_POS) & ANA_ANCTL_DCDC_TAR_RX_2G_MASK);
    REG_W32(ANA_ANCTL_DCDC_REG3_ADDR, cfg);

    // ANCTL_PA1G_REG0 (0x1E60)
    cfg = REG_R32(ANA_ANCTL_RF_LDO_SEL_RX_ADDR);
    cfg = (cfg & ~(ANA_ANCTL_RF_LDO_SEL_RX_MASK + ANA_ANCTL_RF_LDO_SEL_TX_MASK)) |
          ((dcdc_para.ldo_sel_rx << ANA_ANCTL_RF_LDO_SEL_RX_POS) & ANA_ANCTL_RF_LDO_SEL_RX_MASK) |
          ((dcdc_para.ldo_sel_tx << ANA_ANCTL_RF_LDO_SEL_TX_POS) & ANA_ANCTL_RF_LDO_SEL_TX_MASK);
    REG_W32(ANA_ANCTL_RF_LDO_SEL_RX_ADDR, cfg);

    //ANCTL_FS_REG0 (0x1E64)
    cfg = REG_R32(ANA_ANCTL_FS_REG0_ADDR);
    cfg = (cfg & ~(ANA_ANCTL_FS_IQBUF_ICTRL_RX_MASK + ANA_ANCTL_FS_IQBUF_ICTRL_TX_MASK +
                   ANA_ANCTL_FS_CP_ICTRL_TXSET_MASK + ANA_ANCTL_FS_CP_ICTRL_RXSET_MASK)) |
          ((dcdc_para.iqbuf_rx << ANA_ANCTL_FS_IQBUF_ICTRL_RX_POS)&ANA_ANCTL_FS_IQBUF_ICTRL_RX_MASK) |
          ((dcdc_para.iqbuf_tx << ANA_ANCTL_FS_IQBUF_ICTRL_TX_POS)&ANA_ANCTL_FS_IQBUF_ICTRL_TX_MASK) |
          ((dcdc_para.fs_cp_tx << ANA_ANCTL_FS_CP_ICTRL_TXSET_POS)&ANA_ANCTL_FS_CP_ICTRL_TXSET_MASK) |
          ((dcdc_para.fs_cp_rx << ANA_ANCTL_FS_CP_ICTRL_RXSET_POS)&ANA_ANCTL_FS_CP_ICTRL_RXSET_MASK);
    REG_W32(ANA_ANCTL_FS_REG0_ADDR, cfg);

}

static void _set_pa_hi_para(uint8_t mod_type, uint8_t mat_type, uint32_t data_rate, PA_PARA *pa_para)
{
    //general setting
    //(0x480)
    pa_para->pa1g_en = 0;
    //(0x484)
    pa_para->pa1g_ramp_en = 1;

    switch(mat_type) {
    case BOARD_MATCHING_915MHZ:
        // PA1G_CONFIG_0 (0x480)
        pa_para->pa1g_duty_cycle_en = 1;
        pa_para->pa1g_vb_sel        = 1;
        pa_para->pa1g_pwr_lv        = 17;
        pa_para->pa1g_vb2_sel       = 3;
    
        if (mod_type == MOD_TYPE_GFSK || mod_type == MOD_TYPE_OOK) {
            // PA1G_CONFIG_1 (0x484)
            pa_para->pa1g_iref_sel = 2;
            pa_para->pa1g_duty_sel = 7;
            pa_para->pa1g_ramp_sel = 0;
        }
        break;
    case BOARD_MATCHING_868MHZ:
        // PA1G_CONFIG_0 (0x480)
        pa_para->pa1g_duty_cycle_en = 1;
        pa_para->pa1g_vb_sel        = 1;
        pa_para->pa1g_pwr_lv        = 17;
        pa_para->pa1g_vb2_sel       = 3;
    
        if (mod_type == MOD_TYPE_GFSK || mod_type == MOD_TYPE_OOK) {
            // PA1G_CONFIG_1 (0x484)
            pa_para->pa1g_iref_sel = 2;
            pa_para->pa1g_duty_sel = 7;
            pa_para->pa1g_ramp_sel = 0;
        }
        break;
    case BOARD_MATCHING_490MHZ:
        // PA1G_CONFIG_0 (0x480)
        pa_para->pa1g_duty_cycle_en = 1;
        pa_para->pa1g_vb_sel        = 1;
        pa_para->pa1g_pwr_lv        = 21;
        pa_para->pa1g_vb2_sel       = 3;
    
        if (mod_type == MOD_TYPE_GFSK || mod_type == MOD_TYPE_OOK) {
           // PA1G_CONFIG_1 (0x484)
           pa_para->pa1g_iref_sel = 2;
           pa_para->pa1g_duty_sel = 6;
           pa_para->pa1g_ramp_sel = 0;
        }
        break;
    default:
        printf("%s: mat_type is bad %d\n", __func__, mat_type);
        break;    
    }
}

static void _set_pa_low_para(uint8_t mod_type, uint8_t mat_type, uint32_t data_rate, PA_PARA *pa_para)
{
    //general setting
    //(0x1480)
    pa_para->pa1g_en = 0;
    //(0x1484)
    pa_para->pa1g_ramp_en = 1;

    switch(mat_type){
    case BOARD_MATCHING_915MHZ:
        // PA1G_CONFIG_0 (0x480)
        pa_para->pa1g_duty_cycle_en = 1;
        pa_para->pa1g_vb_sel        = 1;
        pa_para->pa1g_pwr_lv        = 17;
        pa_para->pa1g_vb2_sel       = 3;
    
        if (mod_type == MOD_TYPE_GFSK || mod_type == MOD_TYPE_OOK) {
            // PA1G_CONFIG_1 (0x484)
            pa_para->pa1g_iref_sel = 2;
            pa_para->pa1g_duty_sel = 1;
            pa_para->pa1g_ramp_sel = 0;
        }
        break;
    case BOARD_MATCHING_868MHZ:
        // PA1G_CONFIG_0 (0x480)
        pa_para->pa1g_duty_cycle_en = 1;
        pa_para->pa1g_vb_sel        = 1;
        pa_para->pa1g_pwr_lv        = 20;
        pa_para->pa1g_vb2_sel       = 3;
    
        if (mod_type == MOD_TYPE_GFSK || mod_type == MOD_TYPE_OOK) {
            // PA1G_CONFIG_1 (0x484)
            pa_para->pa1g_iref_sel = 2;
            pa_para->pa1g_duty_sel = 6;
            pa_para->pa1g_ramp_sel = 0;
        }
        break;
    case BOARD_MATCHING_490MHZ:
            // PA1G_CONFIG_0 (0x480)
            pa_para->pa1g_duty_cycle_en = 1;
            pa_para->pa1g_vb_sel        = 1;
            pa_para->pa1g_pwr_lv        = 27;
            pa_para->pa1g_vb2_sel       = 3;
        
            if (mod_type == MOD_TYPE_GFSK || mod_type == MOD_TYPE_OOK) {
               // PA1G_CONFIG_1 (0x484)
               pa_para->pa1g_iref_sel = 2;
               pa_para->pa1g_duty_sel = 6;
               pa_para->pa1g_ramp_sel = 0;
            }
        break;
    default:
        printf("%s: mat_type is bad %d\n", __func__, mat_type);
        break;
    }
}

void ana_set_pa_cfg_er81xx(uint8_t pa_type, uint8_t mat_type, uint8_t mod_type, uint32_t data_rate)
{
    uint32_t cfg;
    PA_PARA pa_para = {0};

    switch (pa_type) {
    case PA_TYPE_HI:
        _set_pa_hi_para(mod_type, mat_type, data_rate, &pa_para);
        break;

    case PA_TYPE_LOW:
        _set_pa_low_para(mod_type, mat_type, data_rate, &pa_para);
        break;

    default:
        DBG_PRINT("PA type did not support: default HI PA\n");
        _set_pa_hi_para(mod_type, mat_type, data_rate, &pa_para);
        break;
    }

    // PA1G_CONFIG_0 (0x480)
    cfg = REG_R32(ANA_PA1G_EN_ADDR);
    cfg = (cfg & ~(ANA_PA1G_EN_MASK + ANA_PA1G_DUTY_EN_MASK + ANA_PA1G_VB_DRIVER_SEL_MASK + ANA_PA1G_PWR_MASK + ANA_PA1G_VB2_SEL_MASK)) |
          ((pa_para.pa1g_en << ANA_PA1G_EN_POS) & ANA_PA1G_EN_MASK) | 
          ((pa_para.pa1g_duty_cycle_en << ANA_PA1G_DUTY_EN_POS) & ANA_PA1G_DUTY_EN_MASK) |
          ((pa_para.pa1g_vb_sel << ANA_PA1G_VB_DRIVER_SEL_POS) & ANA_PA1G_VB_DRIVER_SEL_MASK) |
          ((pa_para.pa1g_pwr_lv << ANA_PA1G_PWR_POS) & ANA_PA1G_PWR_MASK) | 
          ((pa_para.pa1g_vb2_sel << ANA_PA1G_VB2_SEL_POS) & ANA_PA1G_VB2_SEL_MASK);
    REG_W32(ANA_PA1G_EN_ADDR, cfg);

    // PA1G_CONFIG_1 (0x484)
    cfg = REG_R32(ANA_PA1G_AMUX_SEL_ADDR);
    cfg = (cfg & ~(ANA_PA1G_IREF_SEL_MASK + ANA_PA1G_DUTY_SEL_MASK + ANA_PA1G_EN_RAMP_MASK + ANA_PA1G_SEL_RAMP_MASK)) |
          ((pa_para.pa1g_iref_sel << ANA_PA1G_IREF_SEL_POS) & ANA_PA1G_IREF_SEL_MASK) |
          ((pa_para.pa1g_duty_sel << ANA_PA1G_DUTY_SEL_POS) & ANA_PA1G_DUTY_SEL_MASK) |
          ((pa_para.pa1g_ramp_en << ANA_PA1G_EN_RAMP_POS) & ANA_PA1G_EN_RAMP_MASK) |
          ((pa_para.pa1g_ramp_sel << ANA_PA1G_SEL_RAMP_POS) & ANA_PA1G_SEL_RAMP_MASK);
    REG_W32(ANA_PA1G_AMUX_SEL_ADDR, cfg);
}

void ana_set_tx_pwr_lv_er81xx(uint8_t mod_type, uint8_t pwr_lv)
{
    uint8_t const_pwr_en;
    uint8_t pwr_const;
    uint32_t cfg;

    switch (mod_type) {
    case MOD_TYPE_OOK:
    case MOD_TYPE_FSK:
    case MOD_TYPE_GFSK:
        // ANCTL_CONFIG_7 (0xE1C)
        const_pwr_en = 1;
        pwr_const    = pwr_lv;

        break;

    case MOD_TYPE_BPSK:
        // ANCTL_CONFIG_7 (0xE1C)
        const_pwr_en = 0;
        pwr_const    = pwr_lv;

        break;

    case MOD_TYPE_BPSK_RAMP:
        // ANCTL_CONFIG_7 (0xE1C)
        const_pwr_en = 0;
        pwr_const    = 0x1;

        break;

    default:
        printf("%s: mod_type did not support\n", __func__);
        // ANCTL_CONFIG_7 (0xE1C)
        const_pwr_en = 1;
        pwr_const    = pwr_lv;

        break;
    }

    // ANCTL_CONFIG_7 (0xE1C)
    cfg = REG_R32(ANA_ANCTL_TX_DAT_RD_DIS_ADDR);
    cfg = (cfg & ~(ANA_ANCTL_CONST_PWR_EN_MASK + ANA_ANCTL_PWR_CONST_MASK)) |
          ((const_pwr_en << ANA_ANCTL_CONST_PWR_EN_POS) & ANA_ANCTL_CONST_PWR_EN_MASK) |
          ((pwr_const << ANA_ANCTL_PWR_CONST_POS) & ANA_ANCTL_PWR_CONST_MASK);
    REG_W32(ANA_ANCTL_TX_DAT_RD_DIS_ADDR, cfg);

}

void ana_set_tx_ramp_cfg_er81xx(uint8_t mod_type)
{
    uint32_t ramp_clk;
    uint8_t ramp_num;
    uint32_t cfg;

    switch (mod_type) {
    case MOD_TYPE_OOK:
    case MOD_TYPE_FSK:
    case MOD_TYPE_GFSK:
        // ANCTL_CONFIG_7_2 (0xE20)
        ramp_clk = 0x0A;
        ramp_num = 0x42;
        break;

    case MOD_TYPE_BPSK:
        // ANCTL_CONFIG_7_2 (0xE20)
        ramp_clk = 0x0A;
        ramp_num = 0x42;
        break;

    case MOD_TYPE_BPSK_RAMP:
        // ANCTL_CONFIG_7_2 (0xE20)
        ramp_clk = 0x13f;
        ramp_num = 0x63;
        break;

    default:
        printf("%s: mod_type did not support\n", __func__);
        // ANCTL_CONFIG_7_2 (0xE20)
        ramp_clk = 0x27;
        ramp_num = 0x13;
        break;
    }

    // ANCTL_CONFIG_7_2 (0xE20)
    cfg = REG_R32(ANA_ANCTL_RAMP_CLK_ADDR);
    cfg = (cfg & ~(ANA_ANCTL_RAMP_CLK_MASK + ANA_ANCTL_RAMP_NUM_MASK)) | 
          ((ramp_clk << ANA_ANCTL_RAMP_CLK_POS) & ANA_ANCTL_RAMP_CLK_MASK) |
          ((ramp_num << ANA_ANCTL_RAMP_NUM_POS) & ANA_ANCTL_RAMP_NUM_MASK);
    REG_W32(ANA_ANCTL_RAMP_CLK_ADDR, cfg);
}

uint32_t ana_get_tpm_din_val_er81xx(void)
{
    return REG_R32(ANA_FREQSYNTH_TPMCAL_CONFIG_3_ADDR);
}

void ana_set_tpm_din_val_er81xx(uint32_t val)
{
    REG_W32(ANA_FREQSYNTH_TPMCAL_CONFIG_3_ADDR, val);
}

void _set_power_down_workaround(void)
{
    uint32_t dr_bk = REG_R32(ANA_SYNTH_CAL_CONFIG_2_ADDR);
    REG_W32(ANA_SYNTH_CAL_CONFIG_2_ADDR, dr_bk * 2);
}

void ana_set_pwr_mode_er81xx(uint8_t mode)
{
    uint32_t cfg;

    if (mode == PWR_MODE_ACTIVITY) {
        REG_W32(ANA_PMU_CONFIG_0_ADDR, 0x0);
        return;
    }

    //0x40011A08
//    REG_W32(ANA_PMU_CONFIG_0_ADDR, 0xFFFFFFFF);
//    cfg = REG_R32(ANA_PMU_CONFIG_0_ADDR) & ~(ANA_PMU_XO_40M_BYCAP_EN_MASK);
//    REG_W32(ANA_PMU_CONFIG_0_ADDR, cfg);
    REG_W32(ANA_PMU_CONFIG_0_ADDR, 0x6FF);

    //0x40011A10
    REG_W32(ANA_PMU_CONFIG_2_ADDR, 0x10002001);

    // 0x40011A0C
    cfg = (REG_R32(ANA_PMU_CONFIG_1_ADDR) & ~(ANA_PMU_DIG_ULPLDOVDD_LV_S_MASK)) |
          ((0x7 << ANA_PMU_DIG_ULPLDOVDD_LV_S_POS) & ANA_PMU_DIG_ULPLDOVDD_LV_S_MASK);
    REG_W32(ANA_PMU_CONFIG_1_ADDR, cfg);

    // 0x40011A00
    REG_W32(ANA_PMU_CTL_ADDR, ANA_PMU_EN_MASK);

    // NOTE:: for soc9005 bbp cic clock r-map issue
    // _set_power_down_workaround();
}

void ana_set_synthesize_er81xx(uint32_t mod_type)
{
}

void ana_set_tx_ramp_backup_er81xx(void)
{
    //no need to backup for retension
}

void ana_get_tx_ramp_backup_er81xx(void)
{
    //no need to backup for retension
}

void ana_enable_singletone_er81xx(uint8_t mod_type, uint32_t pwr_lv, uint8_t enable)
{
    uint32_t reg_val;

    uint8_t tx_en;
    uint8_t rep_mode_en;
    uint8_t singletone_en;

    if (enable) {
        tx_en         = 1;
        rep_mode_en   = 1;
        singletone_en = 1;
    } else {
        tx_en         = 0;
        rep_mode_en   = 0;
        singletone_en = 0;
    }

    // 0x1E04[0] tx enable
    // 0x1E04[22] enabl repeat mode
    // 0x1E04[24] enable single tone
    reg_val = REG_R32(ANA_ANCTL_CONFIG_1_ADDR);
    reg_val = (reg_val & (~(ANA_ANCTL_TX_REP_MASK + ANA_ANCTL_SINGLE_EN_MASK + ANA_ANCTL_TX_EN_MASK))) |
              ((rep_mode_en << ANA_ANCTL_TX_REP_POS) & ANA_ANCTL_TX_REP_MASK) |
              ((singletone_en << ANA_ANCTL_SINGLE_EN_POS) & ANA_ANCTL_SINGLE_EN_MASK) | 
              ((tx_en << ANA_ANCTL_TX_EN_POS) & ANA_ANCTL_TX_EN_MASK);
    REG_W32(ANA_ANCTL_CONFIG_1_ADDR, reg_val);

    ana_set_tx_pwr_lv_er81xx(mod_type, pwr_lv);

    // tx_en should be put at final stage for avoiding clock issue
    //reg_val = REG_R32(ANA_ANCTL_CONFIG_1_ADDR);
    //reg_val = (reg_val & (~(ANA_ANCTL_TX_EN_MASK))) |
    //          ((tx_en << ANA_ANCTL_TX_EN_POS) & ANA_ANCTL_TX_EN_MASK);
    //REG_W32(ANA_ANCTL_CONFIG_1_ADDR, reg_val);
}

void ana_set_user_cfg_er81xx(void)
{
    uint32_t i, cfg_len;

    cfg_len = sizeof(ana_setup_arr_user_cfg) / sizeof(ana_setup_arr_user_cfg[0]);

    for (i = 0; i < cfg_len; i += 2) {
        REG_W32(ana_setup_arr_user_cfg[i], ana_setup_arr_user_cfg[i + 1]);
    }
}

void ana_set_adc_cfg_er81xx(uint8_t phy_mode, uint32_t data_rate)
{
    ana_set_adc_clk_er8130(phy_mode, data_rate);
}

void ana_set_rx_atop_cfg_er81xx(void)
{
    uint32_t cfg;
    //    uint8_t rx_filt_cal_mode_sel = 1;
    uint8_t rx_bb_cur_sel = 1;

    // RX_POWSET (0x1600)
    cfg = REG_R32(ANA_RX_POWSET_ADDR);
    cfg = (cfg & ~(ANA_RX_BB_CURSEL_MASK /* + ANA_RX_FILTCAPCAL_MODE_MASK*/)) | 
          ((rx_bb_cur_sel << ANA_RX_BB_CURSEL_POS) & ANA_RX_BB_CURSEL_MASK) /*|
          ((rx_filt_cal_mode_sel << ANA_RX_FILTCAPCAL_MODE_POS) & ANA_RX_FILTCAPCAL_MODE_MASK)*/
        ;
    REG_W32(ANA_RX_POWSET_ADDR, cfg);
}

void ana_set_module_pd_rst_er81xx(void)
{
    // enable whole module power down & reset
    // 0x1E30 enable whole bit except bit25
    uint32_t reg_val = 0xFDFFFF3F;

    // RX_POWSET (0xE30)
    REG_W32(ANA_ANCTL_CONFIG_7_5_ADDR, reg_val);
}

void ana_set_osc_backup_er81xx(void)
{
    uint32_t reg;
    int16_t coares_ctrl, fine_ctrl;

    reg         = REG_R32(ANA_DIG_LF_OSC_CONFIG5_ADDR);
    coares_ctrl = (reg & ANA_DIG_LF_OSC_COARSECTRL_ROUT_MASK) >> ANA_DIG_LF_OSC_COARSECTRL_ROUT_POS;
    fine_ctrl   = (reg & ANA_DIG_LF_OSC_FINECTRL_ROUT_MASK) >> ANA_DIG_LF_OSC_FINECTRL_ROUT_POS;

    reg  = REG_R32(ANA_DIG_LF_OSC_CONFIG1_ADDR) & ~(ANA_DIG_LF_OSC_FREQ_COARSECTRL_MASK + ANA_DIG_LF_OSC_FREQ_FINECTRL_MASK);
    reg |= ((coares_ctrl << ANA_DIG_LF_OSC_FREQ_COARSECTRL_POS) & ANA_DIG_LF_OSC_FREQ_COARSECTRL_MASK) |
           ((fine_ctrl << ANA_DIG_LF_OSC_FREQ_FINECTRL_POS) & ANA_DIG_LF_OSC_FREQ_FINECTRL_MASK);
    REG_W32(ANA_DIG_LF_OSC_CONFIG1_ADDR, reg);

//    reg = REG_R32(ANA_DIG_LF_OSC_CONFIG3_ADDR) & ~ANA_DIG_LF_OSC_AFC_EN_MASK;
//    REG_W32(ANA_DIG_LF_OSC_CONFIG3_ADDR, reg);

//    reg = REG_R32(ANA_ANCTL_CONFIG_0_ADDR) & ~ANA_ANCTL_OSC_SEL_CTL_MASK;
//    REG_W32(ANA_ANCTL_CONFIG_0_ADDR, reg);
}

void ana_set_bod_enable_er81xx(uint8_t enable)
{
    uint32_t reg;

    reg = REG_R32(ANA_BIAS_CONFIG1_ADDR);

    // low active
    if (enable) {
        reg &= ~ANA_BOD_DISABLE_MASK;
    } else {
        reg |= ANA_BOD_DISABLE_MASK;
    }

    REG_W32(ANA_BIAS_CONFIG1_ADDR, reg);
}

void ana_set_bod_level_er81xx(uint8_t level)
{
    uint32_t reg;

    reg = (REG_R32(ANA_BIAS_CONFIG1_ADDR) & ~ANA_BOD_LV_MASK) | ((level << ANA_BOD_LV_POS) & ANA_BOD_LV_MASK);
    REG_W32(ANA_BIAS_CONFIG1_ADDR, reg);
}

void ana_set_osc_cal_enable_er81xx(uint32_t stable_time)
{
#if 0
    uint32_t i = 0, time_out = 1500000;
	
    // 32k OSC calibration
    REG_W32(ANA_ANCTL_OSC_CAL_EN_ADDR, 0x1);
    while ((REG_R32(ANA_ANCTL_OSC_CAL_EN_ADDR) & ANA_ANCTL_OSC_CAL_EN_MASK) && (i++ < time_out));
    hal_intf_sys_tick_delay_us(stable_time);
#else // manual mode
    uint32_t reg;

    // raise the ldo voltage level (~1.23v)
    reg = REG_R32((ANA_BIAS_CONFIG1_ADDR) & ~(ANA_DIG_ULPLDOVDD_LV_MASK)) | ((0x08 << ANA_DIG_ULPLDOVDD_LV_POS) & ANA_DIG_ULPLDOVDD_LV_MASK) |
          ANA_DIG_ULPLDOVDD_EN_MODE_MASK;
    REG_W32(ANA_BIAS_CONFIG1_ADDR, reg);

    // disable dc-dc
    reg = REG_R32(ANA_DCDC_CONFIG_0_ADDR) &
          ~(ANA_DCDC_BYPASS12_MASK + ANA_DCDC_PD12_MASK/* +
            ANA_DCDC_FLOATING12_MASK*/);
    reg |= (ANA_DCDC_PD12_MASK /*+ ANA_DCDC_FLOATING12_MASK*/);
    REG_W32(ANA_DCDC_CONFIG_0_ADDR, reg);

    // osc reset pull low
    REG_W32(ANA_DIG_LF_OSC_CONFIG4_ADDR, (REG_R32(ANA_DIG_LF_OSC_CONFIG4_ADDR) & ~ANA_DIG_LF_OSC_RST_N_MASK));
    if (stable_time < 1000000) {
        REG_W32(ANA_DIG_LF_OSC_CONFIG4_ADDR, (REG_R32(ANA_DIG_LF_OSC_CONFIG4_ADDR) & ~ANA_DIG_LF_OSC_BIAS_STARTER_N_MASK));
        REG_W32(ANA_DIG_LF_OSC_CONFIG4_ADDR, (REG_R32(ANA_DIG_LF_OSC_CONFIG4_ADDR) | ANA_DIG_LF_OSC_BIAS_STARTER_N_MASK));
    } else {
        // enable afc
        REG_W32(ANA_DIG_LF_OSC_CONFIG3_ADDR, (REG_R32(ANA_DIG_LF_OSC_CONFIG3_ADDR) | ANA_DIG_LF_OSC_AFC_EN_MASK));
    }
    // osc reset pull high
    REG_W32(ANA_DIG_LF_OSC_CONFIG4_ADDR, (REG_R32(ANA_DIG_LF_OSC_CONFIG4_ADDR) | ANA_DIG_LF_OSC_RST_N_MASK));

#endif
}

void ana_set_osc_cal_finish_er81xx()
{
    uint32_t reg;
    int16_t coares_ctrl, fine_ctrl;

    // RD recommends at least 1 or 2 seconds for most situation.
    // A calibration process must be created if wanting to decease it
    //hal_intf_sys_tick_delay_us(stable_time); //kevinyang, 20250331, let upper layer control delay time

    // record the calibration result
    reg          = REG_R32(ANA_DIG_LF_OSC_CONFIG5_ADDR);
    coares_ctrl  = (reg & ANA_DIG_LF_OSC_COARSECTRL_ROUT_MASK) >> ANA_DIG_LF_OSC_COARSECTRL_ROUT_POS;
    fine_ctrl    = (reg & ANA_DIG_LF_OSC_FINECTRL_ROUT_MASK) >> ANA_DIG_LF_OSC_FINECTRL_ROUT_POS;
    reg          = REG_R32(ANA_DIG_LF_OSC_CONFIG1_ADDR) & ~(ANA_DIG_LF_OSC_FREQ_COARSECTRL_MASK + ANA_DIG_LF_OSC_FREQ_FINECTRL_MASK);
    reg         |= ((coares_ctrl << ANA_DIG_LF_OSC_FREQ_COARSECTRL_POS) & ANA_DIG_LF_OSC_FREQ_COARSECTRL_MASK) |
           ((fine_ctrl << ANA_DIG_LF_OSC_FREQ_FINECTRL_POS) & ANA_DIG_LF_OSC_FREQ_FINECTRL_MASK);
    REG_W32(ANA_DIG_LF_OSC_CONFIG1_ADDR, reg);

    // disable binary search
    REG_W32(ANA_DIG_LF_OSC_CONFIG3_ADDR, (REG_R32(ANA_DIG_LF_OSC_CONFIG3_ADDR) & ~ANA_DIG_LF_OSC_SAR_MODE_EN_MASK));

    // retrieve the ldo voltage level (~0.9v)
    //    reg = REG_R32(ANA_BIAS_CONFIG1_ADDR) & ~(ANA_DIG_ULPLDOVDD_LV_MASK) |
    //          ((0x00 << ANA_DIG_ULPLDOVDD_LV_POS) & ANA_DIG_ULPLDOVDD_LV_MASK);
    //    REG_W32(ANA_BIAS_CONFIG1_ADDR, reg);
    // enable dc-dc
    reg = REG_R32(ANA_DCDC_CONFIG_0_ADDR) &
          ~(ANA_DCDC_BYPASS12_MASK + ANA_DCDC_PD12_MASK/* +
            ANA_DCDC_FLOATING12_MASK*/);
    REG_W32(ANA_DCDC_CONFIG_0_ADDR, reg);
}

uint8_t ana_get_rx_status_er81xx(void)
{
    uint8_t cfg;

    //0x1EFC[8:5]
    cfg  = REG_R32(ANA_ANCTL_ST_REG_ADDR);
    cfg &= (BIT5 | BIT6 | BIT7 | BIT8);

    return (cfg >> 5);
}

void ana_toggle_tx_en_er81xx(void)
{
    uint32_t reg_val;
    uint32_t tmp = 10000;

    // 0x1E04[0] tx enable
    // 0x1E04[22] enabl repeat mode
    // 0x1E04[24] enable single tone
    reg_val = REG_R32(ANA_ANCTL_CONFIG_1_ADDR);
    reg_val = (reg_val & (~(ANA_ANCTL_TX_EN_MASK))) |
              ((1 << ANA_ANCTL_TX_EN_POS) & ANA_ANCTL_TX_EN_MASK);
    REG_W32(ANA_ANCTL_CONFIG_1_ADDR, reg_val);

    while(tmp--)
        ;

    reg_val = REG_R32(ANA_ANCTL_CONFIG_1_ADDR);
    reg_val = (reg_val & (~(ANA_ANCTL_TX_EN_MASK))) |
              ((0 << ANA_ANCTL_TX_EN_POS) & ANA_ANCTL_TX_EN_MASK);
    REG_W32(ANA_ANCTL_CONFIG_1_ADDR, reg_val);


}

uint8_t ana_is_tpm_cal_done_er81xx(void)
{
    return ((REG_R32(ANA_FREQSYNTH_TPMCAL_CONFIG_5_ADDR)&ANA_FS_TPMCAL_DONE_MASK)>>ANA_FS_TPMCAL_DONE_POS);
}


uint32_t ana_get_tpm_din_hb_er81xx(void)
{
    return ((REG_R32(ANA_FREQSYNTH_TPMCAL_CONFIG_5_ADDR)&ANA_FS_TPMCAL_TPM_DIN_HB_OUT_MASK));
}

void ana_set_tpm_din_hb_er81xx(uint32_t val)
{
    uint32_t reg;

    reg = REG_R32(ANA_FREQSYNTH_TPMCAL_CONFIG_3_ADDR);
    reg = (reg & ~(ANA_FS_TPMCAL_TPM_DIN_HB_MASK)) |
          ((val << ANA_FS_TPMCAL_TPM_DIN_HB_POS) & ANA_FS_TPMCAL_TPM_DIN_HB_MASK);
    REG_W32(ANA_FREQSYNTH_TPMCAL_CONFIG_3_ADDR, reg);
}

uint8_t ana_get_kvc_er81xx(void)
{
    return ((REG_R32(ANA_FREQSYNTH_CONFIG_7_ADDR)&ANA_FS_KVC_ROUT_MASK)>>ANA_FS_KVC_ROUT_POS);
}

void ana_set_kvc_er81xx(uint8_t val)
{
    uint32_t reg;
    uint8_t bsmode = 0;

    //0x1384[17:13]
    //0x1384[18]
    // if you set kvc by manual, you should disable bsmode(binary search) at same time
    reg = REG_R32(ANA_FREQSYNTH_CONFIG_2_ADDR);
    reg = (reg & ~(ANA_FS_KVC_IN_MASK)) |
          ((val << ANA_FS_KVC_IN_POS) & ANA_FS_KVC_IN_MASK)|
          ((bsmode << ANA_FS_AFC_INIT_BSMODE_EN_POS) & ANA_FS_AFC_INIT_BSMODE_EN_MASK);
    REG_W32(ANA_FREQSYNTH_CONFIG_2_ADDR, reg);
}

void ana_control_16kosc_power(bool enable)
{
    uint32_t reg;

    //addr:0x40011880
    reg = REG_R32(ANA_DIG_LF_OSC16K_CONFIG1_ADDR);
    if (enable) {
        reg &= ~(ANA_DIG_LF_OSC16K_PD_MASK | ANA_DIG_LF_OSC16K_LDO_PD_MASK);
    } else {
        reg |= (ANA_DIG_LF_OSC16K_PD_MASK | ANA_DIG_LF_OSC16K_LDO_PD_MASK);
    }
    REG_W32(ANA_DIG_LF_OSC16K_CONFIG1_ADDR, reg);
}

void ana_control_32kosc_power(bool enable)
{
    uint32_t reg;

    //addr:0x4001130c
    reg = REG_R32(ANA_DIG_LF_OSC_CONFIG4_ADDR);
    if (enable) {
        reg &= ~(ANA_DIG_LF_OSC_RST_N_MASK | ANA_DIG_LF_OSC_PD_MASK | ANA_DIG_LF_OSC_STARTER_N_MASK | ANA_DIG_LF_OSC_BIAS_STARTER_N_MASK);
    } else {
        reg |= ANA_DIG_LF_OSC_PD_MASK;
        reg &= ~ANA_DIG_LF_OSC_RST_N_MASK;
    }
    REG_W32(ANA_DIG_LF_OSC_CONFIG4_ADDR, reg);

    if (enable) {
        reg |= (ANA_DIG_LF_OSC_RST_N_MASK | ANA_DIG_LF_OSC_STARTER_N_MASK | ANA_DIG_LF_OSC_BIAS_STARTER_N_MASK);

        for (uint32_t i = 0; i < 100; i++) {
            __NOP();
        }
        REG_W32(ANA_DIG_LF_OSC_CONFIG4_ADDR, reg);
    }
}

void ana_disable_pmu_shutdown_control_for_32k_16k_osc(void)
{
    uint32_t reg;

    // addr:0x40011A08
    reg  = REG_R32(ANA_PMU_CONFIG_0_ADDR);
    reg &= ~(ANA_PMU_32K_SHDN_EN_MASK | ANA_PMU_16K_SHDN_EN_MASK);
    REG_W32(ANA_PMU_CONFIG_0_ADDR, reg);
}

void ana_tune_16kosc_to_32k_mode(bool boost)
{
    uint32_t reg;

    // addr:0x40011880
    reg = REG_R32(ANA_DIG_LF_OSC16K_CONFIG1_ADDR);
    if (boost) {
        reg &= ~(ANA_DIG_LF_OSC16K_XTRACAP_MASK);
    } else {
        reg |= (ANA_DIG_LF_OSC16K_XTRACAP_MASK);
    }
    REG_W32(ANA_DIG_LF_OSC16K_CONFIG1_ADDR, reg);
}

void ana_power_management_for_16kosc(uint8_t option)
{
    uint32_t reg;

    // addr:0x40011880
    reg = REG_R32(ANA_DIG_LF_OSC16K_CONFIG1_ADDR);
    if (option == HDL_SCLK_16K_PWR_LOWPOWER) {
        reg |= ANA_DIG_LF_OSC16K_LDO_PD_MASK;
        reg &= ~ANA_DIG_LF_OSC_0P6VSEL_MASK;
    } else if (option == HDL_SCLK_16K_PWR_LOWPOWER_0P6V) {
        reg |= ANA_DIG_LF_OSC16K_LDO_PD_MASK;
        reg |= ANA_DIG_LF_OSC_0P6VSEL_MASK;
    } else {
        reg &= ~ANA_DIG_LF_OSC16K_LDO_PD_MASK;
        reg &= ~ANA_DIG_LF_OSC_0P6VSEL_MASK;
    }
    REG_W32(ANA_DIG_LF_OSC16K_CONFIG1_ADDR, reg);
}

int8_t ana_exec_anctl_osc_calibration(void)
{
    uint32_t reg;
    uint32_t time_out = 100000000;
    uint32_t i        = 0;

    // anactl_osc_sel_ctl
    reg  = REG_R32(ANA_ANCTL_CONFIG_0_ADDR);
    reg |= ANA_ANCTL_OSC_SEL_CTL_MASK;
    REG_W32(ANA_ANCTL_CONFIG_0_ADDR, reg);
    // enable osc calibration
    REG_W32(ANA_ANCTL_OSC_CAL_EN_ADDR, ANA_ANCTL_OSC_CAL_EN_MASK);

    // wait for calibration done
    while ((REG_R32(ANA_ANCTL_OSC_CAL_EN_ADDR) & ANA_ANCTL_OSC_CAL_EN_MASK) && (i++ < time_out)) {
        ;
    }

    if (i >= time_out) {
        printf("ana_exec_anctl_osc_calibration: timeout\n");
        return 1; // error
    }

    return 0; // success
}

int8_t ana_exec_anctl_osc16k_calibration(void)
{
    uint32_t reg;
    uint32_t time_out = 100000000;
    uint32_t i        = 0;

    // anactl_osc_sel_ctl
    reg  = REG_R32(ANA_ANCTL_CONFIG_0_ADDR);
    reg |= ANA_ANCTL_OSC_SEL_CTL_MASK;
    REG_W32(ANA_ANCTL_CONFIG_0_ADDR, reg);
    // enable osc16k calibration
    REG_W32(ANA_ANCTL_CONFIG_7_6_ADDR, ANA_ANCTL_OSC16K_CAL_EN_MASK);

    // wait for calibration done
    while ((REG_R32(ANA_ANCTL_CONFIG_7_6_ADDR) & ANA_ANCTL_OSC16K_CAL_EN_MASK) && (i++ < time_out)) {
        ;
    }

    if (i >= time_out) {
        printf("ana_exec_anctl_osc16k_calibration: timeout\n");
        return 1; // error
    }

    return 0; // success
}

int8_t ana_exec_anctl_osc32k_calibration(uint8_t tim_osc)
{
    uint32_t reg;
    uint32_t time_out = 100000000;
    uint32_t i        = 0;

    // anactl_osc_sel_ctl
    reg  = REG_R32(ANA_ANCTL_CONFIG_0_ADDR);
    reg |= ANA_ANCTL_OSC_SEL_CTL_MASK;
    REG_W32(ANA_ANCTL_CONFIG_0_ADDR, reg);
    // anactl_tim_osc
    reg  = REG_R32(ANA_ANCTL_CONFIG_6_ADDR);
    reg |= (tim_osc << ANA_ANCTL_TIM_OSC_POS) & ANA_ANCTL_TIM_OSC_MASK;
    REG_W32(ANA_ANCTL_CONFIG_6_ADDR, reg);
    // enable osc32k calibration
    REG_W32(ANA_ANCTL_CONFIG_7_6_ADDR, ANA_ANCTL_OSC_CAL_EN_MASK);

    // wait for calibration done
    while ((REG_R32(ANA_ANCTL_CONFIG_7_6_ADDR) & ANA_ANCTL_OSC_CAL_EN_MASK) && (i++ < time_out)) {
        ;
    }

    if (i >= time_out) {
        printf("ana_exec_anctl_osc32k_calibration: timeout\n");
        return 1; // error
    }

    return 0; // success
}

void ana_ldo_paramaters_for_16kosc_calibration(uint8_t ldo_cur, uint8_t ldo_sel, uint8_t ldo_tmp, uint16_t freq_ctrl_sel)
{
    uint32_t reg;

    // addr:0x40011880
    reg  = REG_R32(ANA_DIG_LF_OSC16K_CONFIG1_ADDR);
    reg &= ~(ANA_DIG_LF_OSC16K_LDOCUR_MASK);
    reg |= (ldo_cur << ANA_DIG_LF_OSC16K_LDOCUR_POS) & ANA_DIG_LF_OSC16K_LDOCUR_MASK;
    reg &= ~(ANA_DIG_LF_OSC16K_LDOSEL_MASK);
    reg |= (ldo_sel << ANA_DIG_LF_OSC16K_LDOSEL_POS) & ANA_DIG_LF_OSC16K_LDOSEL_MASK;
    reg &= ~(ANA_DIG_LF_OSC16K_LDOTMP_MASK);
    reg |= (ldo_tmp << ANA_DIG_LF_OSC16K_LDOTMP_POS) & ANA_DIG_LF_OSC16K_LDOTMP_MASK;
    reg &= ~(ANA_DIG_LF_OSC16K_FREQCTRLSEL_MASK);
    reg |= (freq_ctrl_sel << ANA_DIG_LF_OSC16K_FREQCTRLSEL_POS) & ANA_DIG_LF_OSC16K_FREQCTRLSEL_MASK;

    REG_W32(ANA_DIG_LF_OSC16K_CONFIG1_ADDR, reg);
}
void ana_reg0_paramaters_for_16kosc_calibration(uint8_t sclk_settle, uint32_t target_count, uint8_t step_coarse)
{
    uint32_t reg;

    // addr:0x40011e78
    reg  = REG_R32(ANA_ANCTL_OSC16K_REG0_ADDR);
    reg &= ~(ANA_ANCTL_OSC16K_SCLKSETTLE_MASK);
    reg |= (sclk_settle << ANA_ANCTL_OSC16K_SCLKSETTLE_POS) & ANA_ANCTL_OSC16K_SCLKSETTLE_MASK;
    reg &= ~(ANA_ANCTL_OSC16K_TARCOUNT_MASK);
    reg |= (target_count << ANA_ANCTL_OSC16K_TARCOUNT_POS) & ANA_ANCTL_OSC16K_TARCOUNT_MASK;
    reg &= ~(ANA_ANCTL_OSC16K_STEPCOARSE_MASK);
    reg |= (step_coarse << ANA_ANCTL_OSC16K_STEPCOARSE_POS) & ANA_ANCTL_OSC16K_STEPCOARSE_MASK;

    REG_W32(ANA_ANCTL_OSC16K_REG0_ADDR, reg);
}

void ana_reg1_paramaters_for_16kosc_calibration(uint8_t num_slow_sclk_cycle, uint16_t init_ctrl_index, uint16_t coarse_diff, uint8_t cal_cnt)
{
    uint32_t reg;

    // addr:0x40011e7c
    reg  = REG_R32(ANA_ANCTL_OSC16K_REG1_ADDR);
    reg &= ~(ANA_ANCTL_OSC16K_NUMSLOWCLKCYCLE_MASK);
    reg |= (num_slow_sclk_cycle << ANA_ANCTL_OSC16K_NUMSLOWCLKCYCLE_POS) & ANA_ANCTL_OSC16K_NUMSLOWCLKCYCLE_MASK;
    reg &= ~(ANA_ANCTL_OSC16K_INITCTRLINDEX_MASK);
    reg |= (init_ctrl_index << ANA_ANCTL_OSC16K_INITCTRLINDEX_POS) & ANA_ANCTL_OSC16K_INITCTRLINDEX_MASK;
    reg &= ~(ANA_ANCTL_OSC16K_COARSEDIFF_MASK);
    reg |= (coarse_diff << ANA_ANCTL_OSC16K_COARSEDIFF_POS) & ANA_ANCTL_OSC16K_COARSEDIFF_MASK;
    reg &= ~(ANA_ANCTL_OSC16K_CALCNT_MASK);
    reg |= (cal_cnt << ANA_ANCTL_OSC16K_CALCNT_POS) & ANA_ANCTL_OSC16K_CALCNT_MASK;

    REG_W32(ANA_ANCTL_OSC16K_REG1_ADDR, reg);
}

void ana_paramaters_for_32kosc_calibration(uint8_t cap_ctrl, uint8_t ictrl, uint8_t ldo_vdd_lv, uint16_t osc_clk_div, uint8_t fref_clk_div,
                                           uint32_t cycles_target)
{
    uint32_t reg;

    // addr:0x40011300
    reg = REG_R32(ANA_DIG_LF_OSC_CONFIG1_ADDR);

    reg &= ~(ANA_DIG_LF_OSC_CAP_CTRL_MASK);
    reg |= (cap_ctrl << ANA_DIG_LF_OSC_CAP_CTRL_POS) & ANA_DIG_LF_OSC_CAP_CTRL_MASK;
    reg &= ~(ANA_DIG_LF_OSC_ICTRL_MASK);
    reg |= (ictrl << ANA_DIG_LF_OSC_ICTRL_POS) & ANA_DIG_LF_OSC_ICTRL_MASK;
    reg &= ~(ANA_DIG_LF_OSC_LDOVDD_LV_MASK);
    reg |= (ldo_vdd_lv << ANA_DIG_LF_OSC_LDOVDD_LV_POS) & ANA_DIG_LF_OSC_LDOVDD_LV_MASK;

    REG_W32(ANA_DIG_LF_OSC_CONFIG1_ADDR, reg);

    // addr:0x40011308
    reg = REG_R32(ANA_DIG_LF_OSC_CONFIG3_ADDR);

    reg &= ~(ANA_DIG_LF_OSC_LF_OSC_CLK_DIV_N_MASK);
    reg |= (osc_clk_div << ANA_DIG_LF_OSC_LF_OSC_CLK_DIV_N_POS) & ANA_DIG_LF_OSC_LF_OSC_CLK_DIV_N_MASK;

    REG_W32(ANA_DIG_LF_OSC_CONFIG3_ADDR, reg);
    // addr:0x4001130c
    reg = REG_R32(ANA_DIG_LF_OSC_CONFIG4_ADDR);

    reg &= ~(ANA_DIG_LF_OSC_FREF_CLK_DIV_N_MASK);
    reg |= (fref_clk_div << ANA_DIG_LF_OSC_FREF_CLK_DIV_N_POS) & ANA_DIG_LF_OSC_FREF_CLK_DIV_N_MASK;

    REG_W32(ANA_DIG_LF_OSC_CONFIG4_ADDR, reg);
    // addr:0x40011304
    reg = REG_R32(ANA_DIG_LF_OSC_CONFIG2_ADDR);

    reg &= ~(ANA_DIG_LF_OSC_DETECTING_CYCLES_TARGET_MASK);
    reg |= (cycles_target << ANA_DIG_LF_OSC_DETECTING_CYCLES_TARGET_POS) & ANA_DIG_LF_OSC_DETECTING_CYCLES_TARGET_MASK;

    REG_W32(ANA_DIG_LF_OSC_CONFIG2_ADDR, reg);
}

void hal_drv_ana_switch_nfc_pwr_src(uint8_t src)
{
    uint32_t reg;

    if (src == NFC_PWR_SRC_MCU) {
        //NFC_PWR_SRC_MCU
        //HW32_REG(0x40011598) = 0xFFFFFFFF;
        //ANCTL->PAD_XTAL_GPREG_REG.RW_GPREG_ONES_1 |= (0x00000001);
        reg = REG_R32(ANA_GPREG_CONFIG_2_ADDR);
        reg |= (0x00000001);
        REG_W32(ANA_GPREG_CONFIG_2_ADDR, reg);
    }

    if (src == NFC_PWR_SRC_READER) {
        //NFC_PWR_SRC_READER
                //- Let NFC engine use NFC power
        //HW32_REG(0x40011598) = 0xFFFFFFFE;
        //ANCTL->PAD_XTAL_GPREG_REG.RW_GPREG_ONES_1 &= ~(0x00000001);
        reg = REG_R32(ANA_GPREG_CONFIG_2_ADDR);
        reg &= ~(0x00000001);
        REG_W32(ANA_GPREG_CONFIG_2_ADDR, reg);
    }
}

/* ================== ASARADC =============== */
void ana_asaradc_vref_level(bool vref)
{
    uint32_t reg = REG_R32(ANA_ASARADC_CONFIG_1_ADDR);
    /* vref[0]=1.6v , verf[1]=2.4v */
    reg &= ~ANA_ASARADC_LDOVDD_LV_MASK;
    if (vref) {
        reg |= ANA_ASARADC_LDOVDD_LV_MASK;
    }
    REG_W32(ANA_ASARADC_CONFIG_1_ADDR, reg);
}

void ana_asaradc_verf_scaler_level(bool enable, uint8_t scaler_lv)
{
    uint32_t reg = REG_R32(ANA_ASARADC_CONFIG_1_ADDR);

    reg &= ~ANA_ASARADC_VDDDET_EN_MASK;
    reg &= ~ANA_ASARADC_VDDDET_VSLV_SEL_MASK;

    if (enable) {
        reg |= ANA_ASARADC_VDDDET_EN_MASK;
        reg |= ((scaler_lv << ANA_ASARADC_VDDDET_VSLV_SEL_POS) & ANA_ASARADC_VDDDET_VSLV_SEL_MASK);
    }
    REG_W32(ANA_ASARADC_CONFIG_1_ADDR, reg);
}

void ana_asaradc_start_er8130(void)
{
    REG_W32(ANA_ASARADC_CONFIG_13_ADDR, ANA_ASARADC_START_MASK);
}

bool ana_asaradc_is_ready_er8130(void)
{
    uint32_t reg = REG_R32(ANA_ASARADC_CONFIG_13_ADDR);
    return (!!(reg & ANA_ASARADC_READY_MASK));
}

void ana_asaradc_set_timing_er8130(uint8_t timer_mode1, uint8_t timer_mode2)
{
    uint32_t reg = REG_R32(ANA_ASARADC_CONFIG_17_ADDR);

    reg &= ~(ANA_TIMER_MODE_1_MASK | ANA_TIMER_MODE_2_MASK);
    reg |= ((timer_mode1 << ANA_TIMER_MODE_1_POS) & ANA_TIMER_MODE_1_MASK);
    reg |= ((timer_mode2 << ANA_TIMER_MODE_2_POS) & ANA_TIMER_MODE_2_MASK);

    REG_W32(ANA_ASARADC_CONFIG_17_ADDR, reg);
}

void and_asaradc_set_fetch_mode_er8310(bool fetch_mode)
{
    uint32_t reg = REG_R32(ANA_ASARADC_CONFIG_17_ADDR);

    if (fetch_mode) {
        reg |= ANA_FETCH_MODE_MASK; //use ASARADC_FSCLK rising edge
    } else {
        reg &= ~ANA_FETCH_MODE_MASK; //use ASARADC_FSCLK falling edge
    }
    REG_W32(ANA_ASARADC_CONFIG_17_ADDR, reg);
}

void ana_asaradc_daf_mode_er8130(bool enable, uint8_t shift_n)
{
    uint32_t reg = REG_R32(ANA_ASARADC_CONFIG_1_ADDR);

    if (enable) {
        reg |= ANA_ASARADC_DAF_EN_MASK;
    } else {
        reg &= ~ANA_ASARADC_DAF_EN_MASK;
    }

    reg &= ~ANA_ASARADC_DAF_AVG_SHIFT_N_MASK;
    reg |= ((shift_n << ANA_ASARADC_DAF_AVG_SHIFT_N_POS) & ANA_ASARADC_DAF_AVG_SHIFT_N_MASK);

    REG_W32(ANA_ASARADC_CONFIG_1_ADDR, reg);
}

void ana_asaradc_set_vin_sel_er8130(uint8_t sel)
{
    REG_W32(ANA_ASARADC_CONFIG_16_ADDR, sel & ANA_ASARADC_VIN_MUX_SEL_SET_MASK);
}

uint8_t ana_asaradc_get_vin_sel_er8130(void)
{
    uint32_t reg = REG_R32(ANA_ASARADC_CONFIG_16_ADDR);
    return ((reg & ANA_ASARADC_VIN_MUX_SEL_SET_MASK) >> ANA_ASARADC_VIN_MUX_SEL_SET_POS);
}

void ana_asaradc_set_interrupt_er8130(bool enable)
{
    REG_W32(ANA_ASARADC_INT_EN_ADDR, enable ? ANA_INT_EN_READY_MASK : 0);
}

void ana_asaradc_clear_int_status_er8130(void)
{
    REG_W32(ANA_ASARADC_INT_ST_ADDR, ANA_INT_ST_READY_MASK);
}

bool ana_asaradc_get_int_status_er8130(void)
{
    uint32_t reg = REG_R32(ANA_ASARADC_INT_ST_ADDR);
    return (!!(reg & ANA_INT_ST_READY_MASK));
}

bool ana_asaradc_get_int_masked_status_er8130(void)
{
    uint32_t reg = REG_R32(ANA_ASARADC_INT_ADDR);
    return (!!(reg & ANA_INT_READY_MASK));
}

uint16_t ana_asaradc_get_data_er8130(void)
{
    uint32_t reg = REG_R32(ANA_ASARADC_CONFIG_14_ADDR);
    return ((reg & ANA_ASARADC_DATA_MASK) >> ANA_ASARADC_DATA_POS);
}

uint32_t ana_asaradc_get_hr_data_er8130(void)
{
    uint32_t reg = REG_R32(ANA_ASARADC_CONFIG_15_ADDR);
    return ((reg & ANA_ASARADC_HR_DATA_MASK) >> ANA_ASARADC_HR_DATA_POS);
}
