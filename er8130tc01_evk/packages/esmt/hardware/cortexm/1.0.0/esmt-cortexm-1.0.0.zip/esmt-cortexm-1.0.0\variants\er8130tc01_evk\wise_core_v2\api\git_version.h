// Auto-generated file - do not edit
#ifndef GIT_VERSION_H
#define GIT_VERSION_H
#define GIT_COMMIT_HASH 0
#endif // GIT_VERSION_H
