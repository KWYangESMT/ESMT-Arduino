/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef __HAL_DRV_SHA_H
#define __HAL_DRV_SHA_H

#include "hal_intf_crypto.h"
#include <stdint.h>
#include "hdl/sha_er8130.h"


#define hal_drv_sha_set_config                      sha_set_config_er8130
#define hal_drv_sha_get_digest                      sha_get_digest_er8130

#endif

