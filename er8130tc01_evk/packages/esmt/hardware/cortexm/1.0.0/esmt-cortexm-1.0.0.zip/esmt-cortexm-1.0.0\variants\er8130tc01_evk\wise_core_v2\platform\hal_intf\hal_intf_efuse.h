/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef __HAL_INTF_EFUSE_H
#define __HAL_INTF_EFUSE_H

#include "esmt_chip_specific.h"
#include "types.h"

#define EFUSE_SN_ADDR 0x008 // for er8130 tc04

HAL_STATUS hal_intf_efuse_read_word(uint16_t addr, uint32_t *data);
HAL_STATUS hal_intf_efuse_write_word(uint16_t addr, uint32_t data);

#endif /* __HAL_INTF_EFUSE_H */
