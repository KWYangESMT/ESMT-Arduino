/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */
 
#include "esmt_chip_specific.h"
#include "bbp_er8130.h"
#include "util_debug_log.h"
#include "modem_config.h"

#define RX_LPF_REG_PAIR_NUM 5
#define BBP_IFEST_REG_NUM 8

enum bbp_iqk_tone {
    BBP_IQK_TONE_250KHZ   = 0,
    BBP_IQK_TONE_500KHZ   = 1,
    BBP_IQK_TONE_1000KHZ  = 2,
    BBP_IQK_TONE_N250KHZ  = 4,
    BBP_IQK_TONE_N500KHZ  = 5,
    BBP_IQK_TONE_N1000KHZ = 6,
};

static const uint32_t bbp_setup_arr_user_cfg[] = {
#if 0 // adc out
    0x4000, 0x00160300,
    0x4004, 0x00160300,
    0x4008, 0x00160300,
    0x400C, 0x00160300,
#endif
};

static const uint32_t bbp_agc_gain_table[] = {
    0x4002815c, 0x33222222,
    0x40028160, 0x33322233,
    0x40028164, 0x33333333,
    0x40028168, 0x33333333,
    0x4002816c, 0x00000000,
    0x40028170, 0x22222200,
    0x40028174, 0x33322222,
    0x40028178, 0x33333333,
    0x4002817c, 0x03987654,
    0x40028180, 0xa9887621,
    0x40028184, 0x654cba98,
    0x40028188, 0xcccba987,
    0x4002818c, 0x76555555,
    0x40028190, 0x00066677,
    0x40028194, 0x77733333,
    0x40028198, 0x77777777,
    0x400281bc, 0x00270014,
    0x400281c0, 0x0054003c,
    0x400281c4, 0x0084006c,
    0x400281c8, 0x00b700a5,
    0x400281cc, 0x00e100cc,
    0x400281d0, 0x010e00f6,
    0x400281d4, 0x01450126,
    0x400281d8, 0x0178015d,
    0x400281dc, 0x01a5018d,
    0x400281e0, 0x01d801c0,
    0x400281e4, 0x020d01f0,
    0x400281e8, 0x023a0222,
    0x400281ec, 0x026a0252,
    0x400281f0, 0x029d0282,
    0x400281f4, 0x02cd02b5,
    0x400281f8, 0x02cd02cd,
    0x40028250, 0x00000000,
    0x40028254, 0x76543210,
    0x40028258, 0x77777777,
};

static const uint32_t bbp_rx_lpf_osr16_h0_5[] = {
    0x40028108, 0xfcdf8be1,
    0x4002810c, 0x080053fb,
    0x40028110, 0x2183003e,
    0x40028114, 0x3a4670ac,
    0x40028118, 0x700800fa,
};

static const uint32_t bbp_rx_lpf_osr16_h1[] = {
    0x40028108, 0xf55f03e4,
    0x4002810c, 0xf91e9bcf,
    0x40028110, 0x19817802,
    0x40028114, 0x4386e8a3,
    0x40028118, 0x7009d12f,
};

static const uint32_t bbp_rx_lpf_osr16_h2[] = {
    0x40028108, 0x03805005,
    0x4002810c, 0xf7dfd00a,
    0x40028110, 0xf85dfbc5,
    0x40028114, 0x4cc57835,
    0x40028118, 0x700e0199,
};

static const uint32_t bbp_rx_lpf_osr16_h4[] = { // osr16
    0x40028108, 0xfd9ff001,
    0x4002810c, 0x031fb3ef,
    0x40028110, 0xf740801f,
    0x40028114, 0x1f1f5bbb,
    0x40028118, 0x600b6123,
};

static const uint32_t bbp_rx_lpf_osr8_h0_5[] = {
    0x40028108, 0x0440780a,
    0x4002810c, 0xf41f7807,
    0x40028110, 0xf91dcbb8,
    0x40028114, 0x4cc5b03d,
    0x40028118, 0x700da992,
};

static const uint32_t bbp_rx_lpf_osr8_h1[] = {
    0x40028108, 0xffdfe3fe,
    0x4002810c, 0x04408006,
    0x40028110, 0xf39f1800,
    0x40028114, 0x26415be1,
    0x40028118, 0x600930fd,
};

static const uint32_t bbp_rx_lpf_osr8_h2[] = {
    0x40028108, 0x04c08803,
    0x4002810c, 0xfb9f5002,
    0x40028110, 0x00815814,
    0x40028114, 0x171e13b9,
    0x40028118, 0x600ce135,
};

static const uint32_t bbp_rx_lpf_osr8_h4[] = {
    0x40028108, 0xfd5f03f7,
    0x4002810c, 0xfd1fc812,
    0x40028110, 0xfa9fc815,
    0x40028114, 0xef9fc026,
    0x40028118, 0x500a6891,
};

static const uint32_t *bbp_rx_lpf_osr16[MOD_IDX_MAX] = {
    bbp_rx_lpf_osr16_h0_5,  //h = 0.5
    bbp_rx_lpf_osr16_h1,    //h = 1
    bbp_rx_lpf_osr16_h2,    //h = 2
    bbp_rx_lpf_osr16_h4,    //h = 4
};

static const uint32_t *bbp_rx_lpf_osr8[] = {
    bbp_rx_lpf_osr8_h0_5,  //h = 0.5
    bbp_rx_lpf_osr8_h1,    //h = 1
    bbp_rx_lpf_osr8_h2,    //h = 2
    bbp_rx_lpf_osr8_h4,    //h = 4
};

struct dr_para_t dr_para_gfsk_er81xx[E_HAL_DR_MAX] = {
    {
        // dr = 4.8K
    },
    {
        // dr = 12.5K
        .init_gidx           = 31,
        .ib_tgt              = DIG_TRAN(0),
        .ed_thres            = {DIG_TRAN(-24.0), DIG_TRAN(-24.0), DIG_TRAN(-23.0), DIG_TRAN(-20.0)},
        .agc_timeout_max     = 0xFA00,
        .if_freq             = IF_FREQ_250KHZ,
        .iqk_tone_sel        = BBP_IQK_TONE_N250KHZ,
        .inband_pwr_win_size = 10,
        .tot_pwr_win_size    = 10,
        .ook_ed_thr          = 0x02f8,
        .pwr_ofs             = DIG_TRAN(3.0),
        .ed_ov_thr_prd       = 4,
    },
    {
        // dr = 32.768K
    },
    {
        // dr = 50K
        .init_gidx           = 31,
        .ib_tgt              = DIG_TRAN(0),
        .ed_thres            = {DIG_TRAN(-18.0), 0, 0, 0},
        .agc_timeout_max     = 0x3E80,
        .if_freq             = IF_FREQ_250KHZ,
        .iqk_tone_sel        = BBP_IQK_TONE_N250KHZ,
        .inband_pwr_win_size = 8,
        .tot_pwr_win_size    = 8,
        .ook_ed_thr          = 0x02f7,
        .pwr_ofs             = DIG_TRAN(3.0),
        .ed_ov_thr_prd       = 4,
    },
    {
        // dr = 100K
        .init_gidx           = 25,
        .ib_tgt              = DIG_TRAN(0),
        .ed_thres            = {DIG_TRAN(-27.0), 0, 0, 0},
        .agc_timeout_max     = 0x1F40,
        .if_freq             = IF_FREQ_250KHZ,
        .iqk_tone_sel        = BBP_IQK_TONE_N250KHZ,
        .inband_pwr_win_size = 7,
        .tot_pwr_win_size    = 7,
        .ook_ed_thr          = 0x02f6,
        .pwr_ofs             = DIG_TRAN(3.0),
        .ed_ov_thr_prd       = 2,
    },
    {
        // dr = 125K
        .init_gidx           = 31,
        .ib_tgt              = DIG_TRAN(0),
        .ed_thres            = {DIG_TRAN(-16.0), 0, 0, 0},
        .agc_timeout_max     = 0x1900,
        .if_freq             = IF_FREQ_250KHZ,
        .iqk_tone_sel        = BBP_IQK_TONE_N250KHZ,
        .inband_pwr_win_size = 6,
        .tot_pwr_win_size    = 6,
        .ook_ed_thr          = 0x02f5,
        .pwr_ofs             = DIG_TRAN(3.0),
        .ed_ov_thr_prd       = 4,
    },
    {
        // dr = 200K
        .init_gidx           = 27,
        .ib_tgt              = DIG_TRAN(-10),
        .ed_thres            = {DIG_TRAN(-30), 0, 0, 0},
        .agc_timeout_max     = 0x1200,
        .if_freq             = IF_FREQ_250KHZ,
        .iqk_tone_sel        = BBP_IQK_TONE_N250KHZ,
        .inband_pwr_win_size = 4,
        .tot_pwr_win_size    = 7,
        .ook_ed_thr          = 0,
    },
    {
        // dr = 250K
        .init_gidx           = 31,
        .ib_tgt              = DIG_TRAN(0.0),
        .ed_thres            = {DIG_TRAN(-18.0), 0, 0, 0},
        .agc_timeout_max     = 0x0C80,
        .if_freq             = IF_FREQ_250KHZ,
        .iqk_tone_sel        = BBP_IQK_TONE_N250KHZ,
        .inband_pwr_win_size = 5,
        .tot_pwr_win_size    = 5,
        .ook_ed_thr          = 0x02f4,
        .pwr_ofs             = DIG_TRAN(3.0),
        .ed_ov_thr_prd       = 4,
    },
    {
        // dr = 500K
        .init_gidx           = 31,
        .ib_tgt              = DIG_TRAN(0),
        .ed_thres            = {DIG_TRAN(-12.0), 0, 0, 0},
        .agc_timeout_max     = 0x0640,
        .if_freq             = IF_FREQ_500KHZ,
        .iqk_tone_sel        = BBP_IQK_TONE_N500KHZ,
        .inband_pwr_win_size = 4,
        .tot_pwr_win_size    = 4,
        .ook_ed_thr          = 0x02f3,
        .pwr_ofs             = DIG_TRAN(3.0),
        .ed_ov_thr_prd       = 2,
    },
    {
        // dr = 1M
        .init_gidx           = 27,
        .ib_tgt              = DIG_TRAN(0),
        .ed_thres            = {DIG_TRAN(-13.0), 0, 0, 0},
        .agc_timeout_max     = 0x0640,
        .if_freq             = IF_FREQ_500KHZ,
        .iqk_tone_sel        = BBP_IQK_TONE_N500KHZ,
        .inband_pwr_win_size = 4,
        .tot_pwr_win_size    = 4,
        .ook_ed_thr          = 0,
        .pwr_ofs             = DIG_TRAN(3.0),
        .ed_ov_thr_prd       = 4,
    },
    {
        // dr = 2M
        // xcvr04 did not suppport 2M
    },
};

struct dr_para_t dr_para_mbus_er81xx[E_HAL_DR_MAX] = {
    {
        // dr = 4.8 kbps
        .init_gidx           = 25,
        .ib_tgt              = DIG_TRAN(-10.0),
        .ed_thres            = {DIG_TRAN(-31.0), 0, 0, 0},
        .agc_timeout_max     = 0x4E200,
        .if_freq             = IF_FREQ_250KHZ,
        .iqk_tone_sel        = BBP_IQK_TONE_N250KHZ,
        .inband_pwr_win_size = 12,
        .tot_pwr_win_size    = 12,
        .ook_ed_thr          = 0,
        .pwr_ofs             = DIG_TRAN(-6.0),
        .ed_ov_thr_prd       = 2,
    },
    {
        // dr = 12.5 kbps
    },
    {
         // dr = 32.768 kbps
        .init_gidx           = 25,
        .ib_tgt              = DIG_TRAN(0),
        .ed_thres            = {DIG_TRAN(-29.0), 0, 0, 0},
        .agc_timeout_max     = 0x1E84,
        .if_freq             = IF_FREQ_250KHZ,
        .iqk_tone_sel        = BBP_IQK_TONE_N250KHZ,
        .inband_pwr_win_size = 8,
        .tot_pwr_win_size    = 8,
        .ook_ed_thr          = 0,
        .pwr_ofs             = DIG_TRAN(3.0),
        .ed_ov_thr_prd       = 1,
    },
    {
        // dr = 50 kbps
    },
    {
        
        // dr = 100.0 kbps
        .init_gidx           = 31,
        .ib_tgt              = DIG_TRAN(0),
        .ed_thres            = {DIG_TRAN(-17.0), 0, 0, 0},
        .agc_timeout_max     = 0x1000,
        .if_freq             = IF_FREQ_250KHZ,
        .iqk_tone_sel        = BBP_IQK_TONE_N250KHZ,
        .inband_pwr_win_size = 7,
        .tot_pwr_win_size    = 7,
        .ook_ed_thr          = 0,
        .pwr_ofs             = DIG_TRAN(3.0),
        .ed_ov_thr_prd       = 1,
    },
    {
        // dr = 125 kbps
    },
    {
        // dr = 200 kbps
    },
    {
        // dr = 250 kbps
    },
    {
        // dr = 500 kbps
    },
    {
        // dr = 1000 kbps
    },
    {
        // dr = 2000 kbps
    },
};

uint32_t ifest_para[E_HAL_DR_MAX][BBP_IFEST_REG_NUM] = {
    [E_HAL_DR_4P8K] = 
        {   // dr = 4.8 kbps
            0x00259E70,
            0x003E82EE,
            0x00ED40C8,
            0x00C18D12,
            0x036A1DA8,
            0x031299C0,
            0x00960258,
            0x00ED8640,
        },
    [E_HAL_DR_32P768K] =     
        {   // dr = 32.768 kbps
            0x01DA9A89,
            0x00064F9C,
            0x0012C2BC,
            0x00F9C064,
            0x03831DA8,
            0x03511B50,
            0x007D0258,
            0x00AF04B0,
        },
    [E_HAL_DR_100K] =   
        {   // dr =100 kbps
            0x01f39ce1,
            0x001f40c8,
            0x00064190,
            0x00e0cf38,
            0x03c19ed4,
            0x039c1da8,
            0x003e812c,
            0x00640258,
        },
};

const uint32_t mbus_lpf[E_HAL_DR_MAX][RX_LPF_REG_PAIR_NUM] = {
    [E_HAL_DR_4P8K] =
        {   // dr = 4.8 kbps
            0xff8043fd,
            0xfd805bfc,
            0xf94093ff,
            0xec80b80f,
            0x500b787e,
        },
    [E_HAL_DR_32P768K] =   
        {   // dr = 32.768 kbps
            0x009ff800,
            0x00c013fe,
            0xfd007bf7,
            0xed0133fa,
            0x500c386c,
        },
    [E_HAL_DR_100K] =   
        {   // dr = 100 kbps
            0xffdfe3fe,
            0x04408006,
            0xf39f1800,
            0x26415be1,
            0x600930fd,
        },
};

uint32_t mbus_para[E_HAL_DR_MAX][5] = {
    [E_HAL_DR_4P8K] =
        {   // dr = 4.8 kbps
            0xBC00039B,
            0x00000022,
            0x003202ee,
            0x0000017f,
            0x03ad0389,
        },
    [E_HAL_DR_32P768K] =    
        {   // dr = 32.768 kbps
            0xBC00044E,
            0x00000022,
            0x003202ee,
            0x0000017f,
            0x04660437,
        },
    [E_HAL_DR_100K] = 
        {   // dr = 100 kbps
            0xbC0003e8,
            0x00000022,
            0x003202ee,
            0x0000017f,
            0x04f90312,
        },
};

uint32_t pe_pwr_thr_802154 = 0x00050805;
uint32_t pe_pwr_thr_mbus[E_HAL_DR_MAX] = {
    0x007F0805, //4.8 kbps
    0x0,        //12.5
    0x007F3F05, //32.768 kbps
    0x0,        //50
    0x007F3F05, //100 kbps
    0x0,        //125
    0x0,        //200
    0x0,        //250
    0x0,        //500
    0x0,        //1000
    0x0,        //2000
};

static BBP_INFO_T bbp_info = {0};
static uint8_t g_agc_idx_backup = 0;

BBP_INFO_T *bbp_get_bbp_info_er81xx(void)
{
    return &bbp_info;
}

void bbp_init_basic_para_er81xx(BBP_INFO_T *bbp, uint32_t mod_type,           uint8_t dr_idx)
{
    uint8_t i;

    bbp->gfo_para.gfo_en = 0;
    bbp->gfo_para.gfo_tim_thr_r1m = 15;
    bbp->gfo_para.gfo_tim_thr_r2m = 7;
    bbp->gfo_para.gfo_tim_thr_l1m = 8;
    bbp->gfo_para.gfo_tim_thr_l2m = 3;

    bbp->iqk_para.alpha_lmt = 6553;
    bbp->iqk_para.beta_lmt = 1638;
    bbp->iqk_para.set_iqk_lmt = FALSE;

    bbp->mod_info.ed_mode = (uint8_t)AGC_MULTI_ED_MODE;

    switch (mod_type) {
    case MOD_TYPE_OOK:
    case MOD_TYPE_FSK:
        bbp->mod_info.gain_loop       = 3;
        bbp->mod_info.bk_step         = 10;
        bbp->mod_info.pwr_ofs         = 24;
        bbp->mod_info.ed_ov_thr_prd   = 3;
        bbp->mod_info.pe_pwr_thr_lr   = 20;
        bbp->mod_info.pe_pwr_raise_lr = 8;
        bbp->mod_info.pe_pwr_thr      = 20;
        bbp->mod_info.pe_pwr_raise    = 8;
        break;
        
    case MOD_TYPE_GFSK:
        bbp->mod_info.gain_loop       = 3;
        bbp->mod_info.bk_step         = 10;
        if (dr_idx == E_HAL_DR_1M) {
            bbp->mod_info.bk_step = 7;
            bbp->gfo_para.gfo_en = 1;
        }
        bbp->mod_info.pwr_ofs         = 24;
        bbp->mod_info.ed_ov_thr_prd   = 2;
        bbp->mod_info.pe_pwr_thr_lr   = 20;
        bbp->mod_info.pe_pwr_raise_lr = 8;
        bbp->mod_info.pe_pwr_thr      = 20;
        bbp->mod_info.pe_pwr_raise    = 8;

        for (i = 0; i < E_HAL_DR_MAX; i++) {
            bbp->mod_info.dr_para[i] = &dr_para_gfsk_er81xx[i];
        }

        break;

    default:
        printf("%s: mod_type is wrong\n", __func__);
        bbp->mod_info.gain_loop       = 3;
        bbp->mod_info.bk_step         = 10;
        bbp->mod_info.pwr_ofs         = 24;
        bbp->mod_info.ed_ov_thr_prd   = 4;
        bbp->mod_info.pe_pwr_thr_lr   = 20;
        bbp->mod_info.pe_pwr_raise_lr = 8;
        bbp->mod_info.pe_pwr_thr      = 20;
        bbp->mod_info.pe_pwr_raise    = 8;

        for (i = 0; i < E_HAL_DR_MAX; i++) {
            bbp->mod_info.dr_para[i] = &dr_para_gfsk_er81xx[i];
        }

        break;
    }
}

static void bbp_set_gain_table_er81xx(void)
{
    uint32_t i, cfg_len;

    cfg_len = sizeof(bbp_agc_gain_table) / sizeof(bbp_agc_gain_table[0]);

    for (i = 0; i < cfg_len; i += 2) {
        REG_W32(bbp_agc_gain_table[i], bbp_agc_gain_table[i + 1]);
    }
}


static void bbp_set_lowpass_filt_er81xx(uint8_t phy_mode, uint8_t dr_idx, uint8_t mod_idx)
{
    uint32_t i;
    const uint32_t *lpf = NULL;
    
    if (phy_mode == PHY_MODE_MBUS) {
        lpf = &mbus_lpf[dr_idx][0];
        
        for (i = 0; i < RX_LPF_REG_PAIR_NUM; i++) {
            REG_W32(BBP_RXLPF_0_ADDR + (i * 4), *((uint32_t *)(lpf) + i));
        }
    } else {
        switch (dr_idx) {
            case E_HAL_DR_12P5K:
                lpf = bbp_rx_lpf_osr16[mod_idx];
                break;
            case E_HAL_DR_50K:
            case E_HAL_DR_100K:
            case E_HAL_DR_125K:
            case E_HAL_DR_250K:
            case E_HAL_DR_500K:
            case E_HAL_DR_1M:
            case E_HAL_DR_2M:
            default:
                lpf = bbp_rx_lpf_osr8[mod_idx];
                break;        
        }

        if (lpf) {
            for (i = 0; i< RX_LPF_REG_PAIR_NUM*2 ; i+=2)
                REG_W32(lpf[i], lpf[i+1]);
        }
    }
}

void bbp_set_osr_er81xx(uint32_t osr)
{
    uint32_t core52_reg, rate;

    rate = (osr == OSR16) ? (0) : (1);

    core52_reg = REG_R32(BBP_RATE_ADDR);
    core52_reg = (core52_reg & ~BBP_RATE_MASK) |
                 ((rate << BBP_RATE_POS) & BBP_RATE_MASK);
    REG_W32(BBP_RATE_ADDR, core52_reg);
}

void bbp_set_iqk_val_er81xx(uint32_t val)
{
    REG_W32(BBP_RX_IQ_P_ADDR, val);
}

uint32_t bbp_get_iqk_val_er81xx(void)
{
    return REG_R32(BBP_RX_IQ_P_ADDR);
}

void bbp_set_iqk_cfg_er81xx(BBP_INFO_T *bbp, uint8_t dr_idx)
{
    uint32_t reg;
    uint8_t iqk_tone_sel = bbp->mod_info.dr_para[dr_idx]->iqk_tone_sel;
    uint8_t iq_num       = 3;

    // 0x40028000[2:1] RXIQ_NUM
    // 0x40028000[14:12] PHY_TONE_SEL
    reg = REG_R32(BBP_RXIQCAL_ADDR);
    reg =
        (reg & ~(BBP_RG_BB_RXIQ_NUM_MASK + BBP_RG_PHY_TONE_SEL_MASK)) |
        ((iq_num << BBP_RG_BB_RXIQ_NUM_POS) & BBP_RG_BB_RXIQ_NUM_MASK) |
        ((iqk_tone_sel << BBP_RG_PHY_TONE_SEL_POS) & BBP_RG_PHY_TONE_SEL_MASK);
    REG_W32(BBP_RG_PHY_TONE_SEL_ADDR, reg);

    // 0x40028210
    REG_W32(BBP_RXIQCAL2_ADDR, 0x0);
}

void bbp_clean_iqk_cfg_er81xx(void)
{
}

void bbp_set_iqk_lmt_er81xx(BBP_INFO_T *bbp)
{
    if (!bbp->iqk_para.set_iqk_lmt) {
        return;
    }

    int16_t alpha        = 0;
    int16_t beta         = 0;
    uint32_t iqk_val     = 0;
    uint32_t iqk_val_wbk = 0;

    struct iqk_para_t curr_iqk_para = bbp->iqk_para;

    bbp_get_iqk_val_er81xx();
    alpha = (iqk_val >> 16) & 0xFFFF;
    beta  = iqk_val & 0xFFFF;
    alpha = (alpha > 0)
                ? ((alpha > curr_iqk_para.alpha_lmt) ? curr_iqk_para.alpha_lmt
                                                     : alpha)
                : ((alpha < (-curr_iqk_para.alpha_lmt))
                       ? (-curr_iqk_para.alpha_lmt)
                       : alpha);
    beta =
        (beta > 0)
            ? ((beta > curr_iqk_para.beta_lmt) ? curr_iqk_para.beta_lmt : beta)
            : ((beta < (-curr_iqk_para.beta_lmt)) ? (-curr_iqk_para.beta_lmt)
                                                  : beta);
    iqk_val_wbk = ((alpha & 0xFFFF) << 16) | (beta & 0xFFFF);

    if (iqk_val != iqk_val_wbk) {
        bbp_set_iqk_val_er81xx(iqk_val_wbk);
    }
}

void bbp_set_rx_syncword_er81xx(uint32_t *syncword, uint8_t sw_len)
{
    uint32_t reg;

    reg = REG_R32(BBP_CORR_ERR_CNT_ADDR);
    reg = (reg & ~(BBP_INT_CORRCODE_BYTE_NUM_MASK)) |
          (((sw_len - 1) << BBP_INT_CORRCODE_BYTE_NUM_POS) & BBP_INT_CORRCODE_BYTE_NUM_MASK);
    REG_W32(BBP_CORR_ERR_CNT_ADDR, reg);

    REG_W32(BBP_CORR_CODE_BT_BLE_ADDR, syncword[0]);
}

void bbp_set_rx_pn9_er81xx(uint8_t enable)
{
    uint32_t reg;

    reg = REG_R32(BBP_DEWHITEN_ADDR);
    reg = (reg & ~(BBP_DEWHITEN_INIT_VAL_MASK + BBP_DEWHITEN_EN_MASK)) |
          ((0x1FF << BBP_DEWHITEN_INIT_VAL_POS) & BBP_DEWHITEN_INIT_VAL_MASK) |
          ((enable << BBP_DEWHITEN_EN_POS) & BBP_DEWHITEN_EN_MASK);
    REG_W32(BBP_DEWHITEN_ADDR, reg);
}

void bbp_set_rx_fec_er81xx(uint8_t enable)
{
    uint32_t reg;

    reg = REG_R32(BBP_RX_FEC_CNTRL_ADDR);
    reg = (reg & ~(BBP_RX_FEC_BYPASS_MASK)) |
          (((!enable) << BBP_RX_FEC_BYPASS_POS) & BBP_RX_FEC_BYPASS_MASK);
    REG_W32(BBP_RX_FEC_CNTRL_ADDR, reg);
}

void bbp_get_rx_info_er81xx(RADIO_RX_INFO_T *rx_info)
{
    rx_info->rx_msr.gfo_est = REG_R32(BBP_GFO_EST_ADDR);
    rx_info->rx_msr.agc_idx = ((REG_R32(BBP_AGC_IDX_CUR_DEBUG_ADDR) & BBP_AGC_IDX_CUR_DEBUG_MASK) >> BBP_AGC_IDX_CUR_DEBUG_POS);
    rx_info->rx_msr.ib_pwr = ((REG_R32(BBP_AGC_INBANDPWR_DBM_ADDR) & BBP_AGC_INBANDPWR_DBM_MASK) >> BBP_AGC_INBANDPWR_DBM_POS);
    rx_info->rx_meta.rssi = (REG_R32(BBP_AGC_INBAND_RSSI_ADDR) & BBP_AGC_INBAND_RSSI_MASK);
}

uint32_t bbp_get_gfo_est_er81xx(void)
{
    return REG_R32(BBP_GFO_EST_ADDR);
}

uint8_t bbp_get_agc_idx_er81xx(void)
{
    return (uint16_t)((REG_R32(BBP_AGC43_ADDR) &
                       BBP_AGC_GAIN_TABLE_INITI_IDX_MASK) >>
                       BBP_AGC_GAIN_TABLE_INITI_IDX_POS);
}

void bbp_set_agc_idx_er81xx(uint8_t idx)
{
    g_agc_idx_backup = idx;

    uint32_t reg = REG_R32(BBP_AGC43_ADDR);
    reg &= ~BBP_AGC_GAIN_TABLE_INITI_IDX_MASK;
    reg |= ((idx << BBP_AGC_GAIN_TABLE_INITI_IDX_POS) & BBP_AGC_GAIN_TABLE_INITI_IDX_MASK);
    REG_W32(BBP_AGC43_ADDR, reg);
}

uint8_t bbp_get_backup_agc_idx_er81xx(void)
{
    if (g_agc_idx_backup == 0) {
        g_agc_idx_backup = bbp_get_agc_idx_er81xx();
    }
    return g_agc_idx_backup;
}

uint16_t bbp_get_inband_pwr_er81xx(void)
{
    return (uint16_t)((REG_R32(BBP_AGC_INBANDPWR_DBM_ADDR) &
                       BBP_AGC_INBANDPWR_DBM_MASK) >>
                      BBP_AGC_INBANDPWR_DBM_POS);
}

uint16_t bbp_get_rssi_er81xx(void)
{
    return (REG_R32(BBP_AGC_INBAND_RSSI_ADDR) & BBP_AGC_INBAND_RSSI_MASK);
}

uint8_t bbp_chk_rssi_rdy_er81xx(void)
{
    // 0 is ready, 1 is wait
    return ((REG_R32(BBP_AGC42_ADDR) & BBP_AGC_INBAND_RSSI_RDY_N_MASK) >>
            BBP_AGC_INBAND_RSSI_RDY_N_POS);
}

void bbp_set_rx_filt_er81xx(uint8_t phy_mode, uint8_t dr_idx, uint8_t mod_idx)
{
    bbp_set_lowpass_filt_er81xx(phy_mode, dr_idx, mod_idx);
}

void bbp_set_agc_er81xx(BBP_INFO_T *bbp, uint8_t phy_mode, uint32_t mod_type, uint8_t dr_idx, uint8_t mod_idx)
{
    uint32_t reg, thr_addr;

    struct dr_para_t *curr_dr_para = (phy_mode == PHY_MODE_MBUS) ? 
                                     (&dr_para_mbus_er81xx[dr_idx]) : 
                                     (bbp->mod_info.dr_para[dr_idx]);
    printf("dr_idx = %d, mod_idx = %d, phy_mode = %d\n", dr_idx, mod_idx, phy_mode);
    printf("time out = %ld\n", bbp->mod_info.dr_para[dr_idx]->agc_timeout_max);

    // agc24, set in-band target
    reg = REG_R32(BBP_AGC_INBAND_TARGET_ADDR);
    reg = (reg & ~BBP_AGC_INBAND_TARGET_MASK) |
          ((curr_dr_para->ib_tgt << BBP_AGC_INBAND_TARGET_POS) &
           BBP_AGC_INBAND_TARGET_MASK);
    REG_W32(BBP_AGC_INBAND_TARGET_ADDR, reg);

    // agc43, set initial gain index, power offset, and gfo
    reg = REG_R32(BBP_AGC_GAIN_TABLE_INITI_IDX_ADDR);
    reg = (reg &
           ~(BBP_AGC_GAIN_TABLE_INITI_IDX_MASK +
             BBP_AGC_PWR_OFFSET_INBAND_MASK + BBP_AGC_DONE_RST_GFO_EN_MASK)) |
          ((curr_dr_para->init_gidx << BBP_AGC_GAIN_TABLE_INITI_IDX_POS) & BBP_AGC_GAIN_TABLE_INITI_IDX_MASK) |
          ((curr_dr_para->pwr_ofs << BBP_AGC_PWR_OFFSET_INBAND_POS) & BBP_AGC_PWR_OFFSET_INBAND_MASK) |
          ((bbp->gfo_para.gfo_en << BBP_AGC_DONE_RST_GFO_EN_POS) & BBP_AGC_DONE_RST_GFO_EN_MASK);
    REG_W32(BBP_AGC_GAIN_TABLE_INITI_IDX_ADDR, reg);

    // agc20 & agc44, set ed threshold
    thr_addr = (AGC_MULTI_ED_MODE == ED_TYPE_THRES)
                   ? BBP_AGC_EG_PWR_THR_ADDR
                   : BBP_AGC_RAMP_UP_ED_THR_ADDR;
    reg      = REG_R32(thr_addr);

    if (AGC_MULTI_ED_MODE == ED_TYPE_THRES) {
        reg = (reg &
               ~(BBP_AGC_ED_OVER_THR_PERIOD_MASK + BBP_AGC_EG_PWR_THR_MASK)) |
              ((curr_dr_para->ed_ov_thr_prd << BBP_AGC_ED_OVER_THR_PERIOD_POS) & BBP_AGC_ED_OVER_THR_PERIOD_MASK) |
              ((curr_dr_para->ed_thres[mod_idx] << BBP_AGC_EG_PWR_THR_POS) & BBP_AGC_EG_PWR_THR_MASK);
    } else { // RAMP UP
        reg = (reg & ~BBP_AGC_RAMP_UP_ED_THR_MASK) |
              ((curr_dr_para->ed_thres[mod_idx] << BBP_AGC_RAMP_UP_ED_THR_POS) & BBP_AGC_RAMP_UP_ED_THR_MASK);
    }

    REG_W32(thr_addr, reg);

    // refine the AGC_INIT_SETTLE_TIME for MBUS 4.8 kbps 
    if (phy_mode == PHY_MODE_MBUS && dr_idx == E_HAL_DR_4P8K) {
        reg = REG_R32(BBP_AGC44_ADDR);
        reg = (reg & ~BBP_AGC_INIT_SETTLE_TIME_MASK) |
              ((0x100 << BBP_AGC_INIT_SETTLE_TIME_POS) & BBP_AGC_INIT_SETTLE_TIME_MASK);
        REG_W32(BBP_AGC44_ADDR, reg);
        printf("[bbp_set_agc_er81xx] phy_mode=%d, dr_idx=%d, reg = 0x%lx\n", phy_mode, dr_idx, reg);
    }

    // agc timeout max
    REG_W32(BBP_AGC_TIME_OUT_MAX_ADDR, curr_dr_para->agc_timeout_max);
}

void bbp_set_bpsk_gain_thd_er81xx(BBP_INFO_T *bbp)
{
    uint32_t reg;

    reg = REG_R32(BBP_BPSK_BPSK_RX_CTRL2_ADDR);
    reg = (reg & ~(BBP_BPSK_DIG_GAIN_MASK + BBP_BPSK_TR_THRESHOLD_MASK)) |
          ((bbp->mod_info.bpsk_dig_gain << BBP_BPSK_DIG_GAIN_POS) & BBP_BPSK_DIG_GAIN_MASK) |
          ((bbp->mod_info.bpsk_tr_thd << BBP_BPSK_TR_THRESHOLD_POS) &
           BBP_BPSK_TR_THRESHOLD_MASK);
    REG_W32(BBP_BPSK_BPSK_RX_CTRL2_ADDR, reg);
}

void bbp_set_agc_gian_update_loop_er81xx(uint8_t update_times)
{
    uint32_t reg;

    reg = REG_R32(BBP_AGC_GAIN_UPT_LOOP_MAX_ADDR);
    reg = (reg & ~(BBP_AGC_GAIN_UPT_LOOP_MAX_MASK)) |
          ((update_times << BBP_AGC_GAIN_UPT_LOOP_MAX_POS) & BBP_AGC_GAIN_UPT_LOOP_MAX_MASK);
    REG_W32(BBP_AGC_GAIN_UPT_LOOP_MAX_ADDR, reg);
}

void bbp_set_basic_cfg_er81xx(BBP_INFO_T *bbp, uint32_t mod_type,          uint8_t dr_idx)
{
    uint32_t reg;
    uint32_t mask;
    uint8_t rf_sat_prot_on = 0;
    uint32_t agc_rf_settle_time = 0x45;
    uint8_t digital_gain        = 0;
    struct gfo_para_t *gfo_para = &bbp->gfo_para;

    bbp_init_basic_para_er81xx(bbp, mod_type, dr_idx);

    bbp_set_pe_power_thr_er81xx(mod_type, dr_idx);

    bbp_set_gain_table_er81xx();

    mask =
        (BBP_INT_GFO_PEAKTIMETHR_1M_MASK + BBP_INT_GFO_PEAKTIMETHR_2M_MASK +
         BBP_INT_GFO_PEAKTIMETHRL_1M_MASK + BBP_INT_GFO_PEAKTIMETHRL_2M_MASK);
    reg = REG_R32(BBP_INT_GFO_PEAKTIMETHR_1M_ADDR);
    reg = (reg & ~mask) |
          ((gfo_para->gfo_tim_thr_r1m << BBP_INT_GFO_PEAKTIMETHR_1M_POS) & BBP_INT_GFO_PEAKTIMETHR_1M_MASK) |
          ((gfo_para->gfo_tim_thr_r2m << BBP_INT_GFO_PEAKTIMETHR_2M_POS) & BBP_INT_GFO_PEAKTIMETHR_2M_MASK) |
          ((gfo_para->gfo_tim_thr_l1m << BBP_INT_GFO_PEAKTIMETHRL_1M_POS) & BBP_INT_GFO_PEAKTIMETHRL_1M_MASK) |
          ((gfo_para->gfo_tim_thr_l2m << BBP_INT_GFO_PEAKTIMETHRL_2M_POS) & BBP_INT_GFO_PEAKTIMETHRL_2M_MASK);
    REG_W32(BBP_INT_GFO_PEAKTIMETHR_1M_ADDR, reg);

    // set times of agc gain loop update, saturate back off step
    reg = REG_R32(BBP_AGC_GAIN_UPT_LOOP_MAX_ADDR);
    reg = (reg &
           ~(BBP_AGC_GAIN_UPT_LOOP_MAX_MASK + BBP_AGC_SAT_BACKOFF_STEP_MASK +
             BBP_AGC_RF_SAT_PROTECT_ON_MASK)) |
          ((bbp->mod_info.gain_loop << BBP_AGC_GAIN_UPT_LOOP_MAX_POS) & BBP_AGC_GAIN_UPT_LOOP_MAX_MASK) |
          ((bbp->mod_info.bk_step << BBP_AGC_SAT_BACKOFF_STEP_POS) & BBP_AGC_SAT_BACKOFF_STEP_MASK) |
          ((rf_sat_prot_on << BBP_AGC_RF_SAT_PROTECT_ON_POS) & BBP_AGC_RF_SAT_PROTECT_ON_MASK);
    REG_W32(BBP_AGC_GAIN_UPT_LOOP_MAX_ADDR, reg);

    // set ed detection mode
    reg = REG_R32(BBP_AGC_MULTI_ED_MODE_ADDR);
    reg = (reg & ~BBP_AGC_MULTI_ED_MODE_MASK) |
          ((bbp->mod_info.ed_mode << BBP_AGC_MULTI_ED_MODE_POS) & BBP_AGC_MULTI_ED_MODE_MASK);
    REG_W32(BBP_AGC_MULTI_ED_MODE_ADDR, reg);

    if (mod_type == MOD_TYPE_FSK && dr_idx == E_HAL_DR_100K) {
        agc_rf_settle_time = 0x8A;
    }

    // set rf settle time
    reg = REG_R32(BBP_AGC_RF_SETTLE_TIME_ADDR);
    reg = (reg & ~BBP_AGC_RF_SETTLE_TIME_MASK) |
          ((agc_rf_settle_time << BBP_AGC_RF_SETTLE_TIME_POS) & BBP_AGC_RF_SETTLE_TIME_MASK);
    REG_W32(BBP_AGC_RF_SETTLE_TIME_ADDR, reg);

    // dig_gain (0xb400)
    reg = REG_R32(BBP_DIGIT_GAIN_ADDR);
    reg = (reg & ~BBP_DIGIT_GAIN_SEL_MASK) |
          ((digital_gain << BBP_DIGIT_GAIN_SEL_POS) & BBP_DIGIT_GAIN_SEL_MASK);
    REG_W32(BBP_DIGIT_GAIN_ADDR, reg);
}

void bbp_set_tx_filt_er81xx(uint32_t mod_type, HAL_DATA_RATE_T dr_idx)
{
    uint32_t reg          = 0;
    uint8_t tx_srrc_scale = 0;
    uint8_t tx_cic_scale  = 0;
    uint8_t tx_cic_mul    = 0;
    uint8_t tx_cic_rate   = 0;

    if (mod_type == MOD_TYPE_BPSK) {
        switch (dr_idx) {
        case E_HAL_DR_1M:
            tx_srrc_scale = 2;
            tx_cic_scale  = 7;
            tx_cic_mul    = 0x80;
            tx_cic_rate   = 4;
            break;

        case E_HAL_DR_500K:
            tx_srrc_scale = 2;
            tx_cic_scale  = 5;
            tx_cic_mul    = 0x80;
            tx_cic_rate   = 8;
            break;

        case E_HAL_DR_250K:
            tx_srrc_scale = 2;
            tx_cic_scale  = 3;
            tx_cic_mul    = 0x80;
            tx_cic_rate   = 0x10;
            break;

        case E_HAL_DR_200K:
            tx_srrc_scale = 2;
            tx_cic_scale  = 2;
            tx_cic_mul    = 0x80;
            tx_cic_rate   = 0x14;
            break;

        case E_HAL_DR_100K:
            tx_srrc_scale = 2;
            tx_cic_scale  = 0;
            tx_cic_mul    = 0x80;
            tx_cic_rate   = 0x28;
            break;

        default:
            //DBG_PRINT("data_rate did not support: dr_idx = %d\n", dr_idx);
            break;
        }

        // TX_FILTER_CFG0 (0x004)
        reg = REG_R32(BBP_BPSK_BPSK_TX_FILTER_CFG0_ADDR);
        reg =
            (reg & ~(BBP_BPSK_TX_SRRC_SCALE_MASK + BBP_BPSK_TX_CIC_SCALE_MASK +
                     BBP_BPSK_TX_CIC_MUL_MASK + BBP_BPSK_TX_CIC_RATE_MASK)) |
            ((tx_srrc_scale << BBP_BPSK_TX_SRRC_SCALE_POS) & BBP_BPSK_TX_SRRC_SCALE_MASK) |
            ((tx_cic_scale << BBP_BPSK_TX_CIC_SCALE_POS) & BBP_BPSK_TX_CIC_SCALE_MASK) |
            ((tx_cic_mul << BBP_BPSK_TX_CIC_MUL_POS) & BBP_BPSK_TX_CIC_MUL_MASK) |
            ((tx_cic_rate << BBP_BPSK_TX_CIC_RATE_POS) & BBP_BPSK_TX_CIC_RATE_MASK);
        REG_W32(BBP_BPSK_BPSK_TX_FILTER_CFG0_ADDR, reg);
    }
}

void bbp_set_user_cfg_er81xx(void)
{
    uint32_t i, cfg_len;

    cfg_len = sizeof(bbp_setup_arr_user_cfg) / sizeof(bbp_setup_arr_user_cfg[0]);

    for (i = 0; i < cfg_len; i += 2) {
        REG_W32(bbp_setup_arr_user_cfg[i], bbp_setup_arr_user_cfg[i + 1]);
    }
}

void bbp_set_pop_clip_er81xx(void)
{
    uint32_t reg = 0;
    uint8_t pop_reset_en = 0;
    uint8_t dig_clip_alm_en = 0;
    uint8_t ana_clip_alm_en = 1;
    uint8_t rf_overflow_flag_en = 0;
    uint8_t to_reset_en = 1;

    // reg 0x4002830C
    reg = REG_R32(BBP_POP_CLIPPING_ADDR);
    reg = (reg & ~(BBP_POP_RESET_EN_MASK + BBP_AGC_DIG_CLIP_ALARM_ENABLE_MASK +
                   BBP_AGC_ANA_CLIP_ALARM_ENABLE_MASK + BBP_AGC_RF_OVERFLOW_FLAG_ENABLE_MASK + 
                   BBP_TO_RESET_EN_MASK)) |
          ((pop_reset_en << BBP_POP_RESET_EN_POS) & BBP_POP_RESET_EN_MASK) |
          ((dig_clip_alm_en << BBP_AGC_DIG_CLIP_ALARM_ENABLE_POS) & BBP_AGC_DIG_CLIP_ALARM_ENABLE_MASK) |
          ((ana_clip_alm_en << BBP_AGC_ANA_CLIP_ALARM_ENABLE_POS) & BBP_AGC_ANA_CLIP_ALARM_ENABLE_MASK) |
          ((rf_overflow_flag_en << BBP_AGC_RF_OVERFLOW_FLAG_ENABLE_POS) & BBP_AGC_RF_OVERFLOW_FLAG_ENABLE_MASK) |
          ((to_reset_en << BBP_TO_RESET_EN_POS) & BBP_TO_RESET_EN_MASK);
    REG_W32(BBP_POP_CLIPPING_ADDR, reg);
}

void bbp_set_win_size_er81xx(BBP_INFO_T *bbp, uint8_t phy_mode, uint8_t dr_idx)
{
    uint32_t reg;

    uint8_t tot_pwr_win_size      = (phy_mode == PHY_MODE_MBUS) ?
                                    (dr_para_mbus_er81xx[dr_idx].tot_pwr_win_size) :
                                    (bbp->mod_info.dr_para[dr_idx]->tot_pwr_win_size);
    uint8_t inb_pwr_win_size      = (phy_mode == PHY_MODE_MBUS) ?
                                    (dr_para_mbus_er81xx[dr_idx].inband_pwr_win_size) :
                                    (bbp->mod_info.dr_para[dr_idx]->inband_pwr_win_size);
    uint8_t inb_pwr_ed_win_size   = 0x5;
    uint8_t inb_pwr_rssi_win_size = 0x8;
    uint8_t tot_pwr_rssi_win_size = 0x6;

    // 0xB208
    reg = REG_R32(BBP_AGC45_ADDR);
    reg =
        (reg & ~(BBP_AGC_TOTPWR_WINSIZE_MASK + BBP_AGC_INBANDPWR_WINSIZE_MASK +
                 BBP_AGC_INBANDPWR_ED_WINSIZE_MASK +
                 BBP_AGC_INBANDPWR_RSSI_WINSIZE_MASK +
                 BBP_AGC_TOTPWR_RSSI_WINSIZE_MASK)) |
        ((tot_pwr_win_size << BBP_AGC_TOTPWR_WINSIZE_POS) & BBP_AGC_TOTPWR_WINSIZE_MASK) |
        ((inb_pwr_win_size << BBP_AGC_INBANDPWR_WINSIZE_POS) & BBP_AGC_INBANDPWR_WINSIZE_MASK) |
        ((inb_pwr_ed_win_size << BBP_AGC_INBANDPWR_ED_WINSIZE_POS) & BBP_AGC_INBANDPWR_ED_WINSIZE_MASK) |
        ((inb_pwr_rssi_win_size << BBP_AGC_INBANDPWR_RSSI_WINSIZE_POS) & BBP_AGC_INBANDPWR_RSSI_WINSIZE_MASK) |
        ((tot_pwr_rssi_win_size << BBP_AGC_TOTPWR_RSSI_WINSIZE_POS) & BBP_AGC_TOTPWR_RSSI_WINSIZE_MASK);
    REG_W32(BBP_AGC45_ADDR, reg);
}

void bbp_set_pe_power_thr_er81xx(uint32_t mod_type,          uint8_t dr_idx)
{
    uint32_t *pe_pwr_thr;

    switch (mod_type) {
    case MOD_TYPE_FSK:
        pe_pwr_thr = &pe_pwr_thr_mbus[dr_idx];
        break;
    case MOD_TYPE_BPSK:
    case MOD_TYPE_QPSK:
    case MOD_TYPE_GFSK:
    case MOD_TYPE_OQPSK:
    case MOD_TYPE_BPSK_RAMP:
    case MOD_TYPE_OOK:
    default:
        pe_pwr_thr = &pe_pwr_thr_802154;
        if (dr_idx == E_HAL_DR_100K) {
            *pe_pwr_thr = 0x002E0805;
        }
        break;
    }
    REG_W32(BBP_PE_POWERTHR_ADDR, *pe_pwr_thr);
}

void bbp_set_ifest_er81xx(uint8_t dr_idx)
{
#if 0
    uint32_t i;
    uint32_t reg = 0;
    uint8_t mbus_mode = 1;

    reg = REG_R32(BBP_MBUS1_ADDR);
    reg = (reg & ~BBP_MBUS_MODE_MASK) |
         ((mbus_mode << BBP_MBUS_MODE_POS) & BBP_MBUS_MODE_MASK);
    REG_W32(BBP_MBUS1_ADDR, reg);

    for (i = 0; i < BBP_IFEST_REG_NUM; i++) {
        REG_W32(BBP_IFEST1_ADDR + (i * 4), *((uint32_t *)(&ifest_para[dr_idx][0]) + i));
    }
#endif
}

void bbp_set_gfo_est_er81xx(uint8_t dr_idx)
{
    uint32_t reg = 0;
    uint8_t gfo_ensw = 0;
    uint8_t gfo_enpl = 1;
    uint8_t omega_div = 0;
    uint8_t gfo_det_lock = 4;

    switch (dr_idx) {
        case E_HAL_DR_4P8K:
            gfo_ensw = 1;
            gfo_enpl = 1;
            omega_div = 1;
            gfo_det_lock = 4;
            break;
        case E_HAL_DR_32P768K:
            gfo_ensw = 0;
            gfo_enpl = 1;
            omega_div = 1;
            gfo_det_lock = 4;
            break;
        case E_HAL_DR_100K:
            gfo_ensw = 0;
            gfo_enpl = 1;
            omega_div = 0;
            gfo_det_lock = 4;
            break;
        default:
            gfo_ensw = 0;
            gfo_enpl = 1;
            omega_div = 0;
            gfo_det_lock = 4;
            break;
    }

    reg = REG_R32(BBP_RXGFSK_CNTL_ADDR);
    reg = (reg & ~(BBP_INT_GFO_ENSW_MASK + BBP_INT_GFO_ENPL_BLE_MASK + BBP_INT_GFO_ENPL_BT_MASK)) |
         ((gfo_ensw << BBP_INT_GFO_ENSW_POS) & BBP_INT_GFO_ENSW_MASK) |
         ((gfo_enpl << BBP_INT_GFO_ENPL_BLE_POS) & BBP_INT_GFO_ENPL_BLE_MASK) |
         ((gfo_enpl << BBP_INT_GFO_ENPL_BT_POS) & BBP_INT_GFO_ENPL_BT_MASK) |
         ((omega_div << BBP_INT_PSD_OMEGA_DIV2_EN_POS) & BBP_INT_PSD_OMEGA_DIV2_EN_MASK);
    REG_W32(BBP_RXGFSK_CNTL_ADDR, reg);

    reg = REG_R32(BBP_GFO_GFSKDETECT_ADDR);
    reg = (reg & ~BBP_INT_GFO_DETECTLOCK_MASK) |
         ((gfo_det_lock << BBP_INT_GFO_DETECTLOCK_POS) & BBP_INT_GFO_DETECTLOCK_MASK);
    REG_W32(BBP_GFO_GFSKDETECT_ADDR, reg);
}

void bbp_set_ddc_if_phi_er81xx(uint8_t phy_mode, uint32_t data_rate)
{
    uint32_t reg = 0;
    uint32_t adc_clk = 0;
    uint32_t lo = 0;
    uint32_t if_phi = 0;

    if (phy_mode == PHY_MODE_MBUS && data_rate == DATA_RATE_100K) {
        return;
    }

    if (phy_mode == PHY_MODE_MBUS && data_rate == DATA_RATE_50K) {
        adc_clk = 4000;
        lo = 250;
    } else {
        switch (data_rate) {
            case DATA_RATE_1M:
                adc_clk = 8000;
                lo = 750;
                break;
            case DATA_RATE_500K:
                adc_clk = 8000;
                lo = 500;
                break;
            case DATA_RATE_250K:
            case DATA_RATE_200K:
            case DATA_RATE_125K:
            case DATA_RATE_100K:
            case DATA_RATE_50K:
            case DATA_RATE_12P5K:
                adc_clk = 8000;
                lo = 250;
                break;
            case DATA_RATE_32P768K:
            case DATA_RATE_4P8K:
                adc_clk = 4000;
                lo = 250;
                break;
            default:
                adc_clk = 8000;
                lo = 250;
                break;
        }
    }
    if_phi = lo * 0x10000 / adc_clk;
    // reg 0x400280F0
    reg = REG_R32(BBP_DDC_CIC_ADDR);
    reg = (reg & ~BBP_DDC_IF_PHI_MASK) | 
          ((if_phi << BBP_DDC_IF_PHI_POS) & BBP_DDC_IF_PHI_MASK);
    REG_W32(BBP_DDC_CIC_ADDR, reg);
}

void bbp_set_bt_rate_er81xx(uint8_t phy_mode, uint8_t mod_type, uint32_t data_rate, uint8_t mod_idx)
{
    uint32_t rate = 1;

    if ((phy_mode == PHY_MODE_MBUS && data_rate == DATA_RATE_4P8K) ||
        ((phy_mode == PHY_MODE_TRANSPARENT || phy_mode == PHY_MODE_802154) &&
          data_rate == DATA_RATE_12P5K/* && mod_idx == MOD_IDX_4*/) ||
        (phy_mode == PHY_MODE_MBUS && mod_type == MOD_TYPE_GFSK && data_rate == DATA_RATE_50K)) {
        rate = 0;
    }

    uint32_t reg = REG_R32(BBP_RATE_ADDR);
    reg &= ~BBP_RATE_MASK;
    reg |= (rate << BBP_RATE_POS) & BBP_RATE_MASK;
    REG_W32(BBP_RATE_ADDR, reg);
}

void bbp_setup_er81xx(uint8_t phy_mode, uint32_t data_rate, uint8_t mod_idx, uint8_t wmbus_mode)
{
    uint32_t group_count;
    const uint32_t (*cfgs)[2] = NULL;
    uint32_t arr_size = 0;
    const uint32_t (*lpf)[2] = NULL;
    uint8_t found = 0;
    uint32_t i, j;
            

    /*===== BB basic setting =====*/
    
    for (i = 0; i < sizeof(bbp_basic_setting) / sizeof(bbp_basic_setting[0]); i++) {
        REG_W32(bbp_basic_setting[i][0], bbp_basic_setting[i][1]);
    }

    for (i = 0; i < sizeof(bbp_gain_table) / sizeof(bbp_gain_table[0]); i++) {
        REG_W32(bbp_gain_table[i][0], bbp_gain_table[i][1]);
    }

    /*===== BB set by phy mode =====*/

    if (phy_mode == PHY_MODE_TRANSPARENT || phy_mode == PHY_MODE_802154) {
        group_count = sizeof(modem_config_group_normal) / sizeof(MODEM_CFG_GRP);
        for (i = 0; i < group_count && !found; ++i) {
            const MODEM_CFG_GRP *group = &modem_config_group_normal[i];

            if (group->data_rate != data_rate)
                continue;

            for (j = 0; j < group->mod_count; ++j) {
                const MODIDX_CSR_CFG *mod_cfg = &group->modidx_cfgs[j];

                if (mod_cfg->mod_idx == mod_idx) {
                    cfgs = mod_cfg->config;
                    arr_size = mod_cfg->config_size;
                    lpf = mod_cfg->lpf;
                    found = true;
                    break;
                }
            }
        }
    }

    if (phy_mode == PHY_MODE_MBUS) {
        group_count = sizeof(modem_config_group_wmbus) / sizeof(MODEM_CFG_GRP_WMBUS);
        for (i = 0; i < group_count && !found; ++i) {
            const MODEM_CFG_GRP_WMBUS *group = &modem_config_group_wmbus[i];

            if (group->data_rate != data_rate || group->wmbus_mode != wmbus_mode)
                continue;

            for (j = 0; j < group->mod_count; ++j) {
                const MODIDX_CSR_CFG *mod_cfg = &group->modidx_cfgs[j];

                if (mod_cfg->mod_idx == mod_idx) {
                    cfgs = mod_cfg->config;
                    arr_size = mod_cfg->config_size;
                    lpf = mod_cfg->lpf;
                    found = true;
                    break;
                }
            }
        }
    }
    
    if (cfgs != NULL) {
        for (i = 0; i < arr_size; i++) {
            REG_W32(cfgs[i][0], cfgs[i][1]);
        }
    } else {
        printf("%s: cfgs is null\n", __func__);
    }

    if (lpf != NULL) {
        for (i = 0; i < 5; i++) {
            REG_W32(lpf[i][0], lpf[i][1]);
        }
    } else {
        printf("%s: lpf is null\n", __func__);
    }

}


void bbp_set_agc_mode_er81xx(uint8_t mode, uint8_t gain_idx)
{
    uint32_t reg = REG_R32(BBP_AGC_MODE_ADDR);
    reg &= ~(BBP_AGC_MODE_MASK | BBP_AGC_IDX_CUR_DEBUG_MASK);
    reg |= (((mode << BBP_AGC_MODE_POS) & BBP_AGC_MODE_MASK) |
            ((gain_idx << BBP_AGC_IDX_CUR_DEBUG_POS) & BBP_AGC_IDX_CUR_DEBUG_MASK));
    REG_W32(BBP_AGC_MODE_ADDR, reg);
}

void bbp_set_ed_threshold_er81xx(int16_t ed_thres)
{
    uint32_t reg = REG_R32(BBP_AGC20_ADDR);
    reg &= ~(BBP_AGC_EG_PWR_THR_MASK);
    reg |= (((ed_thres * 8) << BBP_AGC_EG_PWR_THR_POS) & BBP_AGC_EG_PWR_THR_MASK);
    REG_W32(BBP_AGC20_ADDR, reg);
}

void bbp_enable_cdr_est_er81xx(uint8_t enable)
{
    uint32_t reg = REG_R32(BBP_MBUS1_ADDR);
    reg &= ~BBP_MBUS_MODE_MASK;
    reg |= (enable << BBP_MBUS_MODE_POS) & BBP_MBUS_MODE_MASK;
    REG_W32(BBP_MBUS1_ADDR, reg);
}

void bbp_set_wmbus_rx_extra_cfg_er81xx(uint8_t wmbus_mode, uint32_t data_rate)
{
#if WMBUS_SCENARIO_REDUCE_FALSE_ALARM
    switch(wmbus_mode) {
    case HAL_WMBUS_MODE_S:
    case HAL_WMBUS_MODE_T:
        if (data_rate == 100000) {
            REG_W32(0x40028100, 0x00BC2AAA);
            REG_W32(0x40028104, 0x0005CC00);
            REG_W32(0x40028310, 0xFC0003E8);
            REG_W32(0x4002825C, 0x00000000);
            REG_W32(0x400280A8, 0x6F80370E);
            REG_W32(0x400280D0, 0x003F0805);
            };
        if (data_rate == 32768) {
            REG_W32(0x40028100, 0x00696E2A);
            REG_W32(0x40028104, 0x0005CC00);
            REG_W32(0x40028310, 0xFC00044E);
            REG_W32(0x4002825C, 0x00000000);
            REG_W32(0x400280A8, 0x6F80370E);
            REG_W32(0x400280D0, 0x003F0805);
            };
        break;
    case HAL_WMBUS_MODE_C:
        if (data_rate == 100000) {
            REG_W32(0x40028100, 0x00B32ABC);
            REG_W32(0x40028104, 0x0005CC00);
            REG_W32(0x40028310, 0xFC0003E8);
            REG_W32(0x4002825C, 0x00000000);
            REG_W32(0x400280A8, 0x6F80370E);
            REG_W32(0x400280D0, 0x003F0805);
            };
        if (data_rate == 50000) {
            REG_W32(0x40028100, 0x00B32ABC);
            REG_W32(0x40028104, 0x0005CC00);
            };
        break;
    case HAL_WMBUS_MODE_R:
            REG_W32(0x40028100, 0x00696E2A);
            REG_W32(0x40028104, 0x0005CC00);
            REG_W32(0x40028310, 0xB00003E5);
            REG_W32(0x4002825C, 0x00000000);
            REG_W32(0x400280A8, 0x6F80370E);
            REG_W32(0x400280D0, 0x003F0805);
        break;
    default:
        printf("wmbus_mode is bad = %d\n", wmbus_mode);
    }
#endif    
}

