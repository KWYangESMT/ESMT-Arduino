/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "wise_radio_api.h"
#include "wise_radio_wmbus_api.h"
#include "util.h"
#include "wise_core.h"
#include "wise_tick_api.h"
#include "hal_intf_pmu.h"

#include "drv/hal_drv_pmu.h"
#include "hal_drv_radio.h"
#include "hal_intf_radio.h"
#include "util_crc.h"
#include "util_debug_log.h"
#include "internal_radio_ctrl.h"


#ifndef LIB_PLATFORM_NAME
#define LIB_PLATFORM_NAME 		                "None"
#endif

#ifndef LIB_PLATFORM_ID
#define LIB_PLATFORM_ID 		                0
#endif

#ifndef LIB_VERSION_MAJOR
#define LIB_VERSION_MAJOR 		                0
#endif

#ifndef LIB_VERSION_MINOR
#define LIB_VERSION_MINOR 		                0
#endif

#ifndef LIB_VERSION_BUILD
#define LIB_VERSION_BUILD 		                0
#endif

#ifndef LIB_GIT_SHA
#define LIB_GIT_SHA				                0
#endif

//kevinyang, 20250525, only for internal usage
#define RADIO_STS_TX                            (RADIO_STS_TX_ARMED | RADIO_STS_TX_FIRED | RADIO_STS_TX_FIN | RADIO_STS_TX_ERR)
#define RADIO_STS_RX                            (RADIO_STS_RX_ON | RADIO_STS_RX_BUF_FULL | RADIO_STS_RX_PAUSED)

#define RX_FRAME_META(pframe)                   ((WISE_RX_META_T *)&(((uint8_t *)pframe)[intf_cfg->rx_meta_offset]))
#define RADIO_RSSI_CALC(rawRssi)                (-((int8_t)((0x1000 - (uint16_t)rawRssi) >> 3)))
#define RADIO_ALIGN_16(addr)                    ((addr + 15) & 0xfffffff0)

#define RADIO_FRAME_GUARD_LEN                   16

#define TX_TIMEOUT                              2000UL // ms

// internal radio status flags
#define RADIO_STS_TX_ARMED                      BIT0
#define RADIO_STS_TX_FIRED                      BIT1
#define RADIO_STS_TX_FIN                        BIT2
#define RADIO_STS_TX_ERR                        BIT3
#define RADIO_STS_RX_ON                         BIT4
#define RADIO_STS_RX_BUF_FULL                   BIT5
#define RADIO_STS_RX_PAUSED                     BIT6
#define RADIO_STS_RX_CAL                        BIT7

// internal radio interface config status
#define RADIO_INTF_CFG_VALID                    BIT0
#define RADIO_INTF_FMT_VALID                    BIT1
#define RADIO_INTF_BUF_VALID                    BIT2
//#define RADIO_INTF_SW_FRAME                     BIT3 //frame processed by software
#define RADIO_INTF_TX_SW_FRAME                  BIT3
#define RADIO_INTF_RX_SW_FRAME                  BIT4

//#define RADIO_DEBUG_RAW_FRAME

typedef struct
{
    uint32_t drValue;
    uint32_t rxByteTime; //us
} ST_DR_INTERNAL_PARAM_T;

typedef struct {
    int8_t phy_idx;
} ISR_CB_DATA_RADIO_T;

const ST_DR_INTERNAL_PARAM_T RADIO_DR_VALUE[] = 
{
    {4800,      0},         //E_DATA_RATE_4P8K
    {12500,     0},         //E_DATA_RATE_12P5K
    {32768,     0},         //E_DATA_RATE_32P768K
    {50000,     0},         //E_DATA_RATE_50K
    {100000,    100},       //E_DATA_RATE_100K
    {125000,    0},         //E_DATA_RATE_125K
    {200000,    0},         //E_DATA_RATE_200K
    {250000,    0},         //E_DATA_RATE_250K
    {500000,    20},        //E_DATA_RATE_500K
    {1000000,   0},         //E_DATA_RATE_1M
    {2000000,   0},         //E_DATA_RATE_2M
};

typedef struct
{
    uint8_t dataRateIdx;
    uint16_t threshold;
} ST_RX_CALIB_T;

static ISR_CB_DATA_RADIO_T radio_isr_cb_data[RADIO_PHY_NUM] = {0};
static RADIO_INTF_CFG_T radio_intf_cfg[RADIO_PHY_NUM]       = {0};

static RX_VALIDATE_PROC_T rxDataValidate = NULL;
static RX_SYNC_CALLBACK_T rxSyncCallback = NULL;

//static uint16_t radio_rx_signal_thres = RX_INVALID_SIG_THRES;
static ST_RX_CALIB_T rxSigThres = {0xff, RX_INVALID_SIG_THRES};
static TPM_CAL_PARA* txTpmCalib = NULL;

static uint8_t g_sg_mode_flag = 0; //kevinayng, 20251122, moved from app layer to keep independence of core layer

static void _radio_tx_fire(RADIO_INTF_CFG_T *intf_cfg);
//static int8_t _radio_wait_tx_finish(RADIO_INTF_CFG_T *intf_cfg);
static void _radio_rx_start(RADIO_INTF_CFG_T *intf_cfg, uint8_t ch_index);
static void _radio_rx_stop(RADIO_INTF_CFG_T *intf_cfg);
static void _radio_rx_pause(RADIO_INTF_CFG_T *intf_cfg);
static void _radio_rx_resume(RADIO_INTF_CFG_T *intf_cfg);
static int32_t _setup_sw_crc(int8_t intf_idx);
static int32_t _setup_hw_crc(int8_t intf_idx, RADIO_CFG_T *p_hal_radio);
static uint32_t _sw_radio_crc_calc(RADIO_INTF_CFG_T *intf_cfg, uint8_t *crc_start, uint16_t crc_len, uint32_t crc_init_val);
static int8_t _validate_rx_frame(RADIO_INTF_CFG_T *intf_cfg, uint8_t *pframe);
static int16_t _radio_ch_index(RADIO_INTF_CFG_T *intf_cfg, uint32_t ch_freq);
static inline void _update_rx_state(RADIO_INTF_CFG_T *intf_cfg);
static inline void _process_rx_metadata(RADIO_INTF_CFG_T *intf_cfg, RADIO_FRAME_META_T *meta, uint8_t *pframe, WISE_RX_META_T *rx_meta);
static inline void _validate_rx_data(RADIO_INTF_CFG_T *intf_cfg, uint8_t *pframe, WISE_RX_META_T *rx_meta, uint32_t status);
static inline void _handle_rx_event(RADIO_INTF_CFG_T *intf_cfg, uint32_t status);
static void _radio_isr_internal(void *pdata);
static void _setup_radio_buffer(RADIO_INTF_CFG_T *intf_cfg);
static void _radio_reset_ch_map(RADIO_INTF_CFG_T *intf_cfg);
static uint32_t _radio_get_active_ch_freq(RADIO_INTF_CFG_T *intf_cfg, uint8_t direction);
static void _reset_rx_buffer(RADIO_INTF_CFG_T *intf_cfg);
static void _radio_setup_frame_path(RADIO_INTF_CFG_T *intf_cfg);
static int8_t _radio_config(int8_t intf_idx, RADIO_INTF_CFG_T *intf_cfg);
static int8_t _radio_mbus_config(int8_t intf_idx, RADIO_INTF_CFG_T *intf_cfg, uint8_t isTx);
static int8_t _radio_calibration(RADIO_INTF_CFG_T *intf_cfg);
static void _radio_data_bit_reverse(uint8_t* destBuffer, uint8_t* srcBuffer, int len);
//static uint16_t _sw_rx_syncword_handler(RADIO_INTF_CFG_T *intf_cfg, uint8_t *pframe);
static void _radio_tx_state_transition(RADIO_INTF_CFG_T *intf_cfg);

void _wmbus_set_init(int8_t intf_idx);
void _wmbus_set_deinit(int8_t intf_idx);
void _wmbus_set_mode(int8_t intf_idx, wmbus_mode_t mode);
void _wmbus_set_tx_config(int8_t intf_idx, WISE_RADIO_CFG_T *cfg, WISE_RADIO_PKT_FMT_T *pkt_fmt);
void _wmbus_set_rx_config(int8_t intf_idx, WISE_RADIO_CFG_T *cfg, WISE_RADIO_PKT_FMT_T *pkt_fmt);
void _wmbus_set_rx_validate_proc(RX_VALIDATE_PROC_T rxValidateProc);
void _wmbus_set_rx_sync_callback(RX_SYNC_CALLBACK_T rxSyncProc);

void _ieee802154_set_init(int8_t intf_idx);

//internal test APIs
void _wise_radio_get_rx_info_output(int8_t intf_idx);
void _wise_radio_set_phy_mode(int8_t intf_idx, uint8_t phy_mode);
uint8_t _wise_radio_get_phy_mode(int8_t intf_idx);
void _wise_radio_set_sg_test_mode(uint8_t enable);
uint8_t _wise_radio_get_sg_test_mode();
void _wise_radio_test(void);


void _wmbus_set_init(int8_t intf_idx)
{
    radio_intf_cfg[intf_idx].phy_init_mode = PHY_INIT_WMBUS;
    radio_intf_cfg[intf_idx].phy_mode = E_PHY_MBUS;
}

void _ieee802154_set_init(int8_t intf_idx)
{
    radio_intf_cfg[intf_idx].phy_init_mode = PHY_INIT_802154;
    radio_intf_cfg[intf_idx].phy_mode = E_PHY_802154;
}


void _wmbus_set_deinit(int8_t intf_idx)
{
    rxDataValidate = NULL;
    radio_intf_cfg[intf_idx].phy_init_mode = PHY_INIT_NONE;
}

void _wmbus_set_rx_validate_proc(RX_VALIDATE_PROC_T rxValidateProc)
{
    rxDataValidate = rxValidateProc;
}

void _wmbus_set_rx_sync_callback(RX_SYNC_CALLBACK_T rxSyncProc)
{
    rxSyncCallback = rxSyncProc;
}

static void _radio_tx_fire(RADIO_INTF_CFG_T *intf_cfg)
{
    uint32_t chFreq = 0;
    
    CORE_DECLARE_IRQ_STATE;

    CORE_ENTER_CRITICAL();
    intf_cfg->radio_sts |= RADIO_STS_TX_FIRED;
    CORE_EXIT_CRITICAL();

#ifdef CHIP_RADIO_NEED_TX_TPM_CAL
    //debug_print("set TPM ch=%d %04x %02x\n", intf_cfg->tx_channel, txTpmCalib[intf_cfg->tx_channel].tpm_din_hb, txTpmCalib[intf_cfg->tx_channel].kvc);
    hal_intf_radio_set_tpm_cal_val(&txTpmCalib[intf_cfg->tx_channel]);
#endif

    chFreq = _radio_get_active_ch_freq(intf_cfg, 0);
    hal_intf_radio_set_synthesizer(intf_cfg->phy_idx, chFreq);
    hal_intf_pmu_module_clk_enable(MAC_MODULE | BBP_MODULE | ANA_MODULE);
    hal_intf_radio_tx_start(intf_cfg->phy_idx, intf_cfg->tx_buffer, intf_cfg->tx_len);
}

static void _radio_rx_start(RADIO_INTF_CFG_T *intf_cfg, uint8_t ch_index)
{
    uint8_t *pframe;
    WISE_RX_META_T *pmeta = NULL;
    uint32_t chFreq = 0;
    uint32_t rxLen = 0;
    WISE_RADIO_PKT_FMT_T *pktFmt = &intf_cfg->pkt_fmt;
    RADIO_ADAPT_T *adapt = (RADIO_ADAPT_T *)hal_intf_radio_get_adapt(intf_cfg->phy_idx);
    RADIO_CFG_T *p_hal_radio = &adapt->radio_cfg;
    
    CORE_DECLARE_IRQ_STATE;

    if (!CORE_IS_IN_ISR()) {
        CORE_ENTER_CRITICAL();
    }
    
    intf_cfg->rx_channel = ch_index;
    intf_cfg->radio_sts |= RADIO_STS_RX_ON;
    pframe = intf_cfg->rx_buf_bank[intf_cfg->rx_w_index];
    pmeta = RX_FRAME_META(pframe);
    
    if(intf_cfg->phy_init_mode == PHY_INIT_WMBUS)
        memset(pframe, 0, intf_cfg->rx_buf_len);
    memset(pmeta, 0, sizeof(WISE_RX_META_T));
    
    if (!CORE_IS_IN_ISR()) {
        CORE_EXIT_CRITICAL();
    }

    // if(reInit)
    //     radioConfig(radioIntf);

    // debug_print("+ %d %08x %08x len=%d\n", chIndex, pFrame, pMeta,
    // radioIntf->pktFmt.maxPktLength); memset(pFrame, 0,
    // RADIO_RX_FRAME_BUF_LEN);
    
    chFreq = _radio_get_active_ch_freq(intf_cfg, 1);

    hal_intf_radio_set_synthesizer(intf_cfg->phy_idx, chFreq);
    hal_intf_pmu_module_clk_enable(MAC_MODULE | BBP_MODULE | ANA_MODULE);

    if(intf_cfg->phy_init_mode == PHY_INIT_WMBUS || intf_cfg->phy_mode == E_PHY_MBUS)
    {
#if (ESMT_SOC_CHIP_ID == 0x9005)
        intf_cfg->radio_sts |= RADIO_STS_RX_CAL;
        rxSigThres.threshold = hal_intf_radio_rx_calib(intf_cfg->phy_idx, intf_cfg->phy_mode, intf_cfg->user_cfg.modulation, rxSigThres.threshold);
        intf_cfg->radio_sts &= ~RADIO_STS_RX_CAL;
#endif
    }

    p_hal_radio->frame_hw_opt &= ~(FRAME_HW_PHR | FRAME_HW_CRC);
    
    if (pktFmt->frame_format & FRAME_FMT_CRC_EN) //kevinyang, 20251118, check CRC enable/disable first
    {
        //debug_print("max_pkt_len=%lu crcWidth=%d\n", pktFmt->max_pkt_length, intf_cfg->crcWidth);
        //rxLen = pktFmt->max_pkt_length + intf_cfg->crcWidth;
        rxLen = pktFmt->max_pkt_length;

        if(!(intf_cfg->intf_cfg_sts & RADIO_INTF_RX_SW_FRAME))
        {
            p_hal_radio->frame_hw_opt |= (FRAME_HW_PHR | FRAME_HW_CRC);
        
            if(WISE_SUCCESS != _setup_hw_crc(intf_cfg->phy_idx, p_hal_radio))
            {
                debug_print("RX setup HW CRC failed\n");
            }
        }
    }
    else
        rxLen = pktFmt->max_pkt_length;

    if(intf_cfg->phy_init_mode != PHY_INIT_WMBUS)
    {
        // debug_print("setup RX frame format hw_opt=%08x\n", p_hal_radio->frame_hw_opt);
        if (hal_intf_radio_rx_config(intf_cfg->phy_idx, p_hal_radio) != WISE_SUCCESS) 
        {
            debug_print("radio rx config fail\n");
            return;
        }
    }
    
    //rxLen = pktFmt->max_pkt_length;
    hal_intf_radio_rx_start(intf_cfg->phy_idx, pframe, rxLen);
}

static void _handle_radio_rx_fsm_error(void)
{
    // Workaround for SOC 9005 MAC FSM issue
    // TODO: Remove when IC fixed in future revision
    hal_intf_pmu_reset_module_core(MAC_CORE_RESET | ANA_CORE_RESET);
    hal_intf_pmu_module_sw_reset(DMA_MODULE);
    debug_print("radio rx fsm error, reset mac and ana core\n");
}

static void _radio_rx_stop(RADIO_INTF_CFG_T *intf_cfg)
{
    CORE_DECLARE_IRQ_STATE;

    if (!CORE_IS_IN_ISR()) {
        CORE_ENTER_CRITICAL();
    }

    if(!(intf_cfg->radio_sts & RADIO_STS_RX_PAUSED))
    {
        hal_intf_radio_rx_stop(intf_cfg->phy_idx);
    }
    
    hal_intf_pmu_module_clk_disable(MAC_MODULE | BBP_MODULE | ANA_MODULE);
    
    intf_cfg->rx_channel  = WISE_INVALID_INDEX;
    intf_cfg->radio_sts  &= ~(RADIO_STS_RX_ON | RADIO_STS_RX_PAUSED);

    hal_intf_radio_get_int_status(intf_cfg->phy_idx); //read int status to clear
    NVIC_ClearPendingIRQ(MAC_IRQn);

#if (CHIP_RADIO_FLEXIBLE_FMT_VERSION >= 1)
    if (hal_intf_radio_get_rx_busy(intf_cfg->phy_idx) > 0) {
        _handle_radio_rx_fsm_error();
    }
#endif

    if (!CORE_IS_IN_ISR()) {
        CORE_EXIT_CRITICAL();
    }
}

static void _radio_rx_pause(RADIO_INTF_CFG_T *intf_cfg)
{
    CORE_DECLARE_IRQ_STATE;
    
    if (!CORE_IS_IN_ISR()) {
        CORE_ENTER_CRITICAL();
    }

    if(hal_intf_radio_rx_stop(intf_cfg->phy_idx)) {
        _handle_radio_rx_fsm_error();
    }
    intf_cfg->radio_sts |= RADIO_STS_RX_PAUSED;

    if (!CORE_IS_IN_ISR()) {
        CORE_EXIT_CRITICAL();
    }
}

static void _radio_rx_resume(RADIO_INTF_CFG_T *intf_cfg)
{
    CORE_DECLARE_IRQ_STATE;

    if (!CORE_IS_IN_ISR()) {
        CORE_ENTER_CRITICAL();
    }

    intf_cfg->radio_sts &= ~RADIO_STS_RX_PAUSED;

    if (!CORE_IS_IN_ISR()) {
        CORE_EXIT_CRITICAL();
    }

    _radio_rx_start(intf_cfg, intf_cfg->rx_channel);
}

static void _radio_setup_frame_path(RADIO_INTF_CFG_T *intf_cfg)
{
    WISE_RADIO_PKT_FMT_T *pkt_fmt = &intf_cfg->pkt_fmt;
    //WISE_RADIO_CFG_T *p_radio_cfg = &intf_cfg->user_cfg;
    RADIO_ADAPT_T *adapt = (RADIO_ADAPT_T *)hal_intf_radio_get_adapt(intf_cfg->phy_idx);
    RADIO_CFG_T *p_hal_radio = &adapt->radio_cfg;
    
    p_hal_radio->frame_hw_opt = 0;
    intf_cfg->intf_cfg_sts &= ~(RADIO_INTF_TX_SW_FRAME | RADIO_INTF_RX_SW_FRAME);
    
    if (pkt_fmt->frame_format & FRAME_FMT_PREAMBLE_EN)
        p_hal_radio->frame_hw_opt |= FRAME_HW_PREAMBLE;

    if (pkt_fmt->frame_format & FRAME_FMT_SYNCWORD_EN)
        p_hal_radio->frame_hw_opt |= FRAME_HW_SYNC_WORD;

    /* kevinyang, 20251229, fill this in tx/rx function
    if (pkt_fmt->frame_format & FRAME_FMT_HEADER_EN)
        p_hal_radio->frame_hw_opt |= FRAME_HW_PHR;

    if (pkt_fmt->frame_format & FRAME_FMT_CRC_EN)
        p_hal_radio->frame_hw_opt |= FRAME_HW_CRC;
    */
    
    if (pkt_fmt->frame_format & FRAME_FMT_WHITENING_EN)
        p_hal_radio->frame_hw_opt |= FRAME_HW_WHITENING;

    if (pkt_fmt->frame_format & FRAME_FMT_MSB_FIRST)
        p_hal_radio->frame_hw_opt |= FRAME_HW_DMA_REVERSE;

    if (pkt_fmt->frame_format & FRAME_FMT_FEC_EN)
        p_hal_radio->frame_hw_opt |= FRAME_HW_FEC;

    //if (pkt_fmt->frame_format & FRAME_FMT_MANCH_EN)
    if(pkt_fmt->frame_codec == E_FRAME_CODEC_MANCHESTER)
        p_hal_radio->frame_hw_opt |= FRAME_HW_MANCH;

#if (CHIP_RADIO_FLEXIBLE_FMT_VERSION == 0)
    WISE_RADIO_CFG_T *p_radio_cfg = &intf_cfg->user_cfg;
    if (intf_cfg->phy_mode == E_PHY_TRANSPARENT)
    {
        intf_cfg->intf_cfg_sts |= (RADIO_INTF_TX_SW_FRAME | RADIO_INTF_RX_SW_FRAME); 
    }
#elif (CHIP_RADIO_FLEXIBLE_FMT_VERSION == 1)
    if(intf_cfg->phy_init_mode == PHY_INIT_WMBUS)
    {
        intf_cfg->intf_cfg_sts |= (RADIO_INTF_TX_SW_FRAME | RADIO_INTF_RX_SW_FRAME);
    }
    else
    {
        uint8_t swPHR = ((pkt_fmt->frame_format & FRAME_FMT_HEADER_EN) && (pkt_fmt->phr.hdr_config & PHR_BYTE_ENDIAN_MSB_FIRST)) ? 1 : 0;
        //uint8_t swCRC = ((pkt_fmt->frame_format & FRAME_FMT_CRC_EN) && (pkt_fmt->crc.crc_config & CRC_CFG_OFFSET_INCLUDE_HDR)) ? 1 : 0;
        uint8_t swCRC = 0;

        if(pkt_fmt->frame_format & FRAME_FMT_CRC_EN)
        {
            if(pkt_fmt->crc.crc_config & CRC_INCLUDE_HEADER_ON)
                swCRC = 1;
            if(((pkt_fmt->crc.crc_config >> CRC_CFG_OFFSET_INPUT_BIT_ENDIAN) & 1) != ((pkt_fmt->crc.crc_config >> CRC_CFG_OFFSET_OUTPUT_BIT_ENDIAN) & 1))
                swCRC = 1;
        }
        
        if(swPHR || swCRC)
            intf_cfg->intf_cfg_sts |= (RADIO_INTF_TX_SW_FRAME | RADIO_INTF_RX_SW_FRAME);
        else
            intf_cfg->intf_cfg_sts &= ~(RADIO_INTF_TX_SW_FRAME | RADIO_INTF_RX_SW_FRAME);
    }
#elif (CHIP_RADIO_FLEXIBLE_FMT_VERSION == 2)
    intf_cfg->intf_cfg_sts &= ~RADIO_INTF_RX_SW_FRAME;
    if (pkt_fmt->phr.hdr_bytes == 2 ||
        ((pkt_fmt->crc.crc_config >> CRC_CFG_OFFSET_OUTPUT_BIT_ENDIAN) & 1) !=
        ((pkt_fmt->crc.crc_config >> CRC_CFG_OFFSET_OUTPUT_BYTE_ENDIAN) & 1) ||
        p_hal_radio->phy_mode == PHY_MODE_MBUS) {
        /* TODO: Re-verify and confirm the corresponding format configuration when RADIO_INTF_TX_SW_FRAME is enabled */
        intf_cfg->intf_cfg_sts |= RADIO_INTF_TX_SW_FRAME;
    } else {
        intf_cfg->intf_cfg_sts &= ~RADIO_INTF_TX_SW_FRAME;
    }
#endif

    /* kevinyang, 20251229, config this later depending on trasmit direction
    if(intf_cfg->intf_cfg_sts &= RADIO_INTF_SW_FRAME)
    {
        p_hal_radio->frame_hw_opt &= ~(FRAME_HW_PHR | FRAME_HW_CRC);
    }

    if(intf_cfg->intf_cfg_sts & RADIO_INTF_SW_FRAME)
    {
        debug_print("setup SW frame format hw_opt=%08x\n", p_hal_radio->frame_hw_opt);
    }
    else
    {
        debug_print("setup HW frame format hw_opt=%08x\n", p_hal_radio->frame_hw_opt);
    }
    */
}

static int8_t _radio_calibration(RADIO_INTF_CFG_T *intf_cfg)
{
    RADIO_ADAPT_T *adapt = (RADIO_ADAPT_T *)hal_intf_radio_get_adapt(intf_cfg->phy_idx);
    RADIO_CFG_T *p_hal_radio = &adapt->radio_cfg;
    uint32_t chFreq = 0;
    int i;
    
#if (defined CHIP_RADIO_NEED_RX_CAL) || (defined CHIP_RADIO_NEED_TX_TPM_CAL)

    //Rx calibration
    if(intf_cfg->phy_init_mode == PHY_INIT_WMBUS || intf_cfg->phy_mode == E_PHY_MBUS)
    {
        if((rxSigThres.threshold == RX_INVALID_SIG_THRES) || (rxSigThres.dataRateIdx != intf_cfg->user_cfg.data_rate))
        {
            intf_cfg->rx_channel = 0;
            
            chFreq = _radio_get_active_ch_freq(intf_cfg, 1);

            //debug_print("start rx calibration ch=%lu\n", chFreq);
            
            hal_intf_radio_set_synthesizer(intf_cfg->phy_idx, chFreq);
            hal_intf_pmu_module_clk_enable(MAC_MODULE | BBP_MODULE | ANA_MODULE);
#if (ESMT_SOC_CHIP_ID == 0x9005)
            intf_cfg->radio_sts |= RADIO_STS_RX_CAL;
            rxSigThres.threshold = hal_intf_radio_rx_calib(intf_cfg->phy_idx, intf_cfg->phy_mode, intf_cfg->user_cfg.modulation, rxSigThres.threshold);
            intf_cfg->radio_sts &= ~RADIO_STS_RX_CAL;
#endif

            hal_intf_pmu_module_clk_disable(MAC_MODULE | BBP_MODULE | ANA_MODULE);

            rxSigThres.dataRateIdx = intf_cfg->user_cfg.data_rate;

            //debug_print("finish threshold=%d\n", rxSigThres.threshold);
        }
    }
    
#ifdef CHIP_RADIO_NEED_TX_TPM_CAL
    if(!txTpmCalib)
    {
        debug_print("bug!! NULL TPM buffer\n");
        return WISE_FAIL;
    }

    hal_intf_pmu_module_clk_enable(MAC_MODULE | BBP_MODULE | ANA_MODULE);
    
    for(i = 0; i < intf_cfg->ch_num; i++)
    {
        if(intf_cfg->ch_num == 1)
            p_hal_radio->ch_freq = intf_cfg->ch_freq;
        else
            p_hal_radio->ch_freq = intf_cfg->ch_map[i];
        
        hal_intf_radio_trig_tpm_calib(intf_cfg->phy_idx, p_hal_radio);
        hal_intf_radio_get_tpm_cal_val(&txTpmCalib[i]);

        //debug_print("ch=%d freq=%lu tpm %04x %02x\n", i, p_hal_radio->ch_freq, txTpmCalib[i].tpm_din_hb, txTpmCalib[i].kvc);
    }

    // TODO::
    // IQ calibration is only supported for data rates <= 500 kbps.
    // If switching from 500 kbps to a different data rate, IQ calibration must be performed.
    // Switching between non-500 kbps data rates does not require re-calibration.
    hal_intf_radio_iq_calib(intf_cfg->phy_idx, _radio_get_active_ch_freq(intf_cfg, 0));

    hal_intf_pmu_module_clk_disable(MAC_MODULE | BBP_MODULE | ANA_MODULE);
#endif

#endif
    return WISE_SUCCESS;
}

static void _radio_data_bit_reverse(uint8_t* destBuffer, uint8_t* srcBuffer, int len)
{
    int i;
    
    for (i = 0; i < len; i++) 
    {
        destBuffer[i] = (uint8_t)bit_reverse(srcBuffer[i], 1);
    }
}

static void _radio_tx_state_transition(RADIO_INTF_CFG_T *intf_cfg)
{
    if ((intf_cfg->radio_sts & RADIO_STS_RX_PAUSED) || (intf_cfg->tx_state_trans == TX_FINISH_TO_RX))
    {
        if(intf_cfg->rx_channel == WISE_INVALID_INDEX)
            intf_cfg->rx_channel = intf_cfg->tx_channel;
        _radio_rx_resume(intf_cfg);
    }
    else
    {
        hal_intf_pmu_module_clk_disable(MAC_MODULE | BBP_MODULE | ANA_MODULE);
    }
}

static int8_t _radio_config(int8_t intf_idx, RADIO_INTF_CFG_T *intf_cfg)
{
    WISE_RADIO_CFG_T *p_radio_cfg = &intf_cfg->user_cfg;
    WISE_RADIO_PKT_FMT_T *pkt_fmt = &intf_cfg->pkt_fmt;
    RADIO_ADAPT_T *adapt = (RADIO_ADAPT_T *)hal_intf_radio_get_adapt(intf_idx);
    RADIO_CFG_T *p_hal_radio = &adapt->radio_cfg;
    uint8_t sync_len = p_radio_cfg->sync_word_len;
    uint32_t rxMaxLen = 0;

    memcpy((void *)&p_hal_radio->hdr_bytes, (void *)&pkt_fmt->phr, sizeof(WISE_RADIO_PHR_T));
    
    p_hal_radio->mod_type      = p_radio_cfg->modulation;
    p_hal_radio->ch_freq       = p_radio_cfg->ch_freq_min;
    p_hal_radio->freq_devia    = p_radio_cfg->deviation;
    p_hal_radio->data_rate     = RADIO_DR_VALUE[p_radio_cfg->data_rate].drValue;
    p_hal_radio->sync_word_len = sync_len;

    p_hal_radio->sync_word[0] = bit_reverse(p_radio_cfg->syncword, ((sync_len > 4) ? 4 : sync_len));

    //p_hal_radio->phy_mode = p_radio_cfg->phy_mode;
    p_hal_radio->phy_mode = intf_cfg->phy_mode;
    //debug_print("_radio_config phy_mode=%d\n", p_hal_radio->phy_mode);
    p_hal_radio->pwr_mode = PWR_MODE_ACTIVITY;

    _radio_setup_frame_path(intf_cfg);

    if (pkt_fmt->frame_format & FRAME_FMT_CRC_EN) //kevinyang, 20251118, check CRC enable/disable first
    {
        if(intf_cfg->intf_cfg_sts & (RADIO_INTF_TX_SW_FRAME | RADIO_INTF_RX_SW_FRAME))
            _setup_sw_crc(intf_idx);

        #if 0
        else
        {
            if(WISE_SUCCESS != _setup_hw_crc(intf_idx, p_hal_radio))
            {
                debug_print("setup HW CRC failed\n");
            }
        }
        #endif
        
        //rxMaxLen = pkt_fmt->max_pkt_length + intf_cfg->crcWidth;
        rxMaxLen = pkt_fmt->max_pkt_length;
    }
    else
        rxMaxLen = pkt_fmt->max_pkt_length;
    
    p_hal_radio->tx_pwr_lv  = intf_cfg->tx_pwr_level;
    p_hal_radio->pream_len  = p_radio_cfg->preamble_len;
    p_hal_radio->pream      = p_radio_cfg->preamble;
    //p_hal_radio->rx_max_len = pkt_fmt->max_pkt_length;
    p_hal_radio->rx_max_len = rxMaxLen;

    //wmbus using
    p_hal_radio->wmbus_mode = intf_cfg->wmbus_mode;

    // debug_print("sync %d %08x %08x\n", pHalRadio->sync_word_len,
    // pHalRadio->sync_word[0], pHalRadio->sync_word[1]);
    // debug_print("freq=%lu\n", pHalRadio->ch_freq);

    if (hal_intf_radio_init(intf_idx, p_hal_radio) != WISE_SUCCESS) {
        DBG_PRINT("radio init fail\n");
        goto error;
    }
        
    _radio_calibration(intf_cfg);
    
    return WISE_SUCCESS;

error:
    return WISE_FAIL;
}

static int8_t _radio_mbus_config(int8_t intf_idx, RADIO_INTF_CFG_T *intf_cfg, uint8_t isTx)
{
    WISE_RADIO_CFG_T *p_radio_cfg = &intf_cfg->user_cfg;
    WISE_RADIO_PKT_FMT_T *pkt_fmt = &intf_cfg->pkt_fmt;
    RADIO_ADAPT_T *adapt          = (RADIO_ADAPT_T *)hal_intf_radio_get_adapt(intf_idx);
    RADIO_CFG_T *p_hal_radio      = &adapt->radio_cfg;
    uint8_t sync_len              = p_radio_cfg->sync_word_len;

    memcpy((void *)&p_hal_radio->hdr_bytes, (void *)&pkt_fmt->phr, sizeof(WISE_RADIO_PHR_T));

    p_hal_radio->freq_devia    = p_radio_cfg->deviation;
    p_hal_radio->data_rate     = RADIO_DR_VALUE[p_radio_cfg->data_rate].drValue;
    p_hal_radio->sync_word_len = sync_len;

    p_hal_radio->sync_word[0] = bit_reverse(p_radio_cfg->syncword, ((sync_len > 4) ? 4 : sync_len));
    p_hal_radio->pwr_mode = PWR_MODE_ACTIVITY;

    p_hal_radio->tx_pwr_lv  = intf_cfg->tx_pwr_level;
    p_hal_radio->pream_len  = p_radio_cfg->preamble_len;
    p_hal_radio->pream      = p_radio_cfg->preamble;
    p_hal_radio->rx_max_len = pkt_fmt->max_pkt_length;

    if(isTx)
    {
        if (hal_intf_radio_tx_config(intf_idx, p_hal_radio) != WISE_SUCCESS) {
            DBG_PRINT("radio tx init fail\n");
            goto error;
        }
    }
    else
    {
        if (hal_intf_radio_rx_config(intf_idx, p_hal_radio) != WISE_SUCCESS) {
            DBG_PRINT("radio rx init fail\n");
            goto error;
        }
    }

    return WISE_SUCCESS;
error:
    return WISE_FAIL;
}

static uint32_t _sw_radio_crc_calc(RADIO_INTF_CFG_T *intf_cfg, uint8_t *crc_start, uint16_t crc_len, uint32_t crc_init_val)
{
    uint32_t crcCalc = 0;

    switch(intf_cfg->crcWidth)
    {
        case 1:
            crcCalc = util_crc8_calc(intf_cfg->crcPolySel, intf_cfg->crcTable, crc_start, crc_len, crc_init_val & 0xff);
        break;

        case 2:
            crcCalc = util_crc16_calc(intf_cfg->crcPolySel, (uint16_t*)intf_cfg->crcTable, crc_start, crc_len, crc_init_val & 0xffff);
        break;
    }
    
    return crcCalc;
}

static int8_t _validate_rx_frame(RADIO_INTF_CFG_T *intf_cfg, uint8_t *pframe)
{
    int8_t valid = 0;
    WISE_RX_META_T *rx_meta = RX_FRAME_META(pframe);
    WISE_RADIO_PKT_FMT_T *pkt_fmt = &intf_cfg->pkt_fmt;
    WISE_RADIO_PHR_T *phr_cfg = &pkt_fmt->phr;
    WISE_RADIO_CRC_T *crc_cfg = &pkt_fmt->crc;
    uint32_t phr = 0;
    int i;
    uint16_t pkt_len = 0;
    uint16_t payload_len = 0;

    //debug_print("_validate_rx_frame raw packet:\n");
    //dump_buffer(pframe, rx_meta->data_len);
            
    if (!(pkt_fmt->frame_format & FRAME_FMT_CRC_EN)) {
        //debug_print("no crc checking\n");
        
        return 1;
    }
    
    if ((rx_meta->data_len) && (rx_meta->data_len <= pkt_fmt->max_pkt_length)) {
        if ((phr_cfg->hdr_bytes) && (intf_cfg->phy_mode == E_PHY_TRANSPARENT)) {
            //debug_print("raw packet:\n");
            //dump_buffer(pframe, rx_meta->data_len);

            for (i = 0; i < phr_cfg->hdr_bytes; i++) {
                if (pkt_fmt->frame_format & FRAME_FMT_MSB_FIRST) {
                    pframe[i] = bit_reverse(pframe[i], 1);
                }

                phr = (phr << 8) | ((pframe[i]) & 0xff);
            }

            pkt_len = ((phr >> phr_cfg->length_bit_offset) & intf_cfg->phr_len_mask);
            
            if (pkt_fmt->frame_format & FRAME_FMT_MSB_FIRST) {
                uint16_t reverse_len = 0;

                if (!(phr_cfg->hdr_config & PHR_LENGTH_INCLUDE_CRC)) {
                    reverse_len = pkt_len + intf_cfg->crcWidth;
                }

                for (i = 0; i < reverse_len; i++) {
                    pframe[i + phr_cfg->hdr_bytes] = (uint8_t)bit_reverse(pframe[i + phr_cfg->hdr_bytes], 1);
                }
            }

            /*
            debug_print("rx packet:\n");
            if(phr_cfg->hdr_config & PHR_LENGTH_INCLUDE_CRC)
                dump_buffer(pframe, pkt_len + phr_cfg->hdr_bytes);
            else
                dump_buffer(pframe, pkt_len + phr_cfg->hdr_bytes + intf_cfg->crcWidth);
            */
            
            if (phr_cfg->hdr_config & PHR_LENGTH_INCLUDE_CRC) {
                payload_len = pkt_len - intf_cfg->crcWidth;
            } else {
                payload_len = pkt_len;
            }

            if (pkt_len <= rx_meta->data_len) {
                // for TC03/TC03 HW CRC algorithm
                if (crc_cfg->crc_poly_sel == CRC_POLYNOMIAL_NONE) {
                    uint16_t crc_calc = 0;
                    uint16_t crc_recv = LOAD_LE_16(&pframe[pkt_len + 1]);

                    rx_meta->data_len = pkt_len + phr_cfg->hdr_bytes;
                    crc_calc = crc16_kermit(&pframe[1], pkt_len - 2, crc_cfg->crc_seed);

                    if (crc_calc == crc_recv) {
                        valid = 1;
                    }
                } 
                else 
                { // support more CRC algorithm for ER8130
                    uint8_t *crc_start;
                    uint16_t crc_len;
                    uint32_t crc_calc  = 0;
                    uint32_t crc_check = 0;

                    rx_meta->data_len = phr_cfg->hdr_bytes + payload_len + intf_cfg->crcWidth;

                    if (crc_cfg->crc_config & CRC_INCLUDE_HEADER_ON) {
                        crc_start = pframe;
                        crc_len   = payload_len + phr_cfg->hdr_bytes;
                    } else {
                        crc_start = &pframe[phr_cfg->hdr_bytes];
                        crc_len   = payload_len;
                    }

                    crc_calc = _sw_radio_crc_calc(intf_cfg, crc_start, crc_len, crc_cfg->crc_seed);
                    
                    //debug_print("rx crc %d-%d crc_calc=%04x\n", crc_start - pframe, crc_len, crc_calc);
                    //dump_buffer(crc_start, crc_len);
                    
                    switch (intf_cfg->crcWidth) 
                    {
                        case 2:
                            if(pkt_fmt->frame_format & FRAME_FMT_MSB_FIRST)
                            {
                                if (crc_cfg->crc_config & CRC_OUTPUT_BYTE_ENDIAN_MSB_FIRST) 
                                    crc_check = LOAD_BE_16(&pframe[phr_cfg->hdr_bytes + payload_len]);
                                else
                                    crc_check = LOAD_LE_16(&pframe[phr_cfg->hdr_bytes + payload_len]);
                            }
                            else
                            {
                                crc_calc = bit_reverse_16(crc_calc);
                                
                                if (crc_cfg->crc_config & CRC_OUTPUT_BYTE_ENDIAN_MSB_FIRST) 
                                {
                                    crc_check = LOAD_BE_16(&pframe[phr_cfg->hdr_bytes + payload_len]);
                                    if (crc_cfg->crc_config & CRC_OUTPUT_BIT_ENDIAN_MSB_FIRST) 
                                    {
                                        crc_calc = SWAP_BYTE(crc_calc);
                                    }
                                } 
                                else 
                                {
                                    crc_check = LOAD_LE_16(&pframe[phr_cfg->hdr_bytes + payload_len]);
                                    if (crc_cfg->crc_config & CRC_OUTPUT_BIT_ENDIAN_MSB_FIRST) 
                                    {
                                        crc_calc = SWAP_BYTE(crc_calc);
                                    }
                                }
                            }
                            
                            if (crc_cfg->crc_config & CRC_INVERT_ON)
                            {
                                crc_check = (uint16_t)~crc_check;
                            }
                            break;

                        case 3:
                            break;
                    }

                    //debug_print("crc_calc=%08x crc_check=%08x\n", crc_calc, crc_check);
                    
                    if (crc_calc == crc_check) {
                        valid = 1;
                    }
                }
            } else {
                // debug_print("e pktLen=%d\n", pktLen);
                // dump_buffer(pFrame, 16);
                debug_print("e\n");
            }
        } else {
            if ((intf_cfg->pkt_fmt.pkt_type == PKT_FIXED_LENGTH) && (rx_meta->data_len == pkt_fmt->max_pkt_length)) {
                valid = 1;
            } else if (intf_cfg->phy_mode == E_PHY_802154) {
                valid = 1;
            } else {
                debug_print("e2\n");
            }
        }
    } else {
        debug_print("e3\n");
    }

    return valid;
}

int8_t _pack_tx_frame(RADIO_INTF_CFG_T *intf_cfg, uint8_t *pframe, uint16_t frame_len)
{
    uint16_t crcStart = 0, crcLength = 0, crcOffset = 0;
    uint16_t payloadLen = 0;
    WISE_RADIO_PKT_FMT_T *pktFmt = &intf_cfg->pkt_fmt;
    WISE_RADIO_PHR_T *phr_cfg = &pktFmt->phr;
    WISE_RADIO_CRC_T *crc_cfg = &pktFmt->crc;
    uint8_t *pTxBuffer = intf_cfg->tx_buffer;
    uint16_t phr = 0;
    int i;
    uint16_t lengthMask = 0;
    uint32_t crcCalc = 0;
    
    if ((pktFmt->pkt_type == PKT_VARIABLE_LENGTH) && !(pktFmt->frame_format & FRAME_FMT_HEADER_EN)) {
        debug_print("variable frame length requires frame header\n");
        return WISE_FAIL;
    }

    if ((pktFmt->frame_format & FRAME_FMT_HEADER_EN) && (phr_cfg->hdr_bytes == 0)) {
        debug_print("invalid hdr length\n");
        return WISE_FAIL;
    }

    memcpy(pTxBuffer, pframe, frame_len);

    if (pktFmt->pkt_type == PKT_VARIABLE_LENGTH) 
    {
        if (phr_cfg->hdr_bytes == 1) {
            phr = pTxBuffer[0];
        } else if (phr_cfg->hdr_bytes == 2) {
            if (phr_cfg->hdr_config & PHR_BYTE_ENDIAN_MSB_FIRST) {
                phr = LOAD_BE_16(&pTxBuffer[0]);
            } else {
                phr = LOAD_LE_16(&pTxBuffer[0]);
            }
        } else {
            debug_print("unsupportd PHR length\n");
            return WISE_FAIL;
        }

        for (i = 0; i < phr_cfg->length_bit_size; i++) {
            lengthMask |= (1 << i);
        }

        // debug_print("lengthMask=%04x\n", lengthMask);

        payloadLen = (phr >> phr_cfg->length_bit_offset) & lengthMask;
        // debug_print("payloadLen=%d\n", payloadLen);
    
        if (pktFmt->frame_format & FRAME_FMT_CRC_EN) {
            crcOffset = frame_len;

            if (phr_cfg->hdr_config & PHR_LENGTH_INCLUDE_CRC) {
                crcLength = payloadLen - intf_cfg->crcWidth;
            } else {
                crcLength = payloadLen;
            }

            if (crc_cfg->crc_config & CRC_INCLUDE_HEADER_ON) {
                crcStart   = 0;
                crcLength += phr_cfg->hdr_bytes;
            } else {
                crcStart = phr_cfg->hdr_bytes;
            }

            
            //debug_print("calc crc %d-%d\n", crcStart, crcLength);
            //dump_buffer(&pTxBuffer[crcStart], crcLength);
            
            crcCalc = _sw_radio_crc_calc(intf_cfg, &pTxBuffer[crcStart], crcLength, crc_cfg->crc_seed);
            

            //if (crc_cfg->crc_config & CRC_OUTPUT_BIT_ENDIAN_MSB_FIRST) 
            //{
            //    crcCalc = bit_reverse(crcCalc, intf_cfg->crcWidth);
            //    debug_print("reversed cacCalc=%08x\n", crcCalc);
            //}

            switch (intf_cfg->crcWidth) 
            {
                case 1:
                    pTxBuffer[crcOffset] = crcCalc & 0xff;
                    break;

                case 2:
                    crcCalc = bit_reverse_16(crcCalc);

                    if (crc_cfg->crc_config & CRC_INVERT_ON)
                    {
                        crcCalc = (uint16_t)~crcCalc;
                    }
                            
                    if (crc_cfg->crc_config & CRC_OUTPUT_BYTE_ENDIAN_MSB_FIRST) 
                    {
                        if(crc_cfg->crc_config & CRC_OUTPUT_BIT_ENDIAN_MSB_FIRST)
                        {
                            PUT_LE_16(&pTxBuffer[crcOffset], (crcCalc & 0xffff));
                        }
                        else
                        {
                            PUT_BE_16(&pTxBuffer[crcOffset], (crcCalc & 0xffff));
                        }
                    } 
                    else
                    {
                        if(crc_cfg->crc_config & CRC_OUTPUT_BIT_ENDIAN_MSB_FIRST)
                        {
                            PUT_BE_16(&pTxBuffer[crcOffset], (crcCalc & 0xffff));
                        }
                        else
                        {
                            PUT_LE_16(&pTxBuffer[crcOffset], (crcCalc & 0xffff));
                        }
                    }
                break;

                case 3:
                    if (crc_cfg->crc_config & CRC_OUTPUT_BYTE_ENDIAN_MSB_FIRST) 
                    {
                        PUT_BE_24(&pTxBuffer[crcOffset], (crcCalc & 0xffffff));
                    } 
                    else 
                    {
                        PUT_LE_24(&pTxBuffer[crcOffset], (crcCalc & 0xffffff));
                    }

                break;
            }
        } 
        else 
        {
        }

        intf_cfg->tx_len = frame_len + intf_cfg->crcWidth;

        if (pktFmt->frame_format & FRAME_FMT_MSB_FIRST) {
            for (i = 0; i < frame_len; i++) {
                pTxBuffer[i] = bit_reverse(pTxBuffer[i], 1);
            }
        }

        //debug_print("tx %d\n", intf_cfg->tx_len);
        //dump_buffer(intf_cfg->tx_buffer, intf_cfg->tx_len);
    } else if (pktFmt->pkt_type == PKT_FIXED_LENGTH) {
        intf_cfg->tx_len = frame_len;
    } else {
        return WISE_FAIL;
    }

    return WISE_SUCCESS;
}

static int16_t _radio_ch_index(RADIO_INTF_CFG_T *intf_cfg, uint32_t ch_freq)
{
    int16_t ch_index = WISE_INVALID_INDEX;
    int i;

    if(intf_cfg->ch_num == 1)
    {
        if(ch_freq == intf_cfg->ch_freq)
            return 0;
        else
            return WISE_INVALID_INDEX;
    }

    for (i = 0; i < intf_cfg->ch_num; i++) {
        if (ch_freq == intf_cfg->ch_map[i]) {
            ch_index = i;
            break;
        }
    }

    return ch_index;
}

static inline void _update_rx_state(RADIO_INTF_CFG_T *intf_cfg)
{
    intf_cfg->rx_w_index = (intf_cfg->rx_w_index + 1) % intf_cfg->rx_buf_num;
    intf_cfg->rx_frame_count++;

    if(!(intf_cfg->radio_sts & RADIO_STS_RX_ON))
        return;

    if(intf_cfg->rx_mode == RADIO_RX_CONTINUOUS)
    {
        if(intf_cfg->rx_frame_count < intf_cfg->rx_buf_num) 
        {
            _radio_rx_resume(intf_cfg);
        }
        else
        {
            _radio_rx_pause(intf_cfg);
        }
    } 
    else 
    {
        _radio_rx_stop(intf_cfg);
    }
}

static inline void _process_rx_metadata(RADIO_INTF_CFG_T *intf_cfg, RADIO_FRAME_META_T *meta, uint8_t *pframe, WISE_RX_META_T *rx_meta)
{
    rx_meta->timestamp = wise_tick_get_counter();
    rx_meta->ch_frequency = meta->channel;
    rx_meta->ch_index = _radio_ch_index(intf_cfg, rx_meta->ch_frequency);
    rx_meta->rssi = RADIO_RSSI_CALC(meta->rssi);
    rx_meta->data_len = meta->data_len;
}

static inline void _validate_rx_data(RADIO_INTF_CFG_T *intf_cfg, uint8_t *pframe, WISE_RX_META_T *rx_meta, uint32_t status)
{
    //debug_print("_validate_rx_data status=%08x\n", (unsigned int)status);
    
    if (((intf_cfg->pkt_fmt.frame_format == PKT_FIXED_LENGTH) || (intf_cfg->phy_mode == E_PHY_802154)) &&
        (status & HAL_RADIO_INT_RX_ERR)) 
    { 
        if((intf_cfg->phy_mode == E_PHY_802154) && (intf_cfg->phy_init_mode == PHY_INIT_802154))
        {
            rx_meta->valid = RX_FRAME_INVALID;
        }
        else
        {
            if(_validate_rx_frame(intf_cfg, pframe))
            {
                pframe[0] -= 2;
                rx_meta->data_len -= 2;
                
                rx_meta->valid = RX_FRAME_VALID;
            }
            else
                rx_meta->valid = RX_FRAME_INVALID;
        }
    } 
    else 
    {
        if(intf_cfg->intf_cfg_sts & RADIO_INTF_RX_SW_FRAME)
            rx_meta->valid = _validate_rx_frame(intf_cfg, pframe) ? RX_FRAME_VALID : RX_FRAME_INVALID;
        else
            rx_meta->valid = (status & HAL_RADIO_INT_RX_ERR) ? RX_FRAME_INVALID : RX_FRAME_VALID;
    }


    if (g_sg_mode_flag == ENABLE) 
    {
        // SG mode using
        //directly check mac int status
        if (status & HAL_RADIO_INT_RX_ERR)
            rx_meta->valid = RX_FRAME_INVALID;
        else
            rx_meta->valid = RX_FRAME_VALID;
    }
    
}

static inline void _handle_rx_event(RADIO_INTF_CFG_T *intf_cfg, uint32_t status)
{
    uint8_t *pframe = intf_cfg->rx_buf_bank[intf_cfg->rx_w_index];
    RADIO_FRAME_META_T meta = {0};
    WISE_RX_META_T *rx_meta = RX_FRAME_META(pframe);
    
    hal_intf_radio_get_rx_info(intf_cfg->phy_idx, &meta);
    _update_rx_state(intf_cfg);
    _process_rx_metadata(intf_cfg, &meta, pframe, rx_meta);

#ifdef RADIO_DEBUG_RAW_FRAME
    debug_print("rx raw packet:\n");
    dump_buffer(pframe, rx_meta->data_len);
#endif

#ifdef CHIP_RADIO_HAS_W_MBUS
    if((intf_cfg->phy_init_mode == PHY_INIT_WMBUS) && (rxDataValidate != NULL))
        (rxDataValidate)(intf_cfg, pframe, rx_meta, status);
    else
#endif
    {
        if(intf_cfg->intf_cfg_sts & RADIO_INTF_RX_SW_FRAME) //kevinyang, 20251118, validate_rx only in SW_FRAME mode
            _validate_rx_data(intf_cfg, pframe, rx_meta, status);
        else
        {
#if (CHIP_RADIO_FLEXIBLE_FMT_VERSION < 2)
            WISE_RADIO_PKT_FMT_T* pkt_fmt = &intf_cfg->pkt_fmt;
            
            if(pkt_fmt->frame_format & FRAME_FMT_MSB_FIRST)
            {
 #ifdef RADIO_DEBUG_RAW_FRAME
                debug_print("raw frame bit reverse\n");
 #endif
                _radio_data_bit_reverse(pframe, pframe, rx_meta->data_len);                
            }
#endif

            rx_meta->valid = (status & HAL_RADIO_INT_RX_FIN) ? RX_FRAME_VALID : RX_FRAME_INVALID;

#ifdef RADIO_DEBUG_RAW_FRAME
            debug_print("HW frame %s\n", rx_meta->valid ? "valid" : "invalid");
#endif
        }
    }
    
    if (intf_cfg->evt_callback) {
        intf_cfg->evt_callback(rx_meta->valid == RX_FRAME_VALID ? WISE_RADIO_EVT_RX_FRAME : WISE_RADIO_EVT_RX_ERR);
    }
}

static inline void _handle_tx_event(RADIO_INTF_CFG_T *intf_cfg, uint32_t status)
{
    intf_cfg->radio_sts |= (status & HAL_RADIO_INT_TX_FIN) ? RADIO_STS_TX_FIN : RADIO_STS_TX_ERR;

    _radio_tx_state_transition(intf_cfg);
    
    if (intf_cfg->tx_io_mode == CORE_IO_NONBLOCKING && intf_cfg->evt_callback) 
    {
        intf_cfg->evt_callback((status & HAL_RADIO_INT_TX_FIN) ? WISE_RADIO_EVT_TX_DONE : WISE_RADIO_EVT_TX_ERR);
    }
}

static RAM_TEXT void _radio_isr_internal(void *pdata)
{
    uint32_t status = hal_intf_radio_get_int_status(((ISR_CB_DATA_RADIO_T *)pdata)->phy_idx);
    ISR_CB_DATA_RADIO_T *cb_data = (ISR_CB_DATA_RADIO_T *)pdata;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[cb_data->phy_idx];

    //debug_print("i sts=%08x hw_sts=%08x\n", (unsigned int)status, (unsigned int)hal_intf_radio_get_int_status(((ISR_CB_DATA_RADIO_T *)pdata)->phy_idx));
    
    if (status & (HAL_RADIO_INT_TX_FIN | HAL_RADIO_INT_TX_ERR)) 
    {
        _handle_tx_event(intf_cfg, status);
    }
    
    if((status & HAL_RADIO_INT_RX_SYNCWORD) && (!(intf_cfg->radio_sts & RADIO_STS_RX_CAL)))
    {        
        //if(intf_cfg->phy_init_mode == PHY_INIT_WMBUS) //kevinyang, 20251007, no need to check this
        {            
			if (intf_cfg->evt_callback) 
			{
				intf_cfg->evt_callback(WISE_RADIO_EVT_RX_SYNC_WORD);
			}

            if(rxSyncCallback)
            {
                uint8_t* pFrameBuf = intf_cfg->rx_buf_bank[intf_cfg->rx_w_index];
                uint16_t frameLen = 0;
                RADIO_FRAME_META_T meta = {0};
                WISE_RX_META_T *rx_meta = RX_FRAME_META(pFrameBuf);
                
                frameLen = (rxSyncCallback)(intf_cfg, pFrameBuf);
                if(frameLen > 0)
                {
                    _radio_rx_pause(intf_cfg);
                    
                    hal_intf_radio_get_rx_info(intf_cfg->phy_idx, &meta);
                    meta.data_len = frameLen;

                    hal_intf_radio_get_int_status(((ISR_CB_DATA_RADIO_T *)pdata)->phy_idx); //read int status to clear
                    NVIC_ClearPendingIRQ(MAC_IRQn);
                    
                    _update_rx_state(intf_cfg);
                    _process_rx_metadata(intf_cfg, &meta, pFrameBuf, rx_meta);

                    if(frameLen == 0)
                        rx_meta->valid = RX_FRAME_INVALID;
                    else
                    {
                        if(rxDataValidate)
                            (rxDataValidate)(intf_cfg, pFrameBuf, rx_meta, status);
                    }
                    
                    if (intf_cfg->evt_callback) 
                    {
                        intf_cfg->evt_callback(rx_meta->valid == RX_FRAME_VALID ? WISE_RADIO_EVT_RX_FRAME : WISE_RADIO_EVT_RX_ERR);
                    }
                }
            }
        }
    }
    
    if (status & (HAL_RADIO_INT_RX_FIN | HAL_RADIO_INT_RX_ERR)) {
        _handle_rx_event(intf_cfg, status);
    }
}

int8_t wise_radio_get_version(WISE_RADIO_VERSION_INFO_T *out_ver_info)
{
    if (!out_ver_info) {
        return WISE_FAIL;
    }

    snprintf((char *)out_ver_info->platform_name, MAX_PLATFORM_NAME_LEN - 1, "%s", LIB_PLATFORM_NAME);
    out_ver_info->platform_id = LIB_PLATFORM_ID;
    out_ver_info->ver_major   = LIB_VERSION_MAJOR;
    out_ver_info->ver_minor   = LIB_VERSION_MINOR;
    out_ver_info->ver_build   = LIB_VERSION_BUILD;
    out_ver_info->sha_1 	  = LIB_GIT_SHA;

    return WISE_SUCCESS;
}

#ifdef ES_DEVICE_TRX_RADIO
static void _update_rx_state_external(RADIO_INTF_CFG_T *intf_cfg)
{
    intf_cfg->rx_w_index = (intf_cfg->rx_w_index + 1) % intf_cfg->rx_buf_num;
    intf_cfg->rx_frame_count++;

    if (intf_cfg->rx_mode == RADIO_RX_CONTINUOUS) {
        (intf_cfg->rx_frame_count < intf_cfg->rx_buf_num) ? _radio_rx_resume(intf_cfg) : _radio_rx_pause(intf_cfg);
    } else {
        _radio_rx_stop(intf_cfg);
    }
}

static void _process_rx_metadata_external(RADIO_INTF_CFG_T *intf_cfg, RADIO_FRAME_META_T *meta, uint8_t *pframe, WISE_RX_META_T *rx_meta)
{
    rx_meta->timestamp = wise_tick_get_counter();
    rx_meta->ch_frequency = meta->channel;
    rx_meta->ch_index = _radio_ch_index(intf_cfg, rx_meta->ch_frequency);
    rx_meta->rssi = RADIO_RSSI_CALC(meta->rssi);
    rx_meta->data_len = meta->data_len;
}

static void _validate_rx_data_external(RADIO_INTF_CFG_T *intf_cfg, uint8_t *pframe, WISE_RX_META_T *rx_meta, uint32_t status)
{
    rx_meta->valid = (status & HAL_RADIO_INT_RX_ERR) ? RX_FRAME_INVALID
                     : _validate_rx_frame(intf_cfg, pframe) ? RX_FRAME_VALID 
                     : RX_FRAME_INVALID;
}

static void _handle_rx_event_external(RADIO_INTF_CFG_T *intf_cfg, uint32_t status)
{
    uint8_t *pframe = intf_cfg->rx_buf_bank[intf_cfg->rx_w_index];
    RADIO_FRAME_META_T meta = {0};
    WISE_RX_META_T *rx_meta = RX_FRAME_META(pframe);

    hal_intf_radio_get_rx_info(PHY_IDX_1, &meta);

    if (status & HAL_RADIO_INT_RX_FIN) {
        hal_intf_radio_get_rx_fifo(pframe, meta.data_len);
    } else {
        hal_intf_radio_reset_rx_fifo();
    }

    _update_rx_state_external(intf_cfg);
    _process_rx_metadata_external(intf_cfg, &meta, pframe, rx_meta);
    _validate_rx_data_external(intf_cfg, pframe, rx_meta, status);

    if (intf_cfg->evt_callback) {
        intf_cfg->evt_callback(rx_meta->valid == RX_FRAME_VALID ? WISE_RADIO_EVT_RX_FRAME : WISE_RADIO_EVT_RX_ERR);
    }
}

static void _handle_tx_event_external(RADIO_INTF_CFG_T *intf_cfg, uint32_t status)
{
    intf_cfg->radio_sts |= (status & HAL_RADIO_INT_TX_FIN) ? RADIO_STS_TX_FIN : RADIO_STS_TX_ERR;

    if (intf_cfg->radio_sts & RADIO_STS_RX_PAUSED) {
        _radio_rx_resume(intf_cfg);
    }
    
    if (intf_cfg->tx_io_mode == CORE_IO_NONBLOCKING && intf_cfg->evt_callback) {
        intf_cfg->evt_callback((status & HAL_RADIO_INT_TX_FIN) ? WISE_RADIO_EVT_TX_DONE : WISE_RADIO_EVT_TX_ERR);
    }
}

static void _radio_isr_external(void *pdata)
{
    uint32_t status = hal_intf_radio_get_int_status(PHY_IDX_1);
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[PHY_IDX_1];

    if (status & (HAL_RADIO_INT_RX_FIN | HAL_RADIO_INT_RX_ERR)) {
        _handle_rx_event_external(intf_cfg, status);
    }

    if (status & (HAL_RADIO_INT_TX_FIN | HAL_RADIO_INT_TX_ERR)) {
        _handle_tx_event_external(intf_cfg, status);
    }
}

#endif

static void _setup_radio_buffer(RADIO_INTF_CFG_T *intf_cfg)
{
    //  radio frame buffer
    //  |---|----------------|-------|---------------------|---------------------|
    //      | max packet len |padding|    16 bytes guard   | 16 bytes frame meta
    //      | ^align 16                ^align 16

    uint16_t reqFrameLen   = RADIO_ALIGN_16(intf_cfg->pkt_fmt.max_pkt_length) + RADIO_FRAME_GUARD_LEN;
    uint16_t esmtFrameLen  = reqFrameLen + sizeof(WISE_RX_META_T);
    uint16_t frameBlockLen = RADIO_ALIGN_16(esmtFrameLen);
    uint8_t *bufPtr        = (uint8_t *)RADIO_ALIGN_16(intf_cfg->buffer_pool.addr);
    uint32_t bufLen        = intf_cfg->buffer_pool.length - (intf_cfg->buffer_pool.addr & 0xF);
    uint32_t minReqBufLen  = frameBlockLen * 2; // 1 block for each Rx/Tx
    int i;
    int rxBufNum = 0;

    if (bufLen < minReqBufLen) {
        DBG_PRINT("Error radio buffer config\n");
        return;
    }

    // ES_INFO("Actual buffer pool %08x-%08x\n", bufPtr, bufLen);

    intf_cfg->tx_buffer   = (uint8_t *)bufPtr;
    intf_cfg->tx_buf_len  = reqFrameLen;
    bufPtr               += frameBlockLen;
    bufLen               -= frameBlockLen;

    memset(intf_cfg->rx_buf_bank, 0, sizeof(intf_cfg->rx_buf_bank));
    intf_cfg->rx_buf_len = 0;
    intf_cfg->rx_buf_num = 0;

    rxBufNum = bufLen / frameBlockLen;
    rxBufNum = rxBufNum > RADIO_MAX_RX_BUF_NUM ? RADIO_MAX_RX_BUF_NUM : rxBufNum;

    for (i = 0; i < rxBufNum; i++) {
        // ES_INFO("radio rx 0 %p\n", bufPtr);

        intf_cfg->rx_buf_bank[i]  = bufPtr;
        bufPtr                   += frameBlockLen;

        if (bufLen < frameBlockLen) {
            DBG_PRINT("BUG!! setupRadioBuffer\n");
            break;
        }

        bufLen -= frameBlockLen;
    }

    intf_cfg->rx_buf_len     = reqFrameLen;
    intf_cfg->rx_buf_num     = rxBufNum;
    intf_cfg->rx_meta_offset = frameBlockLen - sizeof(WISE_RX_META_T);
}

static void _radio_reset_ch_map(RADIO_INTF_CFG_T *intf_cfg)
{
    if((intf_cfg->ch_num > 1) && (intf_cfg->ch_map != NULL))
        free(intf_cfg->ch_map);

    intf_cfg->ch_map = NULL;
    intf_cfg->ch_num = 0;

#ifdef CHIP_RADIO_NEED_TX_TPM_CAL
    if(txTpmCalib)
        free(txTpmCalib);
#endif
}

static uint32_t _radio_get_active_ch_freq(RADIO_INTF_CFG_T *intf_cfg, uint8_t direction)
{
    int16_t chIndex = (direction == 0) ? intf_cfg->tx_channel : intf_cfg->rx_channel;
    
    if(intf_cfg->ch_num == 0)
    {
        return 0;
    }
    else if((intf_cfg->ch_num == 1) && (chIndex == 0))
    {
        return intf_cfg->ch_freq;
    }
    else if(intf_cfg->ch_map != NULL)
    {
        return intf_cfg->ch_map[chIndex];
    }

    return 0;
}

static void _reset_rx_buffer(RADIO_INTF_CFG_T *intf_cfg)
{
    intf_cfg->rx_frame_count = 0;
    intf_cfg->rx_w_index = 0;
    intf_cfg->rx_r_index = 0;
}

static int32_t _setup_sw_crc(int8_t intf_idx)
{
    WISE_STATUS status = WISE_SUCCESS;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];
    WISE_RADIO_CRC_T *crc_cfg = &intf_cfg->pkt_fmt.crc;
    
    if(intf_cfg->crcTable)
    {
        free(intf_cfg->crcTable);
        intf_cfg->crcTable = NULL;
    }

    /*
    if(((crc_cfg->crc_config >> CRC_CFG_OFFSET_INPUT_BIT_ENDIAN) & 1) != 
        ((crc_cfg->crc_config >> CRC_CFG_OFFSET_OUTPUT_BIT_ENDIAN) & 1))
    {
        debug_print("CRC endian mode not supported\n");
        return WISE_FAIL;
    }
    */
    
    switch(crc_cfg->crc_poly_sel)
    {
        case CRC_POLYNOMIAL_NONE:
            intf_cfg->crcWidth = 0;
            return WISE_SUCCESS;
        break;
        
        case CRC_POLYNOMIAL_CRC8:
            intf_cfg->crcWidth = 1;

            if(crc_cfg->crc_config & CRC_INPUT_BIT_ENDIAN_MSB_FIRST)
                intf_cfg->crcPolySel = CRC_TYPE_8_CRC8;   
            else
                intf_cfg->crcPolySel = CRC_TYPE_8_MAXIM;
        break;

        case CRC_POLYNOMIAL_CRC16:
            intf_cfg->crcWidth = 2;
            if(crc_cfg->crc_config & CRC_INPUT_BIT_ENDIAN_MSB_FIRST)
                intf_cfg->crcPolySel = CRC_TYPE_16_BUYPASS;
            else
                intf_cfg->crcPolySel = CRC_TYPE_16_CRC16;
        break;
        
        case CRC_POLYNOMIAL_CCITT_16:
        case CRC_POLYNOMIAL_KERMIT:
            intf_cfg->crcWidth = 2;
            if(crc_cfg->crc_config & CRC_INPUT_BIT_ENDIAN_MSB_FIRST)
                intf_cfg->crcPolySel = CRC_TYPE_16_CCITT;
            else
                intf_cfg->crcPolySel = CRC_TYPE_16_MCRF4XX;
        break;
        
        case CRC_POLYNOMIAL_DNP16:
            intf_cfg->crcWidth = 2;
            if(crc_cfg->crc_config & CRC_INPUT_BIT_ENDIAN_MSB_FIRST)
                intf_cfg->crcPolySel = CRC_TYPE_16_EN_13757;
            else
                intf_cfg->crcPolySel = CRC_TYPE_16_DNP;
        break;

        case CRC_POLYNOMIAL_BLE24:
            debug_print("CRC 24 not supported yet.\n");
            return WISE_FAIL;
        break;

        default:
            debug_print("unknown CRC poly\n");
            return WISE_FAIL;
    }
    
    intf_cfg->crcTable = (uint8_t*)malloc(intf_cfg->crcWidth * 256);
    if(!intf_cfg->crcTable)
        return WISE_FAIL;

    switch(intf_cfg->crcWidth)
    {
        case 1:
            util_crc8_gen_table(intf_cfg->crcPolySel, intf_cfg->crcTable);
        break;

        case 2:
            util_crc16_gen_table(intf_cfg->crcPolySel, (uint16_t*)intf_cfg->crcTable);
        break;
    }
    
    return status;
}

static int32_t _setup_hw_crc(int8_t intf_idx, RADIO_CFG_T *p_hal_radio)
{
    WISE_STATUS status = WISE_SUCCESS;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];
    WISE_RADIO_CRC_T *crc_cfg = &intf_cfg->pkt_fmt.crc;

    // if(((crc_cfg->crc_config >> CRC_CFG_OFFSET_INPUT_BIT_ENDIAN) & 1) != 
    //     ((crc_cfg->crc_config >> CRC_CFG_OFFSET_OUTPUT_BIT_ENDIAN) & 1))
    // if(((crc_cfg->crc_config >> CRC_CFG_OFFSET_OUTPUT_BIT_ENDIAN) & 1) != 
    //     ((crc_cfg->crc_config >> CRC_CFG_OFFSET_OUTPUT_BYTE_ENDIAN) & 1))
    // {
    //     debug_print("CRC endian mode not supported\n");
    //     return WISE_FAIL;
    // }

    p_hal_radio->crc_config = crc_cfg->crc_config;
    p_hal_radio->crc_seed = (crc_cfg->crc_config & CRC_OUTPUT_BIT_ENDIAN_MSB_FIRST) ? bit_reverse(crc_cfg->crc_seed, 2) : crc_cfg->crc_seed;

    switch(crc_cfg->crc_poly_sel)
    {
        case CRC_POLYNOMIAL_NONE:
            p_hal_radio->crc_width = 0;
            return WISE_SUCCESS;
        break;
        
        case CRC_POLYNOMIAL_CRC8:
            debug_print("CRC 8 not supported yet.\n");
            return WISE_FAIL;
        break;

        case CRC_POLYNOMIAL_CRC16:
            p_hal_radio->crc_width = 16;
            intf_cfg->crcWidth = 2;
            if(crc_cfg->crc_config & CRC_INPUT_BIT_ENDIAN_MSB_FIRST)
                p_hal_radio->crc_polynomial = util_crc16_get_poly(CRC_TYPE_16_BUYPASS);
            else
                p_hal_radio->crc_polynomial = util_crc16_get_poly(CRC_TYPE_16_ARC);
        break;
        
        case CRC_POLYNOMIAL_CCITT_16:
        case CRC_POLYNOMIAL_KERMIT:
            p_hal_radio->crc_width = 16;
            intf_cfg->crcWidth = 2;
            if(crc_cfg->crc_config & CRC_INPUT_BIT_ENDIAN_MSB_FIRST)
                p_hal_radio->crc_polynomial = util_crc16_get_poly(CRC_TYPE_16_CCITT);
            else
                p_hal_radio->crc_polynomial = util_crc16_get_poly(CRC_TYPE_16_MCRF4XX);
        break;
        
        case CRC_POLYNOMIAL_DNP16:
            p_hal_radio->crc_width = 16;
            intf_cfg->crcWidth = 2;
            if(crc_cfg->crc_config & CRC_INPUT_BIT_ENDIAN_MSB_FIRST)
                p_hal_radio->crc_polynomial = util_crc16_get_poly(CRC_TYPE_16_EN_13757);
            else
                p_hal_radio->crc_polynomial = util_crc16_get_poly(CRC_TYPE_16_DNP);
        break;

        case CRC_POLYNOMIAL_BLE24:
            debug_print("CRC 24 not supported yet.\n");
            return WISE_FAIL;
        break;

        default:
            debug_print("unknown CRC poly\n");
            return WISE_FAIL;
    }

    return status;
}

//======================================================================================================================
//===============================================Radio API implementation===============================================

int8_t wise_radio_init(int8_t phy_idx)
{
    WISE_STATUS status         = WISE_SUCCESS;
    RADIO_ADAPT_T *adapt       = NULL;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[phy_idx];
    
    if(intf_cfg->phy_init_mode != PHY_INIT_NONE)
    {
        debug_print("radio %d already be inited to %d\n", phy_idx, intf_cfg->phy_init_mode);
        status = WISE_FAIL;
        goto finish;
    }
    
    hal_intf_radio_set_adapt(phy_idx);

    adapt = (RADIO_ADAPT_T *)hal_intf_radio_get_adapt(phy_idx);

    if (!adapt || phy_idx >= RADIO_PHY_NUM) {
        DBG_PRINT(": fail\n");
        status = WISE_FAIL;
        goto finish;
    }

    _radio_reset_ch_map(intf_cfg);
    
    memset(intf_cfg, 0, sizeof(RADIO_INTF_CFG_T));

    intf_cfg->rx_channel = WISE_INVALID_INDEX;
    intf_cfg->rx_mode    = RADIO_RX_CONTINUOUS;
    intf_cfg->phy_idx    = phy_idx;
    intf_cfg->phy_init_mode = PHY_INIT_TRANSPARENT;
    intf_cfg->phy_mode = E_PHY_TRANSPARENT;

    radio_isr_cb_data[phy_idx].phy_idx = phy_idx;

    if (phy_idx == PHY_IDX_0) 
    {
        hal_intf_radio_set_isr_callback(PHY_IDX_0, _radio_isr_internal, (void *)&radio_isr_cb_data[phy_idx]);
    }

#ifdef ES_DEVICE_TRX_RADIO

    if (phy_idx == PHY_IDX_1) {
        uint32_t i;
        uint8_t spi_idx = 0;
        /*===== config host interface=====*/
        static WISE_SPI_CONF_T spi_cfg = {.clock_mode     = CLOCK_MODE0,
                                          .spi_mode       = SPI_MODE_REGULAR,
                                          .role           = E_SPI_ROLE_MASTER,
                                          .data_bit_width = 8,
                                          .addr_len       = 2,
                                          .clock_sel      = E_SPI_CLOCK_SEL_5M,
                                          .bit_order      = SPI_MSB_FIRST,
                                          .data_merge     = 1,
                                          .addr_fmt       = 0,
                                          .block_mode     = E_SPI_BLOCK_MODE

        };

        wise_spi_init();
        if (wise_spi_master_open(spi_idx, &spi_cfg) == WISE_SUCCESS) {
            printf("SPI master %d is enabled\n", spi_idx);
        } else {
            printf("Failed to open SPI %d\n", spi_idx);
        }

        /*===== config TRX's gpio=====*/
        static WISE_TRX_GPIO_CFG_T trx_gpio_cfg[] = {
            {0, TRX_GPIO_MODE_DEFAULT, GIO_SEL_BUSY},
            {1, TRX_GPIO_MODE_DEFAULT, GIO_SEL_BUSY},
        };

        for (i = 0; i < TRX_GPIO_MAX_NUM; i++) {
            wise_trx_gpio_cfg(&trx_gpio_cfg[i]);
        }

        /*===== hook on host isr handler=====*/

        hal_intf_radio_set_isr_callback(PHY_IDX_1, _radio_isr_external, (void *)&radio_isr_cb_data[phy_idx]);
    }

#endif

finish:
    return status;
}

int8_t wise_radio_set_buffer(int8_t intf_idx, WISE_RADIO_BUFFER_T *buffer_pool)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    if (!buffer_pool) {
        return WISE_FAIL;
    }

    memcpy(&intf_cfg->buffer_pool, buffer_pool, sizeof(WISE_RADIO_BUFFER_T));

    // ES_INFO("set radio buffer pool %08x, %08x\n", bufferPool->addr,
    // bufferPool->length);

    intf_cfg->intf_cfg_sts |= RADIO_INTF_BUF_VALID;

    if (intf_cfg->intf_cfg_sts & (RADIO_INTF_CFG_VALID | RADIO_INTF_FMT_VALID)) {
        _setup_radio_buffer(intf_cfg);
    }

    return WISE_SUCCESS;
}

void wise_radio_deinit(int8_t intf_idx)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    intf_cfg->phy_init_mode = PHY_INIT_NONE;

    hal_intf_radio_deinit();

    _radio_reset_ch_map(intf_cfg);
    
    memset(intf_cfg, 0, sizeof(RADIO_INTF_CFG_T));
}

int8_t wise_radio_set_evt_callback(int8_t intf_idx, WISE_RADIO_EVT_CB evt_cb)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    if (!evt_cb) {
        return WISE_FAIL;
    }

    intf_cfg->evt_callback = evt_cb;
    return WISE_SUCCESS;
}

int8_t wise_radio_config(int8_t intf_idx, WISE_RADIO_CFG_T *cfg, WISE_RADIO_PKT_FMT_T *pkt_fmt)
{
    WISE_STATUS status         = WISE_SUCCESS;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];
    WISE_RADIO_PHR_T *phr_cfg = &pkt_fmt->phr;
    uint32_t intEnMask = HAL_RADIO_INT_TX_FIN | 
                            HAL_RADIO_INT_TX_ERR |
                            HAL_RADIO_INT_RX_FIN |
                            HAL_RADIO_INT_RX_ERR;
    
    if ((!cfg) || (!pkt_fmt)) {
        debug_print("error: pkt_fmt is wrong\n");
        status = WISE_FAIL;
        goto error_return;
    }

    if (cfg->ch_freq_min > cfg->ch_freq_max) {
        debug_print("error: ch_freq_min > ch_freq_max\n");
        status = WISE_FAIL;
        goto error_return;
    }

    if (cfg->data_rate >= E_DATA_RATE_MAX) {
        debug_print("error: data_rate >= E_DATA_RATE_MAX\n");
        status = WISE_FAIL;
        goto error_return;
    }

    if (pkt_fmt->pkt_type == PKT_VARIABLE_LENGTH) {
        if ((phr_cfg->hdr_bytes == 0) || ((phr_cfg->hdr_bytes != 0) && (phr_cfg->length_bit_size == 0))) {
            debug_print("error: Invalid packet format\n");
            status = WISE_FAIL;
            goto error_return;
        }
    } else {
        phr_cfg->hdr_bytes = 0;
        phr_cfg->length_bit_size = 0;
    }

    _radio_reset_ch_map(intf_cfg);

    if ((cfg->ch_freq_min != 0) && (cfg->ch_freq_max != 0) && (cfg->ch_spacing != 0)) 
    {
        uint32_t ch_freq = cfg->ch_freq_min;
        uint16_t ch_num  = (cfg->ch_freq_max - cfg->ch_freq_min) / cfg->ch_spacing + 1;

        intf_cfg->ch_map = (uint32_t*)malloc(sizeof(uint32_t) * ch_num);
        
        ch_num = 0;
        while (ch_freq <= cfg->ch_freq_max) {
            intf_cfg->ch_map[ch_num]  = ch_freq;
            ch_freq                  += cfg->ch_spacing;
            ch_num++;
        }

        intf_cfg->ch_num = ch_num;
    }
    else if((cfg->ch_spacing == 0) && (cfg->ch_freq_min == cfg->ch_freq_max)) //for only one channel
    {
        intf_cfg->ch_num = 1;
        intf_cfg->ch_freq = cfg->ch_freq_min;
    }

#ifdef CHIP_RADIO_NEED_TX_TPM_CAL
    txTpmCalib = (TPM_CAL_PARA*)malloc(sizeof(TPM_CAL_PARA) * intf_cfg->ch_num);
    if(!txTpmCalib)
    {
        debug_print("TPM calib buf fail\n");
        status = WISE_FAIL;
        goto error_return;
    }

    memset(txTpmCalib, 0, sizeof(TPM_CAL_PARA) * intf_cfg->ch_num);
#endif

    if(intf_cfg->phy_init_mode == PHY_INIT_WMBUS)
    {
        intEnMask |= HAL_RADIO_INT_RX_SYNCWORD;
    }

    if(intf_cfg->tx_io_mode == CORE_IO_BLOCKING)
    {        
        intEnMask &= ~(HAL_RADIO_INT_TX_FIN | HAL_RADIO_INT_TX_ERR);
    }
    else
    {
        intEnMask |= (HAL_RADIO_INT_TX_FIN | HAL_RADIO_INT_TX_ERR);
    }
    
    // keep user config in our mind for later use
    memcpy(&intf_cfg->user_cfg, cfg, sizeof(WISE_RADIO_CFG_T));
    memcpy(&intf_cfg->pkt_fmt, pkt_fmt, sizeof(WISE_RADIO_PKT_FMT_T));

    intf_cfg->rx_byte_time_us = RADIO_DR_VALUE[cfg->data_rate].rxByteTime;
    
    if (phr_cfg->length_bit_size) {
        int i;

        for (i = 0; i < phr_cfg->length_bit_size; i++) {
            intf_cfg->phr_len_mask |= (1 << i);
        }
    }
        
    intf_cfg->intf_cfg_sts |= (RADIO_INTF_CFG_VALID | RADIO_INTF_FMT_VALID);

    if (intf_cfg->intf_cfg_sts & RADIO_INTF_BUF_VALID) {
        _setup_radio_buffer(intf_cfg);
    }
    
    status = _radio_config(intf_idx, intf_cfg);

#if 0 //(CHIP_RADIO_FLEXIBLE_FMT_VERSION >= 1)
    if((intf_cfg->intf_cfg_sts & RADIO_INTF_SW_FRAME) && (intf_cfg->pkt_fmt.pkt_type == PKT_VARIABLE_LENGTH) && (intf_cfg->rx_byte_time_us != 0))
    {
        rxSyncCallback = _sw_rx_syncword_handler;
        rxDataValidate = _validate_rx_data;
        intEnMask |= HAL_RADIO_INT_RX_SYNCWORD;
    }
    else
    {
        rxSyncCallback = NULL;
        rxDataValidate = NULL;
        intEnMask &= ~HAL_RADIO_INT_RX_SYNCWORD;
    }
#endif

    hal_intf_radio_set_int_en(intf_idx, intEnMask);    
error_return:
    return status;
}

void _wmbus_set_mode(int8_t intf_idx, wmbus_mode_t mode)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    switch(mode)
    {
        case WMBUS_MODE_S1:
        case WMBUS_MODE_S2:
            intf_cfg->wmbus_mode = HAL_WMBUS_MODE_S;
        break;

        case WMBUS_MODE_T1:
        case WMBUS_MODE_T2:
            intf_cfg->wmbus_mode = HAL_WMBUS_MODE_T;
        break;

        case WMBUS_MODE_C1:
        case WMBUS_MODE_C2:
            intf_cfg->wmbus_mode = HAL_WMBUS_MODE_C;
        break;

        case WMBUS_MODE_R2:
            intf_cfg->wmbus_mode = HAL_WMBUS_MODE_R;
        break;

        case WMBUS_MODE_F2:
            intf_cfg->wmbus_mode = HAL_WMBUS_MODE_F;
        break;

        default:
            debug_print("Unsupported mbus mode %d\n", mode);
        break;
    }
}

void _wmbus_set_tx_config(int8_t intf_idx, WISE_RADIO_CFG_T *cfg, WISE_RADIO_PKT_FMT_T *pkt_fmt)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    intf_cfg->ch_num = 1;
    intf_cfg->ch_freq = cfg->ch_freq_min;
    
    // keep user config in our mind for later use
    memcpy(&intf_cfg->user_cfg, cfg, sizeof(WISE_RADIO_CFG_T));
    memcpy(&intf_cfg->pkt_fmt, pkt_fmt, sizeof(WISE_RADIO_PKT_FMT_T));

    _radio_mbus_config(intf_idx, intf_cfg, 1);
}

void _wmbus_set_rx_config(int8_t intf_idx, WISE_RADIO_CFG_T *cfg, WISE_RADIO_PKT_FMT_T *pkt_fmt)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    intf_cfg->ch_num = 1;
    intf_cfg->ch_freq = cfg->ch_freq_min;
    
    // keep user config in our mind for later use
    memcpy(&intf_cfg->user_cfg, cfg, sizeof(WISE_RADIO_CFG_T));
    memcpy(&intf_cfg->pkt_fmt, pkt_fmt, sizeof(WISE_RADIO_PKT_FMT_T));
    
    _radio_mbus_config(intf_idx, intf_cfg, 0);
}


int8_t wise_radio_get_channel_freq(int8_t intf_idx, uint8_t ch_index, uint32_t *ch_freq)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    if(intf_cfg->ch_num == 1)
    {
        if(ch_index != 0)
            return WISE_FAIL;

        *ch_freq = intf_cfg->ch_freq;
    }

    if (ch_index < intf_cfg->ch_num) {
        *ch_freq = intf_cfg->ch_map[ch_index];
        return WISE_SUCCESS;
    }

    return WISE_FAIL;
}

uint8_t wise_radio_get_channel_num(int8_t intf_idx)
{
    return radio_intf_cfg[intf_idx].ch_num;
}

int8_t wise_radio_set_channel_table(int8_t intf_idx, uint32_t *freq_table, uint8_t ch_num)
{
    WISE_STATUS status = WISE_SUCCESS;
    int i;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    if ((!freq_table) || (ch_num == 0)) {
        status = WISE_FAIL;
        goto finish;
    }

    _radio_reset_ch_map(intf_cfg);

    intf_cfg->ch_map = (uint32_t*)malloc(sizeof(uint32_t) * ch_num);
    memset(&intf_cfg->ch_map[0], 0, sizeof(uint32_t) * ch_num);

    for (i = 0; i < ch_num; i++) {
        intf_cfg->ch_map[i] = freq_table[i];
    }

    intf_cfg->ch_num = ch_num;

finish:
    return status;
}

void wise_radio_set_tx_csma(int8_t intf_idx, uint8_t enable, WISE_RADIO_CCA_T *csma_cfg)
{
    // RADIO_CTRL_T* radioIntf = &radioCtrl[intfIdx];

    // TODO:
}

int8_t wise_radio_set_tx_pwr(int8_t intf_idx, uint8_t tx_pwr_level)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    if (tx_pwr_level > MAX_TX_PWR_LEVEL) {
        return WISE_FAIL;
    }

    intf_cfg->tx_pwr_level = tx_pwr_level;
    intf_cfg->tx_pwr_dbm = hal_intf_radio_tx_pwr_raw_to_dbm(tx_pwr_level);
    
    hal_intf_radio_set_tx_pwr(intf_idx, tx_pwr_level);
    
    //debug_print("pwr_level %d -> %ddbm\n", tx_pwr_level, intf_cfg->tx_pwr_dbm);
    
    return WISE_SUCCESS;
}

uint8_t wise_radio_get_tx_pwr(int8_t intf_idx)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    return intf_cfg->tx_pwr_level;
}

int8_t wise_radio_set_tx_pwr_dbm(int8_t intf_idx, int8_t pwr_dbm)
{
    uint8_t tx_pwr_level = hal_intf_radio_tx_pwr_dbm_to_raw(pwr_dbm);
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    //debug_print("set pwr_dbm=%d -> gain=%d\n", pwr_dbm, tx_pwr_level);

    intf_cfg->tx_pwr_level = tx_pwr_level;
    intf_cfg->tx_pwr_dbm = pwr_dbm;
    
    hal_intf_radio_set_tx_pwr(intf_idx, tx_pwr_level);
    
    return WISE_SUCCESS;
}

uint8_t wise_radio_get_tx_pwr_dbm(int8_t intf_idx)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];
    return intf_cfg->tx_pwr_dbm;
}

uint16_t wise_radio_get_raw_rssi(int8_t intf_idx)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];
    uint16_t raw_rssi;

    if (!(intf_cfg->radio_sts & RADIO_STS_RX_ON)) {
        return 0xffff;
    }

    _radio_rx_pause(intf_cfg);
    raw_rssi = hal_intf_radio_get_cca_rssi(intf_idx);
    _radio_rx_resume(intf_cfg);

    return raw_rssi;
}

int8_t wise_radio_get_rssi(int8_t intf_idx)
{
    uint16_t raw_rssi = wise_radio_get_raw_rssi(intf_idx);

    if (raw_rssi == 0xffff) {
        return INVALID_RSSI;
    }

    return (int8_t)RADIO_RSSI_CALC(raw_rssi);
}

void wise_radio_set_tx_io_mode(int8_t intf_idx, CORE_IO_MODE_T ioMode)
{
    uint32_t intEn = 0;
    
    radio_intf_cfg[intf_idx].tx_io_mode = ioMode;

    intEn = hal_intf_radio_get_int_en(intf_idx);
    
    if(ioMode == CORE_IO_BLOCKING)
    {        
        intEn &= ~(HAL_RADIO_INT_TX_FIN | HAL_RADIO_INT_TX_ERR);
    }
    else
    {
        intEn |= (HAL_RADIO_INT_TX_FIN | HAL_RADIO_INT_TX_ERR);
    }

    hal_intf_radio_set_int_en(intf_idx, intEn);

}

int8_t wise_radio_tx_frame(int8_t intf_idx, uint8_t ch_index, uint8_t *pframe, uint16_t length)
{
    WISE_STATUS status         = WISE_SUCCESS;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    RADIO_ADAPT_T *adapt = (RADIO_ADAPT_T *)hal_intf_radio_get_adapt(intf_idx);
    RADIO_CFG_T *p_hal_radio = &adapt->radio_cfg;

    if (intf_cfg->radio_sts & RADIO_STS_TX_ARMED) {
        debug_print("[error]radioSts = RADIO_STS_TX_ARMED\n");
        return WISE_FAIL;
    }

    if ((!pframe) || (length == 0) || (length > intf_cfg->pkt_fmt.max_pkt_length) || (ch_index >= intf_cfg->ch_num)) {
        debug_print("[error]para invalid\n");
        return WISE_FAIL;
    }

    if (intf_cfg->pkt_fmt.pkt_type == PKT_FIXED_LENGTH) {
        if (length > intf_cfg->pkt_fmt.max_pkt_length) {
            debug_print("[error]frame overflow\n");
            return WISE_FAIL;
        }

        if (length < intf_cfg->pkt_fmt.max_pkt_length) {
            debug_print("frame underflow\n");
            memset(intf_cfg->tx_buffer, 0, intf_cfg->pkt_fmt.max_pkt_length);
        }
    }

    if (intf_cfg->radio_sts & RADIO_STS_RX_ON) {
        _radio_rx_pause(intf_cfg);
    }

    intf_cfg->tx_channel = ch_index;
    
    if (intf_cfg->intf_cfg_sts & RADIO_INTF_TX_SW_FRAME) 
    {
        if (WISE_SUCCESS != _pack_tx_frame(intf_cfg, pframe, length)) 
        {
            return WISE_FAIL;
        }

        p_hal_radio->frame_hw_opt &= ~(FRAME_HW_PHR | FRAME_HW_CRC);
    } 
    else 
    {
        CORE_DECLARE_IRQ_STATE;

        CORE_ENTER_CRITICAL();

        memcpy(intf_cfg->tx_buffer, pframe, length);

        if (intf_cfg->pkt_fmt.pkt_type == PKT_FIXED_LENGTH) 
        {
            length = intf_cfg->pkt_fmt.max_pkt_length;
        }

        intf_cfg->tx_len = length;
        intf_cfg->radio_sts |= RADIO_STS_TX_ARMED;

        CORE_EXIT_CRITICAL();

        p_hal_radio->frame_hw_opt |= (FRAME_HW_PHR | FRAME_HW_CRC);
        
        if(WISE_SUCCESS != _setup_hw_crc(intf_idx, p_hal_radio))
        {
            debug_print("TX setup HW CRC failed\n");
            return WISE_FAIL;
        }
    }

    if(intf_cfg->phy_init_mode != PHY_INIT_WMBUS)
    {
        //debug_print("setup TX frame format hw_opt=%08x\n", p_hal_radio->frame_hw_opt);
        if (hal_intf_radio_tx_config(intf_idx, p_hal_radio) != WISE_SUCCESS) 
        {
            DBG_PRINT("radio tx init fail\n");
            return WISE_FAIL;
        }
    }
    
    _radio_tx_fire(intf_cfg);

    // HAL should handle Tx frame according to ioMode
    // if ioMode == TX_MODE_BLOCKING, HAL may block in a waiting loop for a flag
    // setup in Tx ISR
    if (intf_cfg->tx_io_mode == CORE_IO_BLOCKING) 
    {
        uint32_t intStatus = 0;
        uint32_t intMask = HAL_RADIO_INT_TX_FIN | HAL_RADIO_INT_TX_ERR;
        uint32_t start_clk = wise_tick_get_counter();
        
        while(1)
        {
            intStatus = hal_intf_radio_get_int_mask_status(intf_idx, intMask);
            if(intStatus)
            {
                if(intStatus & HAL_RADIO_INT_TX_ERR)
                    status = WISE_FAIL;
                
                break;
            }

            if (CLK_TO_MS(wise_tick_get_counter() - start_clk) > TX_TIMEOUT) 
            {
                debug_print("tx timeout\n");
                status = WISE_FAIL;
                break;
            }
        }

        _radio_tx_state_transition(intf_cfg);
        
        intf_cfg->radio_sts &= ~(RADIO_STS_TX);
    }
    
    return status;
}

int8_t wise_radio_set_tx_state_transition(int8_t intf_idx, WISE_TX_TRANSITION_T transition)
{
    int status = WISE_SUCCESS;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    if(transition > TX_FINISH_TO_RX)
        return WISE_FAIL;
    
    intf_cfg->tx_state_trans = transition;
    
    return status;
}


int8_t wise_radio_tx_stop(int8_t intf_idx)
{
    hal_intf_radio_tx_stop(intf_idx);

    return WISE_SUCCESS;
}

int8_t wise_radio_set_rx_max_frame_length(int8_t intf_idx, uint16_t max_len)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    intf_cfg->pkt_fmt.max_pkt_length = max_len;
    
    return WISE_SUCCESS;
}

int8_t wise_radio_set_rx_mode(int8_t intf_idx, WISE_RADIO_RX_MODE_T rx_mode)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    intf_cfg->rx_mode = rx_mode;
    
    return WISE_SUCCESS;
}

int8_t wise_radio_rx_start(int8_t intf_idx, uint8_t ch_index)
{
    WISE_STATUS status         = WISE_SUCCESS;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    CORE_DECLARE_IRQ_STATE;

    if (ch_index >= intf_cfg->ch_num) {
        return WISE_FAIL;
    }

#if 0

    if (radioIntf->rxFrameCount >= RADIO_RX_BUF_NUM) {
        debug_print("rx full\n");
        return WISE_FAIL;
    }

#endif

    /*
    if(radioIntf->radioSts & RADIO_STS_RX_TMR_ON)
    {
        radioRxStopOffTimer(radioIntf);
    }
    */

    CORE_ENTER_CRITICAL();

    if (intf_cfg->radio_sts & RADIO_STS_RX_ON) {
        _radio_rx_stop(intf_cfg);
    }

    _reset_rx_buffer(intf_cfg);
    
    //intf_cfg->rx_mode    = rx_mode;
    intf_cfg->radio_sts &= ~RADIO_STS_RX;

    // radioIntf->rxFrameCount = radioIntf->rxWIndex = radioIntf->rxRIndex = 0;
    CORE_EXIT_CRITICAL();

    /*
    if((onUs != 0) && (onUs != WISE_RADIO_TIME_ENDLESS))
    {
        radioRxSetupOffTimer(radioIntf, onUs);
    }
    */

    _radio_rx_start(intf_cfg, ch_index);

    return status;
}

void wise_radio_rx_stop(int8_t intf_idx)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    /*
    if(radioIntf->radioSts & RADIO_STS_RX_TMR_ON)
    {
        radioRxStopOffTimer(radioIntf);
        radioIntf->radioSts &= ~RADIO_STS_RX_TMR_ON;
    }
    */

    if (intf_cfg->radio_sts & RADIO_STS_RX_ON) {
        _radio_rx_stop(intf_cfg);
    }
}

uint8_t wise_radio_get_rx_frame_num(int8_t intf_idx)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    return intf_cfg->rx_frame_count;
}

int8_t wise_radio_read_rx_frame(int8_t intf_idx, uint8_t *pframe, uint16_t *out_len, WISE_RX_META_T *meta)
{
    WISE_STATUS status         = WISE_SUCCESS;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];
    WISE_RX_META_T *pFrameMeta;
    uint8_t *pFrameStart = NULL;

    CORE_DECLARE_IRQ_STATE;

    if (intf_cfg->rx_frame_count == 0) {
        return WISE_FAIL;
    }

    pFrameStart = intf_cfg->rx_buf_bank[intf_cfg->rx_r_index];
    pFrameMeta  = RX_FRAME_META(pFrameStart);

    if (pFrameMeta->data_len) {
        memcpy(pframe, pFrameStart, pFrameMeta->data_len);
        *out_len = pFrameMeta->data_len;
    }

    if (meta) {
        memcpy(meta, pFrameMeta, sizeof(WISE_RX_META_T));
    }

    CORE_ENTER_CRITICAL();
    intf_cfg->rx_frame_count--;
    intf_cfg->rx_r_index++;

    if (intf_cfg->rx_r_index == intf_cfg->rx_buf_num) {
        intf_cfg->rx_r_index = 0;
    }

    CORE_EXIT_CRITICAL();

    return status;
}

int8_t wise_radio_get_rx_frame_info(int8_t intf_idx, uint32_t *out_frame_addr, WISE_RX_META_T *out_meta)
{
    WISE_STATUS status = WISE_FAIL;
    uint32_t frameAddr = 0;
    WISE_RX_META_T *pFrameMeta;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    CORE_DECLARE_IRQ_STATE;

    if (intf_cfg->rx_frame_count > 0) {
        // debug_print("rIdx=%d\n", radioIntf->rxRIndex);

        CORE_ENTER_CRITICAL();
        frameAddr  = (uint32_t)intf_cfg->rx_buf_bank[intf_cfg->rx_r_index];
        pFrameMeta = RX_FRAME_META(frameAddr);
        memcpy(out_meta, pFrameMeta, sizeof(WISE_RX_META_T));

        if (intf_cfg->phy_mode == E_PHY_802154) {
            uint8_t *pframe = (uint8_t *)frameAddr;

            *out_frame_addr = (uint32_t)&pframe[1];
            out_meta->data_len = pframe[0];
        } else {
            *out_frame_addr = frameAddr;
        }

        CORE_EXIT_CRITICAL();

        status = WISE_SUCCESS;
    }

    return status;
}

int8_t wise_radio_release_rx_frame(int8_t intf_idx)
{
    WISE_STATUS status         = WISE_FAIL;
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];

    CORE_DECLARE_IRQ_STATE;

    if (intf_cfg->rx_frame_count > 0) {
        CORE_ENTER_CRITICAL();
        intf_cfg->rx_frame_count--;
        intf_cfg->rx_r_index++;

        if (intf_cfg->rx_r_index == intf_cfg->rx_buf_num) {
            intf_cfg->rx_r_index = 0;
        }

        if ((intf_cfg->rx_mode == RADIO_RX_CONTINUOUS) && (intf_cfg->radio_sts & RADIO_STS_RX_PAUSED)) {
            _radio_rx_resume(intf_cfg);
        }

        CORE_EXIT_CRITICAL();

        status = WISE_SUCCESS;
    }

    return status;
}

void wise_radio_enable_singletone(int8_t intf_idx, uint8_t ch_index, uint8_t pwr_lv, uint8_t enable)
{
    RADIO_INTF_CFG_T *intf_cfg = &radio_intf_cfg[intf_idx];
    uint32_t chFreq = 0;

    if(intf_cfg->ch_num == 1)
        chFreq = intf_cfg->ch_freq;
    else
        chFreq = intf_cfg->ch_map[ch_index];
    
    hal_intf_radio_set_ch(intf_cfg->phy_idx, chFreq);
    hal_intf_pmu_module_clk_enable(MAC_MODULE | BBP_MODULE | ANA_MODULE);
    hal_intf_radio_enable_singletone(intf_cfg->phy_idx, pwr_lv, enable);

    if (enable == 0) {
        hal_intf_pmu_module_clk_disable(MAC_MODULE | BBP_MODULE | ANA_MODULE);
    }    
}

//implementation of internal test APIs
void _wise_radio_get_rx_info_output(int8_t intf_idx)
{
    hal_intf_radio_print_rx_info(intf_idx);
}

void _wise_radio_test(void)
{
    hal_intf_radio_test();
}

void _wise_radio_set_sg_test_mode(uint8_t enable)
{
    g_sg_mode_flag = enable;
}

uint8_t _wise_radio_get_sg_test_mode()
{
    return g_sg_mode_flag;
}

void _wise_radio_set_phy_mode(int8_t intf_idx, uint8_t phy_mode)
{
    RADIO_ADAPT_T *adapt = (RADIO_ADAPT_T *)hal_intf_radio_get_adapt(intf_idx);
    RADIO_CFG_T *p_hal_radio = &adapt->radio_cfg;
    
    radio_intf_cfg[intf_idx].phy_mode = phy_mode;
    p_hal_radio->phy_mode = phy_mode;
}

uint8_t _wise_radio_get_phy_mode(int8_t intf_idx)
{
    return radio_intf_cfg[intf_idx].phy_mode;
}

void _wise_radio_set_ulpldo(uint8_t enable)
{
    hal_intf_radio_set_ulpldo(enable);
}

