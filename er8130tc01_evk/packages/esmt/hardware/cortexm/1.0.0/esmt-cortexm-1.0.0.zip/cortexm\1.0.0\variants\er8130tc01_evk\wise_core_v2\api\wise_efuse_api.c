/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "api/wise_efuse_api.h"

void wise_efuse_read_word(uint16_t addr, uint32_t * data)
{
    hal_intf_efuse_read_word(addr, data);
}

void wise_efuse_write_word(uint16_t addr, uint32_t data)
{
    hal_intf_efuse_write_word(addr, data);
}

