#include "Arduino.h"
#include "Print.h"
#include "HardwareSerial.h"

#ifdef __cplusplus
extern "C" {
#endif
#include "wise_uart_api.h"
#include "util.h"
#ifdef __cplusplus
}
#endif

extern void _serail_init(uint8_t intf, uint32_t baud);

HardwareSerial Serial(ARDUINO_SERIAL_UART);

void HardwareSerial::begin(uint32_t baud) 
{
    rxFifo = (uint8_t*)malloc(rxFifoSize);
    rxFifoReset();
    
    _serail_init(_intf, baud);
}

int HardwareSerial::available() 
{
    if(rxDataLen > 0)
    {
        return 1;
    }
    
    return 0;
}

int HardwareSerial::read() 
{
    uint8_t c;
    
    /*
    int32_t r = wise_uart_read_char(_intf, &c);

    if (r == WISE_SUCCESS) 
        return (int)c;
    */
    
    if(rxDataLen > 0)
    {
        c = rxFifo[rxFifoRPos];

        rxFifoRPos++;
        if(rxFifoRPos == rxFifoSize)
            rxFifoRPos = 0;
        rxDataLen--;
        
        return (int)c;
    }
    
    return -1;
}

size_t HardwareSerial::write(uint8_t b)
{
    if (wise_uart_write_char(_intf, b) == WISE_SUCCESS) 
        return 1;
    return 0;
}

size_t HardwareSerial::write(const uint8_t *buffer, size_t size) 
{
    size_t n = 0;

    while (size--) 
    {
        n += write(*buffer++);
    }

    return n;
}

int HardwareSerial::pushChar(uint8_t c)
{
    if(rxFifo && (rxDataLen < rxFifoSize))
    {        
        rxFifo[rxFifoWPos] = c;
        rxDataLen++;
        rxFifoWPos++;
        if(rxFifoWPos == rxFifoSize)
            rxFifoWPos = 0;
        
        return 0;
    }

    return -1;
}


void HardwareSerial::rxFifoReset()
{
    if(rxFifo)
    {
        memset(rxFifo, 0, rxFifoSize);
    }

    rxFifoRPos = 0;
    rxFifoWPos = 0;
    rxDataLen = 0;
}


