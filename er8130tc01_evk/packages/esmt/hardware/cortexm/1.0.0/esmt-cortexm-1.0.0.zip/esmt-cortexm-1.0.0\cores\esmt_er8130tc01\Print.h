#pragma once
#include <stddef.h>
#include <stdint.h>

class Print 
{
    public:
        virtual ~Print() {}

        virtual size_t write(uint8_t b) = 0;

        virtual size_t write(const uint8_t *buffer, size_t size) 
        {
            size_t n = 0;

            while (size--) 
            {
                n += write(*buffer++);
            }
            
            return n;
        }
    
        size_t print(const char *s);
        
        size_t println(void);
        size_t println(const char *s);
        size_t println(int v);
        size_t println(unsigned int v);
        size_t println(long v);
        size_t println(unsigned long v);
        
    protected:
        size_t printNumber(unsigned long n, uint8_t base);
};

