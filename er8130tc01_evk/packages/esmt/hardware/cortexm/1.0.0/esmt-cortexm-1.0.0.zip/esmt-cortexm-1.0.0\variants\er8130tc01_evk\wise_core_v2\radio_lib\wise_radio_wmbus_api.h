#ifndef __WSIE_RADIO_WMBUS_API_H_
#define __WSIE_RADIO_WMBUS_API_H_

#include <stdint.h>
#include "types.h"
#include "wmbus_parameters.h"
#include "wise_radio_api.h"

typedef enum
{
    WMBUS_ROLE_OTHER = 0,
    WMBUS_ROLE_METER = 1
} wmbus_role_t;

typedef enum {
    WMBUS_MODE_S1 = 0,
    WMBUS_MODE_S1M = 1,
    WMBUS_MODE_S2 = 2,
    WMBUS_MODE_T1 = 3 ,
    WMBUS_MODE_T2 = 4,
    WMBUS_MODE_C1 = 5,
    WMBUS_MODE_C2 = 6,
    WMBUS_MODE_R2 = 7,
    WMBUS_MODE_F2 = 8,
    WMBUS_MODE_N = 9
} wmbus_mode_t;

typedef enum
{
    WMBUS_FRAME_TYPE_A = 0,
    WMBUS_FRAME_TYPE_B,
} wmbus_frame_type_t;

// Codec
typedef WISE_FRAME_CODEC_T wmbus_codec_t;

//GFSK bandwidth
enum
{
    WMBUS_GFSK_BW_0_25 = 0,   //0.25
    WMBUS_GFSK_BW_0_50,       //0.50
    WMBUS_GFSK_BW_0_75,       //0.75
    WMBUS_GFSK_BW_1_00,       //1.00
};


int8_t wise_radio_wmbus_init(int8_t intf_idx);
int8_t wise_radio_wmbus_set_mode(int8_t intf_idx, wmbus_role_t mbusRole, wmbus_mode_t mbusMode);
int8_t wise_radio_wmbus_set_max_frame_len(int8_t intf_idx, uint16_t maxLen);

int8_t wise_radio_mbus_rx_start(int8_t intf_idx, uint8_t ch_index, WISE_RADIO_RX_MODE_T rx_mode);
void wise_radio_wmbus_rx_stop(int8_t intf_idx);
int8_t wise_radio_wmbus_tx_frame(int8_t intf_idx, uint8_t ch_index, uint8_t *pframe, uint16_t length);

void wise_radio_wmbus_deinit(int8_t intf_idx);

#endif  /* __WSIE_RADIO_WMBUS_API_H_ */

