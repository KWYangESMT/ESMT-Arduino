/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "api/wise_pwm_api.h"

/*---------------------------------------------------------------
  init / deinit
  ---------------------------------------------------------------*/
WISE_STATUS wise_pwm_init(void)
{
    return WISE_SUCCESS;
}

WISE_STATUS wise_pwm_deinit(void)
{
    return wise_pmu_module_clk_disable(PWM_MODULE);
}
/*---------------------------------------------------------------
  configure
  ---------------------------------------------------------------*/
WISE_STATUS wise_pwm_configure(uint8_t channel, uint8_t gpio_index, WISE_PWM_CONF_T *pwm_conf)
{
    if (pwm_conf == NULL) {
        return WISE_INVALID_INDEX;
    }
    wise_pmu_module_clk_enable(PWM_MODULE);
    wise_pwm_io_disable_pin(gpio_index);

    HAL_PWM_CONF_T hal_pwm_conf;
    memset(&hal_pwm_conf, 0, sizeof(hal_pwm_conf));

    if (pwm_conf->common.mode == PWM_MODE_PERIOD) {
        hal_pwm_conf.period          = pwm_conf->u.period.period;
        hal_pwm_conf.active_period   = pwm_conf->u.period.active_period;
        hal_pwm_conf.center_align_en = pwm_conf->common.center_align_en;
        hal_pwm_conf.oneshot_en      = pwm_conf->common.oneshot_en;
        hal_pwm_conf.oneshot_num     = pwm_conf->common.oneshot_num;
        hal_intf_pwm_cfg_output_period(1u << channel, &hal_pwm_conf);
    } else if (pwm_conf->common.mode == PWM_MODE_FREQUENCY) {
        hal_pwm_conf.frequency_Hz    = pwm_conf->u.freq.frequency_Hz;
        hal_pwm_conf.duty_percent    = pwm_conf->u.freq.duty_percent;
        hal_pwm_conf.center_align_en = pwm_conf->common.center_align_en;
        hal_pwm_conf.oneshot_en      = pwm_conf->common.oneshot_en;
        hal_pwm_conf.oneshot_num     = pwm_conf->common.oneshot_num;
        hal_intf_pwm_cfg_output_frequency(1u << channel, &hal_pwm_conf);
    } else {
        return WISE_INVALID_INDEX;
    }

    if (pwm_conf->common.oneshot_en == ENABLE) {
        hal_intf_pwm_enable_oneshot_interrupt(1u << channel);
    } else {
        hal_intf_pwm_disable_oneshot_interrupt(1u << channel);
    }

    hal_intf_pwm_set_io_for_channel_pin(channel, &hal_pwm_conf);
    wise_gpio_set_pwm(channel, gpio_index, ENABLE);
    wise_gpio_set_mode(gpio_index, MODE_PWM);
    return WISE_SUCCESS;
}
/*---------------------------------------------------------------
  start / stop
  ---------------------------------------------------------------*/
void wise_pwm_start(uint32_t channel_mask)
{
    hal_intf_pwm_start(channel_mask);
}

void wise_pwm_stop(uint32_t channel_mask)
{
    hal_intf_pwm_stop(channel_mask);
}
/*---------------------------------------------------------------
  Callback Registration
  ---------------------------------------------------------------*/
WISE_STATUS wise_pwm_register_callback(WISE_PWM_CB_EVENT_T event, CALLBACK_T cb, void *context)
{
    return hal_intf_pwm_register_callback(event, cb, context);
}

WISE_STATUS wise_pwm_unregister_callback(WISE_PWM_CB_EVENT_T event)
{
    return hal_intf_pwm_unregister_callback(event);
}
