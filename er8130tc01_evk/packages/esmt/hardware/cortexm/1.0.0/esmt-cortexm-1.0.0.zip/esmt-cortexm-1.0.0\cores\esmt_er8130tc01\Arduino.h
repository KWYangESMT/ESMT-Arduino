#pragma once
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#include "pins_arduino.h"

#include "wise_core.h"
#include "wise_uart_api.h"
#include "wise_gpio_api.h"

typedef enum
{
    E_PLATFORM_STATE_IDLE = 0,
    E_PLATFORM_STATE_BUSY = 1,
} E_PLATFORM_STATE_T;

void init(void);
E_PLATFORM_STATE_T platform_proc();
void platform_set_state(E_PLATFORM_STATE_T state);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
#include "Print.h"
#include "HardwareSerial.h"
#endif

/* ===== Arduino common macros (C / C++) ===== */
#define HIGH                0x1
#define LOW                 0x0

#define INPUT               0x0
#define OUTPUT              0x1

#ifdef __cplusplus
extern "C" {
#endif

void pinMode(uint8_t pin, uint8_t mode);
void digitalWrite(uint8_t pin, uint8_t val);
int  digitalRead(uint8_t pin);

unsigned long millis(void);
unsigned long micros(void);
void delay(unsigned long ms);

#ifdef __cplusplus
}
#endif
