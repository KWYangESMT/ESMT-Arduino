#include "hal_drv_radio.h"
#include "modem_config.h"

const uint32_t bbp_basic_setting[8][2] = {
    { 0x40028000, 0x00006806 },
    { 0x400280D0, 0x00050805 },
    { 0x4002819C, 0x00055E03 },
    { 0x400281A8, 0x00000045 },
    { 0x400281B4, 0x00000000 },
    { 0x40028204, 0x00402060 },
    { 0x40028304, 0x00000010 },
    { 0x4002830C, 0x00014200 },
};

const uint32_t bbp_gain_table[35][2] = {
    { 0x4002815C, 0x33332222 },
    { 0x40028160, 0x33333333 },
    { 0x40028164, 0x33333333 },
    { 0x40028168, 0x33333333 },
    { 0x4002816C, 0x00000000 },
    { 0x40028170, 0x33300000 },
    { 0x40028174, 0x33333333 },
    { 0x40028178, 0x33333333 },
    { 0x4002817C, 0x43216543 },
    { 0x40028180, 0x32198765 },
    { 0x40028184, 0x65487654 },
    { 0x40028188, 0xCCCBA987 },
    { 0x4002818C, 0x66666666 },
    { 0x40028190, 0x44466666 },
    { 0x40028194, 0x77744444 },
    { 0x40028198, 0x77777777 },
    { 0x400281BC, 0x0029000E },
    { 0x400281C0, 0x0054003F },
    { 0x400281C4, 0x008D0075 },
    { 0x400281C8, 0x00BD00A5 },
    { 0x400281CC, 0x00ED00D5 },
    { 0x400281D0, 0x011D0105 },
    { 0x400281D4, 0x01480135 },
    { 0x400281D8, 0x01780160 },
    { 0x400281DC, 0x01A80190 },
    { 0x400281E0, 0x01D801BD },
    { 0x400281E4, 0x021C01F0 },
    { 0x400281E8, 0x02460231 },
    { 0x400281EC, 0x0279025E },
    { 0x400281F0, 0x02AC0291 },
    { 0x400281F4, 0x02DF02C4 },
    { 0x400281F8, 0x02DF02DF },
    { 0x40028250, 0x00000000 },
    { 0x40028254, 0x76543210 },
    { 0x40028258, 0x77777777 },
};

const uint32_t rxlpf_h0p5_OSR16_S1011[][2] = {
    { 0x40028108, 0xFCDF8BE1 },
    { 0x4002810C, 0x080053FB },
    { 0x40028110, 0x2183003E },
    { 0x40028114, 0x3A4670AC },
    { 0x40028118, 0x700800FA },
};

const uint32_t rxlpf_h0p5_OSR8_S1011[][2] = {
    { 0x40028108, 0x0440780A },
    { 0x4002810C, 0xF41F7807 },
    { 0x40028110, 0xF91DCBB8 },
    { 0x40028114, 0x4CC5B03D },
    { 0x40028118, 0x700DA992 },
};

const uint32_t rxlpf_h1_OSR16_S1011[][2] = {
    { 0x40028108, 0xF55F03E4 },
    { 0x4002810C, 0xF91E9BCF },
    { 0x40028110, 0x19817802 },
    { 0x40028114, 0x4386E8A3 },
    { 0x40028118, 0x7009D12F },
};

const uint32_t rxlpf_h1_OSR8_S1010[][2] = {
    { 0x40028108, 0xFFDFE3FE },
    { 0x4002810C, 0x04408006 },
    { 0x40028110, 0xF39F1800 },
    { 0x40028114, 0x26415BE1 },
    { 0x40028118, 0x600930FD },
};

const uint32_t rxlpf_h2_OSR16_S1011[][2] = {
    { 0x40028108, 0x03805005 },
    { 0x4002810C, 0xF7DFD00A },
    { 0x40028110, 0xF85DFBC5 },
    { 0x40028114, 0x4CC57835 },
    { 0x40028118, 0x700E0199 },
};

const uint32_t rxlpf_h2_OSR8_S1010[][2] = {
    { 0x40028108, 0x04C08803 },
    { 0x4002810C, 0xFB9F5002 },
    { 0x40028110, 0x00815814 },
    { 0x40028114, 0x171E13B9 },
    { 0x40028118, 0x600CE135 },
};

const uint32_t rxlpf_h3_OSR8_S109[][2] = {
    { 0x40028108, 0x008003FF },
    { 0x4002810C, 0x021FEBFD },
    { 0x40028110, 0x025F7801 },
    { 0x40028114, 0xF75ED81B },
    { 0x40028118, 0x5009309D },
};

const uint32_t rxlpf_h4_OSR16_S1010[][2] = {
    { 0x40028108, 0xFD9FF001 },
    { 0x4002810C, 0x031FB3EF },
    { 0x40028110, 0xF740801F },
    { 0x40028114, 0x1F1F5BBB },
    { 0x40028118, 0x600B6123 },
};

const uint32_t rxlpf_h4_OSR8_S109[][2] = {
    { 0x40028108, 0xFD5F03F7 },
    { 0x4002810C, 0xFD1FC812 },
    { 0x40028110, 0xFA9FC815 },
    { 0x40028114, 0xEF9FC026 },
    { 0x40028118, 0x500A6891 },
};

const uint32_t rxlpf_M2O_H1_filter[][2] = {
    { 0x40028108, 0xFFDFE3FE },
    { 0x4002810C, 0x04408006 },
    { 0x40028110, 0xF39F1800 },
    { 0x40028114, 0x26415BE1 },
    { 0x40028118, 0x600930FD },
};

const uint32_t rxlpf_O2M_H3_filter[][2] = {
    { 0x40028108, 0x009FF800 },
    { 0x4002810C, 0x00C013FE },
    { 0x40028110, 0xFD007BF7 },
    { 0x40028114, 0xED0133FA },
    { 0x40028118, 0x500C386C },
};

const uint32_t rxlpf_R_mode_S109[][2] = {
    { 0x40028108, 0xFF8043FD },
    { 0x4002810C, 0xFD805BFC },
    { 0x40028110, 0xF94093FF },
    { 0x40028114, 0xEC80B80F },
    { 0x40028118, 0x500B787E },
};

const uint32_t phy_dr100000_h0p5_config[][2] = {
    { 0x400280F0, 0x17340800 },
    { 0x40028158, 0x00001F40 }, // agc_timeout_max = 8000
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0002FF28 }, // ed_thres = -27.0
    { 0x40028200, 0x000C0019 }, // initial_gain_index = 25
    { 0x40028208, 0x06068577 }, // inband_pwr_win_size = 7, tot_pwr_win_size = 7
};

const uint32_t phy_dr100000_h1_config[][2] = {
    { 0x400280F0, 0x17340800 },
    { 0x40028158, 0x00001F40 }, // agc_timeout_max = 8000
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0002FF28 }, // ed_thres = -27.0
    { 0x40028200, 0x000C0019 }, // initial_gain_index = 25
    { 0x40028208, 0x06068577 }, // inband_pwr_win_size = 7, tot_pwr_win_size = 7
};

const uint32_t phy_dr100000_h2_config[][2] = {
    { 0x400280F0, 0x17340800 },
    { 0x40028158, 0x00001F40 }, // agc_timeout_max = 8000
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0002FF28 }, // ed_thres = -27.0
    { 0x40028200, 0x000C0019 }, // initial_gain_index = 25
    { 0x40028208, 0x06068577 }, // inband_pwr_win_size = 7, tot_pwr_win_size = 7
};

const uint32_t phy_dr100000_h4_config[][2] = {
    { 0x400280F0, 0x17340800 },
    { 0x40028158, 0x00001F40 }, // agc_timeout_max = 8000
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0002FF28 }, // ed_thres = -27.0
    { 0x40028200, 0x000C0019 }, // initial_gain_index = 25
    { 0x40028208, 0x06068577 }, // inband_pwr_win_size = 7, tot_pwr_win_size = 7
};

const uint32_t phy_dr1000000_h0p5_config[][2] = {
    { 0x400280D0, 0x003F0805 },
    { 0x400280F0, 0x17341800 },
    { 0x40028158, 0x00000640 }, // agc_timeout_max = 1600
    { 0x4002819C, 0x0004FE00 },
    { 0x400281A4, 0x0004FF98 }, // ed_thres = -13.0
    { 0x40028200, 0x100C001B }, // initial_gain_index = 27
    { 0x40028208, 0x06068544 }, // inband_pwr_win_size = 4, tot_pwr_win_size = 4
};

const uint32_t phy_dr12500_h0p5_config[][2] = {
    { 0x400280F0, 0x17340800 },
    { 0x40028158, 0x0000FA00 }, // agc_timeout_max = 64000
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0004FF40 }, // ed_thres = -24.0
    { 0x40028200, 0x0008001F }, // initial_gain_index = 31
    { 0x40028208, 0x060685AA }, // inband_pwr_win_size = 10, tot_pwr_win_size = 10
    { 0x40028304, 0x00000000 },
};

const uint32_t phy_dr12500_h1_config[][2] = {
    { 0x400280F0, 0x17340800 },
    { 0x40028158, 0x0000FA00 }, // agc_timeout_max = 64000
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0004FF40 }, // ed_thres = -24.0
    { 0x40028200, 0x0008001F }, // initial_gain_index = 31
    { 0x40028208, 0x060685AA }, // inband_pwr_win_size = 10, tot_pwr_win_size = 10
    { 0x40028304, 0x00000000 },
};

const uint32_t phy_dr12500_h2_config[][2] = {
    { 0x400280F0, 0x17340800 },
    { 0x40028158, 0x0000FA00 }, // agc_timeout_max = 64000
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0004FF48 }, // ed_thres = -23.0
    { 0x40028200, 0x000C001F }, // initial_gain_index = 31
    { 0x40028208, 0x060685AA }, // inband_pwr_win_size = 10, tot_pwr_win_size = 10
    { 0x40028304, 0x00000000 },
};

const uint32_t phy_dr12500_h4_config[][2] = {
    { 0x400280F0, 0x17340800 },
    { 0x40028158, 0x0000FA00 }, // agc_timeout_max = 64000
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0004FF60 }, // ed_thres = -20.0
    { 0x40028200, 0x000C001F }, // initial_gain_index = 31
    { 0x40028208, 0x060685AA }, // inband_pwr_win_size = 10, tot_pwr_win_size = 10
    { 0x40028304, 0x00000000 },
};

const uint32_t phy_dr125000_h0p5_config[][2] = {
    { 0x400280F0, 0x17340800 },
    { 0x40028158, 0x00001900 }, // agc_timeout_max = 6400
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0004FF80 }, // ed_thres = -16.0
    { 0x40028200, 0x000C001F }, // initial_gain_index = 31
    { 0x40028208, 0x06068566 }, // inband_pwr_win_size = 6, tot_pwr_win_size = 6
};

const uint32_t phy_dr250000_h0p5_config[][2] = {
    { 0x400280F0, 0x17340800 },
    { 0x40028158, 0x00000C80 }, // agc_timeout_max = 3200
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0004FF70 }, // ed_thres = -18.0
    { 0x40028200, 0x000C001F }, // initial_gain_index = 31
    { 0x40028208, 0x06068555 }, // inband_pwr_win_size = 5, tot_pwr_win_size = 5
};

const uint32_t phy_dr50000_h0p5_config[][2] = {
    { 0x400280F0, 0x17340800 },
    { 0x40028158, 0x00003E80 }, // agc_timeout_max = 16000
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0004FF70 }, // ed_thres = -18.0
    { 0x40028200, 0x0008001F }, // initial_gain_index = 31
    { 0x40028208, 0x06068588 }, // inband_pwr_win_size = 8, tot_pwr_win_size = 8
};

const uint32_t phy_dr500000_h0p5_config[][2] = {
    { 0x400280F0, 0x17341000 },
    { 0x40028158, 0x00000640 }, // agc_timeout_max = 1600
    { 0x4002819C, 0x00075E00 },
    { 0x400281A4, 0x0002FFA0 }, // ed_thres = -12.0
    { 0x40028200, 0x000C001F }, // initial_gain_index = 31
    { 0x40028208, 0x06068544 }, // inband_pwr_win_size = 4, tot_pwr_win_size = 4
    { 0x40028308, 0x0000002D },
    { 0x4002830C, 0x00012200 },
};

const uint32_t phy_dr500000_h1_config[][2] = {
    { 0x400280F0, 0x17341000 },
    { 0x40028158, 0x00000640 }, // agc_timeout_max = 1600
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0002FFA0 }, // ed_thres = -12.0
    { 0x40028200, 0x000C001F }, // initial_gain_index = 31
    { 0x40028208, 0x06068544 }, // inband_pwr_win_size = 4, tot_pwr_win_size = 4
    { 0x40028308, 0x0000002D },
    { 0x4002830C, 0x00012200 },
};

const uint32_t phy_dr500000_h2_config[][2] = {
    { 0x400280F0, 0x17342000 },
    { 0x40028158, 0x00000640 }, // agc_timeout_max = 1600
    { 0x4002819C, 0x00055E00 },
    { 0x400281A4, 0x0002FFA0 }, // ed_thres = -12.0
    { 0x40028200, 0x000C001F }, // initial_gain_index = 31
    { 0x40028208, 0x06068544 }, // inband_pwr_win_size = 4, tot_pwr_win_size = 4
    { 0x40028308, 0x0000002D },
    { 0x4002830C, 0x00012200 },
};

const uint32_t phy_mbus_c_dr100000_h1_config[][2] = {
    { 0x400280A8, 0x6F00370C },
    { 0x400280B0, 0x041900D2 },
    { 0x400280D0, 0x007F3F05 }, // pe_edpwrthr = 63, pe_pwr_raise_thres_en = 1
    { 0x40028158, 0x00003C00 }, // agc_timeout_max = 15360
    { 0x400281A4, 0x0001FF78 }, // ed_thres = -17.0
    { 0x400281A8, 0x0000008A },
    { 0x40028200, 0x000C001F }, // initial_gain_index = 31
    { 0x40028208, 0x06068577 }, // inband_pwr_win_size = 7, tot_pwr_win_size = 7
    { 0x4002825C, 0x01F39CE1 },
    { 0x40028260, 0x001F40C8 },
    { 0x40028264, 0x00064190 },
    { 0x40028268, 0x00E0CF38 },
    { 0x4002826C, 0x03C19ED4 },
    { 0x40028270, 0x039C1DA8 },
    { 0x40028274, 0x003E812C },
    { 0x40028278, 0x00640258 },
    { 0x40028310, 0xF00003E8 },
};

const uint32_t phy_mbus_c_dr50000_h1_config[][2] = {
    { 0x400280D0, 0x003F0805 }, // pe_edpwrthr = 63, pe_pwr_raise_thres_en = 0
    { 0x400280F0, 0x17341000 },
    { 0x40028158, 0x00003E80 }, // agc_timeout_max = 16000
    { 0x400281A4, 0x0002FF70 }, // ed_thres = -18.0
    { 0x40028200, 0x0008001F }, // initial_gain_index = 31
    { 0x40028208, 0x06068588 }, // inband_pwr_win_size = 8, tot_pwr_win_size = 8
    { 0x40028304, 0x00000000 },
};

const uint32_t phy_mbus_t_dr100000_h1_config[][2] = {
    { 0x400280A8, 0x6F00370C },
    { 0x400280B0, 0x041900D2 },
    { 0x400280D0, 0x007F3F05 }, // pe_edpwrthr = 63, pe_pwr_raise_thres_en = 1
    { 0x40028158, 0x00003C00 }, // agc_timeout_max = 15360
    { 0x400281A4, 0x0001FF78 }, // ed_thres = -17.0
    { 0x400281A8, 0x0000008A },
    { 0x40028200, 0x000C001F }, // initial_gain_index = 31
    { 0x40028208, 0x06068577 }, // inband_pwr_win_size = 7, tot_pwr_win_size = 7
    { 0x4002825C, 0x01F39CE1 },
    { 0x40028260, 0x001F40C8 },
    { 0x40028264, 0x00064190 },
    { 0x40028268, 0x00E0CF38 },
    { 0x4002826C, 0x03C19ED4 },
    { 0x40028270, 0x039C1DA8 },
    { 0x40028274, 0x003E812C },
    { 0x40028278, 0x00640258 },
    { 0x40028310, 0xBC0003E8 },
};

const uint32_t phy_mbus_t_dr32768_h3_config[][2] = {
    { 0x400280A8, 0x6F80370C },
    { 0x400280B0, 0x041900D2 },
    { 0x400280D0, 0x007F3F05 }, // pe_edpwrthr = 63, pe_pwr_raise_thres_en = 1
    { 0x400280F0, 0x17341000 },
    { 0x40028158, 0x00003C00 }, // agc_timeout_max = 15360
    { 0x400281A4, 0x0001FF18 }, // ed_thres = -29.0
    { 0x40028200, 0x000C0019 }, // initial_gain_index = 25
    { 0x40028208, 0x06068588 }, // inband_pwr_win_size = 8, tot_pwr_win_size = 8
    { 0x4002825C, 0x01DA9A89 },
    { 0x40028260, 0x00064F9C },
    { 0x40028264, 0x0012C2BC },
    { 0x40028268, 0x00F9C064 },
    { 0x4002826C, 0x03831DA8 },
    { 0x40028270, 0x03511B50 },
    { 0x40028274, 0x007D0258 },
    { 0x40028278, 0x00AF04B0 },
    { 0x40028310, 0xBC00044E },
    { 0x40028320, 0x04660437 },
    { 0x40028430, 0x00000001 },
};

const uint32_t phy_mbus_r_dr4800_h2p5_config[][2] = {
    { 0x400280A8, 0x6F80370E },
    { 0x400280B0, 0x041900D2 },
    { 0x400280D0, 0x007F0805 }, // pe_edpwrthr = 63, pe_pwr_raise_thres_en = 1
    { 0x400280F0, 0x17341000 },
    { 0x40028158, 0x0004E200 }, // agc_timeout_max = 320000
    { 0x400281A4, 0x0002FF08 }, // ed_thres = -31.0
    { 0x400281B4, 0x0000FFB0 },
    { 0x40028200, 0x01E80019 }, // initial_gain_index = 25
    { 0x40028204, 0x01002060 },
    { 0x40028208, 0x060685CC }, // inband_pwr_win_size = 12, tot_pwr_win_size = 12
    { 0x40028304, 0x00000000 },
    { 0x40028310, 0x3C0003E5 },
    { 0x40028320, 0x03F903D1 },
};

MODIDX_CSR_CFG phy_100000_csrcfgs[] = {
    { MOD_IDX_0P5, phy_dr100000_h0p5_config, sizeof(phy_dr100000_h0p5_config) / sizeof(phy_dr100000_h0p5_config[0]), rxlpf_h0p5_OSR8_S1011 },
    { MOD_IDX_1, phy_dr100000_h1_config, sizeof(phy_dr100000_h1_config) / sizeof(phy_dr100000_h1_config[0]), rxlpf_h1_OSR8_S1010 },
    { MOD_IDX_2, phy_dr100000_h2_config, sizeof(phy_dr100000_h2_config) / sizeof(phy_dr100000_h2_config[0]), rxlpf_h2_OSR8_S1010 },
    { MOD_IDX_4, phy_dr100000_h4_config, sizeof(phy_dr100000_h4_config) / sizeof(phy_dr100000_h4_config[0]), NULL }
};
MODIDX_CSR_CFG phy_1000000_csrcfgs[] = {
    { MOD_IDX_0P5, phy_dr1000000_h0p5_config, sizeof(phy_dr1000000_h0p5_config) / sizeof(phy_dr1000000_h0p5_config[0]), rxlpf_h0p5_OSR8_S1011 }
};
MODIDX_CSR_CFG phy_12500_csrcfgs[] = {
    { MOD_IDX_0P5, phy_dr12500_h0p5_config, sizeof(phy_dr12500_h0p5_config) / sizeof(phy_dr12500_h0p5_config[0]), rxlpf_h0p5_OSR16_S1011 },
    { MOD_IDX_1, phy_dr12500_h1_config, sizeof(phy_dr12500_h1_config) / sizeof(phy_dr12500_h1_config[0]), rxlpf_h1_OSR16_S1011 },
    { MOD_IDX_2, phy_dr12500_h2_config, sizeof(phy_dr12500_h2_config) / sizeof(phy_dr12500_h2_config[0]), rxlpf_h2_OSR16_S1011 },
    { MOD_IDX_4, phy_dr12500_h4_config, sizeof(phy_dr12500_h4_config) / sizeof(phy_dr12500_h4_config[0]), rxlpf_h4_OSR16_S1010 }
};
MODIDX_CSR_CFG phy_125000_csrcfgs[] = {
    { MOD_IDX_0P5, phy_dr125000_h0p5_config, sizeof(phy_dr125000_h0p5_config) / sizeof(phy_dr125000_h0p5_config[0]), rxlpf_h0p5_OSR8_S1011 }
};
MODIDX_CSR_CFG phy_250000_csrcfgs[] = {
    { MOD_IDX_0P5, phy_dr250000_h0p5_config, sizeof(phy_dr250000_h0p5_config) / sizeof(phy_dr250000_h0p5_config[0]), rxlpf_h0p5_OSR8_S1011 }
};
MODIDX_CSR_CFG phy_50000_csrcfgs[] = {
    { MOD_IDX_0P5, phy_dr50000_h0p5_config, sizeof(phy_dr50000_h0p5_config) / sizeof(phy_dr50000_h0p5_config[0]), rxlpf_h0p5_OSR8_S1011 }
};
MODIDX_CSR_CFG phy_500000_csrcfgs[] = {
    { MOD_IDX_0P5, phy_dr500000_h0p5_config, sizeof(phy_dr500000_h0p5_config) / sizeof(phy_dr500000_h0p5_config[0]), rxlpf_h0p5_OSR8_S1011 },
    { MOD_IDX_1, phy_dr500000_h1_config, sizeof(phy_dr500000_h1_config) / sizeof(phy_dr500000_h1_config[0]), rxlpf_h1_OSR8_S1010 },
    { MOD_IDX_2, phy_dr500000_h2_config, sizeof(phy_dr500000_h2_config) / sizeof(phy_dr500000_h2_config[0]), rxlpf_h2_OSR8_S1010 }
};
MODIDX_CSR_CFG phy_mbus_c_100000_csrcfgs[] = {
    { MOD_IDX_1, phy_mbus_c_dr100000_h1_config, sizeof(phy_mbus_c_dr100000_h1_config) / sizeof(phy_mbus_c_dr100000_h1_config[0]), rxlpf_M2O_H1_filter }
};
MODIDX_CSR_CFG phy_mbus_c_50000_csrcfgs[] = {
    { MOD_IDX_1, phy_mbus_c_dr50000_h1_config, sizeof(phy_mbus_c_dr50000_h1_config) / sizeof(phy_mbus_c_dr50000_h1_config[0]), rxlpf_h1_OSR8_S1010 }
};
MODIDX_CSR_CFG phy_mbus_t_100000_csrcfgs[] = {
    { MOD_IDX_1, phy_mbus_t_dr100000_h1_config, sizeof(phy_mbus_t_dr100000_h1_config) / sizeof(phy_mbus_t_dr100000_h1_config[0]), rxlpf_M2O_H1_filter }
};
MODIDX_CSR_CFG phy_mbus_t_32768_csrcfgs[] = {
    { MOD_IDX_0P5, phy_mbus_t_dr32768_h3_config, sizeof(phy_mbus_t_dr32768_h3_config) / sizeof(phy_mbus_t_dr32768_h3_config[0]), rxlpf_O2M_H3_filter }
};
MODIDX_CSR_CFG phy_mbus_r_4800_csrcfgs[] = {
    { MOD_IDX_0P5, phy_mbus_r_dr4800_h2p5_config, sizeof(phy_mbus_r_dr4800_h2p5_config) / sizeof(phy_mbus_r_dr4800_h2p5_config[0]), rxlpf_R_mode_S109 }
};

MODEM_CFG_GRP modem_config_group_normal[7] = {
    { 1000000,  phy_1000000_csrcfgs, sizeof(phy_1000000_csrcfgs) / sizeof(MODIDX_CSR_CFG)},
    { 500000,   phy_500000_csrcfgs, sizeof(phy_500000_csrcfgs) / sizeof(MODIDX_CSR_CFG) },
    { 250000,   phy_250000_csrcfgs, sizeof(phy_250000_csrcfgs) / sizeof(MODIDX_CSR_CFG) },
    { 125000,   phy_125000_csrcfgs, sizeof(phy_125000_csrcfgs) / sizeof(MODIDX_CSR_CFG) },
    { 100000,   phy_100000_csrcfgs, sizeof(phy_100000_csrcfgs) / sizeof(MODIDX_CSR_CFG) },
    { 50000,    phy_50000_csrcfgs,  sizeof(phy_50000_csrcfgs) / sizeof(MODIDX_CSR_CFG)  },
    { 12500,    phy_12500_csrcfgs,  sizeof(phy_12500_csrcfgs) / sizeof(MODIDX_CSR_CFG)  },
};

MODEM_CFG_GRP_WMBUS modem_config_group_wmbus[6] = {
    { HAL_WMBUS_MODE_S, 32768,  phy_mbus_t_32768_csrcfgs,   sizeof(phy_mbus_t_32768_csrcfgs) / sizeof(MODIDX_CSR_CFG)  },
    { HAL_WMBUS_MODE_T, 100000, phy_mbus_t_100000_csrcfgs,  sizeof(phy_mbus_t_100000_csrcfgs) / sizeof(MODIDX_CSR_CFG) },
    { HAL_WMBUS_MODE_T, 32768,  phy_mbus_t_32768_csrcfgs,   sizeof(phy_mbus_t_32768_csrcfgs) / sizeof(MODIDX_CSR_CFG)  },
    { HAL_WMBUS_MODE_C, 100000, phy_mbus_c_100000_csrcfgs,  sizeof(phy_mbus_c_100000_csrcfgs) / sizeof(MODIDX_CSR_CFG) },
    { HAL_WMBUS_MODE_C, 50000,  phy_mbus_c_50000_csrcfgs,   sizeof(phy_mbus_c_50000_csrcfgs) / sizeof(MODIDX_CSR_CFG)  },
    { HAL_WMBUS_MODE_R, 4800,   phy_mbus_r_4800_csrcfgs,    sizeof(phy_mbus_r_4800_csrcfgs) / sizeof(MODIDX_CSR_CFG)   },
};


