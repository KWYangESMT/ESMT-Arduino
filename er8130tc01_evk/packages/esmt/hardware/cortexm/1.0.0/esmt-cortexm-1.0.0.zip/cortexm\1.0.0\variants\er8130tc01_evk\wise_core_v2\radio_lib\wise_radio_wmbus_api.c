#include <stdio.h>
#include "wise_radio_api.h"
#include "wise_radio_wmbus_api.h"
#include "util.h"
#include "hal_intf_radio.h"
#include "hal_intf_sys.h"

#include "wise_core.h"
#include "internal_radio_ctrl.h"
#include "wmbus_parameters.h"
#include "util_bitstream_codec.h"
#include "util_crc.h"


//this compile flag is support by soc 9005
#ifdef CHIP_RADIO_HAS_W_MBUS  //javi

//#define _ENABLE_RF_CFG_DEBUG

#define WMBUS_INVALID                       (0xff)
#define WMBUS_CRC_TYPE                      CRC_TYPE_16_EN_13757
#define WMBUS_CRC_SEED                      (0)
#define WMBUS_FIRST_BLOCK_LEN               10
#define WMBUS_DATA_BLOCK_LEN                16

#define WMBUS_3OF6_ENC_LEN(len)             (((len) * 3 + 1) / 2)
#define WMBUS_MANCHESTER_ENC_LEN(len)       (len * 2)



#ifdef CHIP_RADIO_HAS_W_MBUS_FAKE
#define WMBUS_TEST_FREQ                     922500000
#endif

typedef struct
{
    uint32_t dataRate;
    WISE_DATA_RATE_T wiseDR;
    uint32_t rxByteTimeUs;
} WMBUS_SUPPORT_DR_T;

typedef struct
{
    wmbus_mode_t mode;
    wmbus_role_t role;
    wmbus_frame_type_t frameType;
} WMBUS_WORKING_MODE_T;

enum
{
    ACTIVE_CFG_RX = 0,
    ACTIVE_CFG_TX = 1,
};

extern void _wmbus_set_init(int8_t intf_idx);
extern void _wmbus_set_deinit(int8_t intf_idx);
extern void _wmbus_set_mode(int8_t intf_idx, wmbus_mode_t mode);
extern void _wmbus_set_rx_validate_proc(RX_VALIDATE_PROC_T rxValidateProc);
extern void _wmbus_set_rx_sync_callback(RX_SYNC_CALLBACK_T rxSyncProc);
extern void _wmbus_set_tx_config(int8_t intf_idx, WISE_RADIO_CFG_T *cfg, WISE_RADIO_PKT_FMT_T *pkt_fmt);
extern void _wmbus_set_rx_config(int8_t intf_idx, WISE_RADIO_CFG_T *cfg, WISE_RADIO_PKT_FMT_T *pkt_fmt);

static void _wmbus_release_buffers();
static void _wmbus_fill_rf_config(const wmbus_rf_param_t* rfParam, 
                                    WISE_RADIO_CFG_T* m2oCfg, 
                                    WISE_RADIO_PKT_FMT_T* m2oFmt,
                                    WISE_RADIO_CFG_T* o2mCfg,
                                    WISE_RADIO_PKT_FMT_T* o2mFmt);
#if 0
static WISE_DATA_RATE_T _wmbus_get_data_rate(uint32_t dataRate);
#endif
static uint16_t _wmbus_crc(const uint8_t *data, uint32_t len);

uint16_t _wmbus_gen_sync_pattern(wmbus_mode_t mode, uint8_t *buffer);
void _wmbus_validate_rx_data(RADIO_INTF_CFG_T *intf_cfg, uint8_t *pframe, WISE_RX_META_T *rx_meta, uint32_t status);
uint16_t _wmbus_rx_syncword_handler(RADIO_INTF_CFG_T *intf_cfg, uint8_t *pframe);
int8_t _wmbus_3of6_decode_frame_A(uint8_t* frame, uint8_t* outBuffer, uint16_t* outDataLen);
int8_t _wmbus_manchester_decode_frame_A(uint8_t* frame, uint8_t* outBuffer, uint16_t* outDataLen);
int8_t _wmbus_validate_frame_A(uint8_t* frame, uint16_t frameLen, uint16_t* outDataLen);

int8_t _wmbus_pack_tx_data(WISE_FRAME_CODEC_T codec, uint8_t *txData, uint16_t dataLen, uint8_t *outBuffer, uint16_t* outDataLen);
uint16_t _wmbus_estimate_frame_A_length(uint16_t dataLen);
uint16_t _wmbus_create_frame_A(uint8_t* frame, uint16_t dataLen, uint8_t* outBuffer);
uint16_t _wmbus_3of6_encode_frame(uint8_t* frame, uint16_t frameLen, uint8_t* outBuffer);

#ifdef _ENABLE_RF_CFG_DEBUG
static void _wmbus_debug_radio_cfg();
static void _wmbus_debug_cfg(WISE_RADIO_CFG_T* cfg, WISE_RADIO_PKT_FMT_T* fmt);
#endif

uint32_t _wmbus_get_rx_byte_time(WISE_DATA_RATE_T dataRate);

static WISE_RADIO_CFG_T* m2oRadioCfg = NULL;
static WISE_RADIO_CFG_T* o2mRadioCfg = NULL;
static WISE_RADIO_PKT_FMT_T* m2oPktFmt = NULL;
static WISE_RADIO_PKT_FMT_T* o2mPktFmt = NULL;
static WISE_RADIO_CFG_T* pMbusRxRadioCfg = NULL;
static WISE_RADIO_CFG_T* pMbusTxRadioCfg = NULL;
static WISE_RADIO_PKT_FMT_T* pMbusRxPktFmt = NULL;
static WISE_RADIO_PKT_FMT_T* pMbusTxPktFmt = NULL;

static WMBUS_WORKING_MODE_T workingMode = {WMBUS_INVALID, WMBUS_INVALID, WMBUS_FRAME_TYPE_A};
static uint8_t* wmbusTmpBuffer = NULL;
static uint8_t* wmbusCrcTable = NULL;
static int8_t activeConfig = -1;
static uint8_t *pMbusTxSync = NULL;
static uint8_t pMbusTxSyncLen = 0;
static uint32_t rxByteTime = 0;


const WMBUS_SUPPORT_DR_T WMBUS_DATA_RATES[] =
{
    {4800,      E_DATA_RATE_4P8K,       2500},     //TBD
    {12500,     E_DATA_RATE_12P5K,      850},     //TBD
    {32768,     E_DATA_RATE_32P768K,    350},
    {50000,     E_DATA_RATE_50K,        210},   //TBD
    {100000,    E_DATA_RATE_100K,       100},
};

/*
WISE_RADIO_PKT_FMT_T wmbusPktFmt =
{
    .pkt_type = PKT_FIXED_LENGTH,
    .frame_format = (FRAME_FMT_MSB_FIRST | FRAME_FMT_PREAMBLE_EN | FRAME_FMT_SYNCWORD_EN),
    .max_pkt_length = WMBUS_MAX_PKT_LEN, 

    .phr =
    {
        .hdr_bytes = 0,
        .hdr_config = 0,
        .length_bit_size = 0, 
        .length_bit_offset = 0,   
    },

    .crc =
    {
        .crc_config = 0,
        .crc_poly_sel = 0,
        .crc_seed = 0,
    },
};
*/

int8_t* modeStr[] = {(int8_t*)"S1", (int8_t*)"S1M", (int8_t*)"S2", (int8_t*)"T1", (int8_t*)"T2", (int8_t*)"C1", (int8_t*)"C2", (int8_t*)"R1", (int8_t*)"R2", (int8_t*)"F2", (int8_t*)"N"};
int8_t* roleString[] = {(int8_t*)"other", (int8_t*)"meter"};
int8_t* codecString[] = {(int8_t*)"NONE", (int8_t*)"NRZ", (int8_t*)"MANCHESTER", (int8_t*)"3OF6"};
uint32_t datarateValues[] = {4800, 12500, 32768, 50000, 100000, 125000, 200000, 250000, 500000, 1000000, 2000000};

static uint16_t maxRxFrameLen = WMBUS_MAX_PKT_LEN;


int8_t wise_radio_wmbus_init(int8_t intf_idx)
{
    WISE_STATUS status = WISE_FAIL;

    _wmbus_release_buffers();

    workingMode.mode = WMBUS_INVALID;
    workingMode.role = WMBUS_INVALID;
    
    if (wise_radio_init(intf_idx) != WISE_SUCCESS) 
    {
        goto finish;
    }

    wmbusTmpBuffer = malloc(WMBUS_MAX_PKT_LEN);

    wmbusCrcTable = malloc(512);
    util_crc16_gen_table(WMBUS_CRC_TYPE, (uint16_t*)wmbusCrcTable);
    
    _wmbus_set_init(intf_idx);
    _wmbus_set_rx_validate_proc(_wmbus_validate_rx_data);
    _wmbus_set_rx_sync_callback(_wmbus_rx_syncword_handler);

    activeConfig = -1;
    
    debug_print("wmbus radio inited\n");

finish:
    return status;
}

uint32_t _wmbus_get_rx_byte_time(WISE_DATA_RATE_T dataRate)
{
    uint32_t time = 0;
    int i;
    
    for(i = 0; i < sizeof(WMBUS_DATA_RATES)/sizeof(WMBUS_SUPPORT_DR_T); i++)
    {
        if(dataRate == WMBUS_DATA_RATES[i].wiseDR)
        {
            time = WMBUS_DATA_RATES[i].rxByteTimeUs;
            break;
        }
    }

    return time;
};

int8_t wise_radio_wmbus_set_mode(int8_t intf_idx, wmbus_role_t mbusRole, wmbus_mode_t mbusMode)
{
    WISE_STATUS status = WISE_FAIL;
    const wmbus_rf_param_t* rfParam = NULL;
    
    debug_print("wmbus set mode %d, role: %d\n", mbusMode, mbusRole);

    if(m2oRadioCfg || o2mRadioCfg)
    {
        debug_print("wmbus mode already set\n");
        status = WISE_FAIL;
        goto finish;
    }

    workingMode.mode = mbusMode;
    workingMode.role = mbusRole;
    workingMode.frameType = WMBUS_FRAME_TYPE_A;

    if(pMbusTxSync)
    {
        free(pMbusTxSync);
        pMbusTxSync = NULL;
    }
    pMbusTxSyncLen = 0;
    
    if(mbusMode != WMBUS_MODE_N)
    {
        rfParam = &radioWmbusCfg[mbusMode];
        
        m2oRadioCfg = (WISE_RADIO_CFG_T*)malloc(sizeof(WISE_RADIO_CFG_T));
        if(!m2oRadioCfg)
        {
            ASSERT_ALLOC_FAIL("m2oRadioCfg");
        }
        memset(m2oRadioCfg, 0, sizeof(WISE_RADIO_CFG_T));

        m2oPktFmt = (WISE_RADIO_PKT_FMT_T*)malloc(sizeof(WISE_RADIO_PKT_FMT_T));
        if(!m2oPktFmt)
        {
            ASSERT_ALLOC_FAIL("m2oPktFmt");
        }
        memset(m2oPktFmt, 0, sizeof(WISE_RADIO_PKT_FMT_T));
        
        if(rfParam->mode & MBUS_MODE_FLAG_O2M)
        {
            o2mRadioCfg = (WISE_RADIO_CFG_T*)malloc(sizeof(WISE_RADIO_CFG_T));
            if(!o2mRadioCfg)
            {
                ASSERT_ALLOC_FAIL("o2mRadioCfg");
            }
            memset(o2mRadioCfg, 0, sizeof(WISE_RADIO_CFG_T));

            o2mPktFmt = (WISE_RADIO_PKT_FMT_T*)malloc(sizeof(WISE_RADIO_PKT_FMT_T));
            if(!o2mPktFmt)
            {
                ASSERT_ALLOC_FAIL("o2mPktFmt");
            }
            memset(o2mPktFmt, 0, sizeof(WISE_RADIO_PKT_FMT_T));
        }

        _wmbus_fill_rf_config(rfParam, m2oRadioCfg, m2oPktFmt, o2mRadioCfg, o2mPktFmt);

        //deal with preamble and sync word
        switch(workingMode.mode)
        {
            case WMBUS_MODE_S1:
				if(m2oRadioCfg)
				{
					m2oRadioCfg->preamble_len = 3;
					m2oRadioCfg->preamble = 0x55;

					m2oRadioCfg->sync_word_len = 2;
					m2oRadioCfg->syncword =0x7696;
				}
			break;

            case WMBUS_MODE_S2:
				if(m2oRadioCfg)
				{
					m2oRadioCfg->preamble_len = 3;
					m2oRadioCfg->preamble = 0x55;
					
					m2oRadioCfg->sync_word_len = 2;
					m2oRadioCfg->syncword = 0x7696;

                    //m2oRadioCfg->wmbus_mode = HAL_WMBUS_MODE_S;
				}
				
				if(o2mRadioCfg)
				{
					o2mRadioCfg->preamble_len = 3;
					o2mRadioCfg->preamble = 0x55;

					o2mRadioCfg->sync_word_len = 2;
					o2mRadioCfg->syncword = 0x7696;

                    //o2mRadioCfg->wmbus_mode = HAL_WMBUS_MODE_S;
				}
			break;

            case WMBUS_MODE_T1:
            case WMBUS_MODE_T2:
                if(m2oRadioCfg)
                {
                    m2oRadioCfg->preamble_len = 4;
                    m2oRadioCfg->preamble = 0xAA;

                    m2oRadioCfg->sync_word_len = 2;
                    m2oRadioCfg->syncword = 0x543D; //comment from Raymond, syncword should be 0x543D

                    //m2oRadioCfg->wmbus_mode = HAL_WMBUS_MODE_T;
                }

                if(o2mRadioCfg)
                {
					o2mRadioCfg->preamble_len = 4;
					o2mRadioCfg->preamble = 0xAA;

					o2mRadioCfg->sync_word_len = 2;
					o2mRadioCfg->syncword = 0x7696;

                    //o2mRadioCfg->wmbus_mode = HAL_WMBUS_MODE_T;
                }
            break;
            
            case WMBUS_MODE_C1:
            case WMBUS_MODE_C2:
				if(m2oRadioCfg)
				{
					m2oRadioCfg->preamble_len = 4;
					m2oRadioCfg->preamble = 0x55;
					
					m2oRadioCfg->sync_word_len = 2;
					m2oRadioCfg->syncword = 0x54CD;

                    //m2oRadioCfg->wmbus_mode = HAL_WMBUS_MODE_C;
				}
				
				if(o2mRadioCfg)
				{
					o2mRadioCfg->preamble_len = 4;
					o2mRadioCfg->preamble = 0x55;

					o2mRadioCfg->sync_word_len = 2;
					o2mRadioCfg->syncword = 0x54CD;

                    //o2mRadioCfg->wmbus_mode = HAL_WMBUS_MODE_C;
				}
			break;
			
            case WMBUS_MODE_R2:
				if(m2oRadioCfg)
				{
					m2oRadioCfg->preamble_len = 9;
					m2oRadioCfg->preamble = 0x55;
					
					m2oRadioCfg->sync_word_len = 2;
					m2oRadioCfg->syncword = 0x7696;

                    //m2oRadioCfg->wmbus_mode = HAL_WMBUS_MODE_R;
				}
				
				if(o2mRadioCfg)
				{
					o2mRadioCfg->preamble_len = 9;
					o2mRadioCfg->preamble = 0x55;

					o2mRadioCfg->sync_word_len = 2;
					o2mRadioCfg->syncword = 0x7696;

                    //o2mRadioCfg->wmbus_mode = HAL_WMBUS_MODE_R;
				}
			break;

            case WMBUS_MODE_F2:
				if(m2oRadioCfg)
				{
					m2oRadioCfg->preamble_len = 10;
					m2oRadioCfg->preamble = 0x55;
					
					m2oRadioCfg->sync_word_len = 2;
					m2oRadioCfg->syncword = 0xF68D;

                    //m2oRadioCfg->wmbus_mode = HAL_WMBUS_MODE_F;
				}
				
				if(o2mRadioCfg)
				{
					o2mRadioCfg->preamble_len = 10;
					o2mRadioCfg->preamble = 0x55;

					o2mRadioCfg->sync_word_len = 2;
					o2mRadioCfg->syncword = 0xF68D;

                    //o2mRadioCfg->wmbus_mode = HAL_WMBUS_MODE_F;
				}
			break;

            default:
                debug_print("Mbus mode %d not implemented yet.\n", workingMode.mode);
                goto finish;
            break;
         }

         _wmbus_set_mode(intf_idx, workingMode.mode);

#ifdef _ENABLE_RF_CFG_DEBUG
        _wmbus_debug_radio_cfg();
#endif
    }
    else
    {
    }

    //use M2O config as default
    if(WISE_SUCCESS != wise_radio_config(intf_idx, m2oRadioCfg, m2oPktFmt))
    {
        debug_print("Mbus radio config failed\n");
        goto finish;
    }

    if(workingMode.role == WMBUS_ROLE_METER)
    {
        pMbusRxRadioCfg = o2mRadioCfg;
        pMbusRxPktFmt = o2mPktFmt;
        pMbusTxRadioCfg = m2oRadioCfg;
        pMbusTxPktFmt = m2oPktFmt;
    }
    else
    {
        pMbusRxRadioCfg = m2oRadioCfg;
        pMbusRxPktFmt = m2oPktFmt;
        pMbusTxRadioCfg = o2mRadioCfg;
        pMbusTxPktFmt = o2mPktFmt;
    }

    if(pMbusTxRadioCfg)
    {
        //pMbusTxRadioCfg->preamble_len = 0;
        //pMbusTxRadioCfg->preamble = 0;
        //pMbusTxRadioCfg->sync_word_len = 0;
        //pMbusTxRadioCfg->syncword = 0;
    }

    if(pMbusRxRadioCfg)
    {
        rxByteTime = _wmbus_get_rx_byte_time(pMbusRxRadioCfg->data_rate);
    }

    status = WISE_SUCCESS;
    
finish:
    return status;
}

int8_t wise_radio_wmbus_set_max_frame_len(int8_t intf_idx, uint16_t maxLen)
{
    maxRxFrameLen = maxLen;
    if(pMbusRxPktFmt)
        pMbusRxPktFmt->max_pkt_length = maxRxFrameLen;
    
    return WISE_SUCCESS;
}


void wise_radio_wmbus_deinit(int8_t intf_idx)
{
    _wmbus_release_buffers();
}

int8_t wise_radio_mbus_rx_start(int8_t intf_idx, uint8_t ch_index, WISE_RADIO_RX_MODE_T rx_mode)
{
    if((intf_idx != 0) || ((m2oRadioCfg == NULL) && (m2oRadioCfg == NULL)))
        return WISE_FAIL;
    if((workingMode.mode == WMBUS_INVALID) || (workingMode.role == WMBUS_INVALID))
        return WISE_FAIL;

    if(pMbusRxRadioCfg == NULL)
    {
        debug_print("WMBUS mode=%d role=%d not support rx\n", workingMode.mode, workingMode.role);
        return WISE_FAIL;
    }

    pMbusRxPktFmt->frame_format |= (FRAME_FMT_PREAMBLE_EN | FRAME_FMT_SYNCWORD_EN);
    pMbusRxPktFmt->max_pkt_length = maxRxFrameLen;

    //debug_print("rx cfg:\n");
    //_wmbus_debug_cfg(pMbusRxRadioCfg, &wmbusPktFmt);
    _wmbus_set_rx_config(intf_idx, pMbusRxRadioCfg, pMbusRxPktFmt);
    activeConfig = ACTIVE_CFG_RX;
    wise_radio_set_rx_mode(intf_idx, rx_mode);
    wise_radio_rx_start(intf_idx, ch_index);

    return WISE_SUCCESS;
}

void wise_radio_wmbus_rx_stop(int8_t intf_idx)
{
    wise_radio_rx_stop(intf_idx);
}

int8_t wise_radio_wmbus_tx_frame(int8_t intf_idx, uint8_t ch_index, uint8_t *pFrame, uint16_t length)
{
    uint16_t txLen = 0;
    uint16_t writeOffset = 0;

    if((intf_idx != 0) || ((m2oRadioCfg == NULL) && (m2oRadioCfg == NULL)))
        return WISE_FAIL;
    if((workingMode.mode == WMBUS_INVALID) || (workingMode.role == WMBUS_INVALID))
        return WISE_FAIL;
    
    if(pMbusTxRadioCfg == NULL)
    {
        debug_print("WMBUS mode=%d role=%d not support tx\n", workingMode.mode, workingMode.role);
        return WISE_FAIL;
    }

    memset(wmbusTmpBuffer, 0, WMBUS_MAX_PKT_LEN);

    //writeOffset = _wmbus_gen_sync_pattern(workingMode.mode, wmbusTmpBuffer);
    memcpy(&wmbusTmpBuffer[0], &pMbusTxSync[0], pMbusTxSyncLen);
    writeOffset = pMbusTxSyncLen;
    
    _wmbus_pack_tx_data(pMbusTxPktFmt->frame_codec, pFrame, length, &wmbusTmpBuffer[writeOffset], &txLen);    
    txLen += writeOffset;
    
    //wmbusPktFmt.frame_format = 0; //SW handles everything
    pMbusTxPktFmt->frame_format &= ~(FRAME_FMT_PREAMBLE_EN | FRAME_FMT_SYNCWORD_EN);
    pMbusTxPktFmt->max_pkt_length = txLen;

    if(activeConfig != ACTIVE_CFG_TX)
    {
        _wmbus_set_tx_config(intf_idx, pMbusTxRadioCfg, pMbusTxPktFmt);
        activeConfig = ACTIVE_CFG_TX;
    }

    debug_print("wmbus tx %d\n", txLen);
    dump_buffer(wmbusTmpBuffer, txLen);
    
    wise_radio_tx_frame(intf_idx, ch_index, wmbusTmpBuffer, txLen);
    return WISE_SUCCESS;
}


//============== local functions ================
#ifdef _ENABLE_RF_CFG_DEBUG
static void _wmbus_debug_radio_cfg()
{    
    if(workingMode.mode == WMBUS_INVALID)
    {
        debug_print("WMbus not configured\n");
        return;
    }
    
    debug_print("WMbus mode: %s-%s\n", modeStr[workingMode.mode], roleString[workingMode.role]);
    
    if(m2oRadioCfg)
    {
        debug_print("   m2o:\n");
        debug_print("       modulation=%d\n", m2oRadioCfg->modulation);
        debug_print("       freq max=%ld min=%lu spacing=%lu\n", m2oRadioCfg->ch_freq_max, m2oRadioCfg->ch_freq_min, m2oRadioCfg->ch_spacing);
        debug_print("       deviation=%lu daraRate=%lu\n", m2oRadioCfg->deviation, (uint32_t)m2oRadioCfg->data_rate);
        //debug_print("       phy=%d\n", m2oRadioCfg->phy_mode);
        debug_print("       frameCodec=%s\n", codecString[m2oPktFmt->frame_codec]);
        debug_print("       preamble len=%d pattern=%08x\n", m2oRadioCfg->preamble_len, (unsigned int)m2oRadioCfg->preamble);
        debug_print("       syncword len=%d sync1=%08x\n", m2oRadioCfg->sync_word_len, (unsigned int)m2oRadioCfg->syncword);
    }

    if(o2mRadioCfg)
    {
        debug_print("   o2m:\n");
        debug_print("       modulation=%d\n", o2mRadioCfg->modulation);
        debug_print("       freq max=%ld min=%lu spacing=%lu\n", o2mRadioCfg->ch_freq_max, o2mRadioCfg->ch_freq_min, o2mRadioCfg->ch_spacing);
        debug_print("       deviation=%lu daraRate=%lu\n", o2mRadioCfg->deviation, (uint32_t)o2mRadioCfg->data_rate);
        //debug_print("       phy=%d\n", o2mRadioCfg->phy_mode);
        debug_print("       frameCodec=%s\n", codecString[o2mPktFmt->frame_codec]);
        debug_print("       preamble len=%d pattern=%08x\n", o2mRadioCfg->preamble_len, (unsigned int)o2mRadioCfg->preamble);
        debug_print("       syncword len=%d sync1=%08x\n", o2mRadioCfg->sync_word_len, (unsigned int)o2mRadioCfg->syncword);
    }

    debug_print("\n");
}

static void _wmbus_debug_cfg(WISE_RADIO_CFG_T* cfg, WISE_RADIO_PKT_FMT_T* fmt)
{
    if(cfg)
    {
        debug_print("Radio cofnig:\n");
        debug_print("   modulation=%d\n", cfg->modulation);
        debug_print("   freq max=%ld min=%lu spacing=%lu\n", cfg->ch_freq_max, cfg->ch_freq_min, cfg->ch_spacing);
        debug_print("   deviation=%lu daraRate=%lu\n", cfg->deviation, (uint32_t)datarateValues[cfg->data_rate]);
        //debug_print("   phy=%d\n", cfg->phy_mode);
        debug_print("   frameCodec=%s\n", codecString[cfg->frame_codec]);
        debug_print("   preamble len=%d pattern=%08x\n", cfg->preamble_len, (unsigned int)cfg->preamble);
        debug_print("   syncword len=%d sync1=%08x\n", cfg->sync_word_len, (unsigned int)cfg->syncword);
    }

    if(fmt)
    {
        debug_print("Packet format:\n");
        debug_print("   pkt type=%d\n", fmt->pkt_type);
        debug_print("   format:\n");
        debug_print("       preamble %s\n", fmt->frame_format & FRAME_FMT_PREAMBLE_EN ? "enable" : "disable");
        debug_print("       syncword %s\n", fmt->frame_format & FRAME_FMT_SYNCWORD_EN ? "enable" : "disable");
        debug_print("       header %s\n", fmt->frame_format & FRAME_FMT_HEADER_EN ? "enable" : "disable");
        debug_print("       crc %s\n", fmt->frame_format & FRAME_FMT_CRC_EN ? "enable" : "disable");
        debug_print("       whitening %s\n", fmt->frame_format & FRAME_FMT_WHITENING_EN ? "enable" : "disable");
        debug_print("       frame MSB first %s\n", fmt->frame_format & FRAME_FMT_MSB_FIRST ? "enable" : "disable");
        debug_print("       FEC %s\n", fmt->frame_format & FRAME_FMT_FEC_EN ? "enable" : "disable");
        debug_print("   header:\n");
        debug_print("       phr len: %d\n", fmt->phr.hdr_bytes);
        debug_print("       phr config:\n");
        debug_print("           byte endian: %s first\n", fmt->phr.hdr_config & PHR_BYTE_ENDIAN_MSB_FIRST ? "MSB" : "LSB");
        debug_print("           bit endian: %s first\n", fmt->phr.hdr_config & PHR_LENGTH_BIT_ENDIAN_MSB_FIRST ? "MSB" : "LSB");
        debug_print("           include CRC: %s\n", fmt->phr.hdr_config & PHR_LENGTH_INCLUDE_CRC ? "Y" : "N");
        debug_print("           length bits: [%d:%d]\n", fmt->phr.length_bit_offset, fmt->phr.length_bit_size);
        debug_print("           max pkt length: %ld\n", fmt->max_pkt_length);
        debug_print("   crc:\n");
        debug_print("       crc cofig:\n");
        debug_print("           input bit endian: %s first\n", fmt->crc.crc_config & CRC_INPUT_BIT_ENDIAN_MSB_FIRST ? "MSB" : "LSB");
        debug_print("           output bit endian: %s first\n", fmt->crc.crc_config & CRC_OUTPUT_BIT_ENDIAN_MSB_FIRST ? "MSB" : "LSB");
        debug_print("           output byte endian: %s first\n", fmt->crc.crc_config & CRC_OUTPUT_BYTE_ENDIAN_MSB_FIRST ? "MSB" : "LSB");
        debug_print("           CRC header: %s\n", fmt->crc.crc_config & CRC_INCLUDE_HEADER_ON ? "Y" : "N");
        debug_print("           CRC invert: %s\n", fmt->crc.crc_config & CRC_INVERT ? "Y" : "N");
        debug_print("       crc poly: %d\n", fmt->crc.crc_poly_sel);
        debug_print("       crc seed: %08lx\n", fmt->crc.crc_seed);
    }
}
#endif

#if 0
static WISE_DATA_RATE_T _wmbus_get_data_rate(uint32_t dataRate)
{
    int i;
    int drNum = sizeof(WMBUS_DATA_RATES) / sizeof(WMBUS_SUPPORT_DR_T);

    for(i = 0; i < drNum; i++)
    {
        if(WMBUS_DATA_RATES[i].dataRate == dataRate)
            return WMBUS_DATA_RATES[i].wiseDR;
    }

    debug_print("data rate not found %lu\n", dataRate);
    return (WISE_DATA_RATE_T)0xff;
}
#endif

uint16_t _wmbus_gen_sync_pattern(wmbus_mode_t mode, uint8_t *buffer)
{
    uint16_t total_bits = 0;
    uint32_t sync_word = 0;
    uint8_t sync_word_len = 0;

    switch(mode){
        case WMBUS_MODE_S1:
            total_bits = WMBUS_S_PREAMBLE_SYNC_WORD_LONG_LEN;
            sync_word = WMBUS_S_SYNC_WORD;
            sync_word_len = WMBUS_S_SYNC_WORD_LEN_BIT;
	        break;
        case WMBUS_MODE_S1M:
            case WMBUS_MODE_S2:
            total_bits = WMBUS_S_PREAMBLE_SYNC_WORD_SHORT_LEN;
            sync_word = WMBUS_S_SYNC_WORD;
            sync_word_len = WMBUS_S_SYNC_WORD_LEN_BIT;
	        break;
		case WMBUS_MODE_T1:
        case WMBUS_MODE_T2:
            //kevinyang, 20250612, to fit ESMT IC
            buffer[sync_word_len++] = 0xAA;
            buffer[sync_word_len++] = 0xAA;
            buffer[sync_word_len++] = 0xAA;
            buffer[sync_word_len++] = 0xAA;
            buffer[sync_word_len++] = 0xAA;
            buffer[sync_word_len++] = 0xAA;
            
            buffer[sync_word_len++] = 0x2a;
            buffer[sync_word_len++] = 0xbc;

            return sync_word_len;
            
            total_bits = WMBUS_T_PREAMBLE_SYNC_WORD_MTR_FORMAT_A_LEN;
            sync_word = WMBUS_T_SYNC_WORD_MTR_FORMAT_A;
            sync_word_len = WMBUS_T_SYNC_WORD_MTR_FORMAT_A_LEN_BIT;
            break;
		case WMBUS_MODE_C1:
        case WMBUS_MODE_C2:
            total_bits = WMBUS_C_PREAMBLE_LEN_MIN + WMBUS_C_SYNC_MIN;
            sync_word = WMBUS_C_SYNC_WORD_FORMAT_B;
            sync_word_len = WMBUS_C_SYNC_WORD_LEN_BIT;
            break;
        case WMBUS_MODE_R2:
            total_bits = WMBUS_R_PREAMBLE_SYNC_WORD_FORMAT_A_LEN;
            sync_word = WMBUS_R_SYNC_WORD_FORMAT_A;
            sync_word_len = WMBUS_R_SYNC_WORD_FORMAT_A_LEN_BIT;
	        break;
        case WMBUS_MODE_N:
            total_bits = WMBUS_N_PREAMBLE_LEN_MIN + WMBUS_N_SYNC_MIN;
            sync_word = WMBUS_N_SYNC_WORD_FORMAT_B;
            sync_word_len = WMBUS_N_SYNC_WORD_LEN_BIT;
	        break;
        case WMBUS_MODE_F2:
            total_bits = WMBUS_F_PREAMBLE_SYNC_WORD_LEN;
            sync_word = WMBUS_F_SYNC_WORD_FORMAT_B;
            sync_word_len = WMBUS_F_SYNC_WORD_LEN_BIT;
	        break;

        default:
            return 0;
            break;
	} 

    uint16_t preamble_len = total_bits - sync_word_len;
    uint8_t temp[72] = {0};

    for (uint16_t i = 0; i < preamble_len; ++i) {
        uint16_t bit_pos = i;
        uint16_t byte_index = bit_pos / 8;
        uint16_t bit_index = 7 - (bit_pos % 8);
        uint8_t bit = (i % 2); // alternating 0,1 = "01"
        temp[byte_index] |= (bit << bit_index);
    }

    for (uint8_t i = 0; i < sync_word_len; ++i) {
        uint16_t bit_pos = preamble_len + i;
        uint16_t byte_index = bit_pos / 8;
        uint16_t bit_index = 7 - (bit_pos % 8);
        uint8_t bit = (sync_word >> (sync_word_len - 1 - i)) & 1;
        if (bit)
            temp[byte_index] |= (1 << bit_index);
        else
            temp[byte_index] &= ~(1 << bit_index);
    }

    uint16_t total_bytes = (total_bits + 7) / 8;
    memcpy(buffer, temp, total_bytes);
    return total_bytes;
}

static uint16_t _wmbus_crc(const uint8_t *data, uint32_t len)
{
    return (~(util_crc16_calc(WMBUS_CRC_TYPE, (uint16_t*)wmbusCrcTable, (uint8_t*)data, len, WMBUS_CRC_SEED)) & 0xffff);
}

static void _wmbus_fill_rf_config(const wmbus_rf_param_t* rfParam, 
                                    WISE_RADIO_CFG_T* m2oCfg, 
                                    WISE_RADIO_PKT_FMT_T* m2oFmt,
                                    WISE_RADIO_CFG_T* o2mCfg,
                                    WISE_RADIO_PKT_FMT_T* o2mFmt)
{
    if(rfParam->gfsk_bt == WMBUS_PARAM_NA)
    {
        m2oCfg->modulation = E_MOD_TYPE_FSK;
    }
    else
    {
        m2oCfg->modulation = E_MOD_TYPE_GFSK;
    }

    m2oCfg->ch_freq_max = rfParam->m2o.freq_typ_hz;
    m2oCfg->ch_freq_min = rfParam->m2o.freq_typ_hz;
    m2oCfg->ch_spacing = 0;
    m2oCfg->deviation = rfParam->m2o.fsk_deviation_typ_hz;
    //m2oCfg->phy_mode = E_PHY_MBUS;

#ifdef REDUCE_WMBUS_PARAMS
    m2oCfg->data_rate = rfParam->m2o.data_rate;
#else
    m2oCfg->data_rate = _wmbus_get_data_rate(rfParam->m2o.chip_rate_typ_cps); 
#endif
    
    //m2oCfg->frame_codec = rfParam->m2o.codec;
    
    //will be set latter
    m2oCfg->syncword = 0;
    m2oCfg->sync_word_len = 0;
    m2oCfg->preamble = 0;
    m2oCfg->preamble_len = 0;

    memset(m2oFmt, 0, sizeof(WISE_RADIO_PKT_FMT_T));
    m2oFmt->pkt_type = PKT_FIXED_LENGTH;
    m2oFmt->frame_format = (FRAME_FMT_MSB_FIRST | FRAME_FMT_PREAMBLE_EN | FRAME_FMT_SYNCWORD_EN);
    m2oFmt->max_pkt_length = WMBUS_MAX_PKT_LEN;
    m2oFmt->frame_codec = rfParam->m2o.codec;

    if(o2mCfg)
    {
        o2mCfg->modulation = m2oCfg->modulation;

        o2mCfg->ch_freq_max = rfParam->o2m.freq_typ_hz;
        o2mCfg->ch_freq_min = rfParam->o2m.freq_typ_hz;
        o2mCfg->ch_spacing = 0;
        o2mCfg->deviation = rfParam->o2m.fsk_deviation_typ_hz;
        //o2mCfg->phy_mode = E_PHY_MBUS;

#ifdef REDUCE_WMBUS_PARAMS
        o2mCfg->data_rate = rfParam->o2m.data_rate;
        //o2mCfg->data_rate = E_DATA_RATE_100K; //for test
#else
        o2mCfg->data_rate = _wmbus_get_data_rate(rfParam->o2m.chip_rate_typ_cps); 
#endif

        //o2mCfg->frame_codec = rfParam->o2m.codec;
        
        //will be set latter
        o2mCfg->syncword = 0;
        o2mCfg->sync_word_len = 0;
        o2mCfg->preamble = 0;
        o2mCfg->preamble_len = 0;

        memset(o2mFmt, 0, sizeof(WISE_RADIO_PKT_FMT_T));
        o2mFmt->pkt_type = PKT_FIXED_LENGTH;
        o2mFmt->frame_format = (FRAME_FMT_MSB_FIRST | FRAME_FMT_PREAMBLE_EN | FRAME_FMT_SYNCWORD_EN);
        o2mFmt->max_pkt_length = WMBUS_MAX_PKT_LEN;
        o2mFmt->frame_codec = rfParam->o2m.codec;
    }
}

int8_t _wmbus_validate_frame_A(uint8_t* frame, uint16_t inFrameLen, uint16_t* outDataLen)
{
    uint8_t dataBlocks = 0, lastBlockSize = 0;
    uint16_t crcCalc = 0, crcCheck = 0;
    uint32_t readOffset = 0, writeOffset = 0;
    uint16_t frameLen = 0;
    int i;
    
    crcCalc = _wmbus_crc(&frame[0], WMBUS_FIRST_BLOCK_LEN);    
    crcCheck = LOAD_BE_16(&frame[WMBUS_FIRST_BLOCK_LEN]);
    if(crcCalc != crcCheck)
    {
        debug_print("first block crc error\n");
        goto error_return;
    }

    frameLen = frame[0] + 1;
    dataBlocks = (frameLen - WMBUS_FIRST_BLOCK_LEN) / 16;
    lastBlockSize = (frameLen - WMBUS_FIRST_BLOCK_LEN) % 16;

    readOffset = WMBUS_FIRST_BLOCK_LEN + 2;    
    writeOffset = WMBUS_FIRST_BLOCK_LEN;
    for(i = 0; i < dataBlocks; i++)
    {
        crcCalc = _wmbus_crc(&frame[readOffset], WMBUS_DATA_BLOCK_LEN);
        crcCheck = LOAD_BE_16(&frame[readOffset + WMBUS_DATA_BLOCK_LEN]);
        if(crcCalc != crcCheck)
        {
            debug_print("data block %d crc error\n", i);
            goto error_return;
        }
        
        //if(i < (dataBlocks - 1))
        {
            memcpy(&frame[writeOffset], &frame[readOffset], WMBUS_DATA_BLOCK_LEN);
            writeOffset += WMBUS_DATA_BLOCK_LEN;
        }

        readOffset += (WMBUS_DATA_BLOCK_LEN + 2);
    }

    if(lastBlockSize)
    {
        crcCalc = _wmbus_crc(&frame[readOffset], lastBlockSize);
        crcCheck = LOAD_BE_16(&frame[readOffset + lastBlockSize]);
        if(crcCalc != crcCheck)
        {
            debug_print("last block crc error\n");
            goto error_return;
        }

        memcpy(&frame[writeOffset], &frame[readOffset], lastBlockSize);
    }
    
    //debug_print("rx frame %d\n", frameLen);
    //dump_buffer(frame, frameLen);

    *outDataLen = frameLen;
    
    return 1;
    
error_return:
    return 0;
}

uint16_t _wmbus_create_frame_A(uint8_t* frame, uint16_t dataLen, uint8_t* outBuffer)
{
    uint16_t readOffset = 0, writeOffset = 0;
    uint16_t crcCalc = 0;
    uint8_t dataBlocks = 0, lastBlockSize = 0;
    int i;

    dataBlocks = (dataLen - WMBUS_FIRST_BLOCK_LEN) / 16;
    lastBlockSize = (dataLen - WMBUS_FIRST_BLOCK_LEN) % 16;

    crcCalc = _wmbus_crc(&frame[readOffset], WMBUS_FIRST_BLOCK_LEN);
    memcpy(&outBuffer[writeOffset], &frame[readOffset], WMBUS_FIRST_BLOCK_LEN);
    PUT_BE_16(&outBuffer[writeOffset+WMBUS_FIRST_BLOCK_LEN], crcCalc);

    readOffset += WMBUS_FIRST_BLOCK_LEN;
    writeOffset += (WMBUS_FIRST_BLOCK_LEN + 2);

    for(i = 0; i < dataBlocks; i++)
    {
        crcCalc = _wmbus_crc(&frame[readOffset], WMBUS_DATA_BLOCK_LEN);
        memcpy(&outBuffer[writeOffset], &frame[readOffset], WMBUS_DATA_BLOCK_LEN);
        PUT_BE_16(&outBuffer[writeOffset+WMBUS_DATA_BLOCK_LEN], crcCalc);

        readOffset += WMBUS_DATA_BLOCK_LEN;
        writeOffset += (WMBUS_DATA_BLOCK_LEN + 2);
    }

    if(lastBlockSize)
    {
        crcCalc = _wmbus_crc(&frame[readOffset], lastBlockSize);
        memcpy(&outBuffer[writeOffset], &frame[readOffset], lastBlockSize);
        PUT_BE_16(&outBuffer[writeOffset+lastBlockSize], crcCalc);

        readOffset += lastBlockSize;
        writeOffset += (lastBlockSize + 2);
    }

    return writeOffset;
}

uint16_t _wmbus_3of6_encode_frame(uint8_t* frame, uint16_t frameLen, uint8_t* outBuffer)
{
    uint32_t encLen = 0;
    
    encLen = util_bitstream_encode(BS_TYPE_3_OF_6, frame, frameLen, outBuffer, &encLen);

    return (uint16_t)encLen;
}

uint16_t _wmbus_estimate_frame_A_length(uint16_t frameLen)
{
    uint8_t dataBlocks = 0, lastBlockSize = 0;
    uint16_t lengthA = 0;
    
    dataBlocks = (frameLen - WMBUS_FIRST_BLOCK_LEN) / 16;
    lastBlockSize = (frameLen - WMBUS_FIRST_BLOCK_LEN) % 16;

    lengthA = (WMBUS_FIRST_BLOCK_LEN + 2) + dataBlocks * (WMBUS_DATA_BLOCK_LEN + 2);
    if(lastBlockSize)
        lengthA += (lastBlockSize + 2);

    return lengthA;
}

int8_t _wmbus_3of6_decode_frame_A(uint8_t* pframe, uint8_t* outBuffer, uint16_t* outDataLen)
{
    int32_t decOutputLen = 0;
    uint16_t frameLen = 0;
    uint16_t encDataLen = 0;

    //debug_print("3to6 dec\n");
    
    decOutputLen = util_bitstream_decode(BS_TYPE_3_OF_6, pframe, WMBUS_3OF6_ENC_LEN(1), outBuffer);
    if(decOutputLen != 1)
    {
        debug_print("3of6 decode PHR failed\n");
        goto error_return;
    }

    frameLen = outBuffer[0] + 1;
    encDataLen = _wmbus_estimate_frame_A_length(frameLen);
    
    decOutputLen = util_bitstream_decode(BS_TYPE_3_OF_6, pframe, WMBUS_3OF6_ENC_LEN(encDataLen), outBuffer);
    if(decOutputLen != encDataLen)
    {
        debug_print("3of6 decode frame failed\n");
        goto error_return;
    }
    
    *outDataLen = decOutputLen;
    return 1;

error_return:
    return 0;
}

int8_t _wmbus_manchester_decode_frame_A(uint8_t* pframe, uint8_t* outBuffer, uint16_t* outDataLen)
{
    int32_t decOutputLen = 0;
    uint16_t frameLen = 0;
    uint16_t encDataLen = 0;
    
    decOutputLen = util_bitstream_decode(BS_TYPE_MANCHESTER, pframe, WMBUS_MANCHESTER_ENC_LEN(1), outBuffer);
    if(decOutputLen != 1)
    {
        debug_print("manchester decode PHR failed\n");
        goto error_return;
    }

    frameLen = outBuffer[0] + 1;
    encDataLen = _wmbus_estimate_frame_A_length(frameLen);
    
    decOutputLen = util_bitstream_decode(BS_TYPE_MANCHESTER, pframe, WMBUS_MANCHESTER_ENC_LEN(encDataLen), outBuffer);
    if(decOutputLen != encDataLen)
    {
        debug_print("manchester decode frame failed\n");
        goto error_return;
    }

    *outDataLen = decOutputLen;

    //debug_print("Manchester dec %d\n", decOutputLen);
    //dump_buffer(outBuffer, decOutputLen);
    
    return 1;
    
error_return:
    return 0;
}

static void _wmbus_release_buffers()
{
    SAFE_RELEASE(m2oRadioCfg);
    SAFE_RELEASE(o2mRadioCfg);
    SAFE_RELEASE(m2oPktFmt);
    SAFE_RELEASE(o2mPktFmt);
    SAFE_RELEASE(wmbusTmpBuffer);
    SAFE_RELEASE(wmbusCrcTable);
}

// frame format A
// |---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|
// | L-field | C-field | M-field | A-field | DLL CRC | blocks  |  CRC    |  ...    | block N |  CRC    |
// |  1 byte |  1 byte | 2 bytes | 6 bytes | 2 bytes |16 bytes | 2 bytes |         | n bytes | 2 bytes |
// |<---------  DLL header --------------->|         |<------- N-1 blocks -------->|<-- Last block --->|  
//
//
// frame format B
// |---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|
// | L-field | C-field | M-field | A-field |CI-field |ACC-field|STS-field| Conf    |Dec veri.|Payload  |  CRC    |
// |  1 byte |  1 byte | 2 bytes | 6 bytes | 1 byte  | 1 byte  | 1 byte  | 2 bytes | 2 bytes | 16*N-2  | 2 bytes |
// |<----------------------------------------------   bitstream codec   ---------------------------------------->|
//           |<------------------------------------   L-field  ------------------------------------------------->|
// |<----------------------------------------------   CRC   ------------------------------------------>|
//
// CRC polynomial: x^16 + x^13 + x^12 + x^11 + x^10 + x^8 + x^6 + x^5 + x^2 + 1
// CRC type: CRC_TYPE_16_EN_13757 0x3D65
// CRC init value: 0x0000
int8_t _wmbus_pack_tx_data(WISE_FRAME_CODEC_T codec, uint8_t *txData, uint16_t dataLen, uint8_t *outBuffer, uint16_t* outDataLen)
{
#define GUARD_LEN           8
#define PADDING_LEN         0
    uint16_t lengthA = 0;
    uint8_t* frameA = NULL;
    uint16_t encDataLen = 0;
    uint8_t postamble = 0;
    int i;
    
    lengthA = _wmbus_estimate_frame_A_length(dataLen);
    
    //debug_print("wmbus pack tx input=%d lengthA=%d\n", dataLen, lengthA);
    //dump_buffer(txData, dataLen);

    frameA = malloc(lengthA + GUARD_LEN);
    memset(frameA, 0, lengthA + GUARD_LEN);

    encDataLen = _wmbus_create_frame_A(txData, dataLen, frameA);
    if(encDataLen != lengthA)
    {
        debug_print("bug? encDataLen=%d lengthA=%d\n", encDataLen, lengthA);
    }

    switch(codec)
    {
        case E_FRAME_CODEC_NONE:
        break;
        case E_FRAME_CODEC_NRZ:
        break;
        
        case E_FRAME_CODEC_MANCHESTER:
            encDataLen = util_bitstream_encode(BS_TYPE_MANCHESTER, frameA, encDataLen, outBuffer, NULL);
        break;
        
        case E_FRAME_CODEC_3OUTOF6:
            encDataLen = _wmbus_3of6_encode_frame(frameA, encDataLen, outBuffer);
        break;    
    }
    
    if(frameA[encDataLen] & 0x80)
        postamble = 0x55;
    else
        postamble = 0xaa;
    
    for(i = 0; i < PADDING_LEN; i++)
        outBuffer[encDataLen + i] = postamble;
    *outDataLen = encDataLen + PADDING_LEN;
    
    for(i = 0; i < encDataLen; i++)
    {
        outBuffer[i] = bit_reverse_8(outBuffer[i]);
    }

    if(frameA)
    {
        free(frameA);
    }
    
    return WISE_SUCCESS;
}

void dump_buffer_array_type(uint8_t* buffer, uint32_t len)
{
    int i;
    
    debug_print("{\n");
    for(i = 0; i < len; i++)
    {
        if((i % 16) == 0)
            debug_print("    ");
        debug_print("0x%02x, ", buffer[i]);
        if((i % 16) == 15)
            debug_print("\n");
    }
    debug_print("}\n");
}

RAM_TEXT uint16_t _wmbus_rx_syncword_handler(RADIO_INTF_CFG_T *intf_cfg, uint8_t *pframe)
{
    volatile uint8_t* pEncFrame = pframe;
    uint16_t phrEncLen = 0;
    uint8_t frameLen = 0;
    int32_t decResult = -1;
    int i;
    uint8_t phrCheckExtra = 2;
    uint8_t phrDecBuffer[4] = {0};
    uint8_t tempBuffer[4];
    
    if(intf_cfg->pkt_fmt.frame_codec == E_FRAME_CODEC_MANCHESTER)
        phrEncLen = 2; //WMBUS_MANCHESTER_ENC_LEN(1);
    else if(intf_cfg->pkt_fmt.frame_codec == E_FRAME_CODEC_3OUTOF6)
        phrEncLen = 2;
    else
        phrEncLen = 1;

    if(rxByteTime != 0)
    {
        hal_intf_sys_tick_delay_us(rxByteTime * (phrEncLen+phrCheckExtra) * 2);
    }
    else
    {
        while(pEncFrame[phrEncLen+phrCheckExtra] == 0)
        {
        }
    }

    for(i = 0; i < phrEncLen; i++)
        tempBuffer[i] = bit_reverse_8(pEncFrame[i]);
    
    if(intf_cfg->pkt_fmt.frame_codec == E_FRAME_CODEC_MANCHESTER)
    {
        decResult = util_bitstream_decode(BS_TYPE_MANCHESTER, tempBuffer, phrEncLen, phrDecBuffer);

        if(decResult <= 0)
        {
            debug_print("manchester dec frame len failed\n");

            frameLen = 0;
            goto finish;
        }
        
        frameLen = WMBUS_MANCHESTER_ENC_LEN(_wmbus_estimate_frame_A_length(phrDecBuffer[0]+1));
    }
    else if(intf_cfg->pkt_fmt.frame_codec == E_FRAME_CODEC_3OUTOF6)
    {
        decResult = util_bitstream_decode(BS_TYPE_3_OF_6, tempBuffer, phrEncLen, phrDecBuffer);
        if(decResult <= 0)
        {
            debug_print("3of6 dec frame len failed\n");
            frameLen = 0;
            goto finish;
        }

        frameLen = WMBUS_3OF6_ENC_LEN(_wmbus_estimate_frame_A_length(phrDecBuffer[0]+1));
    }
    else
        frameLen = pEncFrame[0];

    if(frameLen >= maxRxFrameLen)
    {
        frameLen = 0;
        goto finish;
    }
    
    if(rxByteTime != 0)
    {
        uint32_t waitTime = rxByteTime * (frameLen + phrCheckExtra);

        hal_intf_sys_tick_delay_us(waitTime);
    }
    else
    {
        while(pEncFrame[frameLen+2] == 0)
        {
            if((pEncFrame[maxRxFrameLen-1] != 0) || (pEncFrame[maxRxFrameLen-2] != 0) || (pEncFrame[frameLen+3] != 0))
                break;
        };
    }
    
    frameLen += 2;
    
    //debug_print("sync frameLen=%02x\n", frameLen);
    //dump_buffer(pframe, frameLen);
finish:
    //debug_print("s-\n\n");
    return frameLen;
}

void _wmbus_validate_rx_data(RADIO_INTF_CFG_T *intf_cfg, uint8_t *pframe, WISE_RX_META_T *rx_meta, uint32_t status)
{
    uint16_t frameLen = 0;
    int i;
    int8_t result = 0;

    //debug_print("rx raw\n");
    //dump_buffer(pframe, 256);
    //dump_buffer_array_type(pframe, 256);
    
    memset(wmbusTmpBuffer, 0, WMBUS_MAX_PKT_LEN);

    if (rx_meta->data_len > maxRxFrameLen)
    {
        printf("rx len %d exceed max %d\n", rx_meta->data_len, maxRxFrameLen);
        rx_meta->valid = 0;
        return;
    }
    
    for(i = 0; i < rx_meta->data_len; i++)
    {
        pframe[i] = bit_reverse_8(pframe[i]);
    }

    //debug_print("_wmbus_validate_rx_data %d\n", rx_meta->data_len);
    //dump_buffer(pframe, WMBUS_MAX_PKT_LEN);

    switch(intf_cfg->pkt_fmt.frame_codec)
    {
        case E_FRAME_CODEC_NONE:
        break;
        
        case E_FRAME_CODEC_NRZ:
        break;
        
        case E_FRAME_CODEC_MANCHESTER:
            result = _wmbus_manchester_decode_frame_A(pframe, wmbusTmpBuffer, &frameLen);
        break;
        
        case E_FRAME_CODEC_3OUTOF6:
            if(workingMode.frameType == WMBUS_FRAME_TYPE_A)
                result = _wmbus_3of6_decode_frame_A(pframe, wmbusTmpBuffer, &frameLen);
            else
            {
                debug_print("frame format B not supported yet.\n");
            }
        break;
    }

    if(result == 1)
    {
        if(workingMode.frameType == WMBUS_FRAME_TYPE_A)
            result = _wmbus_validate_frame_A(wmbusTmpBuffer, frameLen, &frameLen);
        else
        {
            
        }
        
        if(result == 1)
        {
            memcpy(pframe, wmbusTmpBuffer, frameLen);
            rx_meta->data_len = frameLen;
            rx_meta->valid = 1;
        }
        else
            rx_meta->valid = 0;
        //debug_print("output frame len=%d\n", frameLen);
        //dump_buffer(wmbusTmpBuffer, frameLen);
    }   
}

#endif



