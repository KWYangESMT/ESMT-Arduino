#include <stdio.h>
#include "util_crc.h"
#include "util.h"

typedef struct
{
    uint32_t poly: 16;
    uint32_t inReflect:1;
    uint32_t outReflect:1;
    uint32_t reserved:14;
} UTIL_CRC_CONF_T;

const UTIL_CRC_CONF_T CRC8_POLY[] =
{
    {0x0007, 0, 0, 0},
    {0x0007, 1, 1, 0},
    {0x009B, 0, 0, 0},
    {0x001D, 1, 1, 0},
    {0x001D, 0, 0, 0},
    {0x0039, 1, 1, 0},
    {0x00D5, 0, 0, 0},
    {0x0031, 1, 1, 0},
    {0x0031, 0, 0, 0},
};

const UTIL_CRC_CONF_T CRC16_POLY[] =
{
    {0x1021, 0, 0, 0},
    {0x1021, 1, 1, 0},
    {0x8005, 0, 0, 0},
    {0x8005, 1, 1, 0},
    {0x0589, 0, 0, 0},
    {0x3D65, 0, 0, 0},
    {0x3D65, 1, 1, 0},
    {0xC867, 0, 0, 0},
    {0xA097, 0, 0, 0},
};

void _crc_8_gen_table(uint8_t polynomial, uint8_t inReflect, uint8_t outReflect, uint8_t* crcTable);
void _crc_16_gen_table(uint16_t polynomial, uint8_t inReflect, uint8_t outReflect, uint16_t* crcTable);



void util_crc_list()
{
    uint32_t entryNum = 0;
    int i;
    
    entryNum = sizeof(CRC8_POLY) / sizeof(UTIL_CRC_CONF_T);
    debug_print("CRC 8: \n");
    for(i = 0; i < entryNum; i++)
    {
        debug_print("   0x%02x in=%d out=%d\n", CRC8_POLY[i].poly, CRC8_POLY[i].inReflect, CRC8_POLY[i].outReflect);
    }

    entryNum = sizeof(CRC16_POLY) / sizeof(UTIL_CRC_CONF_T);
    debug_print("CRC 16: \n");
    for(i = 0; i < entryNum; i++)
    {
        debug_print("   0x%04x in=%d out=%d\n", CRC16_POLY[i].poly, CRC16_POLY[i].inReflect, CRC16_POLY[i].outReflect);
    }
}

uint8_t bit_reverse_8(uint8_t value)
{
    value = ((value & 0xAA) >> 1) | ((value & 0x55) << 1);
    value = ((value & 0xCC) >> 2) | ((value & 0x33) << 2);
    value = (value >> 4) | (value << 4);

    return value;
}

void _crc_8_gen_table(uint8_t polynomial, uint8_t inReflect, uint8_t outReflect, uint8_t* crcTable)
{
    for (int byte = 0; byte < 256; ++byte)
    {
        uint8_t crc = (inReflect ? bit_reverse_8((uint8_t)byte) : byte);

        for (int bit = 8; bit > 0; --bit)
        {
            if (crc & 0x80)
            {
                crc = (crc << 1) ^ polynomial;
            }
            else
            {
                crc <<= 1;
            }
        }

        crcTable[byte] = (outReflect ? bit_reverse_8(crc) : crc);
    }
}

int8_t util_crc8_gen_table(uint8_t crcType, uint8_t *table)
{
    if((crcType >= CRC_TYPE_8_NUM) || (!table))
        return UTIL_CRC_FAIL;

    _crc_8_gen_table(CRC8_POLY[crcType].poly, CRC8_POLY[crcType].inReflect, CRC8_POLY[crcType].outReflect, table);
    
    return UTIL_CRC_OK;
}

uint8_t util_crc8_calc(uint8_t crcType, uint8_t *crcTable, uint8_t *data, uint32_t length, uint8_t startVal)
{
    uint8_t val = startVal;
    uint8_t *pos = (uint8_t *)data;
    uint8_t *end = pos + length;

    while (pos < end) 
    {
        val = crcTable[val ^ *pos];
        pos++;
    }

    return val;
}

void _crc_16_gen_table(uint16_t polynomial, uint8_t inReflect, uint8_t outReflect, uint16_t* crcTable)
{
    //debug_print("CRC gen: %04x %d %d %p\n", polynomial, inReflect, outReflect, crcTable);
    
    for (int byte = 0; byte < 256; ++byte)
    {
        uint16_t crc = (inReflect ? (bit_reverse_16((uint16_t)byte) >> 8) : byte);

        for (int bit = 16; bit > 0; --bit)
        {
            if (crc & 0x8000)
            {
                crc = (crc << 1) ^ polynomial;
            }
            else
            {
                crc <<= 1;
            }
        }

        crcTable[byte] = (outReflect ? bit_reverse_16(crc) : crc);
    }
}

uint16_t bit_reverse_16(uint16_t value)
{
    value = ((value & 0xAAAA) >> 1) | ((value & 0x5555) << 1);
    value = ((value & 0xCCCC) >> 2) | ((value & 0x3333) << 2);
    value = ((value & 0xF0F0) >> 4) | ((value & 0x0F0F) << 4);
    value = (value >> 8) | (value << 8);
    
    return value;
}

int8_t util_crc16_gen_table(uint8_t crcType, uint16_t *table)
{
    if((crcType >= CRC_TYPE_16_NUM) || (!table))
        return UTIL_CRC_FAIL;

    _crc_16_gen_table(CRC16_POLY[crcType].poly, CRC16_POLY[crcType].inReflect, CRC16_POLY[crcType].outReflect, table);
    
    return UTIL_CRC_OK;
}

uint16_t util_crc16_calc(uint8_t crcType, uint16_t *crcTable, uint8_t *data, uint32_t length, uint16_t startVal)
{
    uint16_t crc  = startVal;
    uint8_t *pBuf = data;

    if((crcType >= CRC_TYPE_16_NUM) || (!crcTable))
        return 0;
    
    if(CRC16_POLY[crcType].inReflect == 0)
    {
        while (length > 0) 
        {
            crc = crcTable[(crc >> 8 ^ *pBuf++) & 0xff] ^ (crc << 8);
            length--;
        }
    }
    else
    {
        while(length > 0)
        {
            crc = (uint16_t)((crc >> 8) ^ crcTable[((crc ^ *pBuf++) & 0xff)]);
            length--;
        }
    }
    
    return crc;
}

/*
uint16_t util_crc16_kermit(uint8_t crcType, uint16_t *crcTable, uint8_t *buf, int length, uint16_t startVal)
{
    uint16_t crc = startVal;

    for (int i = 0; i < length; ++i) {
        //uint8_t index = (uint8_t)(crc ^ buf[i]);
        crc = (uint16_t)((crc >> 8) ^ crcTable[(uint8_t)(crc ^ buf[i])]);
    }
    
    return crc;
}
*/

uint16_t util_crc16_get_poly(uint8_t crcType)
{
    return (uint16_t)CRC16_POLY[crcType].poly;
}

