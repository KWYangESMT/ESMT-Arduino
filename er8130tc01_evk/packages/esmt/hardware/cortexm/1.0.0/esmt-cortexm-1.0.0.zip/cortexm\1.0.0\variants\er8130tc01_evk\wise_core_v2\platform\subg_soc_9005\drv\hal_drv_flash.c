/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#include "drv/hal_drv_flash.h"
#include "hdl/flctl_er8130.h"
#include "hal_intf_flash.h"


