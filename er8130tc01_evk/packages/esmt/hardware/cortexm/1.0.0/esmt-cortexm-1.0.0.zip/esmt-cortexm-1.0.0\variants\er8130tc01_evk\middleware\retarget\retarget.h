/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef __RETARGET_H
#define __RETARGET_H

void retarget_init(void);

#endif
