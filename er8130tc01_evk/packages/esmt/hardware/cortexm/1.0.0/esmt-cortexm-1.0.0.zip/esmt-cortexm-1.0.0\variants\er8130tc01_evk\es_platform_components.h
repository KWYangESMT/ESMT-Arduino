/*
 * Copyright (C) 2025 Elite Semiconductor Microelectronics Technology Inc
 * All rights reserved.
 *
 */

#ifndef __ES_PLATFORM_COMPONENTS_H
#define __ES_PLATFOMR_COMPONENTS_H

#define TARGET_APP
#define MIDDLEWARE_WISE_CTRL_CMD                    1
#define MIDDLEWARE_WISE_FLASH_FILESYSTEM            1
#define MIDDLEWARE_RETARGET_STDIO                   1
#define STDIO_UART_PORT                             0
#define CTRL_CMD_UART_PORT                          0

#endif /* __ES_PLATFORM_COMPONENTS_H */
